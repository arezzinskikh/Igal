
module.exports={
    "env": {
        "test": {
          "presets": [
            "@babel/preset-env",
            "@babel/preset-react"
          ],
          "plugins": [
            "transform-react-remove-prop-types",
            "@babel/plugin-transform-runtime",
            [
              "@babel/plugin-proposal-decorators",
              {
                "legacy": true
              }
            ],
            "@babel/plugin-proposal-class-properties"
          ]
        }
      }
}