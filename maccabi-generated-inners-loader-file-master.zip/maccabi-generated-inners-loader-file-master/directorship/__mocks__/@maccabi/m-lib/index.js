import mLib from '@maccabi/m-lib';

mLib.saveData.customerData.get = () => {
    return{
        family_data:{family_members:[]},
        logged_customer_info:{
            member_id_code:0,
            member_id:26,
            sex:'ז'
        },
        current_customer_info:{
            member_id_code:0,
            member_id:26,
            sex:'ז'
        }
    }
}

mLib.logs.insertCentralizedLog = () => {}

export default mLib;