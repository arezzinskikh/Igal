const plugins = require('./plugins');
const mLibWebpack = require('@maccabi/m-lib/src/utils/Webpack/webpack.base.prod.babel');
const path = require('path');

module.exports = mLibWebpack({
  plugins, 
  entry: () => {
      return { manifest: [
        path.join(process.cwd(), 'app/manifest.js')
      ],
      app: [
        'idempotent-babel-polyfill',
        path.join(process.cwd(), 'app/containers/App/App.js'),
      ],
      main: [
        path.join(process.cwd(), 'app/app.js'), // Start with js/app.js
      ]
    }
  },
  output: output => Object.assign({}, output, {
    jsonpFunction: 'directorshipJsonp'
  })
});
