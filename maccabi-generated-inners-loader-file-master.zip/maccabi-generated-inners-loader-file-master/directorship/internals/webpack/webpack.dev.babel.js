const plugins = require('./plugins');
const mLibWebpack = require('@maccabi/m-lib/src/utils/Webpack/webpack.base.dev.babel');

module.exports = mLibWebpack({
  plugins
});
