module.exports = require('@maccabi/m-lib/src/utils/Webpack/loader');
