import React, { Fragment } from 'react';
import style from './DebitBank.scss';


const DebitBank = (props) => {

       

        return (
            <Fragment>
                <div className={style.text}>
                התשלום באמצעות הוראת קבע יחול גם על בני המשפחה ו/או חברי מכבי עליהם אתה משלם
                </div>
           
            </Fragment>
        );
    }


export default DebitBank;
