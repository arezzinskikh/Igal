import mLib from '@maccabi/m-lib';


export const popUpShownLog = () => {
    logAction(4513,1347);
}
export const clickOnPrimaryBtnLog = () => {
    logAction(4514,1346);
}
const logAction = (elementId,actionId,url='directorship/CreditsAndDebits/ConfirmationDirectDebits/') => {
    mLib.logs.insertCentralizedLog(elementId, url, actionId);
}
