import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { Modal } from '@maccabi/m-ui';
import { CG_TIMER, BTN_TEXT, MODAL_BODY, MODAL_HEADER, MODAL_ICON } from './constants';
import { clickOnPrimaryBtnLog, popUpShownLog } from './logs';

const CgTransactionTimeout = ({ isCreditCardPage }) => {
    const [isOpen, setIsOpen] = useState(false);
    const history = useHistory();

    useEffect(() => {
        if (isCreditCardPage) {
            const timeInMilliseconds = parseInt(CG_TIMER) * 60000;
            const timer = setTimeout(() => {
                popUpShownLog();
                setIsOpen(true);
            }, timeInMilliseconds);

            return () => {
                clearTimeout(timer);
            };
        }
    }, []);

    const handleClose = (fromBtn = false) => {
        fromBtn && clickOnPrimaryBtnLog();
        setIsOpen(false);
        history.push('/directorship/CreditsAndDebits/DirectDebit/');
    };

    return (
        <Modal
            isOpen={isOpen}
            icon={MODAL_ICON}
            header={MODAL_HEADER}
            body={MODAL_BODY}
            primaryButton={BTN_TEXT}
            toggle={() => handleClose(false)}
            primaryButtonClick={() => handleClose(true)}
        />
    );
};

export default CgTransactionTimeout;
