import mLib from '@maccabi/m-lib';
import { ConfirmationDirectDebitsUrl } from '../../../containers/CreditsAndDebits/constants';
const URL = ConfirmationDirectDebitsUrl;

const CG_TIMER_KEY = 'CG_TIMER';
const CG_TIMER_VALUE = '10'; // time in minutes
export const CG_TIMER = mLib.resources.getResource(URL, CG_TIMER_KEY, CG_TIMER_VALUE);

const MODAL_ICON_KEY = 'MODAL_ICON';
const MODAL_ICON_VALUE = 'attention-big';
export const MODAL_ICON = mLib.resources.getResource(URL, MODAL_ICON_KEY, MODAL_ICON_VALUE);

const MODAL_HEADER_KEY = 'MODAL_HEADER';
const MODAL_HEADER_VALUE = 'למען שמירה על פרטיותך, פרטי האשראי לחיוב נמחקו לאחר מספר דקות ללא שמירה';
export const MODAL_HEADER = mLib.resources.getResource(URL, MODAL_HEADER_KEY, MODAL_HEADER_VALUE);

const MODAL_BODY_KEY = 'MODAL_BODY';
const MODAL_BODY_VALUE = 'אם ברצונך להסדיר את הוראת הקבע, ניתן להזין את הפרטים מחדש';
export const MODAL_BODY = mLib.resources.getResource(URL, MODAL_BODY_KEY, MODAL_BODY_VALUE);

const BTN_TEXT_KEY = 'BTN_TEXT';
const BTN_TEXT_VALUE = 'לבחירת הרשאה לחיוב';
export const BTN_TEXT = mLib.resources.getResource(URL, BTN_TEXT_KEY, BTN_TEXT_VALUE);
