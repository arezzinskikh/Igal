import React from 'react';
import style from './Dashes.scss';
import cx from 'classnames';


const Dashes = ({cls}) => {
        return (<div className={cx(style.SeparationLineBetweenSects, cls)}></div>);    
}

export default Dashes;

