import mLib from '@maccabi/m-lib';
import {ConfirmationDirectDebitsUrl} from '../../../containers/CreditsAndDebits/constants'

export const DATE = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'DATE', 'תאריך');
export const SIGNATURE_AND_CONSET = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'SIGNATURE_AND_CONSET', 'סימון יחשב כחתימה והסכמה.');
export const FULL_NAME = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'FULL_NAME', 'שם מלא');
export const JOINING_CONFIRMED = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'JOINING_CONFIRMED', 'יש לאשר את הצטרפותך');