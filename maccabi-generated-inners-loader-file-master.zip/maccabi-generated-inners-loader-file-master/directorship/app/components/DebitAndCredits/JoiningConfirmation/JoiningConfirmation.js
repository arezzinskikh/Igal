import style from './JoiningConfirmation.scss';
import cx from 'classnames';
import {
    SIGNATURE_AND_CONSET,
    FULL_NAME,
    DATE, 
    JOINING_CONFIRMED
} from './constants';
import Dashes from '../Dashes/Dashes'
import {
    H6,
    Checkbox
} from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';



const JoiningConfirmation =(props) => {

    const errorMessage= () => {
        return showErrorMessage ? JOINING_CONFIRMED : '';
    }


    const { logged_customer_info } = mLib.saveData.customerData.get();
    const { showErrorMessage, changeErrorMessage} = props;
 
    const validCls = cx({
        [style.valid]: showErrorMessage === false,
        [style.notValid]: showErrorMessage === true
    });

        return (
            <div> 
                <Dashes cls={"mb-7 mt-7"} />
                <H6 className={cx(style.titleJoiningConfirmation, "mb-2")}>{props.title}</H6>
                <div className={style.text}>{SIGNATURE_AND_CONSET}</div>
                <div className={style.itemFirstName}>
                    <div className={style.cls}>
                        <Checkbox onChange={changeErrorMessage} invalid={showErrorMessage ? 'invalid' : ''} className={style.checkbox}/>
                        <div className={style.borderLeft}>    
                            <div className={style.fName}>{FULL_NAME}</div>
                            <div className={style.name}>
                                {logged_customer_info.f_name_hebrew} {logged_customer_info.pays_l_name}
                            </div>
                        </div>
                        <div className={style.dateWarp}>
                            <div className={style.dateTitle}>{DATE}</div>
                                <div className={style.date}>
                                        {mLib.date.formatDate()}
                                </div>
                            </div>    
                    </div>
                    <div className={validCls} data-hook="validation">
                                {showErrorMessage && errorMessage()}
                    </div>
                </div>
            </div>
        );
}


export default JoiningConfirmation;
