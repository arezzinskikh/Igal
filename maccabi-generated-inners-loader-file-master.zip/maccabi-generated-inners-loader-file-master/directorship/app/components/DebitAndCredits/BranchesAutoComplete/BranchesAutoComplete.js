import React, { Fragment,useState,useEffect } from 'react';
import style from '../../../containers/CreditsAndDebits/BankAcountPermission/BankAcountPermission.scss';
import { InputAutoComplete,Button } from '@maccabi/m-ui';
import { FORM_BRANCH_LABEL } from '../../../containers/CreditsAndDebits/BankAcountPermission/constatns';
import { insertLog, FORM_FIELDS_TO_LOG } from '../../../containers/CreditsAndDebits/BankAcountPermission/logFile';


const BranchesAutoComplete = ({branches,selectedBranchCode,onBranchSelect,selectedBankCode,branchError}) => {
    const [isFocus,setIsFocus] = useState(false);
    const [filteredList,setFilteredList] = useState([]);
    const [branchValue,setBranchValue] = useState('');

    useEffect(() => {
        setFilteredList(branches);
    },[branches]);

    
    const getBranchByCode = (branchCode) => {
        return branches.find(({branch_code}) => branch_code === branchCode);
    }

    useEffect(() => {
        if(selectedBranchCode !== -1){
            const {branch_name, branch_code} = getBranchByCode(selectedBranchCode);
            setBranchValue(`${branch_code} - ${branch_name}`);
        }else{
            setBranchValue('');
        }
            
    },[selectedBranchCode])

    


    const handleBranchSelect = (branchCode) => {
        const {branch_name, branch_code} = getBranchByCode(branchCode);
        setBranchValue(`${branch_code} - ${branch_name}`);
        onBranchSelect(branchCode);
        setIsFocus(false);
    }

    const rowRenderer = ({branch_code, branch_name}) => {
        return (
            <Button className={style.bankitem} onClick={() => handleBranchSelect(branch_code)} key={branch_code}>
                <div>{branch_code}</div>
                <span className="m-2">-</span>
                <div>{branch_name}</div>
            </Button>);
    };

    const searchBranch = (value) => {
        onBranchSelect(-1);
        setFilteredList(branches.filter(({branch_name, branch_code}) => {
            const fullItemString = `${branch_code} - ${branch_name}`;
            return fullItemString.indexOf(value) > -1
        }));
    }

    const setIsFocusBranchesInput = () =>{
        setIsFocus(true);
        insertLog(FORM_FIELDS_TO_LOG.dropDownSelectBranchOpen);
    }
    
    return (
        <Fragment>
            <InputAutoComplete
                errorMsg={branchError}
                disabled={selectedBankCode === -1}
                filteredItems={filteredList}
                fullList={branches}
                rowRenderer={rowRenderer}
                onSerchFilter={searchBranch}
                placeHolderText={FORM_BRANCH_LABEL}
                showFullListWhenNoInput={true}
                onFocus={setIsFocusBranchesInput}
                onBlur={() => setTimeout(() => {
                    setIsFocus(false)
                }, 100)}
                value={branchValue}
                isFocus={isFocus}
                onValueChange={setBranchValue}
                hook='branchesAutoComplete'
                maxHeightClassName={style.maxHeightClassNameBranch}
            />
        </Fragment>
    );
}

export default BranchesAutoComplete;