import React, { Fragment, useState, useEffect } from 'react';
import style from './DebtsDetails.scss';
import cx from 'classnames';
import { Modal, Checkbox } from '@maccabi/m-ui';
import {
    DEBTS_DETAILS_TITLE,
    DEBTS_DETAILS_PRIMARY_BUTTON_DETAILS_TEXT,
    DEBTS_DETAILS_PRIMARY_BUTTON_COLLECT_TEXT,
    DEBTS_DETAILS_TECHNICAL_ISSUE_TEXT,
    DEBTS_DETAILS_APPROVE_ONE_PAYMENT,
    DEBTS_DETAILS_PERIOD_TITLE,
    DEBTS_DETAILS_FOR_TITLE,
    DEBTS_DETAILS_AMOUNT_TITLE,
    DEBTS_CHECKBOX_ERR_MSG,
    KUPA_DEBT_FIRST_TEXT,
    KUPA_DEBT_SECOND_TEXT,
    CREDIT_CARD_HOK,
    BANK_HOK
} from './constants';
import PropTypes from 'prop-types';
import { insertLog, FORM_FIELDS_TO_LOG } from '../../../containers/CreditsAndDebits/DirectDebit/logFile';

const DebtsDetails = ({
    debtsDetails: { messages, payees, payer_debt },
    isOpen,
    onClose,
    isShowOnlyDetails,
    primaryButtonClick,
    toggleDebtsCheckBox,
    isShabanAuthOnly,
    paymentMethodsName = null,
    kupaDebt
}) => {
    const [isChecked, setIsChecked] = useState(false);
    const [notCheck, setNotCheck] = useState(false);
    const format = require('string-format');

    useEffect(() => {
        if (isOpen) {
            setIsChecked(false);
            isShowOnlyDetails ? insertLog(FORM_FIELDS_TO_LOG.openDebtModal) : insertLog(FORM_FIELDS_TO_LOG.openDebtCollectionApprovalModal);
        }
    }, [isOpen]);

    const isTechnicalIssueOccured = () => {
        const occured = messages && messages.type === 'W-warning' && messages.code === '704';

        return occured;
    };

    const amountWithoutDecimalPoint = amount => {
        return amount % 1 != 0 ? amount.toFixed(2) : amount.toFixed(0);
    };

    const payeeDebtForMonthFormat = payeeDebtForMonth => {
        const stringPayeeDebtForMonth = payeeDebtForMonth.toString();
        const formattedPayeeDebtForMonth = stringPayeeDebtForMonth.slice(4, 6) + '/' + stringPayeeDebtForMonth.slice(0, 4);

        return formattedPayeeDebtForMonth;
    };
    const handleCheckBox = e => {
        const { checked } = e.target;
        checked && setNotCheck(false);
        setIsChecked(checked);
        toggleDebtsCheckBox(checked);
        insertLog(FORM_FIELDS_TO_LOG.debtCollectionApprovalbtn);
    };

    const onCloseModal = () => {
        onClose();
        insertLog(FORM_FIELDS_TO_LOG.debtModalclickingOnClose);
    };

    const onContinueClick = () => {
        if (!isShowOnlyDetails) {
            setNotCheck(!isChecked);
            isChecked && primaryButtonClick();
        } else {
            onClose();
        }
        const variables = paymentMethodsName ? BANK_HOK : CREDIT_CARD_HOK;
        const log = FORM_FIELDS_TO_LOG.DebtCollectionApprovalModalClickContinueBtn;
        log.variables = [{ key: 'element_id', description: variables }];
        isShowOnlyDetails
            ? insertLog(FORM_FIELDS_TO_LOG.debtModalclickingOnIUnderstood)
            : insertLog(FORM_FIELDS_TO_LOG.DebtCollectionApprovalModalClickContinueBtn);
        !isShowOnlyDetails && !isChecked ? insertLog(FORM_FIELDS_TO_LOG.PleaseConfirmDebtCollectionApprovalModal) : '';
    };

    const renderBodyModal = () => {
        return (
            <Fragment>
                {isTechnicalIssueOccured() && <div className={'mt-2'}>{DEBTS_DETAILS_TECHNICAL_ISSUE_TEXT}</div>}
                <div className={style.scroll}>
                    <div className={style.flipScroll}>
                        {payees &&
                            payees.map((payee, index) => {
                                return (
                                    <div className={style.wrapSection}>
                                        <div className={style.title}>
                                            <div className={style.name}>{payee.payee_full_name}</div>
                                            <div className={style.id}>{payee.payee_id}</div>
                                        </div>
                                        <div className={style.table}>
                                            <div className={style.header}>
                                                <div className={style.mashlim}>{DEBTS_DETAILS_FOR_TITLE}</div>
                                                <div className={style.period}>{DEBTS_DETAILS_PERIOD_TITLE}</div>
                                                <div className={style.amount}>{DEBTS_DETAILS_AMOUNT_TITLE}</div>
                                            </div>
                                            {payee.payee_debts &&
                                                payee.payee_debts.map((payee_debt, index) => {
                                                    return (
                                                        <div className={style.content}>
                                                            <div className={style.mashlim}>{payee_debt.payee_debt_desc}</div>
                                                            <div className={style.period}>
                                                                {payeeDebtForMonthFormat(payee_debt.payee_debt_for_month)}
                                                            </div>
                                                            <div className={style.amount}>
                                                                <span className={style.amountLtr}>
                                                                    {amountWithoutDecimalPoint(payee_debt.payee_debt)}
                                                                </span>{' '}
                                                                ש״ח
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                        </div>
                                    </div>
                                );
                            })}
                    </div>
                </div>
                {!isShowOnlyDetails && (
                    <div className={style.checkboxContainer}>
                        <Checkbox
                            ischecked={isChecked}
                            onChange={handleCheckBox}
                            invalid={notCheck ? 'invalid' : ''}
                            invalidMessage={notCheck ? DEBTS_CHECKBOX_ERR_MSG : ''}
                            className={cx(style.checkbox, 'd-flex')}>
                            {DEBTS_DETAILS_APPROVE_ONE_PAYMENT}
                        </Checkbox>
                        {kupaDebt > 0 && isShabanAuthOnly && (
                            <div className={style.kupaDebt}>
                                {KUPA_DEBT_FIRST_TEXT} {amountWithoutDecimalPoint(kupaDebt)} {KUPA_DEBT_SECOND_TEXT}
                            </div>
                        )}
                    </div>
                )}
            </Fragment>
        );
    };

    return (
        <Modal
            isOpen={isOpen}
            icon={'attention-big'}
            toggle={onCloseModal}
            header={format(DEBTS_DETAILS_TITLE, amountWithoutDecimalPoint(payer_debt))}
            body={renderBodyModal()}
            primaryButton={isShowOnlyDetails ? DEBTS_DETAILS_PRIMARY_BUTTON_DETAILS_TEXT : DEBTS_DETAILS_PRIMARY_BUTTON_COLLECT_TEXT}
            primaryButtonClick={onContinueClick}
            bodyClassName={style.bodyClassName}
            headerClassName={style.headerModal}
            className={style.debtsModal}
        />
    );
};

DebtsDetails.propTypes = {
    debtsDetails: PropTypes.number.isRequired,
    onClose: PropTypes.func.isRequired,
    isOpen: PropTypes.bool.isRequired,
    isShowOnlyDetails: PropTypes.bool.isRequired
};

export default DebtsDetails;
