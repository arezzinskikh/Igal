import mLib from '@maccabi/m-lib';
import { URL_DIRECT_DEBIT } from '../../../containers/CreditsAndDebits/constants';

export const DEBTS_CHECKBOX_ERR_MSG = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DEBTS_CHECKBOX_ERR_MSG',
    'על מנת להמשיך בתהליך יש להסכים לגביית חוב בהוראת הקבע החדשה או להסדיר קודם את החוב במרכז הרפואי'
);
export const DEBTS_DETAILS_AMOUNT_TITLE = mLib.resources.getResource(URL_DIRECT_DEBIT, ' DEBTS_DETAILS_AMOUNT_TITLE', 'סכום החוב');
export const DEBTS_DETAILS_FOR_TITLE = mLib.resources.getResource(URL_DIRECT_DEBIT, ' DEBTS_DETAILS_FOR_TITLE', 'חוב עבור');
export const DEBTS_DETAILS_PERIOD_TITLE = mLib.resources.getResource(URL_DIRECT_DEBIT, ' DEBTS_DETAILS_PERIOD_TITLE', 'תקופת החוב');
export const DEBTS_DETAILS_TECHNICAL_ISSUE_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DEBTS_DETAILS_TECHNICAL_ISSUE_TEXT',
    'הפירוט המוצג הינו חלקי עקב מגבלה טכנית. לקבלת הפירוט המלא, יש לפנות למוקד מכבי ללא הפסקה ב 3555*'
);
export const DEBTS_DETAILS_TITLE = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DEBTS_DETAILS_TITLE',
    'בחשבונך במכבי קיים חוב בסה"כ {0} ש"ח בגין אי תשלום:'
);
export const DEBTS_DETAILS_PRIMARY_BUTTON_DETAILS_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DEBTS_DETAILS_PRIMARY_BUTTON_DETAILS_TEXT',
    'הבנתי, תודה'
);
export const DEBTS_DETAILS_PRIMARY_BUTTON_COLLECT_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DEBTS_DETAILS_PRIMARY_BUTTON_COLLECT_TEXT',
    'המשך'
);

export const DEBTS_DETAILS_APPROVE_ONE_PAYMENT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DEBTS_DETAILS_APPROVE_ONE_PAYMENT',
    'הסימון מהווה אישור לגביית החוב בתשלום אחד בהוראת הקבע החדשה המעודכנת'
);


export const KUPA_DEBT_FIRST_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'KUPA_DEBT_FIRST_TEXT',
    'בהתאם להסכם שלך עם מכבי, בהוראת הקבע ייגבו חובות בגין דמי ביטוח בלבד. אם ברצונך לשלם את יתרת החוב בסך'
);

export const KUPA_DEBT_SECOND_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'KUPA_DEBT_SECOND_TEXT',
    'ש"ח, ניתן לפנות למוקד השירות הטלפוני'
);

export const BANK_HOK = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'BANK_HOK',
    'הוראת קבע בנקאית'
);


export const CREDIT_CARD_HOK = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'CREDIT_CARD_HOK',
    'הוראת קבע באשראי'
);

