export { default } from './DebtsDetails';
