import mLib from '@maccabi/m-lib';
import {URL_DIRECT_DEBIT} from '../../../containers/CreditsAndDebits/constants';

export const DIRECT_DEBIT_FAMILY_LIST_DISCLAIMER = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_FAMILY_LIST_DISCLAIMER',
    'התשלום באמצעות הוראת קבע יחול גם על בני המשפחה ו/או חברי מכבי עליהם אתה משלם'
);