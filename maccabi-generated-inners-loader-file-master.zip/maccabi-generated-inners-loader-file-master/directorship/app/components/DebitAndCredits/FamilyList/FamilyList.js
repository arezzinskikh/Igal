import React, { useEffect } from 'react';
import style from './FamilyList.scss';
import cx from 'classnames';
import { DIRECT_DEBIT_FAMILY_LIST_DISCLAIMER } from './constants';
import {insertLog , FORM_FIELDS_TO_LOG} from '../../../containers/CreditsAndDebits/DirectDebit/logFile';




const FamilyList = (props) => {

    useEffect(() => {
        const {fromConfirmationHokPage = false} = props;
        if (!fromConfirmationHokPage){
            insertLog(FORM_FIELDS_TO_LOG.detailsOfFamilyList);
        }
      }, []);


    const isDisabled = (item) => {
        const id = item.member_status === '7';

        return id;
    }
    
        const { items } = props;
        

        return (
            <div> 
                <div className={style.text}>{DIRECT_DEBIT_FAMILY_LIST_DISCLAIMER}</div>
                <div className={style.items}>
                    {items.map(item => {
                        const cls = cx(style.item,{
                            [style.disable] : isDisabled(item)
                        })
                        return(
                        <div className={cls}>
                            <div className={style.name}>
                                {item.member_first_name} {item.member_last_name}
                            </div>
                            <div className={style.id}>{item.member_id}</div>
                        </div>
                    )})}
                </div>
            </div>
        );
    }
    FamilyList.propTypes = {
        items: PropTypes.object.isRequired
    };

export default FamilyList;
