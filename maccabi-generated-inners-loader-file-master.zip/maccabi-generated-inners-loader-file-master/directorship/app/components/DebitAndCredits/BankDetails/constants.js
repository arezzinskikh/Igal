import mLib from '@maccabi/m-lib';
import {ConfirmationDirectDebitsUrl,URL_DIRECT_DEBIT} from '../../../containers/CreditsAndDebits/constants';

export const DIRECT_DEBIT_BANK_DETAILS_TITLE = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_BANK_DETAILS_TITLE',
    'פרטי חשבון בנק לחיוב'
);
export const DIRECT_DEBIT_BANK_DETAILS_ACCOUNT_NUMBER_TITLE = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_BANK_DETAILS_ACCOUNT_NUMBER_TITLE',
    'מספר חשבון'
);
export const REPLACMENT_PAYMENT_METHOD = mLib.resources.getResource(URL_DIRECT_DEBIT, 'REPLACMENT_PAYMENT_METHOD', 'החלפת אמצעי תשלום');
export const BANK_INFO_UPDATE = mLib.resources.getResource(URL_DIRECT_DEBIT, 'BANK_INFO_UPDATE', 'עדכון פרטי חשבון');
export const CHANGE_BANK = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'CHANGE_BANK', 'עריכה');
export const DIRECT_DEBIT_BANK_DETAILS_BRANCH_CODE_TITLE = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_BANK_DETAILS_BRANCH_CODE_TITLE',
    'מספר סניף'
);

export const DIRECT_DEBIT_BANK_DETAILS_BANK_CODE_TITLE = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_BANK_DETAILS_BANK_CODE_TITLE',
    'מספר בנק'
);