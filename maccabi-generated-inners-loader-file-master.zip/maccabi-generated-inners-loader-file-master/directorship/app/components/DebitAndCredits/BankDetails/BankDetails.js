import React, { useEffect } from 'react';
import style from './BankDetails.scss';
import cx from 'classnames';
import { withRouter } from 'react-router-dom';
import { H2, Img, CoupleButtons, Button } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import {
    DIRECT_DEBIT_BANK_DETAILS_TITLE,
    DIRECT_DEBIT_BANK_DETAILS_BANK_CODE_TITLE,
    DIRECT_DEBIT_BANK_DETAILS_BRANCH_CODE_TITLE,
    DIRECT_DEBIT_BANK_DETAILS_ACCOUNT_NUMBER_TITLE,
    REPLACMENT_PAYMENT_METHOD,
    BANK_INFO_UPDATE,
    CHANGE_BANK
} from './constants';
import PropTypes from 'prop-types';
import BankDetailsItem from './BankDetailesItem';
import DirectDebitTermsOfUseModal from '../DirectDebitTermsOfUseModal/DirectDebitTermsOfUseModal';
import {insertLog , FORM_FIELDS_TO_LOG} from '../../../containers/CreditsAndDebits/DirectDebit/logFile';

const BankDetails = props => {
    const {
        bankCode,
        accountNumber,
        primaryButtonClick,
        secondaryButtonClick,
        branchCode,
        fromConfirmationBankHokPage,
        showErrorMessage,
        changeErrorMessage,
        onChangeBank,
        clickTremOfUseOk,
        ClickTermsOfUseClose,
        termsOfUseModalOpen,
        agreeToTermsRef,
        onCheckChangeCallBack,
        agreeToTermsOfUse,
        fromConfirmationHokPage = false
    } = props;
    const { logged_customer_info } = mLib.saveData.customerData.get();

    useEffect(() => {
        if (!fromConfirmationHokPage){
            insertLog(FORM_FIELDS_TO_LOG.viewDetailsOfBankDirectDebit);
        }
      }, []);

 

    const bankIconPath = () => {
        const key = bankCode && bankCode.toString().replace("'", '');
        let bip = mLib.resources.getImage('directorship/CreditsAndDebits/DirectDebit', key);
        if (bip === null) {
            bip = mLib.resources.getImage('directorship/CreditsAndDebits/DirectDebit', '-1');
        }
        return bip;
    };

    const fullName = logged_customer_info.f_name_hebrew + ' ' + logged_customer_info.l_name_hebrew;

    return (
        <div className={style.bankDetailsWrap}>
            <H2 className={cx(style.title, 'mt-7')}>{DIRECT_DEBIT_BANK_DETAILS_TITLE}</H2>
            <div className={style.name}>{fullName}</div>
            <div className={style.line}>
                <Img extension="png" path={bankIconPath()} />
                <BankDetailsItem code={bankCode} text={DIRECT_DEBIT_BANK_DETAILS_BANK_CODE_TITLE} />
                <BankDetailsItem code={branchCode} text={DIRECT_DEBIT_BANK_DETAILS_BRANCH_CODE_TITLE} />
                <BankDetailsItem code={accountNumber} text={DIRECT_DEBIT_BANK_DETAILS_ACCOUNT_NUMBER_TITLE} />
            </div>
            {fromConfirmationBankHokPage ? (
                <div>
                    <DirectDebitTermsOfUseModal
                        pageType={'BANK'}
                        showErrorMessage={showErrorMessage}
                        changeErrorMessage={changeErrorMessage}
                        clickTremOfUseOk={clickTremOfUseOk}
                        ClickTermsOfUseClose={ClickTermsOfUseClose}
                        termsOfUseModalOpen={termsOfUseModalOpen}
                        agreeToTermsRef={agreeToTermsRef}
                        onCheckChangeCallBack={onCheckChangeCallBack}
                        agreeToTermsOfUse={agreeToTermsOfUse}
                    />
                    <Button onClick={() => onChangeBank()} maincta className={style.editBankBtn} color="primary" size="sm" outline>
                        {CHANGE_BANK}
                    </Button>
                </div>
            ) : (
                <CoupleButtons
                    secondText={REPLACMENT_PAYMENT_METHOD}
                    firstText={BANK_INFO_UPDATE}
                    firstOnClick={() => primaryButtonClick(true)}
                    secondOnClick={() => secondaryButtonClick(false)}
                    classname={style.coupleButtonsWrap}
                    firstclassname={style.firstclassname}
                />
            )}
        </div>
    );
};

BankDetails.propTypes = {
    bankCode: PropTypes.number.isRequired,
    branchCode: PropTypes.number.isRequired,
    accountNumber: PropTypes.number.isRequired,
    primaryButtonClick: propTypes.func.isRequired,
    secondaryButtonClick: propTypes.func.isRequired
};

export default withRouter(BankDetails);
