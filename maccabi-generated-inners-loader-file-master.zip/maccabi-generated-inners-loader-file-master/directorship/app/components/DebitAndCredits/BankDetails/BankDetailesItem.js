import React, { Fragment } from 'react';
import style from './BankDetails.scss';
import PropTypes from 'prop-types';

const BankDetailsItem = props => {
    const { code, text } = props;

    return (
        <Fragment>
            <div className={style.item}>
                <div className={style.number}>{code}</div>
                <div className={style.text}>{text}</div>
            </div>
        </Fragment>
    );
};

BankDetailsItem.propTypes = {
    text: PropTypes.string.isRequired,
    code: PropTypes.number.isRequired
};

export default BankDetailsItem;
