import React, { Component } from 'react';
import style from './Acceptance.scss';
import cx from 'classnames';
import { H2, CoupleButtons, Checkbox } from '@maccabi/m-ui';

const propTypes = {
    className: PropTypes.string,
    title: PropTypes.string,
    name: PropTypes.string,
    checked: PropTypes.bool,
    primaryButtonClick: PropTypes.func.isRequired,
    secondaryButtonClick: PropTypes.func.isRequired
};

const Acceptance = (porps) => {

        const { title, name, checked, primaryButtonClick, secondaryButtonClick, className } = props;
        let today = 'xxxxxx';

        return (
            <div className={cx(style.wrap, className)}>
                <H2 className={style.title}>{title} </H2>
                <div className={style.text}>סימון יחשב כחתימה והסכמה.</div>
                <div className={style.line}>
                    <Checkbox checked={checked} className={style.text}></Checkbox>
                    <div className={style.wrapName}>
                        <div className={style.label}>שם מלא</div>
                        <div className={style.textLabel}>{name}</div>
                    </div>
                    <div className={style.wrapDate}>
                        <div className={style.label}>תאריך</div>
                        <div className={style.textLabel}>{today}</div>
                    </div>
                </div>
                <CoupleButtons
                    firstText="הצטרפות"
                    secondText="ביטול"
                    firstOnClick={primaryButtonClick}
                    secondOnClick={secondaryButtonClick}
                    classname={דtyle.coupleButtonsWrap}
                    firstclassname={style.firstclassname}
                />
            </div>
        );
    }


export default Acceptance;
