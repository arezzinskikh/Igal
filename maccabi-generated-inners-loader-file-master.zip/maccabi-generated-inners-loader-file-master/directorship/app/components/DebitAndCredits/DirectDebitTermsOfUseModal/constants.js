import mLib from '@maccabi/m-lib';
import { ConfirmationDirectDebitsUrl } from '../../../containers/CreditsAndDebits/constants';

export const CONDITIONS_BE_CONFIRMED = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'CONDITIONS_BE_CONFIRMED', 'יש לאשר את התנאים');
export const MUST_BE_ֹCONFIRMED = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'MUST_BE_ֹCONFIRMED', 'יש לאשר את ');
export const TERMS_OF_USE = {
    CREDIT: {
        title: mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'TERMS_OF_CREDIT_CARD_title', 'תנאי הוראת קבע בכרטיס אשראי'),
        textConfirmation: mLib.resources.getResource(
            ConfirmationDirectDebitsUrl,
            'TERMS_OF_CREDIT_CARD_textConfirmation',
            'תנאי הוראת הקבע בכרטיס האשראי'
        ),
        primaryBtn: mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'TERMS_OF_CREDIT_CARD_primaryBtn', 'הבנתי, תודה'),
        secondaryBtn: mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'TERMS_OF_CREDIT_CARD_secondaryBtn', 'שמירה / הדפסה'),
        content: mLib.resources.getResource(
            ConfirmationDirectDebitsUrl,
            'CREDIT_CARD_TERMS_OF_USE',
            '\n\
            א. הוראה זו נחתמה על ידי בלי לנקוב במספר התשלומים ובסכומיהם, הואיל וניתנה על ידי הרשאה למפיקת כרטיס האשראי באמצעות ״קרן מכבי״ לגבות חיובים מעת לעת כפי שיפורט למנפיקה.\n\
             \n\
             ב. ידוע לי כי סכומי החיובים ומועדיהם יקבעו מעת לעת ע״י קרן מכבי ו/או מכבי שירותי בריאות (״מכבי״) עפ״י תעריפי הגביה השונים, לרבות אלה הנהוגים במכבי ובתוכניות הביטוח הנוספות, לרבות על פי ההשתתפויות וההיטלים בהם אני חייב על פי חוק ביטוח בריאות ממלכתי (כולל בעת ביקור אצל רופאים, מכונים ובגין תרופות) ועל פי פירוט הסכומים שתקבע מכבי, לרבות חיובים עבור בני משפחה/חברים נוספים לגביהם ניתנה הסכמתי לשלם.\n\
             \n\
             ג. הרשאה זו תהיה בתוקף גם לחיוב כרטיס שיונפק וישא מספר אחר, כחלופה לכרטיס שמספרו נקוב בהוראה זו.\n\
              \n\
              ד. הרשאה זו תפקע ע״י הודעה בכתב ממני לחברת האשראי או ל״מכבי״ או על פי כל דין ותיכנס לתוקפה יום עסקים אחד לאחר מתן ההודעה לחברת כרטיסי האשראי או ל״מכבי״.\n\
        \n\
        ה. ידוע לי כי מכבי שומרת לעצמה את הזכות לשנות את מועדי הגביה, וכי במקרה כזה, תיתכן בעתיד גביה חד פעמית לאחר מתן הודעה מראש, עבור חודשים לצורך התאמת מועדי הגביה לעיבודים החודשיים ב״מכבי״.\n\
        \n\
        ו. בכל מקרה, המועד שבו יבוצעו לטובתי/לחובתי זיכויים/חיובים, על ידי החברה המנפיקה, יקבע בהתאם להסכם שביני לבין החברה המנפיקה.\n\
        \n\
        ז. ידוע לי, כי במידה וביום החתימה על הרשאה זו מעודכנים כבר במערכות ״מכבי״ חברים עליהם אני משלם/ת, חברים אלו ימשיכו להיות משולמים על ידי, ולא יהיה כל שינוי בהרכב החברים עד לקבלת בקשה בכתב ממני.\n\
        \n\
        טופס זה יוחזר ממולא וחתום למרכז הרפואי מכבי, ולאחר החזרתו נציג מכבי יצור עמך קשר. עד למועד יצירת הקשר על ידי נציג מכבי, לא נבצע כל שינוי באמצעי התשלום שמעודכן במערכות הקופה, ואותו הנך  מעוניין/ת להחליף בכרטיס האשראי המופיע בטופס הרשאה זה. במידה ולא יצרו עמך קשר בתוך 2 ימי עבודה מיום העברת טופס זה חתום, אנא צור/צרי קשר עם המרכז הרפואי מכבי אליו הועבר הטופס.\n\
        \n\
        '
        )
    },
    BANK: {
        title: mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'TERMS_OF_BANK_title', 'תנאי הוראת קבע בנקאית'),
        textConfirmation: mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'TERMS_OF_BANK_textConfirmation', 'תנאי הוראת הקבע הבנקאית'),
        primaryBtn: mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'TERMS_OF_BANK_primaryBtn', 'הבנתי, תודה'),
        secondaryBtn: mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'TERMS_OF_BANK_secondaryBtn', 'שמירה / הדפסה'),
        content: mLib.resources.getResource(
            ConfirmationDirectDebitsUrl,
            'BANK_TERMS_OF_USE',
            '\n\
            1. אני הח"מ \b{fullName}\b (שם בעלי החשבון כמופיע בספרי הבנק) מס׳ תעודת זהות \b{member_id}\b מבקשים בזה להקים בחשבוננו הנ"ל ("החשבון") הרשאה לחיוב \
            חשבוננו, בסכומים ובמועדים שיומצאו לכם מדי פעם בפעם ע"י המוטב באמצעות \
            קוד המוסד, בכפוף למגבלות שסומנו לעיל (ככל שסומנו)\n\
            \n\
            2. כמו כן יחולו ההוראות הבאות:\n\
             א. עלינו לקבל מהמוטב את הפרטים הנדרשים למילוי הבקשה להקמת ההרשאה לחיוב החשבון.\n\
             \n\
             ב. הרשאה זו ניתנת לביטול ע"י הודעה בכתב מאיתנו לבנק שתכנס לתוקף יום עסקים אחד לאחר מתן ההודעה לבנק, וכן ניתנת לביטול עפ"י הוראת כל דין.\n\
             \n\
              ג. נהיה רשאים לבטל חיוב מסוים, ובלבד שהודעה על כך תימסר על ידנו בכתב לבנק, לא יאוחר מ-3 ימי עסקים לאחר מועד החיוב. ככל שהודעת הביטול ניתנה לאחר מועד החיוב, הזיכוי יעשה בערך יום מתן הודעת הביטול.\n\
              \n\
        ד. נהיה רשאים לדרוש מהבנק, בהודעה בכתב, לבטל חיוב, אם החיוב אינו תואם את  מועד פקיעת התוקף שנקבע בהרשאה, או את הסכומים שנקבעו בהרשאה, אם נקבעו.\n\
        \n\
        ה. הבנק אינו אחראי בכל הנוגע לעסקה שבינינו לבין המוטב.\n\
        \n\
        ו. הרשאה שלא יעשה בה שימוש במשך תקופה של 24 חודשים ממועד החיוב האחרון, בטלה.\n\
        \n\
        ז. אם תענו לבקשתנו, הבנק יפעל בהתאם להוראות הרשאה זו, בכפוף להוראות כל דין והסכם שבינינו לבין הבנק.\n\
        \n\
        ח. הבנק רשאי להוציאנו מן ההסדר המפורט בכתב הרשאה זו, אם תהיה לו סיבה סבירה לכך, ויודיע לנו על כך מיד לאחר קבלת החלטתו תוך ציון הסיבה.\n\
        \n\
        3. אנו מסכימים שבקשה זו תוגש לבנק על ידי המוטב.\n'
        )
    }
};
