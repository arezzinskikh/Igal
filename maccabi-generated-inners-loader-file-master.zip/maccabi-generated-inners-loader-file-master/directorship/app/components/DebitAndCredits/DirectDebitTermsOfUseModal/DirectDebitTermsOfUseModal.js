import React, { useState, Fragment } from 'react';
import { SpecialModal, Checkbox } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import { TERMS_OF_USE, MUST_BE_ֹCONFIRMED, CONDITIONS_BE_CONFIRMED } from './constants';
import style from './DirectDebitTermsOfUseModal.scss';
import cx from 'classnames';
import format from 'string-format';
import {insertLog , FORM_FIELDS_TO_LOG} from '../../../containers/CreditsAndDebits/ConfirmationDirectDebits/logFile';

const DirectDebitTermsOfUseModal = ({
    pageType,
    showErrorMessage,
    changeErrorMessage, 
    clickTremOfUseOk,
    ClickTermsOfUseClose,
    agreeToTermsOfUse,
    agreeToTermsRef,
    onCheckChangeCallBack
}) => {
    const [isOpen, toggleModal] = useState(false);
    const { logged_customer_info } = mLib.saveData.customerData.get();
    const fullName = logged_customer_info.f_name_hebrew + ' ' + logged_customer_info.l_name_hebrew;

    const onClickModalOk = () => {
        clickTremOfUseOk(true);
        toggleModal(false);
    };

    const onClickModalClose = () => {
        ClickTermsOfUseClose();
        toggleModal(false);
    };

    const errorMessage = () => {
        return showErrorMessage ? CONDITIONS_BE_CONFIRMED : '';
    };

    const onPrintBtnClick = () => {
        const currentUrl = window.location.href;
        const danainfo = mLib.juniper.getDanaInfo(currentUrl);
        const baseUrl = process.env.WEB_API_URL_DIRECTORSHIP + process.env.WEB_API_URL_GET_TERMS_OF_USE_PDF;
        const isBank = pageType === 'BANK';
        const url = format(baseUrl, logged_customer_info.member_id_code, logged_customer_info.member_id, danainfo, isBank);
        isBank ? insertLog(FORM_FIELDS_TO_LOG.bankHokModelBankTermsPrintSave) : insertLog(FORM_FIELDS_TO_LOG.CCHokModelCreditcardTermsPrintSave); 
        mLib.openPdfNewTab.openPdfNewTab(url, 'מכבי');
    };

    const validCls = cx({
        [style.valid]: showErrorMessage === false,
        [style.notValid]: showErrorMessage === true
    });
    const handleToggle = e => {
        toggleModal(e.target.checked);
        onCheckChangeCallBack(e);
        changeErrorMessage();
    };

    return (
        <div>
            <SpecialModal
                toggle={() => onClickModalClose()}
                isOpen={isOpen}
                header={TERMS_OF_USE[pageType].title}
                primaryButton={TERMS_OF_USE[pageType].primaryBtn}
                primaryButtonClick={() => onClickModalOk()}
                secondaryButton={TERMS_OF_USE[pageType].secondaryBtn}
                secondaryButtonClick={() => onPrintBtnClick()}
                footerClassName={style.modalFooterBtns}>
                <div className={style.termsOfUseContent}>
                    {TERMS_OF_USE[pageType].content.split('\n').map(
                        (item, i) =>
                            i > 0 && (
                                <p className={style.subList} key={i}>
                                    {item
                                        .replace('{fullName}', fullName)
                                        .replace('{member_id}', logged_customer_info.member_id)
                                        .split('\r')
                                        .map((itm, index) => (
                                            <span key={index}>
                                                {itm
                                                    .split('\b')
                                                    .map((it, dx) => (dx == 1 || dx == 3 ? <b key={dx}>{it}</b> : <Fragment>{it}</Fragment>))}
                                            </span>
                                        ))}
                                </p>
                            )
                    )}
                </div>
            </SpecialModal>
            <Checkbox
                id="agreeToTermOfUse"
                label={''}
                usePropsForCheck={true}
                invalid={showErrorMessage ? 'invalid' : ''}
                className={style.checkbox}
                ref={agreeToTermsRef}
                ischecked={agreeToTermsOfUse}
                onCheckChangeCallBack={event => handleToggle(event)}>
                <div className={style.TermsOfStandingWarp}>
                    {MUST_BE_ֹCONFIRMED}
                    <a className={style.TermsOfStanding} onClick={() => toggleModal(true)}>
                        {TERMS_OF_USE[pageType].textConfirmation}
                    </a>
                </div>
            </Checkbox>
            <div className={validCls} data-hook="validation">
                {showErrorMessage && errorMessage()}
            </div>
        </div>
    );
};

export default DirectDebitTermsOfUseModal;
