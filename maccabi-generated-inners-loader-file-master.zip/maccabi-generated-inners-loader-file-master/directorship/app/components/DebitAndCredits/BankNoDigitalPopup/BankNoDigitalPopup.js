import React , { useEffect }  from 'react';
import { Modal } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import { BODY,HEADER,PRIMARY_BTN_NO_KOSHER,PRIVARY_BTN_KOSHER,SECONDERY_BTN_NOT_KOSHER } from './constatns';
import { insertLog, FORM_FIELDS_TO_LOG } from '../../../containers/CreditsAndDebits/BankAcountPermission/logFile';

const BankNoDigitalPopup = ({isOpen,onClose,selectedBankName}) => {

    const isKosher = mLib.site.isKosher();

    useEffect(() => {
        if(isOpen){
             const log = FORM_FIELDS_TO_LOG.openModalIsNotSupportedDigitally;
             log.variables = [{ key: 'element_id', description: selectedBankName }];
            insertLog(log);
        }

      }, [isOpen]);


      const ManualForm = ()=>{
        insertLog(FORM_FIELDS_TO_LOG.ModalNotSupportedBtnManualForm);
        window.location.href="https://www.maccabi4u.co.il/24497-he/Maccabi.aspx"
      }

      const onCloseModal = ()=>
      {
        insertLog(FORM_FIELDS_TO_LOG.ModalNotSupportedBtnNewBank);
        onClose();
      }

      const clickOnToggle = () =>{
        insertLog(FORM_FIELDS_TO_LOG.clickOnXbtn);
        onClose();
      }
    return(
        <Modal
            isOpen={isOpen}
            toggle={clickOnToggle}
            icon={'attention-big'}
            header={HEADER}
            body={BODY}
            primaryButton={isKosher ? PRIVARY_BTN_KOSHER : PRIMARY_BTN_NO_KOSHER}
            primaryButtonClick={isKosher ? onClose : ManualForm}
            secondaryButton={isKosher ? undefined :SECONDERY_BTN_NOT_KOSHER}
            secondaryButtonClick={isKosher ? undefined : onCloseModal}
        />
    )
}

export default BankNoDigitalPopup;