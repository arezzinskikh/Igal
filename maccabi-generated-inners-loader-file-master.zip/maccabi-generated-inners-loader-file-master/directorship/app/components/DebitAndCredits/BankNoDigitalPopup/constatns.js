import mLib from '@maccabi/m-lib';
import { URL_BANK_DEBIT } from '../../../containers/CreditsAndDebits/constants';
const URL = URL_BANK_DEBIT;

const HEADER_KEY = 'HEADER';
const HEADER_VALUE = 'בנק זה אינו מאפשר ביצוע תהליך דיגיטלי';
export const HEADER = mLib.resources.getResource(URL, HEADER_KEY, HEADER_VALUE);

const BODY_KEY = 'BODY';
const BODY_VALUE = 'ניתן להצטרף באמצעות מילוי טופס ידני או לפנות למוקד השירות הטלפוני ב 3555*';
export const BODY = mLib.resources.getResource(URL, BODY_KEY, BODY_VALUE);

const PRIVARY_BTN_KOSHER_KEY = 'PRIVARY_BTN_KOSHER';
const PRIVARY_BTN_KOSHER_VALUE = 'לבחירת בנק אחר';
export const PRIVARY_BTN_KOSHER = mLib.resources.getResource(URL, PRIVARY_BTN_KOSHER_KEY, PRIVARY_BTN_KOSHER_VALUE);

const PRIMARY_BTN_NO_KOSHER_KEY = 'PRIMARY_BTN_NO_KOSHER';
const PRIMARY_BTN_NO_KOSHER_VALUE = 'למילוי טופס ידני';
export const PRIMARY_BTN_NO_KOSHER = mLib.resources.getResource(URL, PRIMARY_BTN_NO_KOSHER_KEY, PRIMARY_BTN_NO_KOSHER_VALUE);

const SECONDERY_BTN_NOT_KOSHER_KEY = 'SECONDERY_BTN_NOT_KOSHER';
const SECONDERY_BTN_NOT_KOSHER_VALUE = 'לבחירת בנק אחר';
export const SECONDERY_BTN_NOT_KOSHER = mLib.resources.getResource(URL, SECONDERY_BTN_NOT_KOSHER_KEY, SECONDERY_BTN_NOT_KOSHER_VALUE);
