import React, { useEffect } from 'react';
import style from './MessagePaidByAnotherPayer.scss';
import cx from 'classnames';
import { H4, Icon } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import {
    DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER,
    DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT,
    DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SUB_TEXT
} from './constants';
import { insertLog, FORM_FIELDS_TO_LOG } from '../../../containers/CreditsAndDebits/DirectDebit/logFile';

const MessagePaidByAnotherPayer = () => {
    useEffect(() => {
        insertLog(FORM_FIELDS_TO_LOG.paidNonPaying);
    }, []);

    const { logged_customer_info } = mLib.saveData.customerData.get();
    return (
        <div className={cx(style.DebitAndCreditsMsgForPaidMember)}>
            <Icon name="attention-big" className={style.icon} />
            <H4 className="mt-5" tag="h4">
                {DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER + ' ' + logged_customer_info.pays_f_name + ' ' + logged_customer_info.pays_l_name}
            </H4>
            <div className={cx(style.secoundTitle, 'mt-2', 'mb-5')}>{DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT}</div>
            <div className={style.subText}>{DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SUB_TEXT}</div>
        </div>
    );
};

export default MessagePaidByAnotherPayer;
