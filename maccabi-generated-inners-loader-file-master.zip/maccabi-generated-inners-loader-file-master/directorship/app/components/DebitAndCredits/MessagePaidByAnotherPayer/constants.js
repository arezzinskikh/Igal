import mLib from '@maccabi/m-lib';
import { URL_DIRECT_DEBIT } from '../../../containers/CreditsAndDebits/constants';

export const DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER',
    'הוראת הקבע עבורך משולמת על ידי'
);

export const DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT',
    'פרטי הוראת הקבע מוצגים עבור הגורם המשלם בלבד'
);

export const DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SUB_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SUB_TEXT',
    'להצטרפות להוראת קבע אישית עבורך, עליך לפנות למוקד השירות הטלפוני ב 3555*'
);
