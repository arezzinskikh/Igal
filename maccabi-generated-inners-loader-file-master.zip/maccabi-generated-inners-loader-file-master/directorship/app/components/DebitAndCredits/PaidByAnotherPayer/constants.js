import mLib from '@maccabi/m-lib';
import { URL_DIRECT_DEBIT } from '../../../containers/CreditsAndDebits/constants';

export const DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_WITH_COLON = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_WITH_COLON',
    'הוראת הקבע עבורך משולמת על ידי:'
);
export const DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT',
    'פרטי הוראת הקבע מוצגים עבור הגורם המשלם בלבד'
);
