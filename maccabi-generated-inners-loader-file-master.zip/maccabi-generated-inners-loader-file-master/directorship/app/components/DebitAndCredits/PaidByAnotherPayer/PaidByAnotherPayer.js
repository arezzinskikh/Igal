import React, { useEffect } from 'react';
import style from './PaidByAnotherPayer.scss';
import cx from 'classnames';
import { H6 } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import Dashes from '../Dashes/Dashes';
import { DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_WITH_COLON, DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT } from './constants';
import { insertLog, FORM_FIELDS_TO_LOG } from '../../../containers/CreditsAndDebits/DirectDebit/logFile';

const PaidByAnotherPayer = props => {
    const { logged_customer_info } = mLib.saveData.customerData.get();

    useEffect(() => {
        insertLog(FORM_FIELDS_TO_LOG.paidPays);
    }, []);

    return (
        <div className={cx(style.DebitAndCreditsMsgForPaidMember)}>
            <H6 className={cx(style.firstTitle, 'mt-7')} tag="h6">
                {`${DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_WITH_COLON}  ${logged_customer_info.pays_f_name} ${logged_customer_info.pays_l_name}`}
            </H6>
            <div className={cx(style.secoundTitle, 'mt-2', 'mb-7')}>{DIRECT_DEBIT_MESSAGE_PAID_BY_ANOTHER_PAYER_SECOUND_TEXT}</div>
            <Dashes cls={'mb-7 mt-7'} />
        </div>
    );
};

export default PaidByAnotherPayer;
