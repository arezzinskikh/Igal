import mLib from '@maccabi/m-lib';
import {ConfirmationDirectDebitsUrl,URL_DIRECT_DEBIT} from '../../../containers/CreditsAndDebits/constants'

export const CARD_REPLACEMENT = mLib.resources.getResource(URL_DIRECT_DEBIT, 'CARD_REPLACEMENT', 'החלפת כרטיס');
export const REPLACMENT_PAYMENT_METHOD = mLib.resources.getResource(URL_DIRECT_DEBIT, 'REPLACMENT_PAYMENT_METHOD', 'החלפת אמצעי תשלום');
export const DIRECT_DEBIT_CREDIT_CARD_DETAILS_TITLE = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_CREDIT_CARD_DETAILS_TITLE',
    'פרטי כרטיס האשראי לחיוב'
);
export const CHANGE_CREDIT_CARD = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'CHANGE_CREDIT_CARD', 'החלפת כרטיס');