import React, { Fragment, useEffect } from 'react';
import { useHistory } from "react-router-dom";
import style from './CreditCardDetails.scss';
import { H2, CoupleButtons, Img, Pipe, PipeItem, Button } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
//import ShowCreditCardDetailes from '../logs/logs'
import PropTypes from 'prop-types';
import { REPLACMENT_PAYMENT_METHOD, CARD_REPLACEMENT, DIRECT_DEBIT_CREDIT_CARD_DETAILS_TITLE, CHANGE_CREDIT_CARD } from './constants';
import DirectDebitTermsOfUseModal from '../DirectDebitTermsOfUseModal/DirectDebitTermsOfUseModal';
import * as directDebitLogs  from '../../../containers/CreditsAndDebits/DirectDebit/logFile';
import * as ConfirmationDirectDebitsLogs  from '../../../containers/CreditsAndDebits/ConfirmationDirectDebits/logFile';
import { useDispatch } from 'react-redux';
import {prepareTransaction} from '../../../containers/CreditsAndDebits/actions';


const CreditCardDetails = ({
    lastFourDigitsCreditCard,
    creditCardType,
    primaryButtonClick,
    secondaryButtonClick,
    fromConfirmationCreditCardHokPage,
    changeErrorMessage,
    showErrorMessage,
    clickTremOfUseOk,
    ClickTermsOfUseClose,
    termsOfUseModalOpen,
    agreeToTermsRef,
    onCheckChangeCallBack,
    agreeToTermsOfUse,
    fromConfirmationHokPage = false}) => {
    
    const dispatch = useDispatch();
    const history = useHistory();
    const { logged_customer_info } = mLib.saveData.customerData.get();

    useEffect(() => {
        if (!fromConfirmationHokPage){
            directDebitLogs.insertLog(directDebitLogs.FORM_FIELDS_TO_LOG.DetailsOnCreditDirectDebit);
        }
      }, []);


    const getDots = () => {
        const n = 12;
        const dots = [...Array(n)].map((e, i) => <span className={style.dot} key={i}></span>);

        return dots;
    };

    const creditCardIconPath = () => {
        const key = creditCardType.replace("'", '');
        let iconPath = mLib.resources.getImage('directorship/CreditsAndDebits/DirectDebit', key);
        if (iconPath === null) {
            iconPath = mLib.resources.getImage('directorship/CreditsAndDebits/DirectDebit', '-2');
        }
        return iconPath;
    };

    const onChangeCreditCard = () => {
        setRouteLeavingGuard(false);
        dispatch(prepareTransaction(history.push))
        ConfirmationDirectDebitsLogs.insertLog(ConfirmationDirectDebitsLogs.FORM_FIELDS_TO_LOG.CcHokClickOnEditBtn);
    };

    const setRouteLeavingGuard =(shouldShow=true)=> {
        const propsLeaving = {
            shouldBlockNavigation: shouldShow,
            navigate: history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

 

    return (
        <Fragment>
            <div className={style.wrap}>
                <H2 className={style.title}>{DIRECT_DEBIT_CREDIT_CARD_DETAILS_TITLE}</H2>
                <Pipe className={style.pipe}>
                    <PipeItem className={style.pipeName}>
                        {logged_customer_info.f_name_hebrew} {logged_customer_info.l_name_hebrew}
                    </PipeItem>
                    {logged_customer_info.email && <PipeItem className={style.pipeEmail}>{logged_customer_info.email}</PipeItem>}
                </Pipe>
                <div className={style.name}></div>
                <div className={style.line}>
                    <Img extension="png" path={creditCardIconPath()} />
                    <div className={style.number}>{lastFourDigitsCreditCard}</div>
                    {getDots()}
                    <div className={style.brand}>{creditCardType}</div>
                </div>
                {fromConfirmationCreditCardHokPage ? (
                    <div>
                        <DirectDebitTermsOfUseModal
                            pageType={'CREDIT'}
                            showErrorMessage={showErrorMessage}
                            changeErrorMessage={changeErrorMessage}
                            clickTremOfUseOk={clickTremOfUseOk}
                            ClickTermsOfUseClose={ClickTermsOfUseClose}
                            termsOfUseModalOpen={termsOfUseModalOpen}
                            agreeToTermsRef={agreeToTermsRef}
                            onCheckChangeCallBack={onCheckChangeCallBack}
                            agreeToTermsOfUse={agreeToTermsOfUse}
                        />
                        <Button onClick={() => onChangeCreditCard()} maincta className={style.editBtn} color="primary" size="sm" outline>
                            {CHANGE_CREDIT_CARD}
                        </Button>
                    </div>
                ) : (
                    <CoupleButtons
                        secondText={REPLACMENT_PAYMENT_METHOD}
                        firstText={CARD_REPLACEMENT}
                        firstOnClick={() => primaryButtonClick(true)}
                        secondOnClick={() => secondaryButtonClick(false)}
                        classname={style.coupleButtonsWrap}
                        firstclassname={style.firstclassname}
                    />
                )}
            </div>
        </Fragment>
    );
};

CreditCardDetails.propTypes = {
    lastFourDigitsCreditCard: PropTypes.number.isRequired,
    creditCardType: PropTypes.string.isRequired,
    primaryButtonClick: propTypes.func.isRequired,
    secondaryButtonClick: propTypes.func.isRequired
};

export default CreditCardDetails;
