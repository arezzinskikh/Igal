import React, { Component, Fragment } from 'react';
import autobind from 'autobind';
import cx from 'classnames';
import { Input, Button, CheckboxGroup, InputAutoComplete } from '@maccabi/m-ui';
import Section from '../Section';
import style from './AddressSection.scss';

const DEFAULT_FREE_TEXT_STREET_MAX_LENGTH = 15;
const DEFAULT_MIN_LETTERS_FOR_SEARCH = 2;
const DEFAULT_HOUSE_NUMBER_MAX_LENGTH = 5;
const DEFAULT_APARTMENT_NUMBER_MAX_LENGTH = 3;

@autobind
class AddressSection extends Component {
    constructor(props) {
        super(props);

        this.state = {
            cityIsValid: true,
            streetIsValid: true,
            houseIsValid: true,
            apartmentIsValid: true,
            entranceIsValid: true,
            poBoxIsValid: true,
            citiesInputAutoCompleteFocus: false,
            streetsInputAutoCompleteFocus: false,
            cityHasNamedStreets: false
        };
    }

    static propTypes = {
        filteredCitiesList: PropTypes.arrayOf(object),
        filteredStreetsList: PropTypes.arrayOf(object),
        setFilteredCitiesList: PropTypes.Func,
        setFilteredStreetsList: PropTypes.Func,
        setValidationFunction: PropTypes.Func,
        canSwitchAddressType: PropTypes.bool,
        required: PropTypes.bool,
        isPoAddress: PropTypes.bool,
        sectionTitle: PropTypes.string,
        sectionSubTitle: PropTypes.string,
        isOpen: PropTypes.bool,
        city_name: PropTypes.string,
        city_code_maccabi: PropTypes.string,
        street_code: PropTypes.string,
        street_name: PropType.string,
        //zip_code: PropTypes.string,
        house_num: PropTypes.string,
        apartment_num: PropTypes.string,
        entrance: PropTypes.string,
        po_box: PropTypes.string,
        onFieldsChange: PropTypes.func,
        onIsPoAddressChange: PropTypes.func,
        toggleIsOpen: PropTypes.func,
        freeTextStreetMaxLength: PropTypes.number, // Default value: 15
        minLettersForSearch: PropTypes.number, // Default value: 2
        houseNumberMaxLength: PropTypes.number, // Default value: 5
        apartmentNumberMaxLength: PropTypes.number, // Default value: 3
        constants: PropTypes.shape({
            regularAddressTypeLabel: PropTypes.string,
            poboxAddressTypeLabel: PropTypes.string,
            cityLabel: PropTypes.string,
            streetLabel: PropTypes.string,
            houseLabel,
            apartmentLabel: PropTypes.string,
            entranceLabel: PropTypes.string,
            poBoxLabel: PropTypes.string,
            addAddressLabel: PropTypes.string,
            removeAddressLabel: PropTypes.string,
            emptyCityValidation: PropTypes.string,
            unselectedCityValidation: PropTypes.string,
            unselectedStreetValidation: PropTypes.string,
            emptyStreetValidation: PropTypes.string,
            houseValidation: PropTypes.string,
            apartmentValidation: PropTypes.string,
            entranceValidation: PropTypes.string,
            poValidation: PropTypes.string,
            noResultsText: PropTypes.string,
            dataHook: PropType.string
        })
    };

    componentDidMount() {
        const { city_name, setValidationFunction, setFilteredCitiesList } = this.props;

        if (city_name) setFilteredCitiesList(city_name);

        //const cityHasNamedStreets = filteredStreetsList.length > 0;
        setValidationFunction && setValidationFunction(this.validateAddress);
    }

    componentDidUpdate(prevProps) {
        const { street_name, filteredCitiesList, setValidationFunction, setFilteredStreetsList } = this.props;

        if (prevProps.setValidationFunction !== setValidationFunction) {
            setValidationFunction && setValidationFunction(this.validateAddress);
        }

        if (prevProps.filteredCitiesList !== filteredCitiesList) {
            if (filteredCitiesList.length === 1) {
                //TODO
                const city = filteredCitiesList[0];
                const city_id = city.city_id;
                if (city_id) setFilteredStreetsList(city_id, street_name);
                this.setState({
                    cityHasNamedStreets: city.has_streets
                });
            }
        }

        //  if (prevProps.filteredStreetsList !== filteredStreetsList ) {
        //     const cityHasNamedStreets = filteredStreetsList.length > 0;
        //     this.setState({
        //         cityHasNamedStreets: cityHasNamedStreets
        //     });
        //  }
    }

    /* Changing a value should result in clearing all other values according to an hierarchy provided in the specifications */
    objectToClearByInputsHierarchy = propName => {
        let properties = {};

        /* Don't use break statement and let the cases fall through */
        switch (propName) {
            case 'address':
                properties.city_name = '';
                properties.postal_code = 0;
                properties.city_code_maccabi = 0;
                properties.street_name = '';
                properties.street_code = '';
                properties.house_num = '';
                properties.apartment_num = '';
                properties.entrance = '';
                properties.po_box = 0;
            case 'city_name':
                properties.street_name = '';
                properties.street_code = '';
                properties.po_box = 0;
            case 'street_name': {
                properties.house_num = '';
                properties.po_box = 0;
            }
            case 'house_num': {
                properties.apartment_num = '';
            }
            case 'apartment_num': {
                properties.entrance = '';
            }
        }

        return properties;
    };

    onChange(name, e, maxChars) {
        const { onFieldsChange } = this.props;
        const value = e.target.value;

        if (!(maxChars && value && value.length > maxChars)) {
            let propertiesToUpdate = this.objectToClearByInputsHierarchy(name);
            propertiesToUpdate[name] = e.target.value;
            onFieldsChange && onFieldsChange(propertiesToUpdate);
        }
    }

    onAddressTypeChange(isPoAddress) {
        const { onIsPoAddressChange } = this.props;
        onIsPoAddressChange && onIsPoAddressChange(isPoAddress);
    }

    validateCity() {
        const errorMessage = this.cityErrorMessage();
        const isValid = errorMessage === null;
        this.setState({ cityIsValid: isValid });
        return isValid;
    }

    cityErrorMessage() {
        const { city_name, city_code_maccabi, constants } = this.props;

        let errorMessage = null;
        if (!city_name || city_name.length === 0) {
            errorMessage = constants.emptyCityValidation;
        } else if (!city_code_maccabi) {
            errorMessage = constants.unselectedCityValidation;
        }

        return errorMessage;
    }

    validateStreet() {
        const errorMessage = this.streetErrorMessage();
        const isValid = errorMessage === null;
        this.setState({ streetIsValid: isValid });
        return isValid;
    }

    streetErrorMessage() {
        const { cityHasNamedStreets } = this.state;
        const { street_code, street_name, constants } = this.props;

        let errorMessage = null;
        if (!street_name || street_name.length === 0) {
            errorMessage = constants.emptyStreetValidation;
        } else if (cityHasNamedStreets && !street_code) {
            errorMessage = constants.unselectedStreetValidation;
        }
        return errorMessage;
    }

    validateHouse() {
        const { house_num } = this.props;
        const { cityHasNamedStreets } = this.state;

        // Required only if city has named streets
        const invalid = cityHasNamedStreets && !house_num;
        this.setState({ houseIsValid: !invalid });
        return !invalid;
    }

    validatePoBox() {
        const { po_box } = this.props;
        const invalid = !po_box;
        this.setState({ poBoxIsValid: !invalid });
        return !invalid;
    }

    validateAddress() {
        const { isPoAddress } = this.props;
        if (isPoAddress) {
            return this.validateCity() & this.validatePoBox();
        } else {
            return this.validateCity() & this.validateStreet() & this.validateHouse();
        }
    }

    rowRenderer = (item, currentActiveName, click) => {
        let buttonText = [];

        if (currentActiveName && item.name.indexOf(currentActiveName) !== -1) {
            buttonText = item.name.split(currentActiveName);
        } else {
            buttonText.push(item.name);
        }

        const lastButtonTextItemIndex = buttonText.length - 1;

        return (
            <Button className={style.autoCompleteResult} color="link" onClick={e => click && click(e, item)}>
                {buttonText.map((text, index) => {
                    return (
                        <Fragment>
                            <span>{text}</span>
                            {index !== lastButtonTextItemIndex && <span className={style.markedAutoCompleteResult}>{currentActiveName}</span>}
                        </Fragment>
                    );
                })}
            </Button>
        );
    };

    onCitySelect = (e, item) => {
        const { city_code_maccabi } = this.props;

        /* Check if value had changed */
        if (item.sub_city_id !== city_code_maccabi) {
            this.updateCityRelatedProps(item.name, item.city_id, item.sub_city_id);
        }

        this.setState({
            citiesInputAutoCompleteFocus: false,
            streetIsValid: true, // Set street state to valid to hide the validation message
            cityHasNamedStreets: item.has_streets
        });
    };

    onStreetSelect = (e, item) => {
        const { street_code } = this.props;

        /* Check if value had changed */
        if (item.street_id !== street_code) {
            this.updateStreetRelatedProps(item.name, item.street_id);
        }

        this.setState({
            streetsInputAutoCompleteFocus: false
        });
    };

    filterCities = value => {
        const { setFilteredCitiesList } = this.props;
        setFilteredCitiesList && setFilteredCitiesList(value);
    };

    filterStreets = value => {
        const { setFilteredStreetsList, postal_code } = this.props;
        setFilteredStreetsList && setFilteredStreetsList(postal_code, value);
    };

    updateCityRelatedProps = (cityName, cityId, subCityId) => {
        const { onFieldsChange } = this.props;
        let propertiesToUpdate = this.objectToClearByInputsHierarchy('city_name');
        propertiesToUpdate.city_name = cityName;
        propertiesToUpdate.postal_code = cityId;
        propertiesToUpdate.city_code_maccabi = subCityId;
        onFieldsChange && onFieldsChange(propertiesToUpdate);
    };

    updateStreetRelatedProps = (streetName, streetId) => {
        const { onFieldsChange } = this.props;
        let propertiesToUpdate = this.objectToClearByInputsHierarchy('street_name');
        propertiesToUpdate.street_name = streetName;
        propertiesToUpdate.street_code = streetId;
        onFieldsChange && onFieldsChange(propertiesToUpdate);
    };

    onCityValueChange = value => {
        this.updateCityRelatedProps(value, 0, 0);
        if (value === '') this.filterCities(value);
    };

    onStreetValueChange = value => {
        const { freeTextStreetMaxLength } = this.props;

        if (value.length <= freeTextStreetMaxLength || DEFAULT_FREE_TEXT_STREET_MAX_LENGTH) {
            this.updateStreetRelatedProps(value, 0);
        }
    };

    noResultsRender = () => {
        const { constants } = this.props;
        return <div className={style.noAutoCompleteResultsContainer}>{constants.noResultsText}</div>;
    };

    onAutocompleteFocus = (inputAutoCompleteFocusStateName, validStateName) => {
        this.setState({
            [inputAutoCompleteFocusStateName]: true,
            [validStateName]: true
        });
    };

    onCitiesAutocompleteFocus = () => {
        this.onAutocompleteFocus('citiesInputAutoCompleteFocus', 'cityIsValid');
    };

    onStreetsAutocompleteFocus = () => {
        this.onAutocompleteFocus('streetsInputAutoCompleteFocus', 'streetIsValid');
    };

    onAutocompleteBlur(inputAutoCompleteFocusStateName, validationFunc) {
        /* Add timeout because otherwise select button elements are destructed before click event has a chance to fire */
        window.setTimeout(() => {
            validationFunc();
            this.setState({
                [inputAutoCompleteFocusStateName]: false
            });
        }, 100);
    }

    onCityBlur() {
        this.onAutocompleteBlur('citiesInputAutoCompleteFocus', this.validateCity);
    }

    onStreetBlur() {
        this.onAutocompleteBlur('streetsInputAutoCompleteFocus', this.validateStreet);
    }

    // eslint-disable-next-line max-lines-per-function
    getAddressForm() {
        const {
            isPoAddress,
            city_name,
            street_name,
            freeTextStreetMaxLength,
            houseNumberMaxLength,
            apartmentNumberMaxLength,
            house_num,
            apartment_num,
            entrance,
            po_box,
            constants,
            minLettersForSearch,
            filteredCitiesList,
            filteredStreetsList,
            dataHook,
            disabled
        } = this.props;

        const {
            cityIsValid,
            streetIsValid,
            houseIsValid,
            apartmentIsValid,
            entranceIsValid,
            poBoxIsValid,
            cityHasNamedStreets,
            citiesInputAutoCompleteFocus,
            streetsInputAutoCompleteFocus
        } = this.state;
        const minSearchLetters = minLettersForSearch || DEFAULT_MIN_LETTERS_FOR_SEARCH;

        return (
            <div className={style.formContainer}>
                <div className={cx(style.formRow, style.mobileCol)}>
                    <div className={cx(style.inputContainer, style.bigInput)}>
                        <InputAutoComplete
                            disabled={disabled}
                            filteredItems={filteredCitiesList}
                            rowRenderer={value => this.rowRenderer(value, city_name, this.onCitySelect)}
                            onSerchFilter={this.filterCities}
                            noResultsRender={this.noResultsRender}
                            placeHolderText={constants.cityLabel}
                            itemWrapperClass={cx(style.itemWrapperClass)}
                            minLetterForSearch={minSearchLetters}
                            showFullListWhenNoInput={false}
                            value={city_name || ''}
                            onValueChange={this.onCityValueChange}
                            isFocus={citiesInputAutoCompleteFocus}
                            onFocus={this.onCitiesAutocompleteFocus}
                            onBlur={() => this.onCityBlur()}
                            errorMsg={!cityIsValid ? this.cityErrorMessage() : null}
                            hook={dataHook + 'city'}
                        />
                    </div>
                    {isPoAddress && (
                        <div className={cx(style.inputContainer, style.bigInput)}>
                            <Input
                                disabled={disabled}
                                onBlur={e => this.validatePoBox(e.target.value)}
                                onFocus={() => this.setState({ poBoxIsValid: true })}
                                error={!poBoxIsValid ? constants.poValidation : null}
                                onChange={e => this.onChange('po_box', e)}
                                width={'regular'}
                                value={po_box}
                                type={'number'}
                                maxlength={5}
                                label={constants.poBoxLabel}
                                hook={dataHook + 'poBox'}
                            />
                        </div>
                    )}
                    {!isPoAddress && (
                        <div className={cx(style.inputContainer, style.bigInput)}>
                            {/*cityHasNamedStreets &&*/}
                            {cityHasNamedStreets && (
                                <InputAutoComplete
                                    disabled={disabled}
                                    filteredItems={filteredStreetsList}
                                    itemWrapperClass={cx(style.itemWrapperClass)}
                                    rowRenderer={value => this.rowRenderer(value, street_name, this.onStreetSelect)}
                                    onSerchFilter={this.filterStreets}
                                    noResultsRender={this.noResultsRender}
                                    placeHolderText={constants.streetLabel}
                                    minLetterForSearch={minSearchLetters}
                                    showFullListWhenNoInput={false}
                                    value={street_name || ''}
                                    onValueChange={this.onStreetValueChange}
                                    isFocus={streetsInputAutoCompleteFocus}
                                    onFocus={this.onStreetsAutocompleteFocus}
                                    onBlur={() => this.onStreetBlur()}
                                    errorMsg={!streetIsValid ? this.streetErrorMessage() : null}
                                    hook={dataHook + 'street'}
                                />
                            )}
                            {!cityHasNamedStreets && (
                                <Input
                                    disabled={disabled}
                                    onBlur={() => this.validateStreet()}
                                    onFocus={() => this.setState({ streetIsValid: true })}
                                    error={!streetIsValid ? this.streetErrorMessage() : null}
                                    onChange={e => this.onChange('street_name', e, freeTextStreetMaxLength || DEFAULT_FREE_TEXT_STREET_MAX_LENGTH)}
                                    width={'regular'}
                                    value={street_name}
                                    type={'text'}
                                    label={constants.streetLabel}
                                    hook={dataHook + 'street_name'}
                                />
                            )}
                        </div>
                    )}
                </div>
                {!isPoAddress && (
                    <div className={style.formRow}>
                        <div className={cx(style.inputContainer, style.smallInput)}>
                            <Input
                                disabled={disabled}
                                onBlur={e => this.validateHouse(e.target.value)}
                                onFocus={() => this.setState({ houseIsValid: true })}
                                error={!houseIsValid ? constants.houseValidation : null}
                                inputclassname={style.small}
                                onChange={e => this.onChange('house_num', e, houseNumberMaxLength || DEFAULT_HOUSE_NUMBER_MAX_LENGTH)}
                                width={'narrow'}
                                value={house_num}
                                type={'text'}
                                label={constants.houseLabel}
                                hook={dataHook + 'house'}
                            />
                        </div>
                        <div className={cx(style.inputContainer, style.smallInput)}>
                            <Input
                                disabled={disabled}
                                onFocus={() => this.setState({ apartmentIsValid: true })}
                                error={!apartmentIsValid ? constants.apartmentValidation : null}
                                inputclassname={style.small}
                                onChange={e => this.onChange('apartment_num', e, apartmentNumberMaxLength || DEFAULT_APARTMENT_NUMBER_MAX_LENGTH)}
                                width={'narrow'}
                                value={apartment_num}
                                type={'number'}
                                label={constants.apartmentLabel}
                                hook={dataHook + 'apartment'}
                            />
                        </div>
                        <div className={cx(style.inputContainer, style.smallInput)}>
                            <Input
                                disabled={disabled}
                                onFocus={() => this.setState({ entranceIsValid: true })}
                                error={!entranceIsValid ? constants.entranceValidation : null}
                                inputclassname={style.small}
                                onChange={e => this.onChange('entrance', e, 2)}
                                width={'narrow'}
                                value={entrance}
                                type={'text'}
                                label={constants.entranceLabel}
                                hook={dataHook + 'entrance'}
                            />
                        </div>
                    </div>
                )}
            </div>
        );
    }

    setIsValid(isValid) {
        this.setState({
            cityIsValid: isValid,
            streetIsValid: isValid,
            houseIsValid: isValid,
            apartmentIsValid: isValid,
            entranceIsValid: isValid,
            poBoxIsValid: isValid
        });
    }

    getSelectedCheckbox() {
        const { isPoAddress } = this.props;
        return isPoAddress ? 1 : 0;
    }

    selectCheckbox(index) {
        this.setState({ cityIsValid: true });

        const { city_name, setFilteredCitiesList, onIsPoAddressChange } = this.props;
        const isPoAddress = index ? true : false;

        if (this.state.cityHasNamedStreets)
            //if(city_name)
            setFilteredCitiesList(city_name);

        //this.updatePoAddressRelatedProps(isPoAddress);
        onIsPoAddressChange && onIsPoAddressChange(isPoAddress);
    }

    toggleIsOpen() {
        const { isOpen, toggleIsOpen, onFieldsChange } = this.props;

        if (isOpen) {
            const propertiesToUpdate = this.objectToClearByInputsHierarchy('address');
            onFieldsChange && onFieldsChange(propertiesToUpdate);
        }

        toggleIsOpen && toggleIsOpen();
    }

    render() {
        const { canSwitchAddressType, required, sectionTitle, sectionSubTitle, isOpen, constants, dataHook,disabled,IsRender } = this.props;

        return (
            <Section
                title={sectionTitle}
                subTitle={sectionSubTitle}
                className={cx(style.container, !required && !isOpen ? style.noBottomPadding : '')}>
                {canSwitchAddressType && isOpen && (
                    <CheckboxGroup
                        disabled = {disabled}
                        classnamecheckboxgroup={style.radioContainer}
                        classnamecheckboxradio={style.radioLabel}
                        selectedindex={this.getSelectedCheckbox()}
                        onCheck={index => this.selectCheckbox(index)}>
                        {constants.regularAddressTypeLabel}
                        {constants.poboxAddressTypeLabel}
                    </CheckboxGroup>
                )}
                {isOpen && this.getAddressForm()}
                {!required && (
                    <div className={style.addRemoveBtnContainer}>
                        <IsRender uniqueName={'hideToAll'}>
                            <Button
                                hook={dataHook + 'addAddress'}
                                outline
                                className={style.btn}
                                size={'sm'}
                                color="primary"
                                onClick={() => this.toggleIsOpen()}>
                                {isOpen ? constants.removeAddressLabel : constants.addAddressLabel}
                            </Button>
                        </IsRender>
                    </div>
                )}
            </Section>
        );
    }
}

export default AddressSection;
