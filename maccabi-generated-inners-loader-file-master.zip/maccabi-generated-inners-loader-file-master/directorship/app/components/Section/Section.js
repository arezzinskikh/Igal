import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { H2 } from '@maccabi/m-ui';
import style from './Section.scss';

const Section = ({title, subTitle, remarks, children, className}) => {

    const renderTitle = () => {
        const titleComponent = <H2>{title}</H2>;
        return remarks ? (
            <div className={style.row}>
                {titleComponent}
                <span className={style.remark}>({remarks})</span>
            </div>
        ) : titleComponent
    }

    return (
        <div className={cx(style.section, className)}>
            <div className={style.titleContainer}>
                {renderTitle()}
                {subTitle && <span className={style.subTitle}>{subTitle}</span>}
            </div>
            {children}
        </div>
    );
}

Section.propTypes = {
    title: PropTypes.string.isRequired,
    subTitle: PropTypes.string,
    remarks: PropTypes.string,
    children: PropTypes.node,
    className: PropTypes.node
};

export default Section;