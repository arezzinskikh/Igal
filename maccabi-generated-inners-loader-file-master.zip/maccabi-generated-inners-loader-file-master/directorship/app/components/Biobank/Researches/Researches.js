import React, { Component } from 'react';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import { H2, CaruselText, Item } from '@maccabi/m-ui';
import cx from 'classnames';
import style from './Researches.scss';

@autobind
class Researches extends Component {
    static propTypes = {
        researches: PropTypes.object.isRequired
    };

    render() {
        const { researches } = this.props;

        return (
            <div className={cx(style.wrap)} data-hook='researches__wrapper'>
                <H2 className={cx(style.title)}>{mLib.resources.getResource('directorship/biobank', 'Research_Title', 'המחקרים שלנו')}</H2>
                <div className={'d-md-flex d-none'}>
                    <CaruselText variableWidth={true} arrows={false} percentage={80}>
                        {researches.map(research => (
                            <div className={cx(style.wrapItem)}>
                                <Item
                                    className={cx(style.item)}
                                    imgPath={process.env.MEDIA_DOMAIN + research.value.Image}
                                    title={research.value.Title}
                                    text={research.value.Description}
                                    textClassName={cx(style.textClassName)}
                                />
                            </div>
                        ))}
                    </CaruselText>
                </div>
                <div className={'d-md-none d-flex'}>
                    <CaruselText variableWidth={true} arrows={false} percentage={100}>
                        {researches.map(research => (
                            <div className={cx(style.wrapItem)}>
                                <Item
                                    className={cx(style.item)}
                                    imgPath={process.env.MEDIA_DOMAIN + research.value.Image}
                                    title={research.value.Title}
                                    text={research.value.Description}
                                />
                            </div>
                        ))}
                    </CaruselText>
                </div>
            </div>
        );
    }
}

export default Researches;
