import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Carusel as CaruselMUI, H2 } from '@maccabi/m-ui';
import style from './Carusel.scss';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';

@autobind
class Carusel extends Component {
    constructor(props) {
        super(props);
        this.state = {};

        this.getArrayCarusel();
    }

    static propTypes = {
        carusel: PropTypes.object.isRequired,
        className: PropTypes.string
    };

    getArrayCarusel() {
        let arrayCarusel = [];
        const format = require('string-format');

        if (!!this.props.carusel && this.props.carusel.length > 0 && !!this.props.carusel[0].value) {
            for (let j = 0; j < Object.keys(this.props.carusel[0].value).length; j++) {
                let key = format('Image{0}', j + 1);
                let value = this.props.carusel[0].value[key];

                let image = format('{0}{1}', process.env.MEDIA_DOMAIN, value);
                arrayCarusel.push(image);
            }
        }

        return arrayCarusel;
    }

    render() {
      
        let arrayCarusel = this.getArrayCarusel();

        return (
            <div className={cx(style.wrap)} dir="rtl" data-hook='carusel__wrapper'>
                <H2 className={cx(style.title)}>{mLib.resources.getResource('directorship/biobank', 'Carusel_Title', 'המעבדה')}</H2>

                <CaruselMUI className={cx(style.wrap, this.props.className, style.above370)} width={310}>
                    {arrayCarusel.map(item => (
                        <img src={item} />
                    ))}
                </CaruselMUI>

                <CaruselMUI className={cx(style.wrap, this.props.className, style.under370)} width={300}>
                    {arrayCarusel.map(item => (
                        <img src={item} />
                    ))}
                </CaruselMUI>
            </div>
        );
    }
}

export default Carusel;
