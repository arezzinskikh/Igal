import React, { Component } from 'react';
import autobind from 'autobind';
import cx from 'classnames';
import style from './SampleType.scss';
import mLib from '@maccabi/m-lib';
import { Item, H2 } from '@maccabi/m-ui';
@autobind
class SamplesType extends Component {
    static propTypes = {
        samplesType: PropTypes.object.isRequired
    };

    render() {
        const { samplesType } = this.props;

        return (
            <div className={cx(style.wrap)} data-hook='sampleType__wrapper'>
                <H2 className={cx(style.title)}>
                    {mLib.resources.getResource('directorship/biobank', 'SamplesType_Title', 'סוגי הדגימות הנשמרות במסגרת מיזם טיפה למחקר')}
                </H2>
                <div className={cx(style.items)}>
                    {samplesType.map(type => (
                        <Item
                            className={cx(style.item)}
                            imgPath={process.env.MEDIA_DOMAIN + type.value.Image}
                            title={type.value.Title}
                            text={type.value.Description}
                            textClassName={cx(style.textClassName)}
                        />
                    ))}
                </div>
            </div>
        );
    }
}

export default SamplesType;
