import React, { Component } from 'react';
import autobind from 'autobind';
import cx from 'classnames';
import style from './Table.scss';
import mLib from '@maccabi/m-lib';
import { H2, Table as TableMUI, Thead, Tbody, Tr, Th, Td, Button } from '@maccabi/m-ui';

@autobind
class Table extends Component {
    static propTypes = {
        interactions: PropTypes.object.isRequired
    };

   
    onClick(interaction) {
        mLib.logs.insertCentralizedLog(4182);
        this.props.openPdf(interaction.id);
    }

    render() {
        const { interactions } = this.props;

        return (
            <div className={cx(style.wrap)} data-hook='table__wrapper'>
                <H2 className={cx(style.title)}>
                    {mLib.resources.getResource('directorship/biobank', 'Interaction_Title', 'סטטוס השתתפות במיזם')}
                </H2>
                <TableMUI>
                    <Thead>
                        <Tr>
                            <Th>{mLib.resources.getResource('directorship/biobank', 'Interaction_Date', 'תאריך')}</Th>
                            <Th>{mLib.resources.getResource('directorship/biobank', 'Interaction_Subject', 'נושא הפנייה')}</Th>
                            <Th>{mLib.resources.getResource('directorship/biobank', 'Interaction_Status', 'סטטוס')}</Th>
                            <Th>{mLib.resources.getResource('directorship/biobank', 'Interaction_File', 'קובץ')}</Th>

                        </Tr>
                    </Thead>

                    <Tbody>

                    {interactions.map((interaction, index) => (
                        <Tr>
                        <Td className={cx(style.firstTD)}>{mLib.date.formatDate(interaction.created_on)}</Td>
                        <Td className={cx(style.secondTD)}>{interaction.unified_subject}</Td>
                        <Td className={cx(style.thirdTD)}>{interaction.unified_status}</Td>
                        <Td className={cx(style.fourthTD)}>
                            {interaction.has_documents_from_maccabi && <Button reverse size='auto' color='link' onClick={() => this.onClick(interaction,`btnPdf__${index}`)}>לצפיה </Button>}
                        </Td>
                    </Tr>
                    ))}
                       
                    </Tbody>
                </TableMUI>
            </div>
        );
    }
}

export default Table;
