/* eslint-disable react/no-danger */
import React, { Component , Fragment } from 'react';
import cx from 'classnames';
import autobind from 'autobind-decorator';
import style from './Header.scss';
import { Headline, Img } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';

@autobind
class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    static propTypes = {
        biobankStats: PropTypes.object.isRequired
    };


    htmlContent = content => {
        return { __html: content };
    };

    render() {
        let bioBankIcon = require('./images/asset.png');
        const biobank_Description_DefaultText = (
            <Fragment >
                <b> טיפה למחקר</b>
                <sup>TM</sup>
                <span >
                    הוא מיזם מחקרי שמטרתו להגיע לפריצות דרך רפואיות בכדי לפתח כלים לגילוי מוקדם של מחלות בעזרת מחקרים גנטיים וביולוגיים. הדגימות שלך
                    ייקחו חלק במחקרים שבעתיד הלא רחוק יסייעו בפיתוח תרופות למחלות שאין להן מרפא כיום. בזכותך ויחד אתך , יוקם המיזם המחקרי מהגדולים
                    בעולם שישים את ישראל בחזית הקדמה הרפואית והמדעית ויעזור לשפר ולהציל חיים.
                </span>
            </Fragment>
        );
        const biobank_Description = mLib.resources.getResource('directorship/biobank', 'Biobank_Description', biobank_Description_DefaultText);

        return (
            <div className={cx(style.wrap)}>
                <div className={cx(style.wrapBackground)}>
                    <Img className={cx(style.icon)} path={bioBankIcon} alt={'טיפה למחקר'} />
                   {!!this.props.biobankStats && <div className={cx(style.box)}>
                        <div>{mLib.resources.getResource('directorship/biobank', 'Biobank_Title_Count', 'עד עכשיו הצטרפו למיזם:')}</div>
                        { <div className={cx(style.number)}>{this.props.biobankStats.total_enrolled.toLocaleString(undefined, {maximumFractionDigits:2})} </div>}
                    </div>}
                </div>
                <Headline tag="H2" priority="4" className={cx(style.subTitle)}>
                    {mLib.resources.getResource('directorship/biobank', 'Biobank_Title', 'מהו מיזם טיפה למחקר')}
                </Headline>
                <div className={cx(style.text)}>
                    <div className={cx(style.border)} dangerouslySetInnerHTML={this.htmlContent(biobank_Description)}/>
                     
                </div>
            </div>
        );
    }
}

export default Header;
