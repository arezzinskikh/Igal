import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { Card, H1, Icon } from '@maccabi/m-ui';
import style from './DetailsHeader.scss';
import mLib from '@maccabi/m-lib';

const MALE_AVATAR = 'man';
const FEMALE_AVATAR = 'woman';
const BOY_AVATAR = 'boy';
const GIRL_AVATAR = 'girl';
const BABY_BOY_AVATAR = 'babyBoy';
const BABY_GIRL_AVATAR = 'babyGirl';
const MALE_GENDER_VALUE = 'ז';

const DetailsHeader = ({ memberData, onOpenInsuranceHistory, constants }) => {
    const iconName = () => {
        const age = memberData.current_customer_info.age.years;
        const isMale = memberData.current_customer_info.sex === MALE_GENDER_VALUE;

        if (constants.minAgeBoyGirlAvatar >= age) {
            return isMale ? BABY_BOY_AVATAR : BABY_GIRL_AVATAR;
        }
        else if (constants.minAgeGrownupAvatar >= age) {
            return isMale ? BOY_AVATAR : GIRL_AVATAR;
        }
        else {
            return isMale ? MALE_AVATAR : FEMALE_AVATAR;
        }
    };

    const fullName = () => {
        return `${memberData.current_customer_info.f_name_hebrew} ${memberData.current_customer_info.l_name_hebrew}`;
    }

    const openPopup = () => {
        onOpenInsuranceHistory && onOpenInsuranceHistory();
    }

    const currentInsurance = () => {
        // TODO: REMOVE THIS WHEN MLIB FUNCTION WILL BE CREATED
        //return 'מכבי שלי';

        return mLib.customer.getCurrentInsurance();
    }

    return (
        <Card visibility="inner" className={cx(style.informationCard, 'mb-7 mb-lg-7')}>
            <div className={style.cardRow}>
                <div className={style.avatarContainer}>
                    <Icon directorship='/avatar-big' name={iconName()} iconclassname={style.avatar} />
                </div>
                <div className={style.nameIdContainer}>
                    <H1 className={style.memberName}>{fullName()} </H1>
                    <span className={style.memberId}> {memberData.current_customer_info.member_id}</span>
                </div>
            </div>
            <div className={style.content}>
                <div className={style.subContent}>
                    <div className={cx(style.contentContainer, style.first)}>
                        <span className={style.containerTitle}>{constants.personalDetailsAge}</span>
                        <span className={style.containerValue}>{memberData.current_customer_info.age.years}</span>
                    </div>
                    <div className={cx(style.contentContainer, style.second)}>
                        <span className={style.containerTitle}>{constants.personalDetailsBranch}</span>
                        <span className={style.containerValue}>{memberData.logged_customer_info.branch}</span>
                    </div>
                </div>
                <div className={cx(style.subContent, style.fixed)}>
                    <div className={cx(style.contentContainer, style.third)}>
                        <span className={style.containerTitle}>{constants.personalDetailsInsuranceGroup}</span>
                        <span className={style.containerValue}>{currentInsurance()}</span>
                    </div>
                    <div className={cx(style.contentContainer, style.forth)}>
                        <span className={style.insuranceAge} onClick={openPopup}>{constants.personalDetailsInsuranceAgeAgreement}</span>
                    </div>
                </div>
            </div>
        </Card>
    )
}

DetailsHeader.propTypes = {
    memberData: PropTypes.object,
    constants: PropTypes.shape({
        personalDetailsAge: PropTypes.string,
        personalDetailsInsuranceGroup: PropTypes.string,
        personalDetailsBranch: PropTypes.string,
        personalDetailsInsuranceAgeAgreement: PropTypes.string,
        minAgeBoyGirlAvatar: PropTypes.number,
        minAgeGrownupAvatar: PropTypes.number
    }),
    onOpenInsuranceHistory: PropTypes.func
}

export default DetailsHeader;