import React, { Component } from 'react';
import autobind from 'autobind';
import { NavLink, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { H1, H2, H3 } from '@maccabi/m-ui';

const mapStateToProps = createStructuredSelector({});

@withRouter
@connect(mapStateToProps)
@autobind
class Header extends Component {
    render() {
        return (
            <header className={style.wrap}>
                <H1>פעולות ומידע</H1>
                <H1>שלום {this.props.name}</H1>
                <H2>
                    {process.env.APP_NAME} - {process.env.APP_VERSION}
                </H2>
                <H3>חלק זה לא יופיע בסביבת ייצור</H3>
                <NavLink className={style.item} activeClassName={style.active} to="/NoCardVisit/Lobby">
                    No Card Visit
                </NavLink>
                <NavLink className={style.item} activeClassName={style.active} to="/LettersForMember/Lobby">
                    Letters For Member
                </NavLink>
            </header>
        );
    }
}

export default Header;
