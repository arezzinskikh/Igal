import React from 'react';
import {Modal} from '@maccabi/m-ui';
import PropTypes from 'prop-types';

import {insertLog} from '../../../containers/BabyRegistration/logFile';
import {STATIC_TXT_MODALS} from './constants';

const BabyRegistrationModal = (props) => {
    const {modalName, isOpen} = props;

    const modalHeader = () => {
        switch (modalName) {
            case STATIC_TXT_MODALS.nameForAbaby.name: 
                const {modalByGender} = props;
                return STATIC_TXT_MODALS.nameForAbaby.title[modalByGender];
            default:
                return STATIC_TXT_MODALS[modalName].title;
        }
    }

    const modalBody = () => {
        switch (modalName) {
            case STATIC_TXT_MODALS.nameForAbaby.name: 
                const {modalByGender} = props;
                return STATIC_TXT_MODALS.nameForAbaby.subtitle[modalByGender];
            case STATIC_TXT_MODALS.vetekHorim.name:
                const {babyNameForModal} = props;
                return STATIC_TXT_MODALS.vetekHorim.subtitle.vetekHorimPartOne + babyNameForModal + STATIC_TXT_MODALS.vetekHorim.subtitle.vetekHorimPartTwo
            default:
                return STATIC_TXT_MODALS[modalName].subtitle;
        }
    }
    
    const onToggleModal = () => {
        const log = STATIC_TXT_MODALS[modalName]?.log;
        log && log.closeBtn && insertLog({elementId:log.closeBtn, elementInPage:log.elementInPage, actionId:log.actionId})
        props.onToggle()
    }

    const onPrimaryBtnClick = () => {
        const log = STATIC_TXT_MODALS[modalName]?.log;
        log && log.primaryBtn && insertLog({elementId:log.primaryBtn, elementInPage:log.elementInPage, actionId:log.actionId})
        props.primaryBtnClick()
    }

    const onSecondaryBtnClick = () => {
        const log = STATIC_TXT_MODALS[modalName]?.log;
        log && log.secondaryBtn && insertLog({elementId:log.secondaryBtn, elementInPage:log.elementInPage, actionId:log.actionId})
        props.secondaryBtnClick()
    }
    
    return (
        <div>
            <Modal 
                isOpen={isOpen}
                icon={props.icon ? props.icon : 'attention-big'}
                toggle={() => onToggleModal()}
                header={modalName && modalHeader()}
                body={modalName && modalBody()}
                primaryButton={modalName && STATIC_TXT_MODALS[modalName].primaryBtn}
                primaryButtonClick={() => onPrimaryBtnClick()}
                secondaryButton={modalName && STATIC_TXT_MODALS[modalName].secondaryBtn ? STATIC_TXT_MODALS[modalName].secondaryBtn : null}
                secondaryButtonClick={props.secondaryBtnClick ? () => onSecondaryBtnClick() : null}
            />
        </div>
    )

}

BabyRegistrationModal.propTypes = {
    modalName: PropTypes.string.isRequired,
    isOpen: PropTypes.bool.isRequired,
    icon: PropTypes.string,
    onToggle: PropTypes.func,
    primaryBtnClick: PropTypes.func,
    secondaryBtnClick: PropTypes.func
};

export default BabyRegistrationModal;