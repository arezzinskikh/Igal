import mLib from '@maccabi/m-lib';

export const PAGE_ALIAS = 'directorship/BabyRegistration/';
export const SUMMARY_AND_REGISTRATION_PAGE_ALIAS = "directorship/BabyRegistration/RegistrationSummary/";

export const MODAL_BY_STATUS_AND_NAME = {
    "02": 'alreadyRegistered',
    "03": 'errorInProgress', 
    "04": 'errorInProgress',
    "05": 'errorInProgress',
    "98": 'errorInProgress',
    MALE_PARENT: 'maleParent',
    MALE_PARENT_BTL_REQUIRED_STATUS: "1",
    ELIGIBLE: '01'
}

export const STATIC_TXT_MODALS = {
    maleParent: {
        name: 'maleParent',
        title: mLib.resources.getResource(PAGE_ALIAS, 'Modal_title_maleParent', 'להשלמת תהליך הרישום, יש להסדיר קודם את רישום התינוק בביטוח לאומי.'),
        subtitle: mLib.resources.getResource(PAGE_ALIAS, 'Modal_sub_maleParent', 'במידת הצורך ניתן לפנות למוקד הטלפוני או למרכז הרפואי הקרוב.'),
        primaryBtn: mLib.resources.getResource(PAGE_ALIAS, 'Modal_btn_maleParent', 'הבנתי, תודה'),
        log: {
            closeBtn: 4362,
            primaryBtn: 4360,
            elementInPage: PAGE_ALIAS,
            actionId: 1343
        }
    },
    alreadyRegistered:  {
        name: 'alreadyRegistered',
        title: mLib.resources.getResource(PAGE_ALIAS, 'Modal_title_alreadyInMyMaccabi', 'אנחנו מכירים?'),
        subtitle: mLib.resources.getResource(PAGE_ALIAS, 'Modal_sub_alreadyRegistered', 'מספר תעודת הזהות שהוזן נמצא במערכות מכבי'),
        primaryBtn: mLib.resources.getResource(PAGE_ALIAS, 'Modal_btn_alreadyRegistered', 'הבנתי, תודה'),
        log: {
            closeBtn: 4364,
            primaryBtn: 4363,
            elementInPage: PAGE_ALIAS,
            actionId: 1343
        }
    },
    errorInProgress: {
        name: 'errorInProgress',
        title: mLib.resources.getResource(PAGE_ALIAS, 'Modal_title_errorInProgress', 'לצערנו לא ניתן להשלים את פעולת הרישום'),
        subtitle: mLib.resources.getResource(PAGE_ALIAS, 'Modal_sub_errorInProgress', 'ניתן לפנות למוקד "מכבי ללא הפסקה" 3555*'),
        primaryBtn: mLib.resources.getResource(PAGE_ALIAS, 'Modal_btn_errorInProgress', 'הבנתי, תודה'),
        log: {
            closeBtn: 4366,
            primaryBtn: 4365,
            elementInPage: PAGE_ALIAS,
            actionId: 1343
        }
    },
    nameForAbaby: {
        name: 'nameForAbaby',
        title: {
            boy: mLib.resources.getResource(PAGE_ALIAS, 'Modal_title_nameForBabyBoy', 'נראה שעוד לא בחרת שם לתינוק החדש'),
            girl: mLib.resources.getResource(PAGE_ALIAS, 'Modal_title_nameForBabyGirl', 'נראה שעוד לא בחרת שם לתינוקת החדשה'),
        },
        subtitle: {
            boy: mLib.resources.getResource(PAGE_ALIAS, 'Modal_sub_nameForBabyBoy','לא הוזן שם פרטי לתינוק. באפשרותך להשלימו מאוחר יותר במוקד מכבי ללא הפסקה 3555* או במרכז הרפואי הקרוב לביתך'),
            girl: mLib.resources.getResource(PAGE_ALIAS, 'Modal_sub_nameForBabyGirl','לא הוזן שם פרטי לתינוקת. באפשרותך להשלימו מאוחר יותר במוקד מכבי ללא הפסקה 3555* או במרכז הרפואי הקרוב לביתך'),
        },
        primaryBtn: mLib.resources.getResource(PAGE_ALIAS, 'Modal_btn_p_nameForBaby', 'המשך לכיסוי ביטוחי'),
        secondaryBtn: mLib.resources.getResource(PAGE_ALIAS, 'Modal_btn_s_nameForBaby', 'חזרה לעריכת הטופס'),
        log: {
            closeBtn: 4369,
            primaryBtn: 4367,
            secondaryBtn: 4368,
            elementInPage: PAGE_ALIAS,
            actionId: 1343
        }
    },
    vetekHorim: {
        name: 'vetekHorim',
        title: mLib.resources.getResource(PAGE_ALIAS, 'Modal_title_vetekHorim', 'לתשומת ליבך'),
        subtitle: {
            vetekHorimPartOne: mLib.resources.getResource(PAGE_ALIAS, 'Modal_sub_vetekHorimPartOne','בחירה זו לא תשמור ל'),
            vetekHorimPartTwo: mLib.resources.getResource(PAGE_ALIAS, 'Modal_sub_vetekHorimPartTwo',' על זכויות ותק ההורים '),
        },
        primaryBtn: mLib.resources.getResource(PAGE_ALIAS, 'Modal_btn_p_vetekHorim', 'הבנתי, תודה'),
        log: {
            primaryBtn: 4384,
            elementInPage: PAGE_ALIAS,
            actionId: 1343
        }
    },
    addressNotValid: {
        name: 'addressNotValid',
        title: mLib.resources.getResource(SUMMARY_AND_REGISTRATION_PAGE_ALIAS,'Modal_title_addressNotValid', "על מנת לקבל כרטיסים מגנטיים, יש לעדכן את הכתובת במכבי"),
        subtitle: mLib.resources.getResource(SUMMARY_AND_REGISTRATION_PAGE_ALIAS, 'Modal_sub_addressNotValid', 'הכתובת הרשומה במכבי כנראה שגויה. נא לעדכן כתובת עדכנית עבור משלוח כרטיסים מגנטיים.'),
        primaryBtn: mLib.resources.getResource(SUMMARY_AND_REGISTRATION_PAGE_ALIAS, 'Modal_btn_p_addressNotValid', 'המשך'),
        secondaryBtn: mLib.resources.getResource(SUMMARY_AND_REGISTRATION_PAGE_ALIAS, 'Modal_btn_s_addressNotValid', 'לעדכון כתובת'),
        log: {
            primaryBtn: 4385,
            secondaryBtn: 4386,
            elementInPage: SUMMARY_AND_REGISTRATION_PAGE_ALIAS,
            actionId: 1343
        }
    }
};
