import React from 'react';
import {H1} from '@maccabi/m-ui';
import style from './SelectedDate.scss';
import {SUMMARY_STATIC_TXT} from '../../../../containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/constants';

const SelectedDate = props => {
    return (
        <div>        
            <div className={style.selectedDateWrap}>
                <H1 className={style.selectedDate}>{SUMMARY_STATIC_TXT.subtitle.selectedDate + props.selectedDate}</H1>
            </div>    
        </div>     
    );
   
}

export default SelectedDate;
