import React, { Component } from 'react';
import { withRouter }from 'react-router-dom';
import autobind from 'autobind';
import {H4,Button,IconLoader} from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import moment from 'moment';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';

import style from './Confirmation.scss'

import {SUMMARY_STATIC_TXT} from '../../../../containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/constants';
import {STATIC_TXT} from '../../../../containers/BabyRegistration/constants';
import {selectBabyRegistrationResponse} from '../../../../containers/BabyRegistration/selectors';
import {resetState} from '../../../../containers/BabyRegistration/actions';

import BabyIcon from '../BabyIcon/BabyIcon';
import Insurance from '../Insurance/Insurance';
import SelectedDate from '../SelectedDate/SelectedDate';
import KerenMaccabiSummary from '../KerenMaccabiSummary/KerenMaccabiSummary';
import MagneticCards from '../MagneticCards/MagneticCards';
import EmailConfirmation from '../EmailConfirmation/EmailConfirmation';
import { insertLog } from '../../../../containers/BabyRegistration/logFile';

const mapDispatchToProps = (dispatch) => ({
    resetState: () => dispatch(resetState()),
});

const mapStateToProps = createStructuredSelector({
    ragistrationResponse: selectBabyRegistrationResponse
});

@connect(mapStateToProps, mapDispatchToProps)
@autobind
class Confirmation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: true,
            emailToPresent: false
        }
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        const {ragistrationResponse} = this.props;
        const memberData = mLib.saveData.customerData.get();
        if (ragistrationResponse) {
            const emailToPresent = memberData.current_customer_info.email ? memberData.current_customer_info.email : false;
            this.setState({
                isLoading: false,
                emailToPresent: emailToPresent
            })
        }
    }

    onFinishButton() {
        const log = SUMMARY_STATIC_TXT?.button?.finish?.log;
        log && insertLog(log)
        this.props.resetState();
        this.props.history.push("/directorship/BabyRegistration/")
    }

    get successTitle(){
        const {firstStepSavedForm} = this.props;
        const successPageTitle = `${firstStepSavedForm.babyFirstName.value ? 
            firstStepSavedForm.babyFirstName.value : firstStepSavedForm.babyFirstName.default} 
        ${firstStepSavedForm.babySurname.value ? firstStepSavedForm.babySurname.default : ""}`
        return successPageTitle
    }

    render() {  
        const {emailToPresent,isLoading} = this.state;
        const {firstStepSavedForm,secondStepSavedForm,isAddressValid,addressToPresent,
            chosenShabanInsurance,chosenStartDate,ragistrationResponse} = this.props;
        if (isLoading) return <IconLoader size="lg"/>
        const {shabanRegistrationFailed,kerenMaccabiRegistrationFailed,magneticCardsFailed} = ragistrationResponse;
        return (
            <div>
                <BabyIcon babyGender={firstStepSavedForm.babyGender.value}/>

                <H4 className={style.pageHeadlineTitle}>
                    {SUMMARY_STATIC_TXT.SuccessPageTitle + this.successTitle}
                </H4>

                {chosenShabanInsurance &&
                    <div className={style.shabanWrap}>
                        <Insurance selectedInsuranceIndex={secondStepSavedForm.insurance.value}
                            failed={shabanRegistrationFailed}
                        />
                        {!shabanRegistrationFailed &&
                            <SelectedDate 
                                selectedDate={chosenStartDate === STATIC_TXT.chooseTime.startingBirthDate.index ?
                                mLib.date.formatDate(firstStepSavedForm.babyBirthDate.value.split("T")[0]) :
                                moment().format('DD/MM/YYYY')}
                            />
                        }
                    </div>
                }
                        
                <div className={style.successPageSeparator}></div>

                {secondStepSavedForm.kerenMaccabi.value &&
                    <KerenMaccabiSummary failed={kerenMaccabiRegistrationFailed}/>
                }
                
                <div className={style.emailAndCardsWrap}>
                    {emailToPresent && <EmailConfirmation emailAddressToPresent={emailToPresent}/>}
                    {emailToPresent && <div className={style.verticalSeperatorConfirmationPage}></div>}
                    <MagneticCards emailToPresent={emailToPresent} isConfirmationPage={true} isAddressValid={isAddressValid} addressToPresent={addressToPresent} failed={magneticCardsFailed}/>
                </div>

                <div className={style.confirmationDisclaimer}>{SUMMARY_STATIC_TXT.SuccessPageDisclaimer}</div>

                <Button color="primary" onClick={() => this.onFinishButton()} size="md" className={style.finishBtn} maincta={'true'}>
                    {SUMMARY_STATIC_TXT.button.finish.text}
                </Button>
            </div>
        );
    }
}

export default withRouter(Confirmation);