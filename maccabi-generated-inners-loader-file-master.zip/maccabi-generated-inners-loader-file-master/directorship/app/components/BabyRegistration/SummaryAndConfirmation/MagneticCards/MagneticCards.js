import React ,{Fragment} from 'react';
import cx from 'classnames';
import {Icon,Button} from '@maccabi/m-ui';

import style from './MagneticCards.scss';
import {SUMMARY_STATIC_TXT} from '../../../../containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/constants';

const MagneticCards = props => {

    const getSubtitleForConfirmationPage = () => {
        let subtitle = {text:"", styling:""};
        if (props.failed) {
            subtitle = {text: SUMMARY_STATIC_TXT.subtitle.magneticCardsFail, styling: "confirmationSubtitleFail"}
        } else if (!props.isAddressValid) {
            subtitle = {text: SUMMARY_STATIC_TXT.subtitle.addressNotValid, styling: "magneticCardsNotValid"}
        } else {
            subtitle = {text: SUMMARY_STATIC_TXT.subtitle.magneticCards, styling: "confirmationPageSubtitle"}
        }
        return subtitle
    }
    
    return (
        <Fragment>
            {props.isConfirmationPage ?
                <div className={cx(style.magneticCardsWrapConfirmationPage, props.emailToPresent && style.halfWidth)}>
                    <Icon name={"id-icon"} className={cx(style.magneticCardsIcon,props.failed && style.iconFailed)}/>
                    <p className={style[getSubtitleForConfirmationPage().styling]}>
                        {getSubtitleForConfirmationPage().text}
                    </p>
                    <p className={props.failed ? style.failMessage : style.confirmationAddress}>
                        {props.failed ? SUMMARY_STATIC_TXT.subtitle.magneticCardsFailRemark : props.addressToPresent}
                    </p>
                </div>
                :
                <div className={style.magneticCardsWrapSummaryPage}>
                    {!props.isAddressValid &&
                        <p className={style.magneticCardsNotValid}>{SUMMARY_STATIC_TXT.subtitle.addressNotValid}</p>
                    }
                    <p className={style.magneticCards}>{SUMMARY_STATIC_TXT.subtitle.magneticCards + ": " + props.addressToPresent}</p>
                    <Button onClick={() => props.onContinueToChangeAddress()} color="link" reverse className={style.updateAddress}>
                        {SUMMARY_STATIC_TXT.button.changeAddress.text}
                    </Button>
                </div> 
            }
        </Fragment>
    );
   
}

export default MagneticCards;
