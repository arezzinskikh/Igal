import React from 'react';
import { withRouter }from 'react-router-dom';
import moment from 'moment';
import {H4,CoupleButtons} from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';

import style from './Summary.scss'

import {SUMMARY_STATIC_TXT} from '../../../../containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/constants';
import {STATIC_TXT} from '../../../../containers/BabyRegistration/constants';
import BabyIcon from '../BabyIcon/BabyIcon';
import BabyInfoSummaryDetails from '../BabyInfoSummaryDetails/BabyInfoSummaryDetails';
import Insurance from '../Insurance/Insurance';
import SelectedDate from '../SelectedDate/SelectedDate';
import KerenMaccabiSummary from '../KerenMaccabiSummary/KerenMaccabiSummary';
import MagneticCards from '../MagneticCards/MagneticCards';

const Summary = props => {
    const {firstStepSavedForm,secondStepSavedForm,isAddressValid,addressToPresent,
        approveRegistration,goBackToFillRegistrationForm,onContinueToChangeAddress,
        chosenShabanInsurance,chosenStartDate} = props;
    return (
            <div>
                <BabyIcon babyGender={firstStepSavedForm.babyGender.value}/>

                <H4 className={style.pageHeadlineTitle} hook="summaryHeadlineTitle">
                    {firstStepSavedForm.babyGender.value === "תינוק" ? SUMMARY_STATIC_TXT.SummaryPageTitleBoy : SUMMARY_STATIC_TXT.SummaryPageTitleGirl}
                </H4>

                <BabyInfoSummaryDetails firstStepSavedForm={firstStepSavedForm}/>

                {chosenShabanInsurance &&
                    <div className={style.shabanWrap}>
                        <Insurance selectedInsuranceIndex={secondStepSavedForm.insurance.value}/> 
                        <SelectedDate 
                            selectedDate={chosenStartDate === STATIC_TXT.chooseTime.startingBirthDate.index ?
                            mLib.date.formatDate(firstStepSavedForm.babyBirthDate.value.split("T")[0]) :
                            moment().format('DD/MM/YYYY')}
                        />
                    </div>
                } 
                
                <div className={style.summaryPageSeparator}></div>

                {secondStepSavedForm.kerenMaccabi.value &&
                    <KerenMaccabiSummary/>
                }

                <MagneticCards isAddressValid={isAddressValid} 
                addressToPresent={addressToPresent} onContinueToChangeAddress={onContinueToChangeAddress}/>

                <CoupleButtons
                    firstText={SUMMARY_STATIC_TXT.button.approveRegistration.text} 
                    secondText={SUMMARY_STATIC_TXT.button.returnToEditRegistration.text}
                    firstOnClick={() => approveRegistration()}
                    secondOnClick={() => goBackToFillRegistrationForm()}
                    classname={style.coupleBtnsSummaryPage}
                    firstclassname={style.coupleBtnsSummaryPageFirst}
                />
            
        </div>      
);
}

export default withRouter(Summary);