import React from 'react';
import {Icon} from '@maccabi/m-ui';
import style from './BabyIcon.scss';

const BabyIcon = props => {
    return (
        <div>
            {props.babyGender === "תינוק" ?
                <Icon name={"baby-boy"} className={style.genderIcon}/>
            :
                <Icon name={"baby-girl"} className={style.genderIcon}/>
            }
        </div>
    );
   
}

export default BabyIcon;