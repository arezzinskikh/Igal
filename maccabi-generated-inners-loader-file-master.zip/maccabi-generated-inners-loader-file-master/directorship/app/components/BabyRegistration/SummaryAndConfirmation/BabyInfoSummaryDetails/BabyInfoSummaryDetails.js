import React from 'react';
import {PipeDivider} from '@maccabi/m-ui';
import cx from 'classnames';

import style from './BabyInfoSummaryDetails.scss';
import mLib from '@maccabi/m-lib';

const BabyInfoSummaryDetails = ({firstStepSavedForm}) => {
    return (
        <PipeDivider isGray="true" isAfter="true" height={"29"} className={style.pipeDividerBabyInfo} itemClassName={style.pipeItemClass}>
            <div className="ml-5">
                <div className={style.pipeDividerTitle}>שם פרטי</div>
                <div className={style.pipeDividerInfo}>{firstStepSavedForm.babyFirstName.value ? firstStepSavedForm.babyFirstName.value : firstStepSavedForm.babyFirstName.default}</div>
            </div>  
            <div className="ml-5 mr-5">
                <div className={style.pipeDividerTitle}>שם משפחה</div>
                <div className={style.pipeDividerInfo}>{firstStepSavedForm.babySurname.value ? firstStepSavedForm.babySurname.value : firstStepSavedForm.babySurname.default}</div>
            </div>      
            <div className="ml-5 mr-5">
                <div className={style.pipeDividerTitle}>תעודת זהות</div>
                <div className={cx(style.pipeDividerInfo,style.noOverFlow)}>{firstStepSavedForm.babyId.value}</div>
            </div>      
            <div className="ml-md-5 mr-md-5">
                <div className={style.pipeDividerTitle}>תאריך לידה</div>
                <div className={style.pipeDividerInfo}>{mLib.date.formatDate(firstStepSavedForm.babyBirthDate.value.split("T")[0])}</div>
            </div>   
        </PipeDivider>
    );
   
}

export default BabyInfoSummaryDetails;
