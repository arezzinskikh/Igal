import React from 'react';
import {H2,Icon} from '@maccabi/m-ui';
import style from './Insurance.scss';
import cx from 'classnames';

import {SUMMARY_STATIC_TXT} from '../../../../containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/constants';
import {shabanInsuranceTypes} from '../../../../containers/BabyRegistration/constants';

const Insurance = ({selectedInsuranceIndex,failed}) => {

    const insuranceType = shabanInsuranceTypes.filter(shaban=>shaban.index === selectedInsuranceIndex)[0]
    return (
        <div className={style.insuranceSummaryWrap}>
            <H2 className={style.selectedInsurance}>{SUMMARY_STATIC_TXT.subtitle.selectedInsurance}</H2>
            <div>
                <div className={style.insuranceIconSummary}>
                    <Icon name={insuranceType.icon} fill={false}
                    className={cx(style.insuranceIconSummary, style[insuranceType.name])} />
                </div>
                {failed ?
                <div>
                    <p className={style.lblInsuranceFailed}>{SUMMARY_STATIC_TXT.subtitle.selectedInsuranceFail}</p>
                    <p className={style.failMessage}>{SUMMARY_STATIC_TXT.subtitle.failMessage}</p>
                </div> :
                <div>
                    <p className={style.lblInsuranceSummary}>{insuranceType.text}</p>
                </div>
                }
            </div>
        </div>
    );
   
}

export default Insurance;
