import React from 'react';
import {Icon} from '@maccabi/m-ui';

import style from './EmailConfirmation.scss';
import {SUMMARY_STATIC_TXT} from '../../../../containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/constants';

const EmailConfirmation = props => {
    return (        
        <div className={style.emailWrapConfirmationPage}>
            <Icon name={"envelope"} className={style.emailIcon}/>
            <p className={style.confirmationPageEmail}>{SUMMARY_STATIC_TXT.subtitle.emailConfirmation}</p>
            <p className={style.confirmationEmailAddress}>{props.emailAddressToPresent}</p>
        </div>
    );
   
}

export default EmailConfirmation;
