import React from 'react';
import {H2} from '@maccabi/m-ui';

import style from './KerenMaccabiSummary.scss';
import {STATIC_TXT} from '../../../../containers/BabyRegistration/constants';
import {SUMMARY_STATIC_TXT} from '../../../../containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/constants';

const KerenMaccabiSummary = props => {
    return (
        <div className={style.kerenMaccabiSummaryWrap}>
            <H2 className={style.kerenMaccabiInsurance}>{STATIC_TXT.kerenMaccabi.text}</H2>
            {props.failed ?
                <div>
                    <p className={style.kerenMaccabilabelFailed}>{SUMMARY_STATIC_TXT.subtitle.kerenMaccabiFail}</p>
                    <p className={style.failMessage}>{SUMMARY_STATIC_TXT.subtitle.failMessage}</p>
                </div> :
                <div>
                    <p className={style.kerenMaccabilblSummary}>{STATIC_TXT.kerenMaccabi.remark}</p>
                </div>
            }
        </div>
    );
   
}

export default KerenMaccabiSummary;
