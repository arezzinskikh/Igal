import React from 'react';
import mLib from '@maccabi/m-lib';
import {Pipe,PipeItem} from '@maccabi/m-ui';
import cx from 'classnames';

import style from './AdditionalInfoLinks.scss';
import {STATIC_TXT} from '../../../containers/BabyRegistration/constants.js';

const AdditionalInfoLinks = () => {
    const isKosher = mLib.site.isKosher();
    return (
        <div>
            {!isKosher && 
            <div className={style.additionalInfoDescription}>
                <p data-hook="Description" className={"mr-2 mr-sm-0 ml-sm-1"}>{STATIC_TXT.additionalInfoLinksText}</p>
                <Pipe className={style.pipeItems} isAfter="true">
                    {STATIC_TXT.additionalInfoLinks.map((item,index) => (
                        <PipeItem>
                            <a href={item.link}
                            className={cx("mr-2 ml-2", index === 0 && "mr-sm-0")} 
                            key={index} target="_blank">{item.text}</a>
                        </PipeItem>
                    )
                    )}
                </Pipe>
            </div>
            }
        </div>
    );
}

export default AdditionalInfoLinks;
