import React, {Component} from 'react';
import autobind from 'autobind';
import { withRouter } from 'react-router-dom';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import {MODAL_BY_STATUS_AND_NAME} from '../BabyRegistrationModal/constants';
import {setResetSteps} from '../../../containers/BabyRegistration/actions';
import {selectIsFirstStepFinished,selectEligibilityResponse} from '../../../containers/BabyRegistration/selectors';
import FirstStepBabyInfo from './FirstStepBabyInfo/FirstStepBabyInfo';
import SecondStepChooseInsurance from './SecondStepChooseInsurance/SecondStepChooseInsurance';
import BabyRegistrationModal from '../BabyRegistrationModal/BabyRegistrationModal';

const mapDispatchToProps = (dispatch) => ({
    setResetSteps: () => dispatch(setResetSteps())
});
const mapStateToProps = createStructuredSelector({
    isFirstStepFinished: selectIsFirstStepFinished,
    eligibilityResponse: selectEligibilityResponse
});

@connect(mapStateToProps, mapDispatchToProps)
@autobind
class FillRegistrationForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            canProceedToSecondStepInForm: false,
            showModal: false
        }
    }

    componentDidMount() {
        this.props.setResetSteps()
    }

    componentDidUpdate(prevProps) {
        const {isFirstStepFinished,eligibilityResponse,setResetSteps} = this.props;
        // if first step filled and there's eligibilityResponse from server, we check if we can proceed to 2nd step - 
        // if there's modal to pop - we !can-not! proceed to 2nd step
        if (prevProps.isFirstStepFinished !== isFirstStepFinished && isFirstStepFinished && eligibilityResponse) {
            const {basicEligibilityStatus,btlRequiredStatus} = eligibilityResponse;
            const modalToPop = basicEligibilityStatus === MODAL_BY_STATUS_AND_NAME.ELIGIBLE && btlRequiredStatus === MODAL_BY_STATUS_AND_NAME.MALE_PARENT_BTL_REQUIRED_STATUS 
            ? MODAL_BY_STATUS_AND_NAME.MALE_PARENT : MODAL_BY_STATUS_AND_NAME[basicEligibilityStatus]
            if (modalToPop) {
                setResetSteps()
                this.setState({showModal: true, modalName: modalToPop})
            } else {
                this.setState({canProceedToSecondStepInForm: true})
            }
        }
       
    }

    render() {
        const {showModal,modalName,canProceedToSecondStepInForm} = this.state;
        const {isFirstStepFinished} = this.props;
        return (
            <div>
                <BabyRegistrationModal isOpen={showModal} 
                    primaryBtnClick={() => this.setState({showModal: false})} 
                    modalName={modalName} onToggle={() => this.setState({showModal: false})}
                />

                {!isFirstStepFinished &&
                <FirstStepBabyInfo/>
                }

                {isFirstStepFinished && canProceedToSecondStepInForm && 
                <SecondStepChooseInsurance/>
                }
            </div>
        );
    }
}

FillRegistrationForm.propTypes = {
    isFirstStepFinished: PropTypes.bool.isRequired,
};

export default withRouter(FillRegistrationForm);