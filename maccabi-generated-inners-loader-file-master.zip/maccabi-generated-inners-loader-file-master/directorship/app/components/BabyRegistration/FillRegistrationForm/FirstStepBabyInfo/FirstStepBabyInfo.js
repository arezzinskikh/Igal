import React, {Component} from 'react';
import { withRouter }from 'react-router-dom';
import autobind from 'autobind';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import {H4,H2,CoupleButtons} from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import PropTypes from 'prop-types';

import style from './FirstStepBabyInfo.scss';
import {getBabyInsuranceEligibility,updateFormValue,updateFormError,cleanForm,updateDefaultValues} from '../../../../containers/BabyRegistration/actions';
import {selectFirstStepBabyInfoForm,selectIsFirstStepFinished} from '../../../../containers/BabyRegistration/selectors';
import { STATIC_TXT, FORM, VALIDATION_ERRORS, GENDER_LIST, SURNAME_DEFAULT_VALUE } from '../../../../containers/BabyRegistration/constants';
import {STATIC_TXT_MODALS} from '../../BabyRegistrationModal/constants'
import ChooseBabyGender from './ChooseBabyGender/ChooseBabyGender';
import InsertBabyDetails from './InsertBabyDetails/InsertBabyDetails';
import BabyRegistrationModal from '../../BabyRegistrationModal/BabyRegistrationModal';
import {insertLog} from '../../../../containers/BabyRegistration/logFile';

const mapDispatchToProps = (dispatch) => ({
    updateFormValue: (field,value,formPart=FORM.FIRST_PART) => dispatch(updateFormValue(field, value, formPart)),
    updateFormError: (field,value,formPart=FORM.FIRST_PART) => dispatch(updateFormError(field, value, formPart)),
    cleanForm: () => dispatch(cleanForm()),
    updateDefaultValues: (field,value,formPart=FORM.FIRST_PART) => dispatch(updateDefaultValues(field, value, formPart)),
    getBabyInsuranceEligibility: (payload) => dispatch(getBabyInsuranceEligibility(payload))
});

const mapStateToProps = createStructuredSelector({
    form: selectFirstStepBabyInfoForm,
    isFirstStepFinished: selectIsFirstStepFinished
});

@connect(mapStateToProps, mapDispatchToProps)
@autobind
class FirstStepBabyInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showBabyFirstNameModal: false,
            babyNameModalPoppedOnce: false
        };
    }

    onInputFieldChange = (field, value) => {
        this.setRouteLeavingGuard()
        this.props.updateFormValue(field,value)
    }

    setRouteLeavingGuard =()=> {
        const propsLeaving = {
            shouldBlockNavigation: true,
            navigate: this.props.history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    onClickToChooseInsuranceStep() {
        const log = STATIC_TXT?.button?.continueToInsuranceCoverage?.log;
        log && insertLog(log)

        const {form} = this.props;
        const {babyNameModalPoppedOnce} = this.state; 
        const canPass = this.validateFields()
        if (!canPass) {return}

        if (!form[FORM.FIRST_NAME].value && !babyNameModalPoppedOnce) {
            this.setState({ showBabyFirstNameModal: true,babyNameModalPoppedOnce: true })
        } else {
            this.submitFirstStepBabyInfo()
        }
    }

    validateFields() {
        const {form, updateFormError} = this.props;
        let canPass = true;
        for (const [formField, fieldDetails] of Object.entries(form)) {
            if (fieldDetails.mustEnterField === true && !fieldDetails.value) {
                canPass = false
                updateFormError(formField,VALIDATION_ERRORS[formField])
            }
            if (fieldDetails.error) { canPass = false }
        }
        return canPass
    }


    onContinueToChooseInsuranceAfterModal() {
        this.setState({showBabyFirstNameModal: false}, ()=> this.submitFirstStepBabyInfo())
    }

    submitFirstStepBabyInfo() {
        const {form,getBabyInsuranceEligibility} = this.props;
        this.saveDefaultValues()
        getBabyInsuranceEligibility(form[FORM.ID].value)
    }

    saveDefaultValues() {
        const {form,updateDefaultValues} = this.props;
        if (!form[FORM.FIRST_NAME].value) {
            updateDefaultValues(FORM.FIRST_NAME,form[FORM.GENDER].value)
        }
        if (!form[FORM.SURNAME].value) {
            updateDefaultValues(FORM.SURNAME,SURNAME_DEFAULT_VALUE)
        }
    }
    render() {
        const {form,updateFormError,cleanForm} = this.props;
        const {showBabyFirstNameModal} = this.state;
        return (
            <div className={style.fillBabyInfoPageWrap}>

                <BabyRegistrationModal isOpen={showBabyFirstNameModal}
                    primaryBtnClick={this.onContinueToChooseInsuranceAfterModal}
                    onToggle={() => this.setState({showBabyFirstNameModal: false})}
                    secondaryBtnClick={() => this.setState({showBabyFirstNameModal: false})} 
                    modalName={STATIC_TXT_MODALS.nameForAbaby.name} 
                    modalByGender={form[FORM.GENDER].value === GENDER_LIST[0].text ? GENDER_LIST[0].valueName :  GENDER_LIST[1].valueName}
                />
                
                <div className={style.fillBabyInfoTitleWrap}>
                    <H4 className={style.pageTitle}>{STATIC_TXT.title.congratulations}</H4>
                    <H2 className={style.pageSubTitle}>{STATIC_TXT.subtitle.registerBabyAsMaccabiMember}</H2>
                </div>

                <ChooseBabyGender
                    onChange = {this.onInputFieldChange}
                    error={form[FORM.GENDER].error}
                    babyGender={form[FORM.GENDER].value}
                    updateErrors={updateFormError}
                />
                
                 <InsertBabyDetails
                    onChange = {this.onInputFieldChange}
                    updateErrors={updateFormError}
                    form = {form}
                /> 

                <CoupleButtons
                    firstText={STATIC_TXT.button.continueToInsuranceCoverage.text} 
                    secondText={STATIC_TXT.button.cleanForm.text}
                    firstOnClick={() => this.onClickToChooseInsuranceStep()}
                    secondOnClick={() => cleanForm()}
                    classname ={style.coupleBtnsStepOnePage}
                    firstclassname={style.coupleBtnsStepOnePageFirst}
                    secondclassname={style.coupleBtnsStepOnePageSecond}
                />
            </div>
        );
    }
}

FirstStepBabyInfo.propTypes = {
    form: PropTypes.object.isRequired,
    updateFormError: PropTypes.func.isRequired,
    updateFormValue: PropTypes.func.isRequired,
    updateDefaultValues: PropTypes.func.isRequired,
    cleanForm: PropTypes.func.isRequired,
    getBabyInsuranceEligibility: PropTypes.func.isRequired
};

export default withRouter(FirstStepBabyInfo);