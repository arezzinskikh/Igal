import React from 'react';
import {Input,DatePicker} from '@maccabi/m-ui';
import PropTypes from 'prop-types';

import style from './InsertBabyDetails.scss';
import { FORM, VALIDATION_ERRORS} from '../../../../../containers/BabyRegistration/constants';
import {insertFormLog} from '../../../../../containers/BabyRegistration/logFile';

const InsertBabyDetails = props => {

    const validateID = value => {
        let errorInValue = false;
        if (value) {
            const minNum = 100000000
            const maxNum = 999999999
            if (value < minNum || value > maxNum) {
                errorInValue = true;
            } 
            let mone = 0, incNum;
            for (let i=0; i < 9; i++) {
               incNum = Number(value.charAt(i));
               incNum *= (i%2)+1;
               if (incNum > 9)
                  incNum -= 9;
               mone += incNum;
            }
            if (mone%10 !== 0) {
                errorInValue = true;
            }
        }
        props.updateErrors(FORM.ID, errorInValue ? VALIDATION_ERRORS.babyId : VALIDATION_ERRORS.noError)
        value && !errorInValue && insertFormLog(FORM.ID,value)
    }

    const validateName = (field,value) => {
        /* eslint-disable-next-line */
        const validList = /^[\u0590-\u05fe][\u0590-\u05fe'\s]*$/i
        const isValidCharOnly = validList.test(value)
        if (value && !isValidCharOnly) return
        return props.onChange(field, value)
    }

    const changeDateField = (e) => {
        const dateString = e && e._d && e._d.toISOString().slice(0, -5)
        props.onChange(FORM.BIRTHDATE,dateString)
        props.updateErrors(FORM.BIRTHDATE, VALIDATION_ERRORS.noError)
        dateString && insertFormLog(FORM.BIRTHDATE,dateString)
    }

    const birthdayMaxDate = () => {
        return new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() + 1)
    }

    const birthdayMinDate = () => {
        return new Date(new Date().getFullYear(), new Date().getMonth() - 6, new Date().getDate())
    }

    const getDate = () => {
        const date = props.form[FORM.BIRTHDATE].value
        if (date) {
            return date
        } else {
            return null
        }
    }
    
    const nameInputList = [
        {label:"יש כבר שם? (לא חובה)", type:'text', maxlength:25, field:FORM.FIRST_NAME},
        {label:"שם משפחה (לא חובה)", type:'text', maxlength:30, field:FORM.SURNAME}
    ]
     
    return (
        <div className={style.babyDetailsWrap}>

            <div className={style.inputRow}>
                <DatePicker
                    className={style.datePickerBirthday}
                    minDate={birthdayMinDate()}
                    maxDate={birthdayMaxDate()}
                    placeholder={"תאריך לידה"}
                    date={getDate()}
                    error={props.form.babyBirthDate.error}
                    clearDate={!getDate()}
                    getDate={e => changeDateField(e && e)}
                />
                <Input
                    inputgroupclass={style.inputGroupClass}
                    label='תעודת זהות'
                    type='number'
                    width="regular"
                    maxlength={9}
                    onBlur={e => validateID(e.target.value)}
                    onChange={e => props.onChange(FORM.ID, e.target.value)}
                    error={props.form.babyId.error}
                    value={props.form.babyId.value}
                />
            </div>

            <div className={style.inputRow}>
                {nameInputList.map(input=> 
                    <Input
                        inputgroupclass={style.inputGroupClass}
                        label={input.label}
                        type={input.type}
                        width="regular"
                        maxlength={input.maxlength}
                        onBlur={e => e.target.value && insertFormLog(input.field, e.target.value)}
                        onChange={e => validateName(input.field, e.target.value)}
                        error={props.form[input.field].error}
                        value={props.form[input.field].value}
                    />
                )}
            </div>

        </div>
    );
    
}

InsertBabyDetails.propTypes = {
    updateErrors: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired
};

export default InsertBabyDetails;