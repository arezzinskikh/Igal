import React from 'react';
import {IconRadioButton} from '@maccabi/m-ui';

import style from './ChooseBabyGender.scss';
import { FORM, VALIDATION_ERRORS, GENDER_LIST } from '../../../../../containers/BabyRegistration/constants';
import {insertFormLog} from '../../../../../containers/BabyRegistration/logFile';

const ChooseBabyGender = (props) => {

    const onPickGender =(e)=> {
        const {text} = e;
        props.onChange(FORM.GENDER,text)
        props.updateErrors(FORM.GENDER, VALIDATION_ERRORS.noError)
        insertFormLog(FORM.GENDER,text)
    }

    const genderValueToIndex = (text) => {
        switch (text) {
        case GENDER_LIST[0].text:
            return 0
        case GENDER_LIST[1].text:
            return 1
        default:
            return -1;
        }
    }

    return (
        <div className={style.chooseBabyGenderWrap}>
            <IconRadioButton
                className={style.chooseGenderBtnWrap}
                list={GENDER_LIST}
                onClick={(e)=> onPickGender(e)}
                color={props.error ? "danger" : "primary"}
                selectedIndex={genderValueToIndex(props.babyGender)}
            />
            {props.error && <p className={style.chooseBabyGenderErrorText}>{props.error}</p>}
        </div>
    );
}


ChooseBabyGender.propTypes = {
    updateErrors: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired
};

export default ChooseBabyGender;