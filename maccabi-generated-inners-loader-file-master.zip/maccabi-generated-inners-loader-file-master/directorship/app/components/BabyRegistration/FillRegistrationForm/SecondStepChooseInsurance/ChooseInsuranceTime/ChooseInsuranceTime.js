import React, {Component} from 'react';
import {CheckboxGroup,H2} from '@maccabi/m-ui';
import PropTypes from 'prop-types';

import style from './ChooseInsuranceTime.scss';
import { STATIC_TXT, FORM, VALIDATION_ERRORS } from '../../../../../containers/BabyRegistration/constants';
import {STATIC_TXT_MODALS} from '../../../BabyRegistrationModal/constants';
import BabyRegistrationModal from '../../../BabyRegistrationModal/BabyRegistrationModal';
import { insertFormLog } from '../../../../../containers/BabyRegistration/logFile';

class ChooseInsuranceTime extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showLoseVetekHorimModal: false,
            loseVetekHorimModalPoppedOnce: false
        };
    }

    selectTime = (index) => { 
        const {loseVetekHorimModalPoppedOnce} = this.state;
        this.props.updateFormError(FORM.TIME,VALIDATION_ERRORS.noError)
        if (index === STATIC_TXT.chooseTime.startingToday.index && !loseVetekHorimModalPoppedOnce) {
            this.setState({
                showLoseVetekHorimModal: true,
                loseVetekHorimModalPoppedOnce: true
            })
        }
        this.props.updateFormValue(FORM.TIME, index)
        index > -1 && insertFormLog(FORM.TIME, index)
    }

    render () {
        const {chooseTimeError,selectedindex,canChooseTime,firstStepSavedForm} = this.props;
        const babyNameForModal = firstStepSavedForm.babyFirstName.value ? firstStepSavedForm.babyFirstName.value : firstStepSavedForm.babyFirstName.default;
        const {showLoseVetekHorimModal} = this.state;
        return (
            <div className={style.chooseTimeWrap}>
                {canChooseTime &&
                    <div className={style.canChooseTimeWrap}>
  
                        <BabyRegistrationModal isOpen={showLoseVetekHorimModal} 
                            modalName={STATIC_TXT_MODALS.vetekHorim.name}
                            onToggle={() => this.setState({showLoseVetekHorimModal: false})}
                            babyNameForModal={babyNameForModal}
                            primaryBtnClick={() => this.setState({showLoseVetekHorimModal: false})}/>

                        <H2 className={style.chooseTimeTitle}>{STATIC_TXT.subtitle.chooseTime}</H2>

                        <CheckboxGroup
                            classnamecheckboxgroup={style.checkboxGroupChooseTime}
                            classnamecheckboxradio={style.checkboxRadiocheckboxGroupChooseTime}
                            selectedindex={selectedindex}
                            onCheck={(index) => this.selectTime(index)}>
                                <div className={style.checkboxItemChooseTime}>
                                    <label className={style.chooseTimeLbl}>{STATIC_TXT.chooseTime.startingBirthDate.text}</label>
                                    <p className={style.chooseTimeRemark}>{STATIC_TXT.chooseTime.startingBirthDate.remark}</p>
                                </div>

                                <div className={style.checkboxItemChooseTime}>
                                    <label className={style.chooseTimeLbl}>{STATIC_TXT.chooseTime.startingToday.text}</label>
                                    <p className={style.chooseTimeRemark}>{STATIC_TXT.chooseTime.startingToday.remark}</p>
                                </div>
                        </CheckboxGroup>
                        {chooseTimeError && selectedindex <0 && 
                            <p className={style.errorTxt}>{chooseTimeError}</p>
                        }

                    </div>
                }
                {!canChooseTime &&
                    <div className={style.cantChooseTimeWrap}>
                        <H2 className={style.cantChooseTimeTitle}>{STATIC_TXT.subtitle.canNotChooseInsurance}</H2>
                        <div className={style.cantChooseTime}>
                            <p className={style.cantChooseTimeSubtitle}>{STATIC_TXT.chooseTime.startingToday.text}</p>
                            <p className={style.cantChooseTimeRemark}>{STATIC_TXT.chooseTime.startingToday.remark}</p>
                        </div>
                    </div>
                }
            </div>
        );
    }
}

ChooseInsuranceTime.propTypes = {
    updateFormError: PropTypes.func.isRequired,
    updateFormValue: PropTypes.func.isRequired,
    chooseTimeError: PropTypes.string,
    selectedindex: PropTypes.number,
    canChooseTime: PropTypes.bool,
    firstStepSavedForm: PropTypes.object
};

export default ChooseInsuranceTime;