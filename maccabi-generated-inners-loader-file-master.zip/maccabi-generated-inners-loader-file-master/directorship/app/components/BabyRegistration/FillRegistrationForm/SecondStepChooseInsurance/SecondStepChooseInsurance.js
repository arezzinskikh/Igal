import React, {Component} from 'react';
import autobind from 'autobind';
import { withRouter }from 'react-router-dom';
import {H4,H2,CoupleButtons} from '@maccabi/m-ui';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import mLib from '@maccabi/m-lib';
import PropTypes from 'prop-types';

import style from './SecondStepChooseInsurance.scss';
import { STATIC_TXT,VALIDATION_ERRORS,FORM,TERMS_OF_USE_INDEX_TO_TITLE } from '../../../../containers/BabyRegistration/constants';
import {setSecondStepFinished,updateFormValue,updateFormError,updateInsuranceNotChosen,updateTermsOfUse,setResetSteps} from '../../../../containers/BabyRegistration/actions';
import {selectFirstStepBabyInfoForm,selectSecondStepSavedForm,selectEligibilityResponse} from '../../../../containers/BabyRegistration/selectors';
import ChooseInsurance from './ChooseInsurance/ChooseInsurance';
import ChooseInsuranceTime from './ChooseInsuranceTime/ChooseInsuranceTime';
import DisabilityInsurance from './DisabilityInsurance/DisabilityInsurance';
import KerenMaccabi from './KerenMaccabi/KerenMaccabi';
import { insertLog } from '../../../../containers/BabyRegistration/logFile';

//dont turn mapDispatchToProps into object syntax!
const mapDispatchToProps = (dispatch) => ({
    updateFormValue: (field,value,formPart=FORM.SECOND_PART) => dispatch(updateFormValue(field, value, formPart)),
    updateFormError: (field,value,formPart=FORM.SECOND_PART) => dispatch(updateFormError(field, value, formPart)),
    updateTermsOfUse: () => dispatch(updateTermsOfUse()),
    updateInsuranceNotChosen: () => dispatch(updateInsuranceNotChosen()),
    setSecondStepFinished: () => dispatch(setSecondStepFinished()),
    setResetSteps: () => dispatch(setResetSteps())
});

const mapStateToProps = createStructuredSelector({
    firstStepSavedForm: selectFirstStepBabyInfoForm,
    form: selectSecondStepSavedForm,
    eligibilityResponse: selectEligibilityResponse
});
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class SecondStepChooseInsurance extends Component {

    componentDidMount() {
        window.scrollTo(0, 0);
    }

    onSubmitFormToRegister(){
        const log = STATIC_TXT?.button?.continueToApproveRegistration?.log;
        log && insertLog(log)
  
        const {form,eligibilityResponse,updateFormError,setSecondStepFinished} = this.props;
        const chosenInsuranceValue = form.insurance.value;
        let isValid = true;
        // we need to validate only in case of active hok screen and insurnce was chosen
        if (eligibilityResponse.activeHokScreen && chosenInsuranceValue > -1) {
            //if we can choose time - time must be chosen!
            if (eligibilityResponse.canChooseTime && form.time.value < 0) {
                updateFormError(FORM.TIME,VALIDATION_ERRORS.time)
                isValid = false;
            }
            //we must confirm the matching terms of use is checked
            if (!form[TERMS_OF_USE_INDEX_TO_TITLE[chosenInsuranceValue]].value) {
                updateFormError(TERMS_OF_USE_INDEX_TO_TITLE[chosenInsuranceValue],VALIDATION_ERRORS.termsOfUse)
                isValid = false;
            }
        }
        if (!isValid) return;
        setSecondStepFinished()
        this.turnOffRouteLeavingGuard();
        setTimeout(() => {
            this.props.history.push('/directorship/BabyRegistration/RegistrationSummary/');
        }, 50);
    }

    turnOffRouteLeavingGuard() {
        const propsLeaving = {
            shouldBlockNavigation: false,
            navigate: this.props.history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    returnToFillBabyInfo() {
        const log = STATIC_TXT?.button?.returnBabyInfo?.log;
        log && insertLog(log)
        this.props.setResetSteps()
    }

    render() {
        const {form,eligibilityResponse} = this.props;
        const {activeHokScreen,kerenMaccabiActive,canChooseTime} = eligibilityResponse;
        const insuranceChosen = form[FORM.INSURANCE].value > -1
        return (
            <div>

                <H4 className={style.pageTitle}>{STATIC_TXT.title.congratulations}</H4>

                {!activeHokScreen ?
                    <H2 className={style.chooseInsuranceTitleNoHok}>{STATIC_TXT.subtitle.needHOKtoJoin}</H2> 
                    :
                    <div className={style.chooseInsuranceHeadline}>
                        <H2 className={style.chooseInsuranceTitle}>{STATIC_TXT.subtitle.canChooseInsurance}</H2>
                        <span className={style.chooseInsuranceSpan}>{STATIC_TXT.subtitle.notMust}</span>
                    </div>
                }
            
                <ChooseInsurance 
                    activeHokScreen={activeHokScreen}
                    selectedindex={form[FORM.INSURANCE].value}
                    termsOfUseMaccabiGold={form[FORM.TERMS_OF_USE_MACCABI_GOLD].value}
                    termsOfUseMyMaccabi={form[FORM.TERMS_OF_USE_MY_MACCABI].value}
                    termsOfUseMaccabiGoldError={form[FORM.TERMS_OF_USE_MACCABI_GOLD].error}
                    termsOfUseMyMaccabiError={form[FORM.TERMS_OF_USE_MY_MACCABI].error}
                    {...this.props}/>
               
                <DisabilityInsurance disabilityInsurance={form[FORM.DISABILITY_INSURANCE].value}/>

                <KerenMaccabi 
                    kerenMaccabiActive={kerenMaccabiActive}
                    kerenMaccabiChecked={form[FORM.KEREN_MACCABI].value}
                    {...this.props}/>
                
                {activeHokScreen && insuranceChosen &&
                    <ChooseInsuranceTime 
                        canChooseTime = {canChooseTime}
                        selectedindex={form[FORM.TIME].value}
                        chooseTimeError={form[FORM.TIME].error}
                        {...this.props}/>
                }

                <CoupleButtons
                    firstText={STATIC_TXT.button.continueToApproveRegistration.text}
                    secondText={STATIC_TXT.button.returnBabyInfo.text}
                    firstOnClick={() => this.onSubmitFormToRegister()}
                    secondOnClick={() => this.returnToFillBabyInfo()}
                    classname ={style.coupleBtnsSecondStep}
                    firstclassname={style.coupleBtnsSecondStepFirst}
                    secondclassname={style.coupleBtnsSecondStepSecond}
                />
            </div>
        );
    }
}

SecondStepChooseInsurance.propTypes = {
    form: PropTypes.object.isRequired,
    updateFormError: PropTypes.func.isRequired,
    updateFormValue: PropTypes.func.isRequired,
    updateTermsOfUse: PropTypes.func.isRequired,
    updateInsuranceNotChosen: PropTypes.func.isRequired,
    setSecondStepFinished: PropTypes.func.isRequired,
    eligibilityResponse: PropTypes.object,
    setResetSteps: PropTypes.func.isRequired
};

export default withRouter(SecondStepChooseInsurance);