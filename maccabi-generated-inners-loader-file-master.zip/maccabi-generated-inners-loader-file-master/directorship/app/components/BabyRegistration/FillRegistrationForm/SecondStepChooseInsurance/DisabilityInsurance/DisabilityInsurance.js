import React from 'react';
import cx from 'classnames';
import {CheckboxGroup,Icon} from '@maccabi/m-ui';

import { STATIC_TXT } from '../../../../../containers/BabyRegistration/constants';
import style from './DisabilityInsurance.scss';

const DisabilityInsurance = ({disabilityInsurance}) => {
    return (
        <CheckboxGroup 
            classnamecheckboxgroup={style.checkboxGroupDisabilityInsurance} 
            classnamecheckboxradio={style.checkboxRadiocheckboxGroupDisability}
            selectedindex={disabilityInsurance}
            disabled={true}>
            <div className={style.checkboxItemInsurance}>
                <div className={style.checkboxItemIconAndRemark}>
                    <Icon name={STATIC_TXT.maccabiDisability.icon} className={style.insuranceDisabilityIcon} fill={false}/>
                    <p className={style.disabilityRemark}>{STATIC_TXT.maccabiDisability.remark}</p>
                </div>
                <p className={cx(style.checkboxItemLabelLnk,style.addPadding)}>{STATIC_TXT.maccabiDisability.text}</p>
            </div>
        </CheckboxGroup>
    );
}

export default DisabilityInsurance;