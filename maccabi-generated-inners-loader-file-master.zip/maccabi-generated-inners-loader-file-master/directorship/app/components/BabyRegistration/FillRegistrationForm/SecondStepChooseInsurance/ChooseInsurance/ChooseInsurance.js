import React,{useState} from 'react';
import {CheckboxGroup,SpecialModal} from '@maccabi/m-ui';

import style from './ChooseInsurance.scss';
import { STATIC_TXT, FORM, VALIDATION_ERRORS,TERMS_OF_USE_INDEX_TO_TITLE,shabanInsuranceTypes} from '../../../../../containers/BabyRegistration/constants';
import NotActiveHokChooseInsuranceScreen from './NotActiveHokChooseInsuranceScreen/NotActiveHokChooseInsuranceScreen';
import InsuranceType from './InsuranceType/InsuranceType';
import TermsOfUseCheckbox from './TermsOfUseCheckbox/TermsOfUseCheckbox';
import { insertLog, insertFormLog } from '../../../../../containers/BabyRegistration/logFile';

const ChooseInsurance = (props) => {  

    const [termsOfUseModal, toggleModal] = useState({show:false, type: ""})

    const selectInsurance = (index) => {
        props.updateTermsOfUse()
        if (index === -1) {
            props.updateInsuranceNotChosen()
        }
        props.updateFormValue(FORM.INSURANCE,index === props.selectedindex ? -1 : index)
        index > -1 && insertFormLog(FORM.INSURANCE, index)
    }

    const onCheckTermsOfUse = (e,termsOfUseType) => {
        const value = e.target.checked;
        props.updateFormValue(termsOfUseType, value)
        props.updateFormError(termsOfUseType,VALIDATION_ERRORS.noError)
        insertFormLog(termsOfUseType, value)
    }

    const onClickTermsOfUse = (termsOfUseType) => {
        const log = STATIC_TXT[termsOfUseType]?.log
        log && insertLog(log)
        toggleModal({show:true, type:termsOfUseType})
    }

    const toggleShabanTermsOfUseModal = (btn) => {
        const log = STATIC_TXT?.button?.termsOfUseBtn?.log;
        log && log[btn] && insertLog({elementId:log[btn], elementInPage:log.elementInPage, actionId:log.actionId})
        toggleModal({show:false,type:""})
    }
    
    return (
        <div>
            {props.activeHokScreen ?
                <div className={style.chooseInsuranceWrap}>
                    {termsOfUseModal.type && termsOfUseModal.show &&
                    <SpecialModal
                        toggle={() => toggleShabanTermsOfUseModal("closeBtn")}
                        isOpen={termsOfUseModal.show}
                        header={termsOfUseModal.type && STATIC_TXT[termsOfUseModal.type].title}
                        primaryButton={STATIC_TXT.button.termsOfUseBtn.text}
                        primaryButtonClick={() => toggleShabanTermsOfUseModal("primaryBtn")}>
                        <div className={style.termsOfUseModalBody}>
                        {termsOfUseModal.type && STATIC_TXT[termsOfUseModal.type].body.map((sentence,index) => 
                            <p key={index + 'tou_sentence'}>{sentence.text}</p>
                        )}
                        </div>
                    </SpecialModal>}

                    <CheckboxGroup selectedindex={props.selectedindex}
                        classnamecheckboxgroup={style.checkboxGroupChooseInsurance}
                        onCheck={(index) => selectInsurance(index)}>
                        {shabanInsuranceTypes.map((insurance) => 
                            <InsuranceType
                                name={insurance.name}
                                key={"insuranceType_"+insurance.index}
                                iconName = {insurance.icon}
                                insuranceLinkLog = {insurance.moreInfoLog}
                                text={insurance.text}
                                infoLink={insurance.link}
                                infoLinkText={insurance.moreInfo}
                                class={props.selectedindex == insurance.index ? 'checked' : ""}
                            />
                        )}
                    </CheckboxGroup>

                    {props.selectedindex === TERMS_OF_USE_INDEX_TO_TITLE['termsOfUseMyMaccabi'] &&
                        <TermsOfUseCheckbox 
                            className={style.termsOfUseWrapMyMaccabi}
                            ischecked={props.termsOfUseMyMaccabi}
                            showTermsOfUseErrorTxt={props.termsOfUseMyMaccabiError}
                            onClickTermsOfUse={onClickTermsOfUse}
                            onCheckTermsOfUse={onCheckTermsOfUse}
                            termsOfUseInsurance = {FORM.TERMS_OF_USE_MY_MACCABI}
                        />
                    }

                    {props.selectedindex === TERMS_OF_USE_INDEX_TO_TITLE['termsOfUseMaccabiGold'] &&
                        <TermsOfUseCheckbox 
                            className={style.termsOfUseWrapMaccabiGold}
                            ischecked={props.termsOfUseMaccabiGold}
                            showTermsOfUseErrorTxt={props.termsOfUseMaccabiGoldError}
                            onClickTermsOfUse={onClickTermsOfUse}
                            onCheckTermsOfUse={onCheckTermsOfUse}
                            termsOfUseInsurance = {FORM.TERMS_OF_USE_MACCABI_GOLD}
                        />
                    }
  
                </div>
            :
            <NotActiveHokChooseInsuranceScreen/>
            }
        </div>
    );   

}

export default ChooseInsurance;