import React from 'react';
import {Checkbox} from '@maccabi/m-ui';
import { STATIC_TXT, FORM} from '../../../../../containers/BabyRegistration/constants';
import style from './KerenMaccabi.scss';
import { insertFormLog } from '../../../../../containers/BabyRegistration/logFile';

const KerenMaccabi = props => {

    const onCheckKerenMaccabi = e => {
        const value = e.target.checked;
        props.updateFormValue(FORM.KEREN_MACCABI, value)
        insertFormLog(FORM.KEREN_MACCABI, value)
    }

    return (    
        <div className={style.kerenMaccabiWrap}>
            {props.kerenMaccabiActive ?
                <Checkbox
                    className={style.kerenMaccabiCheckbox}
                    ischecked={props.kerenMaccabiChecked}
                    onCheckChangeCallBack = {(e)=>onCheckKerenMaccabi(e)}>
                    <div className={style.checkboxItemkerenMaccabi}>
                        <label className={style.kerenMaccabiTxt}>{STATIC_TXT.kerenMaccabi.text}</label>
                        <p className={style.kerenMaccabiRemark}>{STATIC_TXT.kerenMaccabi.remark}</p>
                    </div>
                </Checkbox>
            :
            <div className={style.kerenNotActive}>
                <div className={style.kerenMaccabiTxt}>{STATIC_TXT.kerenMaccabi.text}</div>
                <div className={style.kerenMaccabiRemark}>{STATIC_TXT.kerenMaccabi.remark}</div> 
                <p className={style.additionalRemark}>{STATIC_TXT.subtitle.noKerenMaccabi}</p>
            </div>
            }
        </div>
    );
}

export default KerenMaccabi;