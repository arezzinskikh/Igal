import React from 'react';
import cx from 'classnames';
import {Checkbox} from '@maccabi/m-ui';

import style from '../ChooseInsurance.scss';

const TermsOfUseCheckbox = (props) => {  

    return (
        <div className={props.className}>
            <Checkbox ischecked={props.ischecked} className={cx(style.termsOfUseCheckbox)}
            invalid={props.showTermsOfUseErrorTxt && !props.ischecked ? 'invalid' : ''}
            onCheckChangeCallBack = {(e)=>props.onCheckTermsOfUse(e, props.termsOfUseInsurance)}>
                <p className={style.termsOfUseTxt}>קראתי והבנתי את</p>
            </Checkbox>
            <span className={style.termsOfUseLink} onClick={()=>props.onClickTermsOfUse(props.termsOfUseInsurance)}>תנאי ההצטרפות</span>
            {props.showTermsOfUseErrorTxt && !props.ischecked && 
                <p className={style.errorTxt}>{props.showTermsOfUseErrorTxt}</p>
            }
        </div>
    );   

}

export default TermsOfUseCheckbox;