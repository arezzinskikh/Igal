import React from 'react';
import {Icon,Button} from '@maccabi/m-ui';
import cx from 'classnames';

import style from './InsuranceType.scss';
import {insertLog} from '../../../../../../containers/BabyRegistration/logFile';

const InsuranceType = (props) => { 

    const onClickMoreInfo = (e) => {
        e.stopPropagation();
        const log = props?.insuranceLinkLog;
        log && insertLog(log)
        window.open(props.infoLink, '_blank');
    }

    return (
        <div className={cx(style.chooseInsuranceTypeWrap,props.class && style[props.class])}>
            <div className={cx(style.insuranceIconDiv, props.notActiveHok && style.notActiveHok)}>
                <Icon name={props.iconName} className={cx(style.insuranceIcon, style[props.name])} fill={false}/>
            </div>
            <div className={style.checkboxItemLabelLnk}>
                <p className={cx(style.formGroupLblInsurance, props.notActiveHok && style.notActiveHok)}>{props.text}</p>
                <Button onClick={(e) => onClickMoreInfo(e)} color="link" className={style.formGroupLink}>
                    {props.infoLinkText}
                </Button>
            </div>
        </div>
    );   
}

export default InsuranceType;