import React from 'react';
import {shabanInsuranceTypes} from '../../../../../../containers/BabyRegistration/constants';
import style from './NotActiveHokChooseInsuranceScreen.scss';
import InsuranceType from '../InsuranceType/InsuranceType';

const NotActiveHokChooseInsuranceScreen = () => {  

    return (
        <div className={style.chooseInsuranceWrapNotActive}>
        {shabanInsuranceTypes.map((insurance)=> 
                <div key={"notActiveHokInsurance_"+insurance.index} className={style.checkboxItemInsurance}>
                    <InsuranceType 
                        name={insurance.name}
                        key={"insuranceType_"+insurance.index}
                        iconName = {insurance.icon}
                        insuranceLinkLog = {insurance.moreInfoLog}
                        text={insurance.text}
                        infoLink={insurance.link}
                        infoLinkText={insurance.moreInfo}
                        notActiveHok={true}
                    />
                </div>
            )}
        </div>
    );   

}

export default NotActiveHokChooseInsuranceScreen;