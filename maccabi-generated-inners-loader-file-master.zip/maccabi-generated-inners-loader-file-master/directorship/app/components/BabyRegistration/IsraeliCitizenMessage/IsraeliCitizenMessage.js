import React from 'react';
import {H1,Icon} from '@maccabi/m-ui';

import style from './IsraeliCitizenMessage.scss';
import { STATIC_TXT} from '../../../containers/BabyRegistration/constants';

const IsraeliCitizenMessage = () => {
    return (
        <div className={style.cardMessage}>
            <Icon name="attention-big" iconclassname={style.israeliCitizenMessageIcon}/>
            <div className={style.israeliCitizenMessage}>
                <H1 className={style.israeliCitizenMessageTitle}>{STATIC_TXT.title.israeliCitizenOnly}</H1>
                <p className={style.israeliCitizenMessageTxt}>{STATIC_TXT.subtitle.forAdditionalInfo}</p>
            </div>
        </div>
    );
}

export default IsraeliCitizenMessage;