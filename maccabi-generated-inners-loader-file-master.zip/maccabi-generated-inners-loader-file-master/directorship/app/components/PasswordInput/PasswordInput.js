import React, { Component } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { Input, Icon } from '@maccabi/m-ui';
import style from './PasswordInput.scss';
import autobind from 'autobind';

const VISIBILITY = ['visible', 'hidden'];
const VISIBILITY_DATA = {
    hidden: {
        inputType: 'password',
        icon: 'passwordHide'
    },
    visible: {
        inputType: 'text',
        icon: 'passwordShow'
    }
};
const WIDTH = ['narrow', 'regular', 'wide', 'auto'];

@autobind
class PasswordInput extends Component {
    constructor(props) {
        super(props);

        this.state = {
           // fieldActivate: this.props.value ? true : false,
            fieldFocus: false
        };
    }

    static propTypes = {
        labelclassname: PropTypes.string,
        errorclassname: PropTypes.string,
        inputgroupclass: PropTypes.string,
        inputclassname: PropTypes.string,
        label: PropTypes.string,
        error: PropTypes.string,
        width: PropTypes.oneOf(WIDTH),
        value: PropTypes.node,
        onFocus: PropTypes.func,
        onBlur: PropTypes.func,
        onChange: PropTypes.func,
        children: PropTypes.node,
        disabled: PropTypes.bool,
        hook: PropTypes.string,
        visibilityState: PropTypes.oneOf(VISIBILITY),
        updateVisibilityState: PropTypes.func
    };

    static defaultProps = {
        visibilityState: VISIBILITY[1],
        width: WIDTH[1]
    };

    updateVisibilityState() {
        const { visibilityState, updateVisibilityState } = this.props;
        const newState = visibilityState === VISIBILITY[0] ? VISIBILITY[1] : VISIBILITY[0];
        updateVisibilityState && updateVisibilityState(newState);
    }

    onFocus(e) {
        if (!this.props.disabled) {
            this.setState(() => ({
                //fieldActivate: true,
                fieldFocus: true
            }));
            this.props.onFocus && this.props.onFocus(e);
        }
    }

    onBlur(e) {
        if (!this.props.value) {
            this.setState(() => ({
                //fieldActivate: false
            }));
        }
        this.setState(() => ({
            fieldFocus: false
        }));

        this.props.onBlur && this.props.onBlur(e);
    }

    onChange(e) {
        if (this.props.value === null || this.props.value === undefined) {
            this.setState(() => ({
                fieldFocus: false
            }));
        }
        if (this.props.value) {
            this.setState({
                fieldFocus: true
            });
        }
        this.onFocus(e);
        e.preventDefault();

        this.props.onChange && this.props.onChange(e);
    }

    render() {
        const { visibilityState, updateVisibilityState, onFocus, onBlur, onChange, ...rest } = this.props;
        const type = VISIBILITY_DATA[visibilityState].inputType;
        const icon = VISIBILITY_DATA[visibilityState].icon;
        const iconClass = cx(style.icon, this.state.fieldFocus && style.active);

        return (
            <div className={style.container}>
                <Input
                    inputgroupclass={style.fixErrorMessageOverflow}
                    onFocus={this.onFocus}
                    onBlur={this.onBlur}
                    onChange={this.onChange}
                    type={type}
                    {...rest} />
                <div className={style.iconContainer} onClick={this.updateVisibilityState}>
                    <Icon name={icon} iconclassname={iconClass} />
                </div>
            </div>
        )
    }
}

export default PasswordInput;