import React from 'react';
import {Img, H1} from '@maccabi/m-ui';

import style from './MyMaccabiIcon.scss';
import myMaccabiIcon from './images/myMaccabi.jpg';

const MyMaccabiIcon = ({title}) => {
    return (
        <div className={style.myMaccabiIconWrap}>
            <Img className={style.myMaccabiIcon} path={myMaccabiIcon} alt={'מכבי שלי'} />
            {title &&
                <H1 className={style.pageTitle}>{title}</H1>
            }
        </div>
    );
}

export default MyMaccabiIcon;
