

import React, { Fragment } from 'react';
import mLib from '@maccabi/m-lib';
import style from './ChooseTime.scss';
import cx from 'classnames';
import { STATIC_TXT,FORM_FIELDS } from '../../../../containers/JoinMyMaccabi/constants';
import {CheckboxGroup} from '@maccabi/m-ui';

const ChooseTime = ({error,chosenTime,nextMonthDate,handleSelect}) => {

    const getDate = () => {
        let date = STATIC_TXT.chooseTime.startingFrom;
        return date + nextMonthDate
    }

    const selectCheckbox = (index) => {
        handleSelect(FORM_FIELDS.TIME, index);
        const log = STATIC_TXT?.chooseTime?.log ?? {};
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId);
    }

    const invalidTime = error && chosenTime < 0;

    return (
        <Fragment>
            <div className={style.choosingTimeWrap}>
                <h2 className={style.choosingTimeTitle}>{STATIC_TXT.chooseTime.text}</h2> 
                <div className={style.choosingTimeCheckboxWrap}>
                    <CheckboxGroup selectedindex={chosenTime}
                        onCheck={(index) => selectCheckbox(index)}
                        classnamecheckboxgroup={style.radioContainer} 
                        classnamecheckboxradio={cx(style.radioLabel, !invalidTime && style.blueValid)}
                        children={[STATIC_TXT.chooseTime.startingToday, getDate()]}
                        invalid={invalidTime ? ' ' : ''}
                    />
                </div>
                {invalidTime && <p className={style.errorTxt}>{error}</p>}
                <p className={cx(style.choosingTimeDisclaimer, invalidTime && "pt-0")}>{STATIC_TXT.disclaimer}</p>
            </div>
        </Fragment>
    );
}

export default ChooseTime;