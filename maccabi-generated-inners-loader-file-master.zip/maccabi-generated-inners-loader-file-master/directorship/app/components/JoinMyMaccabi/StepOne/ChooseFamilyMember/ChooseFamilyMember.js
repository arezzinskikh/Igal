import React, { Fragment } from 'react';
import {ButtonMultiPicker} from '@maccabi/m-ui';

import style from './ChooseFamilyMember.scss';
import { STATIC_TXT, FORM_FIELDS } from '../../../../containers/JoinMyMaccabi/constants';

const ChooseFamilyMember = (props) => {

    const {memberObjectForBtnPicker, familyMembers, chosenMembers, handleSelect, error, membersThatCannotBePayed} = props;
    const familyMembersToIndex = () => {
        if (chosenMembers) {
            const membersToIndexList = chosenMembers.map(member => 
                member.index
            );
            return membersToIndexList
        }
        return []
    }

    const handleFamilyMemberPicked = (list) => {
        const chosenList = list.map(index => ({
            ...familyMembers[index],
            index
        }));
        handleSelect(FORM_FIELDS.MEMBERS,chosenList);
    }

    const getNotEligibleMembersString = () => {
        let membersString = "";
        const addComma = (ind) => {
            if (ind === 0) return ""
            return ind === membersThatCannotBePayed.length - 1 ? " ו" : ", "
        }
        membersThatCannotBePayed.forEach((member,ind) => {
            membersString = membersString + addComma(ind) + member.first_name + " " + member.last_name
        });
        return membersString
    }

    const showCanNotPayOnMembersRemark = membersThatCannotBePayed.length > 0;
    
    return (
        <Fragment>
            <div className={style.choosingFamilyMembersWrap}>
                <h2 className={style.choosingFamilyMemberTitle}>{STATIC_TXT.choosingFamilyMembers.Title}</h2> 
                <p className={style.choosingFamilyMemberTxt}>{STATIC_TXT.choosingFamilyMembers.Text}</p> 
            </div>
            <ButtonMultiPicker
                list={memberObjectForBtnPicker} 
                onClick={handleFamilyMemberPicked} 
                nameOfFiledToDisplay="field"
                descOfFiledToDisplay="description"
                color={error && !chosenMembers.length ? 'danger' : 'primary'}
                selectedIndex={familyMembersToIndex()}
            />
            {error && !chosenMembers.length && <p className={style.errorTxt}>{error}</p>}
            {showCanNotPayOnMembersRemark && 
                <p className={style.membersCantBePayedRemark}>
                    { `${STATIC_TXT.canNotPayOnMembers.partOne} ${getNotEligibleMembersString()} ${STATIC_TXT.canNotPayOnMembers.partTwo}` }
                </p>
            }
        </Fragment>
    );
}

export default ChooseFamilyMember;