import React, {Component} from 'react';
import { withRouter }from 'react-router-dom';
import autobind from 'autobind';
import {Button,Checkbox,H1} from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

import style from './FillRequestForm.scss';
import {onFormFieldChange} from '../../../containers/JoinMyMaccabi/actions';
import {selectFamilyMembers,selectChosenTime,selectChosenMembers,selectIsTermsOfUseChecked,selectFamilyMemberObjectForBtnPicker,selectNextMonthDate,selectMembersThatCanNotBePayedOn} from '../../../containers/JoinMyMaccabi/selectors';
import {STATIC_TXT, FORM_FIELDS} from '../../../containers/JoinMyMaccabi/constants';
import {getFormErrorByField} from '../../../containers/JoinMyMaccabi/validator';
import ChooseFamilyMember from './ChooseFamilyMember/ChooseFamilyMember';
import ChooseTime from './ChooseTime/ChooseTime';

const mapDispatchToProps = (dispatch) => ({
    onFormFieldChange: (payload) => dispatch(onFormFieldChange(payload))
});

const mapStateToProps = createStructuredSelector({
    familyMembers: selectFamilyMembers,
    nextMonthDate: selectNextMonthDate,
    chosenTime: selectChosenTime,
    chosenMembers: selectChosenMembers,
    termsOfUse: selectIsTermsOfUseChecked,
    memberObjectForBtnPicker: selectFamilyMemberObjectForBtnPicker,
    membersThatCannotBePayed: selectMembersThatCanNotBePayedOn
});

@autobind
@withRouter
@connect(mapStateToProps, mapDispatchToProps)
class FillRequestForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            errors: {
                chosenTime: '',
                chosenMembers: '',
                termsOfUse: ''
            }
        }
    }

    onCheckTermsOfUse = (e) => {
        const value = e.target.checked;
        this.handleSelect(FORM_FIELDS.TERMS_OF_USE,value);
        const log = STATIC_TXT?.termsOfUse?.log ?? {};
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, value ? log.actionIdCheck : log.actionIdUnCheck)
    }

    handleSelect = (field, value) => {
        const data = {field,value}
        this.props.onFormFieldChange(data)
    }

    onSubmitForm = () => {
        const {termsOfUse,chosenTime,chosenMembers} = this.props
        const form = {termsOfUse,chosenTime,chosenMembers}
        const errors = Object.fromEntries(
            Object.entries(form).map(([field, value]) => [field, getFormErrorByField(field, value)])
        );
        const isValid = Object.values(errors).filter(Boolean).length === 0
        this.setState({errors});
        if (!isValid) return;
        this.props.history.push('/directorship/JoinMyMaccabi/RequestSummary/');
        const log = STATIC_TXT?.button?.continueToApproveForm?.log ?? {};
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId);
    }

    render() {
        const {nextMonthDate,familyMembers,chosenMembers,chosenTime,termsOfUse,memberObjectForBtnPicker,membersThatCannotBePayed} = this.props;
        const {errors} = this.state;
        const showTermsOfUseErrorTxt = errors.termsOfUse && !termsOfUse;
        return (
            <div>
                <H1 className={style.pageTitle}>{STATIC_TXT.title.myMaccabiPlan}</H1>
                {familyMembers.length > 1 && 
                    <ChooseFamilyMember 
                        handleSelect={this.handleSelect} 
                        familyMembers={familyMembers}
                        error={errors.chosenMembers} 
                        chosenMembers = {chosenMembers}
                        memberObjectForBtnPicker={memberObjectForBtnPicker}
                        membersThatCannotBePayed={membersThatCannotBePayed}
                    />
                }
                <ChooseTime 
                    handleSelect={this.handleSelect} 
                    nextMonthDate={nextMonthDate} 
                    error={errors.chosenTime}
                    chosenTime={chosenTime}
                />
                <Checkbox 
                    className={style.termsOfUseCheckbox}
                    ischecked={termsOfUse}
                    invalid={showTermsOfUseErrorTxt ? 'invalid' : ''}
                    onCheckChangeCallBack = {(e)=>this.onCheckTermsOfUse(e)}
                >
                    <p className={style.termsOfUseTxt}>{STATIC_TXT.termsOfUse.text.partOne}
                        <a className={style.termsOfUseLink} target="_blank" href={STATIC_TXT.termsOfUse.link}>
                            {STATIC_TXT.termsOfUse.text.partTwo}
                        </a>
                        {STATIC_TXT.termsOfUse.text.partThree}
                    </p>
                </Checkbox>
                {showTermsOfUseErrorTxt && <p className={style.errorTxt}>{errors.termsOfUse}</p>}
                <div className={style.continueBtnWrap}>
                    <Button color="primary" 
                        onClick={()=>this.onSubmitForm()} 
                        size="md" 
                        className={style.continueBtn}
                        maincta={'true'}
                    >
                        {STATIC_TXT.button.continueToApproveForm.text}
                    </Button>
                </div>
            </div>
        );
    }
}

export default FillRequestForm;