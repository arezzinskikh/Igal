import React from 'react';
import {H1} from '@maccabi/m-ui';
import style from './ModuleMessage.scss';

const ModuleMessage = ({message}) => {
    return (
        <div>
            <div className={style.moduleMessageWrap}>
                <H1 className={style.moduleMessageTitle}>{message.title}</H1>
                <p>{message.subtitle}</p>
            </div>
        </div>
    );
}

export default ModuleMessage;
