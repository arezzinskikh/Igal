import React from 'react';
import mLib from '@maccabi/m-lib';
import { Link } from 'react-router';
import { Pipe, PipeItem } from '@maccabi/m-ui';
import style from './MainDescriptionAndLinks.scss';
import { STATIC_TXT } from '../../../containers/JoinMyMaccabi/constants';

const MainDescriptionAndLinks = () => {
    const isKosher = mLib.site.isKosher();
    return (
        <div className={style.scrollDescription}>
            <p data-hook="Description" className="m-0">
                {STATIC_TXT.JoinMyMaccabiDescription} <a href="/directorship/CreditsAndDebits/DirectDebit/">מכאן</a>.
            </p>
            {!isKosher && (
                <Pipe className={style.pipeItems}>
                    {STATIC_TXT.links.map((item, index) => {
                        return (
                            <PipeItem>
                                <a href={item.link} className={index === 0 ? 'pr-0' : ''} key={index} target="_blank">
                                    {item.text}
                                </a>
                            </PipeItem>
                        );
                    })}
                </Pipe>
            )}
        </div>
    );
};

export default MainDescriptionAndLinks;
