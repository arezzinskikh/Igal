import React from 'react';
import {withRouter} from 'react-router-dom';
import cx from 'classnames';

import {H2,H4,Icon,Button} from '@maccabi/m-ui';
import style from './RegistrationSuccessOrFailScreen.scss';
import SuccessFailSummary from './SuccessFailSummary/SuccessFailSummary';
import {STATIC_TXT} from '../../../../containers/JoinMyMaccabi/constants'

const RegistrationSuccessOrFailScreen =({registrationFailedList,registrationSucceedList,onClickUnderstoodBtnAfterFail})=> {
    const success = registrationSucceedList.length ? true : false
    const fail = registrationFailedList.length ? true : false
    return (
        <div className={style.summaryWrap}>
            {success &&
                <div className={style.failSuccessWrap}>
                    <Icon name="success-big" iconclassname={cx(style.successIcon, 'ml-3')}/>
                    <H4 className={style.successTitle}>{STATIC_TXT.title.joiningRequestSuccess}</H4>
                    <SuccessFailSummary list={registrationSucceedList} description={STATIC_TXT.subtitle.joiningRequestSuccessText}/>
                </div>
            }
            {fail && success && <div className={style.sep}></div>}
            {fail && 
                <div className={style.failSuccessWrap}>
                    <H2 className={style.failTitle}>{STATIC_TXT.title.errorInProgress}</H2>
                    <SuccessFailSummary list={registrationFailedList} description={STATIC_TXT.subtitle.joiningRequestFailText}/>
                    <div className={style.understoodBtnWrap}>
                        <Button color="primary" 
                            onClick={()=>onClickUnderstoodBtnAfterFail()} 
                            size="md" 
                            className={style.understoodBtn}
                            maincta={'true'}>
                                {STATIC_TXT.button.understood}
                        </Button>
                    </div>
                </div>
            }
        </div>
    );
}

export default withRouter(RegistrationSuccessOrFailScreen);