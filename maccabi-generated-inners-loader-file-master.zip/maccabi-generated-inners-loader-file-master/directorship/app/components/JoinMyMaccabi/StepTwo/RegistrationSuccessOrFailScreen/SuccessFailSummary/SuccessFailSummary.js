import React from 'react';

import {H2,PipeDivider} from '@maccabi/m-ui';
import style from './SuccessFailSummary.scss';

const SuccessFailSummary =({list,description})=> {
    return (
        <div className={style.pipeDividerWrap}>
            <PipeDivider className={"d-flex justify-content-center"} itemClassName={style.pipeItemSuccessFail} isAfter={'true'}>
                {list.map((member,ind) => {
                        return (
                            <H2 className={style.pipeItem} key={ind}>{member.first_name + " " + member.last_name}</H2>
                        )
                    })
                }
            </PipeDivider>
            <p className={style.failSuccessTxt}>{description}</p>
        </div>
    );
}

export default SuccessFailSummary;