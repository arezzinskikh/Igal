import React, { Component,Fragment } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { withRouter, Redirect} from 'react-router-dom';
import mLib from '@maccabi/m-lib';
import autobind from 'autobind';
import cx from 'classnames';
import {MainHeadline, MainHeadlineScrollable,H1, Icon, MainBody, Button,Modal} from '@maccabi/m-ui';

import style from './RequestSummary.scss';
import {STATIC_TXT, STARTING_DATE} from '../../../containers/JoinMyMaccabi/constants';
import MainDescriptionAndLinks from '../MainDescriptionAndLinks/MainDescriptionAndLinks';
import MyMaccabiIcon from '../MyMaccabiIcon/MyMaccabiIcon';
import reducer from '../../../containers/JoinMyMaccabi/reducer';
import saga from '../../../containers/JoinMyMaccabi/saga'
import {selectIsStepOneFinished,
    selectFamilyMembers,
    selectNextMonthDate,
    selectAllInMyMaccabi,
    selectChosenTime,
    selectChosenMembers,
    selectRegistraionResponse,
    selectRegistraionFailed,
    selectRegistraionSuccessed,
    selectGlobalLoader,
    selectErrorInSendingRequest
} from '../../../containers/JoinMyMaccabi/selectors';
import {deleteRequestFromState,postAdditionalInsurances} from '../../../containers/JoinMyMaccabi/actions';
import Summary from './Summary/Summary';
import RegistrationSuccessOrFailScreen from './RegistrationSuccessOrFailScreen/RegistrationSuccessOrFailScreen';

const mapDispatchToProps = (dispatch) => ({
    deleteRequestFromState: () => dispatch(deleteRequestFromState()),
    postAdditionalInsurances: (data) => dispatch(postAdditionalInsurances(data))
});

const mapStateToProps = createStructuredSelector({
    savedIsStepOneFinished: selectIsStepOneFinished,
    familyMembers: selectFamilyMembers,
    nextMonthDate: selectNextMonthDate,
    allInMyMaccabi: selectAllInMyMaccabi,
    savedSelectedChosenTime: selectChosenTime,
    savedSelectedMembers: selectChosenMembers,
    registrationResponse: selectRegistraionResponse,
    registrationSucceedList: selectRegistraionSuccessed,
    registrationFailedList: selectRegistraionFailed,
    isLoaderOn: selectGlobalLoader,
    errorInSendingRequest: selectErrorInSendingRequest
});

@mLib.appInfra.injectReducer({ key: 'myMaccabiReducer', reducer})
@mLib.appInfra.injectSaga({ key: 'myMaccabiReducer', saga, mode: '@@saga-injector/daemon'})
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class RequestSummary extends Component {

    constructor(props) {
        super(props);
        this.state = {
            openModal: {
                type: null
            }
        };
    }

    componentDidMount() {
        window.scrollTo(0, 0);
    }

    componentDidUpdate(prevProps) {
        const {errorInSendingRequest} = this.props;
        if (errorInSendingRequest !== prevProps.errorInSendingRequest && errorInSendingRequest) {
            this.toggleModal('modalErrorInSendingRequest', null)
        }
    }

    getDate() {
        const {savedSelectedChosenTime,nextMonthDate} = this.props;
        let date = STATIC_TXT.chooseTime.startingFrom;
        if (savedSelectedChosenTime === STARTING_DATE.startingNextMonth) {
            date = date + nextMonthDate
        } else if (savedSelectedChosenTime === STARTING_DATE.startingToday) {
            date = STATIC_TXT.chooseTime.startingToday;
        }
        return date
    }

    onSendRequest() {
        const {savedSelectedChosenTime,savedSelectedMembers} = this.props;
        const request = {
            startMyMaccabiFromToday: savedSelectedChosenTime === STARTING_DATE.startingToday ? true : false,
            savedSelectedMembers
        }
        this.props.postAdditionalInsurances(request)
        const log = STATIC_TXT?.button?.approveRegistration?.log ?? {};
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId);
    }

    onCancelFormRequest() {
        this.toggleModal('modalIsDeleteRequestToggle');
    }

    toggleModal(type, log = null) {
        this.setState(
            ({ openModal }) => {
                const isClose = openModal.type === type;

                return {
                    openModal: {
                        type: isClose ? null : type,
                    }
                };
            }, 
            () => {
                if (log) {
                    mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId);
                }
            }
        );
    }

    renderOpenModal() {
        const {openModal: { type }} = this.state;
        const isOpen = typeof type === 'string';
        if (!isOpen) return null;

        const activeText = STATIC_TXT[type];
        const logs = activeText && activeText.logs;
        const btnClicked = logs && logs.btnClicked;
        return (
            <Modal
                toggle={() => {
                    this.toggleModal(type);
                }}
                isOpen={true}
                icon={activeText && activeText.icon}
                hook={type}
                header={(activeText && activeText.title)}
                body={activeText && activeText.body}
                primaryButton={activeText && activeText.btnOk}
                primaryButtonIconClass={'ml-3'}
                primaryButtonClick={() => {
                    this.toggleModal(type, btnClicked);
                    this.getToggleConfirmHandler(activeText);
                }}
                secondaryButton={activeText && activeText.btnCancel}
                secondaryButtonClick={() => this.toggleModal(type)}>
            </Modal>
        );
    }

    getToggleConfirmHandler(modal) {
        const handlers = {
            deleteRequest: () => {
                this.props.deleteRequestFromState();
                this.props.history.goBack();
            }
        };
        const handlerName = modal.onConfirmHandler; ///deleteRequest
        return handlers[handlerName]() || function() {};
    }

    onContinueAfterFail() {
        this.props.deleteRequestFromState(); //delete saved state and go back to first page to start over and fetch data from api again
        return <Redirect to="/directorship/JoinMyMaccabi/lobby/"/> 
    }
    
    render () {
        const {isLoaderOn,savedIsStepOneFinished,registrationResponse,
            savedSelectedMembers,registrationSucceedList,registrationFailedList,errorInSendingRequest,history} = this.props;
        if (!savedIsStepOneFinished) { 
            return <Redirect to="/directorship/JoinMyMaccabi/lobby/"/> 
        }
        if (isLoaderOn) return "";
        return (
            <Fragment>
                {this.renderOpenModal()}
                <MainHeadline>
                    <MainHeadlineScrollable>
                        <H1 hook="JoinMyMaccabiTitle">{STATIC_TXT.JoinMyMaccabiTitle}</H1>
                    </MainHeadlineScrollable>
                </MainHeadline>
                <MainBody scrollClassName={style.scrollCardBody} className={style.mainBody}>
                    <MainDescriptionAndLinks/>
                    <div className={style.myMaccabiCard}>
                        {errorInSendingRequest &&
                            <MyMaccabiIcon title={STATIC_TXT.title.myMaccabiPlan}/>
                        }
                        {!registrationResponse && !errorInSendingRequest &&
                        <div>
                            <div className={cx(style.topBtnsWrapper,'d-xl-flex d-none')}>
                                <Button tag="a" color="link" onClick={()=>history.goBack()} className={style.topBtn}>
                                    <Icon name="arrow-line" iconclassname={cx(style.goBackIcon, 'ml-3')}>
                                        {STATIC_TXT.goBack}
                                    </Icon>
                                </Button>
                            </div>
                            <MyMaccabiIcon title={STATIC_TXT.title.myMaccabiPlan}/>
                            <Summary 
                                onApproveClick={this.onSendRequest}
                                onCancelBtnClick={this.onCancelFormRequest}
                                savedSelectedMembers={savedSelectedMembers}
                                getDate={this.getDate}/>
                        </div>
                        }
                        {registrationResponse && !errorInSendingRequest &&
                        <div>
                            <MyMaccabiIcon title={STATIC_TXT.title.myMaccabiPlan}/>
                            <RegistrationSuccessOrFailScreen
                                registrationSucceedList = {registrationSucceedList}
                                registrationFailedList = {registrationFailedList}
                                onClickUnderstoodBtnAfterFail = {this.onContinueAfterFail}
                            />
                        </div>
                        }
                    </div>
                </MainBody>        
            </Fragment>
        );
    }
}

export default withRouter(RequestSummary);