import React from 'react';
import {CoupleButtons} from '@maccabi/m-ui';

import style from './ApproveCancelBtns.scss';
import { STATIC_TXT} from '../../../../containers/JoinMyMaccabi/constants';

const ApproveCancelBtns = ({onApproveClick,onCancelBtnClick}) => {
    return (
        <div className={style.buttonsWrap}>
            <CoupleButtons
                firstText={STATIC_TXT.button.approveRegistration.text}
                secondText={STATIC_TXT.button.cancelRegistration}
                firstOnClick={() => onApproveClick()}
                secondOnClick={() => onCancelBtnClick()}
                firstclassname={style.firstApproveBtn}
                secondclassname={style.secondCancelBtn}
            />
        </div>
    );
}

export default ApproveCancelBtns;