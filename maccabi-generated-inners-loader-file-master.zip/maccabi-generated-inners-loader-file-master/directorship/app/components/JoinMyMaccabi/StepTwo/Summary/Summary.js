import React from 'react';
import {withRouter} from 'react-router-dom';
import {H2,H3,PipeDivider} from '@maccabi/m-ui';

import style from './Summary.scss';
import {STATIC_TXT} from '../../../../containers/JoinMyMaccabi/constants'
import ApproveCancelBtns from '../ApproveCancelBtns/ApproveCancelBtns'

const Summary =({getDate, savedSelectedMembers,onCancelBtnClick,onApproveClick})=> {
    return (
        <div className={style.summaryWrap}>
            <h1 className={style.summaryTitle}>{STATIC_TXT.title.joiningRequestSummary}</h1>
            <div className={style.summarySubTitleWrap}>
                <H3 className={style.chosenMembersSubtitle}>{STATIC_TXT.joiningRequest.chosenMembersSubtitle}</H3>
                <PipeDivider className={"d-flex justify-content-center"} itemClassName={style.pipeItemSummary} isAfter={'true'}> 
                    {savedSelectedMembers.map((member,ind) => 
                        <H2 className={style.pipeItem} key={ind}>{member.first_name + " " + member.last_name}</H2>
                    )}
                </PipeDivider>
            </div>
            <div className={style.summarySubTitleWrap}>
                <H3 className={style.chosenTimeSubtitle}>{STATIC_TXT.joiningRequest.chosenTimeSubtitle}</H3>
                <H2 className={style.summaryChosenDate}>{getDate()}</H2>
            </div>
            <ApproveCancelBtns onCancelBtnClick={onCancelBtnClick} onApproveClick={onApproveClick}/>
        </div>
    );
}

export default withRouter(Summary);