import React, { Component } from 'react';
import format from 'string-format'
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import autobind from 'autobind-decorator';
import style from './ClalButton.scss';
import { Icon,Button } from '@maccabi/m-ui';
import {makeSelectHash,makeSelectTimestamp} from '../../../containers/TravelAbroadInsurance/selectors';

const mapStateToProps = createStructuredSelector({
   hash:makeSelectHash,
   timestamp:makeSelectTimestamp
});

@connect(mapStateToProps, null)
@autobind
class ClalButton extends Component {
    constructor(props) {
        super(props);
        this.state = {
            x: false
        };
    }

    static propTypes = {
        clalButton: PropTypes.object.isRequired,
        isAdult: PropTypes.bool
    };

    htmlContent = content => {
        return { __html: content };
    };

    handleOpenEnglishReport = () => {
        const{hash,timestamp} = this.props;
        const {current_customer_info:{member_id_code,member_id}} = mLib.saveData.customerData.get();
        const currentUrl = window.location.href;
        const danainfo = mLib.juniper.getDanaInfo(currentUrl);
        const url = format(process.env.WEB_API_URL_DIRECTORSHIP+process.env.WEB_API_GET_ENGLISH_REPORT,member_id_code,member_id,timestamp,hash);
        mLib.openPdfNewTab.openPdfNewTab(url+danainfo,"מכבי");
    }

    render() {
        const { isAdult } = this.props;
        const src = require(`./assets/clal.png`);
        return (
            <div className={cx(style.wrap, !isAdult && style.wrapChild, this.state.x && style.r)}>
                 <Button className={style.englishReport} onClick={this.handleOpenEnglishReport}>
                     <span>
                         {mLib.resources.getResource('directorship/TravelAbroadInsurance', 'GET_ENGLISH_REPORT', 'לצפייה בדף מידע רפואי באנגלית')}
                     </span>
                </Button>
                <img src={src} alt="אייקון כלל" />
                <div className={cx(style.title)}>
                    {mLib.resources.getResource('directorship/TravelAbroadInsurance', 'TravelAbroadInsurance_ClalButton_Title', 'חדש! הלחצן של כלל')}
                </div>
                <div className={cx(style.text)}>
                    {mLib.resources.getResource(
                        'directorship/TravelAbroadInsurance',
                        'TravelAbroadInsurance_ClalButton_Description',
                        'אפליקציית החירום של כלל, כוללת מגוון שירותים ומאפשרת החזר מיידי עד $500 עבור הוצאות רפואיות ותשלום מיידי בסך $170 לאיחור בקבלת  מזוודה, ישירות לחשבון הבנק'
                    )}
                </div>

                {this.props.clalButton.map(item => (
                    <div className={cx(style.starLine)}>
                        <Icon name="star-full" className={cx(style.fullStar)} />
                        <span dangerouslySetInnerHTML={this.htmlContent(item.value)} />
                    </div>
                ))}

                {/*<div className={cx(style.starLine)}>
                    <Icon name="star-full" className={cx(style.fullStar)} />
                    <span> רכשתם הרחבה לכבודה? יש לכם כיסוי לטלפון נייד עד $400</span>
                </div>*/}
            </div>
        );
    }
}

export default ClalButton;
