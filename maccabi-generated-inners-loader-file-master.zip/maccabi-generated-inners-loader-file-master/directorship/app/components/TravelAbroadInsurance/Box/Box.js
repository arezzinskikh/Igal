import React, { Component } from 'react';
import autobind from 'autobind';
import cx from 'classnames';
import style from './Box.scss';

@autobind
class Box extends Component {
    static propTypes = {
        box: PropTypes.object.isRequired
    };

    htmlContent = content => {
        return { __html: content };
    };
    
    render() {
        const { box } = this.props;

        return (
            <div className={cx(style.wrap)}>
                {box.map(type => (
                    <div className={cx(style.item)}>
                        <div className={cx(style.title)} dangerouslySetInnerHTML={this.htmlContent(type.value.Title)}/>
                        <div className={cx(style.text1)} dangerouslySetInnerHTML={this.htmlContent(type.value.Text1)}/>
                        {type.value.Text2 && <div className={cx(style.text2)} dangerouslySetInnerHTML={this.htmlContent(type.value.Text2)}/>}
                    </div>
                ))}
            </div>
        );
    }
}

export default Box;
