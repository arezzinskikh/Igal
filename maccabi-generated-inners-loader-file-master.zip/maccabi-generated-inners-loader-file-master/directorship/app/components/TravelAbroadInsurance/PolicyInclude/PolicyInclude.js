import React, { Component } from 'react';
import autobind from 'autobind';
import cx from 'classnames';
import style from './PolicyInclude.scss';
import mLib from '@maccabi/m-lib';
import { Item, H2 } from '@maccabi/m-ui';

@autobind
class PolicyInclude extends Component {
    static propTypes = {
        policyInclude: PropTypes.object.isRequired
    };

    render() {
        const { policyInclude } = this.props;

        return (
            <div className={cx(style.wrap)}>
                <H2 className={cx(style.title)}>
                    {mLib.resources.getResource('directorship/TravelAbroadInsurance', 'PolicyInclude_Title', 'פוליסת מדיכלל החדשה כוללת')}
                </H2>
                <div className={cx(style.items)}>
                    {policyInclude.map(item => (
                        <Item
                            className={cx(style.item)}
                            imgPath={process.env.MEDIA_DOMAIN + item.value.Image}
                            text={item.value.Text}
                            textClassName={cx(style.textClassName)}
                        />
                    ))}
                </div>
            </div>
        );
    }
}

export default PolicyInclude;
