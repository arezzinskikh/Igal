import React, { Component, Fragment } from 'react';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import autobind from 'autobind-decorator';
import style from './Header.scss';
import { Headline, Img, Button } from '@maccabi/m-ui';
import PropTypes from 'prop-types';

@autobind
class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    static propTypes = {
        isAdult: PropTypes.bool
    };

    buttonOnClick() {
        this.props.buttonOnClick();
    }

    render() {
        let calcIcon = require('./images/clalLogo.png');
        let { isAdult } = this.props;
        const isKosher = mLib.site.isKosher();

        return (
            <div className={cx(style.wrap)}>
                <div className={cx(style.wrapBackground, isKosher && style.wrapBackgroundKosher)}>
                    <Img className={cx(style.icon)} path={calcIcon} alt={'כלל ביטוח'} />
                </div>
                <div className={cx(style.box, isAdult && style.boxAdult)}>
                    <div className={style.insideBox}>
                        <Headline tag="H2" priority="4" className={cx(style.subTitle)}>
                            {mLib.resources.getResource(
                                'directorship/TravelAbroadInsurance',
                                'TravelAbroadInsurance_Banner_Title',
                                'ביטוח נסיעות לחו״ל קבוצתי לחברי מכבי שירותי בריאות'
                            )}
                        </Headline>
                        <div className={cx(style.firstText)}>
                            {mLib.resources.getResource(
                                'directorship/TravelAbroadInsurance',
                                'TravelAbroadInsurance_Banner_SubTitle',
                                'באמצעות כלל חברה לביטוח בע״מ'
                            )}
                        </div>

                        {isAdult ? (
                            <Fragment>
                                <div className={cx(style.secondText)}>
                                    {mLib.resources.getResource(
                                        'directorship/TravelAbroadInsurance',
                                        'TravelAbroadInsurance_Banner_Description_Adult',
                                        'לידיעתך, הפרטים האישיים שלך יועברו לאתר מדיכלל לצורך הרכישה. הפרטים כוללים: שם, תעודת זהות ומספר טלפון.'
                                    )}
                                </div>
                                <div className={style.covidText}>
                                    {mLib.resources.getResource(
                                        'directorship/TravelAbroadInsurance',
                                        'TravelAbroadInsurance_Banner_Description_COVID_TEXT',
                                        'נוכח המצב, מתאפשרת רכישת ביטוח נסיעות לחו"ל באופן מוגבל ובהתחשב במצב רפואי, גיל, יעד נסיעה, משך נסיעה ומועד הזמנה ביחס לנסיעה. מידע נוסף ניתן לקבל במוקד בטלפון 2627* או '
                                    )}
                                    <span className={style.covidPhone}>
                                    {mLib.resources.getResource(
                                        'directorship/TravelAbroadInsurance',
                                        'TravelAbroadInsurance_Banner_Description_COVID_PHONE',
                                        '03-7111172'
                                    )}
                                    </span>
                                </div>
                                <Button size="md" color="primary" onClick={() => this.buttonOnClick()} className={style.button}>
                                    {mLib.resources.getResource(
                                        'directorship/TravelAbroadInsurance',
                                        'TravelAbroadInsurance_Button',
                                        'לקבלת הצעה והצטרפות באתר כלל'
                                    )}
                                </Button>
                            </Fragment>
                        ) : (
                            <Fragment>
                                <div className={cx(style.thirdText)}>
                                    {mLib.resources.getResource(
                                        'directorship/TravelAbroadInsurance',
                                        'TravelAbroadInsurance_Banner_Description_Child',
                                        'רכישת פוליסות ביטוח חו״ל דרך האתר מתאפשרת לחברים מעל גיל 18.'
                                    )}
                                </div>
                                <div className={cx(style.fourthText)}>
                                    {mLib.resources.getResource(
                                        'directorship/TravelAbroadInsurance',
                                        'TravelAbroadInsurance_Banner_SubDescription_Child',
                                        'ניתן לפנות למוקד ״כלל ביטוח״ 2627* לקבלת סיוע.'
                                    )}
                                </div>
                            </Fragment>
                        )}
                    </div>
                </div>
            </div>
        );
    }
}

export default Header;
