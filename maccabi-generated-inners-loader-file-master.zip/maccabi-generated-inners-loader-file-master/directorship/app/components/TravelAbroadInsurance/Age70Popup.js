import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import mLib from '@maccabi/m-lib';
import { Modal } from '@maccabi/m-ui';

@autobind
class Age70Popup extends Component {
    static propTypes = {
        close: PropTypes.func.isRequired,
        isOpen: PropTypes.bool.isRequired
    };

    onClose() {
        this.props.close();
    }

    renderBodyModal() {
        return (
            <div className={'mt-2'}>
                <div>לרכישה יש לפנות למוקד כלל בטלפון 2627* </div>
                <div>או 1-700-702-202</div>
            </div>
        );
    }

    render() {
        const { isOpen } = this.props;

        return (
            <Modal
                isOpen={isOpen}
                icon={'travel-1'}
                toggle={this.onClose}
                header={mLib.resources.getResource(
                    'directorship/TravelAbroadInsurance',
                    'Age70Popup_Title',
                    'מעל גיל 70 פוליסת מדיכלל ניתנת לרכישה דרך מוקד כלל'
                )}
                body={mLib.resources.getResource(
                    'directorship/TravelAbroadInsurance',
                    'Age70Popup_Content',
                    this.renderBodyModal()
                )}
                primaryButton={mLib.resources.getResource('directorship/TravelAbroadInsurance', 'Age70Popup_Title', 'הבנתי, תודה')}
                primaryButtonClick={this.onClose}
            />
        );
    }
}

export default Age70Popup;
