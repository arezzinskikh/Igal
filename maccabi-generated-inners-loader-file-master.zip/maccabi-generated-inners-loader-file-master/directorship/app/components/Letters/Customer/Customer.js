import React, { Component } from 'react';
import { CustomerTimeLineItem, Pipe, PipeItem } from '@maccabi/m-ui';
import { LetterType } from '../../../containers/AppInner/Enums';
import cx from 'classnames';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';

@autobind
class Customer extends Component {
    static propTypes = {
        item: PropTypes.object.isRequired,
        loggedCustomerInfo: PropTypes.object.isRequired,
        staticTxt: PropTypes.object.isRequired,
        isChildInfo: PropTypes.bool.isRequired,
        index: PropTypes.string.isRequired,
        familyData: PropTypes.object.isRequired
    };

    getStatus(item) {
        switch (item.status) {
            case 0:
                return mLib.resources.getResource('directorship/lettersformember/lobby', 'Text_Status_.MembersPhrRecord_0', 'בטיפול');
            case 1:
                return mLib.resources.getResource('directorship/lettersformember/lobby', 'Text_Status_.MembersPhrRecord_1', 'הופק מסמך');
            default:
                return mLib.resources.getResource('directorship/lettersformember/lobby', 'Text_Status_.MembersPhrRecord_2', 'לא ניתן להפיק מסמך');
        }
    }

    childName(item) {
        let name;
        this.props.familyData.family_members.some(function(el) {
            if (el.member_id === item.member_id) {
                name = el.first_name;
                return true;
            }
        });
        return name;
    }

    getCustomerName() {
        const { item, loggedCustomerInfo, isChildInfo, staticTxt } = this.props;

        if (item.letter_type === LetterType.LettersForMembers) {
            if (item.child_info && loggedCustomerInfo) {
                return loggedCustomerInfo.f_name_hebrew + ' ' + staticTxt.for + ' ' + item.recipient_f_name;
            } else return item.recipient_f_name;
        } else if (item.letter_type !== LetterType.LettersForMembers) {
            if (isChildInfo && loggedCustomerInfo) {
                return loggedCustomerInfo.f_name_hebrew + ' ' + staticTxt.for + ' ' + this.childName(item);
            } else return loggedCustomerInfo.f_name_hebrew;
        }
    }

    render() {
        const { item, index } = this.props;

        return (
            <Pipe height={12}>
                <PipeItem>
                    <CustomerTimeLineItem data-hook={`name__${index}`}>{this.getCustomerName()}</CustomerTimeLineItem>
                </PipeItem>
                {item.letter_type === LetterType.MembersPhrRecord && (
                    <PipeItem className="pr-3">
                        <span className={cx('pr-3')}>{this.getStatus(item)}</span>
                    </PipeItem>
                )}
            </Pipe>
        );
    }
}

export default Customer;
