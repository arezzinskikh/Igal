

import React, { Component, Fragment } from 'react';
import style from './ButtonDocuments.scss';
import { ButtonDocument } from '@maccabi/m-ui';
import cx from 'classnames';
import autobind from 'autobind';
import { LetterType } from '../../../containers/AppInner/Enums';

@autobind
class ButtonDocuments extends Component {
    static propTypes = {
        item: PropTypes.object.isRequired,
        index: PropTypes.number.isRequired,
        openPdfHandler: PropTypes.func.isRequired,
        openPdfByLinkHandler: PropTypes.func.isRequired,
        openTutorialsHandler: PropTypes.func.isRequired
    };

    onClick(item, id) {
        if (item.letter_type === LetterType.LettersForMembers) {
            this.props.openPdfHandler(item, id);
        } else if (item.letter_type === LetterType.MembersPhrRecord && item.status === 1) {
            this.props.openPdfByLinkHandler(item, id);
        }
    }

    getIcon(name) {
        switch (name) {
            case 'webpage':
                return 'link';
            case 'video':
                return 'play';
            default:
                return 'pdf-icon';
        }
    }

    getTooltipText(name, display_text) {
        switch (name) {
            case 'webpage':
                return ' מידע בנושא ' + display_text;
            case 'video':
                return ' סרטון בנושא ' + display_text;
            default:
                return ' מסמך בנושא ' + display_text;
        }
    }

    render() {
        const { item, index } = this.props;

        return (
            <Fragment>
                {item.letter_type !== LetterType.MembersTutorials && (
                    <ButtonDocument
                        tooltipID={index}
                        className="mt-3"
                        hook={`btnPdf__${index}`}
                        onClick={() => this.onClick(item, `btnPdf__${index}`)}
                        icon={this.getIcon('pfd')}>
                        לצפייה
                    </ButtonDocument>
                )}
                {item.letter_type === LetterType.MembersTutorials && (
                    <div className={cx(style.wrap)}>
                        {item.tutorials.map((tutorial, innerIndex) => (
                            <ButtonDocument
                                tooltipText={this.getTooltipText(tutorial.tutorial_type, tutorial.display_text)}
                                tooltipID={index + '_' + innerIndex}
                                onClick={() => this.props.openTutorialsHandler(tutorial, 'doc' + index + '_' + innerIndex)}
                                hook={'doc' + index + '_' + innerIndex}
                                icon={this.getIcon(tutorial.tutorial_type)}
                                className={cx(style.item)}
                                iconclassname={cx(style[tutorial.tutorial_type])}>
                                לצפייה
                            </ButtonDocument>
                        ))}
                    </div>
                )}
            </Fragment>
        );
    }
}

export default ButtonDocuments;
