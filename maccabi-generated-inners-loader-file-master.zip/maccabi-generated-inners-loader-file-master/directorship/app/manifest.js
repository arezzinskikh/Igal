import { ModuleRegistry, ReactLazyComponent } from 'react-module-container';

class LazyApp extends ReactLazyComponent {
  constructor(props) {

    const { staticsBaseUrl } = props.topology;

    const manifest = {
      files: [
        `${staticsBaseUrl}app.js`,
        `${staticsBaseUrl}2.css`,
        `${staticsBaseUrl}4.css`,
        `${staticsBaseUrl}3.css`,
      ],
      component: 'DirectorshipApp',
      unloadStylesOnDestroy: true
    };

    super(props, manifest);
  }
}

ModuleRegistry.registerComponent('DirectorshipInner', () => LazyApp);
