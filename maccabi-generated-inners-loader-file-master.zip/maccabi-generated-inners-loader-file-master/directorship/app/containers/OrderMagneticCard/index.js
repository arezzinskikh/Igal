export { default } from './OrderMagneticCard';
