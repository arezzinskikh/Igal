import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import cx from 'classnames';
import autobind from 'autobind';
import format from 'string-format';
import mLib from '@maccabi/m-lib';
import OrderAlreadyExist from '../OrderAlreadyExist';
import Under18Lobby from '../Under18Lobby';
import { makeSelectOrderMagneticCardData } from '../selectors';
import reducer from '../reducer';
import saga from '../saga';
import { H1, H3, List, MainHeadline, MainHeadlineScrollable, MainBody, H4, Card, Icon, Button, IconLoader } from '@maccabi/m-ui';
import {
    RADIO_BUTTON_TEXT_VALUE,
    ORDER_SUMMARY_NOTE_OVER_18,
    ORDER_SUMMARY_NOTE_UNDER_18,
    ORDER_SUMMARY_TITLE,
    ORDER_SUMMARY_BUTTON_PRICE,
    ORDER_SUMMARY_BUTTON_FREE,
    ORDER_SUMMARY_REASON,
    ORDER_SUMMARY_PRICE_NOTE,
    ORDER_SUMMARY_UPDATE_ADDRESS,
    SUMMARY_PAGE_NAV,
    LOG_IDS, 
    MAGNETIC_CARD_ORDER_STEP, 
    MAIN_REMARKS,
    MODULE_INFO_TEXT_VALUE, 
    TERMS_LINK_TEXT_VALUE,
    TERMS_LINK_URL_TEXT_VALUE, 
    CARD_ISSUED_WARNING_TITLE, 
    LOBBY_PAGE_NAV, 
    REMARKS_TITLE, 
    ERROR_LOG 
} from '../constants';
import style from './OrderSummary.scss';

const mapStateToProps = createStructuredSelector({
    orderMagneticCardData: makeSelectOrderMagneticCardData
});

@withRouter
@connect(mapStateToProps, null)
@autobind
class OrderSummary extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isSend: false
        };
    }

    componentDidMount() {
        const { routeLeavingGuardOn } = this.props;
        routeLeavingGuardOn && routeLeavingGuardOn();
    }

    componentWillUnmount() {
        const { isSend } = this.state;
        if (!isSend) {
            this.props.unLoad();
        }
    }

    handleClick = () => {
        const { cost, onPress,routeLeavingGuardOff } = this.props; // , 
        routeLeavingGuardOff && routeLeavingGuardOff();
        this.setState({ isSend: true });
        if (cost > 0) {
            mLib.logs.insertCentralizedLog(LOG_IDS.ORDER_SUMMARY_FINISH_BTN_COST, SUMMARY_PAGE_NAV);
        } else {
            mLib.logs.insertCentralizedLog(LOG_IDS.ORDER_SUMMARY_FINISH_BTN_NO_COST, SUMMARY_PAGE_NAV);
        }
        
        onPress();
    };

    getReason = () => {
        const { reason } = this.props;
        const reasonWithText = RADIO_BUTTON_TEXT_VALUE.find(r => r.value.code === reason.code);
        return reasonWithText && reasonWithText.text;
    };

    onUpdateAddressClick = () => {
        const { onUpdateAddress } = this.props;
        mLib.logs.insertCentralizedLog(LOG_IDS.ORDER_SUMMARY_UPDATE_ADDRESS_BTN, SUMMARY_PAGE_NAV);
        onUpdateAddress && onUpdateAddress();
    };

    getAddress = () => {
        const { address } = this.props;
        if (address) {
            const { po_box, city_name, street_name, house_num, apartment_num, zip_code } = address;
            let apartment = '';
            // Has po box
            if (po_box && po_box !== 0) {
                return `ת.ד ${po_box}, ${city_name}`;
            }
            if (apartment_num && apartment_num !== null) {
                apartment = `דירה ${apartment_num}`;
            }

            return `${street_name} ${house_num} ${apartment}, ${city_name} ${zip_code}`;
        }

        return '';
    };
    get isLoggedUser() {
        const memberData = mLib.saveData.customerData.get();
        return memberData.current_customer_info.member_id === memberData.logged_customer_info.member_id;
    }

    validateNavigation(isOrderSummaryPage, isOrderSuccessPage) {
        let redirectTo = null;
        if (isOrderSummaryPage) {
            redirectTo = SUMMARY_PAGE_NAV;
        } else if (isOrderSuccessPage) {
            redirectTo = SUCCESS_PAGE_NAV;
        } else {
            redirectTo = LOBBY_PAGE_NAV;
        }

        return redirectTo;
    }

    getTitle() {
        const title = mLib.site.getModuleTitle(SUMMARY_PAGE_NAV, 'Title', 'הזמנת כרטיס מגנטי');
        return title;
    }

    getRemarks() {
        const {
            orderMagneticCardData: { cost, reason = {}, moduleStep = {} }
        } = this.props;

        /* Different remarks for order card confirmation page */
        if (moduleStep.key === MAGNETIC_CARD_ORDER_STEP.FINAL_CONFIRMATION_STEP.key) {
            if (cost && reason.code === 2) {
                return COST_REMARKS;
            }
        } else {
            return MAIN_REMARKS;
        }

        return [];
    }

    showSubContent() {
        const {
            orderMagneticCardData: { moduleStep = {} }
        } = this.props;
        return moduleStep.showSubContent;
    }

    renderSummary() {
        const { cost, loading, isTextForOver18 } = this.props;
        const subTitleText = isTextForOver18 ? ORDER_SUMMARY_NOTE_OVER_18 : ORDER_SUMMARY_NOTE_UNDER_18;
        const cardCostsMoney = cost > 0;
        const btnText = cardCostsMoney ? ORDER_SUMMARY_BUTTON_PRICE : ORDER_SUMMARY_BUTTON_FREE;

        return (
            <Card visibility="inner" className={cx(style.orderSummary, 'mb-0 mb-lg-7')}>
                <Icon name="card" iconclassname={style.cardIcon} />
                <H4 className={cx(style.title, 'mb-2')} hook="h4">
                    {ORDER_SUMMARY_TITLE}
                </H4>
                <span className={cx(style.address, 'mb-2')}>{format(ORDER_SUMMARY_REASON, this.getReason())}</span>
                <div className={style.priceContainer}>
                    {cardCostsMoney && <span className={style.infoText}>{format(ORDER_SUMMARY_PRICE_NOTE, cost)}</span>}
                </div>
                <span className={style.infoText}>{`${subTitleText}: ${this.getAddress()}`}</span>
                {this.isLoggedUser ? (
                    <div className={style.updateAddressContainer}>
                        <button className={style.link} onClick={this.onUpdateAddressClick}>
                            {ORDER_SUMMARY_UPDATE_ADDRESS}
                        </button>
                    </div>
                ) : (
                    <div>
                        <br />
                    </div>
                )}
                <div className="d-xl-flex">
                    <Button maincta className={style.button} size="md" color="primary" onClick={this.handleClick} hook="ok">
                        {loading && <IconLoader size="sm" className={cx(style.iconLoader)} />}
                        {btnText}
                    </Button>
                </div>
            </Card>
        );
    }


    render() {
        const {
            orderMagneticCardData: { moduleStep = {} }
        } = this.props;
        console.log(moduleStep.key);
        const showOrderCardSummary = moduleStep.key === MAGNETIC_CARD_ORDER_STEP.FINAL_CONFIRMATION_STEP.key;

        return (
            <Fragment>
                {showOrderCardSummary && this.renderSummary()}
            </Fragment>
        );
    }
}
OrderSummary.propTypes = {
    reason: PropTypes.object.isRequired,
    cost: PropTypes.number.isRequired,
    address: PropTypes.address.isRequired,
    loading: PropTypes.bool.isRequired,
    isTextForOver18: PropTypes.bool.isRequired,
    onPress: PropTypes.func.isRequired,
    onUpdateAddress: PropTypes.func
};

export default OrderSummary;
