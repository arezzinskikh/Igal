import React,{useEffect} from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import { Button, IconLoader } from '@maccabi/m-ui';
import Information from '../Information';
import { 
    LOBBY_PAGE_NAV,
    ORDER_SUCCESS_SUCCESS_TITLE,
    SUCCESS_PAGE_NAV,
    FINISH_BUTTON_TEXT,
    ORDER_FINISHED_BTN,
    ORDER_FINISHED_NOTE,
    LOG_IDS
} from '../constants';
import style from './OrderFinished.scss';

const OrderFinished = ({ onPress, title, loading, navigateTo,history }) => {

    const navigateToLobby = () => {
        navigateTo && navigateTo(`/${LOBBY_PAGE_NAV}/`);
    }
    useEffect(() => {
        window.addEventListener('popstate',navigateToLobby);

          return () => {
            setTimeout(() => {
                window.removeEventListener('popstate',navigateToLobby);
            }, 50);
          }
    },[])

    

    const getTitle = () => {
        return `${title} ${ORDER_SUCCESS_SUCCESS_TITLE}`;
    };

    const handleClick = () => {
        mLib.logs.insertCentralizedLog(LOG_IDS.ORDER_FINISHED_SHOWN, SUCCESS_PAGE_NAV);
        onPress();
    };

    const handleFinishClick = () => {
        navigateTo && navigateTo(mLib.url.getUrlByVersion(2, '/home'));
    };

    const hasFamily = () => {
        const memberData = mLib.saveData.customerData.get();
        return memberData.family_data.family_members.length > 1;
    };

    return (
        <div className={style.container}>
            <Information type={'success'} title={getTitle()} navigateTo={navigateTo} />
            {hasFamily() && (
                <div className={cx(style.orderMoreContainer, 'mb-3')}>
                    <div className={style.orderMoreText}>{ORDER_FINISHED_NOTE}</div>
                    <div className={style.orderMoreBtn}>
                        <Button className={style.btn} size="sm" color="primary" onClick={handleClick} hook="ok">
                            {loading && <IconLoader size="sm" className={cx(style.iconLoader)} />}
                            {ORDER_FINISHED_BTN}
                        </Button>
                    </div>
                </div>
            )}
            <div className={cx(style.finishBtn, 'd-lg-none d-flex')}>
                <Button maincta className={style.button} color="primary" onClick={handleFinishClick} hook="ok">
                    {FINISH_BUTTON_TEXT}
                </Button>
            </div>
        </div>
    );
};

OrderFinished.propTypes = {
    onPress: PropTypes.func.isRequired,
    title: PropTypes.string.isRequired,
    loading: PropTypes.bool.isRequired
};

export default OrderFinished;
