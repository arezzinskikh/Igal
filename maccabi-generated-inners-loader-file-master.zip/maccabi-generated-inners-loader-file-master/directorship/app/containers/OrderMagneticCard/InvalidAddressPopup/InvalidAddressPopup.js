import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import mLib from '@maccabi/m-lib';
import { Modal } from '@maccabi/m-ui';
import { LOBBY_PAGE_NAV, INVALID_ADDRESS_TITLE, INVALID_ADDRESS_BODY, 
    INVALID_ADDRESS_PRIMARY_BUTTON_TEXT, SHOW_LOG_ID, LOG_IDS } from '../constants';

const ICON = 'attention-big';

@autobind
class InvalidAddressPopup extends Component {
    static propTypes = {
        updateAddress: PropTypes.func.isRequired,
        close: PropTypes.func.isRequired,
        isOpen: PropTypes.bool.isRequired
    };

    componentDidMount() {
        mLib.logs.insertCentralizedLog(LOG_IDS.INVALID_ADDRESS_POPUP_SHOW, LOBBY_PAGE_NAV, SHOW_LOG_ID, false);
    }

    onClose() {
        const { close } = this.props;
        close();
    }

    onPrimaryButtonClick() {
        const { updateAddress } = this.props;
        updateAddress();
    }

    render() {
        const { isOpen } = this.props;

        return (
            <Modal
                isOpen={isOpen}
                icon={ICON}
                toggle={this.onClose}
                header={INVALID_ADDRESS_TITLE}
                body={INVALID_ADDRESS_BODY}
                primaryButton={INVALID_ADDRESS_PRIMARY_BUTTON_TEXT}
                primaryButtonClick={this.onPrimaryButtonClick} />
        )
    }
}

export default InvalidAddressPopup;