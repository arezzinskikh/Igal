import { takeLatest, call, put } from 'redux-saga/effects';
import { 
    ORDER_COST_REQUEST,
    FINISH_ORDER,
    ORDER_CARD_SUCCESS_CODE,
    ERROR_PAGE_NAV,
    SUCCESS_PAGE_NAV,
    SUMMARY_PAGE_NAV,
    REASON_CODES
} from './constants';
import { 
    toggleLoading,
    setCost,
    orderFinished,
    setCardIssued,
    setInactiveDebitCard, 
    setInvalidAddress,
    setError } from './actions';
import mLib from '@maccabi/m-lib';
import { getCardCost, finishOrder } from '../../services/OrderMagneticCard/apiService';
const { setGlobalLoading } = mLib.saveData.globalLoader;

function selectAction(isCardIssuedAlert, isAddressValidAlert, hasActiveDebitCard, cost) {
    if (isCardIssuedAlert) {
        return setCardIssued();
    } else if (isAddressValidAlert) {
        return setInvalidAddress();
    } else if (cost > 0 && !hasActiveDebitCard) {
        return setInactiveDebitCard();
    } else {
        return setCost(cost);
    }
}

function moveToPage(contex,action) {
    action(`/${contex}/`.toLowerCase());
}

const MOVE_TO_CONTEX = {
    ERROR_PAGE_NAV,
    SUCCESS_PAGE_NAV,
    SUMMARY_PAGE_NAV,
}

function* handleOrderCostRequest(action) {
    const { reason, activeUser, onAfterMemberDataUpdated, isMobile,redirectAction } = action;

    try {
        if (isMobile) {
            yield call(setGlobalLoading, true);
        }
        yield put(toggleLoading());

        // Set new customer data to session in case the member updated its credit card information
        yield call(mLib.customer.getCustomerData);
        mLib.saveData.customerData.setCurrent(null);
        mLib.saveData.customerData.setCurrent(activeUser);
        onAfterMemberDataUpdated && onAfterMemberDataUpdated();

        const memberData = mLib.saveData.customerData.get();
        const loggedUser = memberData.logged_customer_info;

        const result = yield call(getCardCost, loggedUser.member_id_code, loggedUser.member_id, activeUser.member_id_code, activeUser.member_id);
        const { members } = result;
        const currentMember = members.find(member => member.mem_id === activeUser.member_id && member.mem_code === activeUser.member_id_code);
        const { is_card_issued_alert, is_address_invalid_alert, lost_card_cost, stolen_card_cost, invalid_card_cost } = currentMember;

        const reasonCode = reason.code;
        let cost = -1;
        
        switch (reasonCode) {
            case REASON_CODES.LOST:
                cost = lost_card_cost;
                break;
            case REASON_CODES.STOLEN:
                cost = stolen_card_cost;
                break;
            case REASON_CODES.NOT_VALID_CARD:
                cost = invalid_card_cost;
                break;
        }

        yield put(selectAction(is_card_issued_alert, is_address_invalid_alert, loggedUser.is_charge_allowed, cost));
        if(!is_address_invalid_alert && !(!loggedUser.is_charge_allowed && cost > 0)){
            if (is_card_issued_alert) {
                yield call(moveToPage,MOVE_TO_CONTEX.ERROR_PAGE_NAV,redirectAction);
            }else{
                yield call(moveToPage,MOVE_TO_CONTEX.SUMMARY_PAGE_NAV,redirectAction);
            }
        }
    } catch (err) {
        console.error('err', err);
        yield put(setError());
        yield call(moveToPage,MOVE_TO_CONTEX.ERROR_PAGE_NAV,redirectAction);
    } finally {
        if (isMobile) {
            yield call(setGlobalLoading, false);
        }
        yield put(toggleLoading());
    }
}

function* handleFinishOrder(action) {
    const {redirectAction,memberData,reason} = action;

    try {
        const currentCustomerInfo = memberData.current_customer_info;
        const loggedInUser = memberData.logged_customer_info;

        yield put(toggleLoading());
        const result = yield call(
            finishOrder,
            loggedInUser.member_id_code,
            loggedInUser.member_id,
            currentCustomerInfo.member_id_code,
            currentCustomerInfo.member_id,
            reason.code
        );
        const { members } = result;
        const currentMember = members.find(
            member => member.mem_id === currentCustomerInfo.member_id && member.mem_code === currentCustomerInfo.member_id_code
        );
        const { issue_status = undefined } = currentMember;

        if (issue_status !== ORDER_CARD_SUCCESS_CODE) {
            yield put(setError());
            yield call(moveToPage,MOVE_TO_CONTEX.ERROR_PAGE_NAV,redirectAction);
        } else {
            yield put(orderFinished());
            yield call(moveToPage,MOVE_TO_CONTEX.SUCCESS_PAGE_NAV,redirectAction);
        }
    } catch (err) {
        console.error('err', err);
        yield put(setError());
        yield call(moveToPage,MOVE_TO_CONTEX.ERROR_PAGE_NAV,redirectAction);
    } finally {
        yield put(toggleLoading());
    }
}

export default function* rootSaga() {
    yield [
        takeLatest(ORDER_COST_REQUEST, handleOrderCostRequest),
        takeLatest(FINISH_ORDER, handleFinishOrder)
    ];
}
