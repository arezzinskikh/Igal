import { ORDER_COST_REQUEST, SET_REASON, ON_LOAD, TOGGLE_LOADING, SET_COST, FINISH_ORDER, ORDER_FINISHED, CARD_ISSUED, 
    SET_INACTIVE_DEBIT_CARD, SET_INVALID_ADDRESS, RESET, SET_ERROR, ON_UNLOAD, KEEP_STATE_ON_LOAD } from './constants';

export function onLoad() {
    return {
        type: ON_LOAD
    };
}

export function onUnload() {
    return {
        type: ON_UNLOAD
    };
}

export function reset() {
    return {
        type: RESET
    };
}

export function toggleLoading() {
    return {
        type: TOGGLE_LOADING
    }
}

export function orderCostRequest(reason, activeUser, onAfterMemberDataUpdated,isMobile,redirectAction) {
    return {
        type: ORDER_COST_REQUEST,
        reason: reason,
        activeUser: activeUser,
        onAfterMemberDataUpdated: onAfterMemberDataUpdated,
        isMobile,
        redirectAction
    };
}

export function setCost(cost) {
    return {
       type: SET_COST,
       cost: cost
    }
}

export function setInactiveDebitCard() {
    return {
        type: SET_INACTIVE_DEBIT_CARD
    }
}

export function setInvalidAddress() {
    return {
        type: SET_INVALID_ADDRESS
    }
}

export function orderFinished() {
    return {
        type: ORDER_FINISHED
    }
}

export function setReason(reason) {
    return {
        type: SET_REASON,
        reason
    };
}

export function finishOrder(memberData, reason,redirectAction) {
    return {
        type: FINISH_ORDER,
        memberData,
        reason,
        redirectAction
    }; 
}

export function setCardIssued() {
    return {
        type: CARD_ISSUED        
    }
}

export function setError() {
    return {
        type: SET_ERROR
    }
}

export function keepStateOnLoad() {
    return {
        type: KEEP_STATE_ON_LOAD
    }
}