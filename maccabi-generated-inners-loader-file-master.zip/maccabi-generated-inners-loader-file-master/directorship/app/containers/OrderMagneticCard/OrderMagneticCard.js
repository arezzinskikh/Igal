import React, { Component, Fragment } from 'react';
import { Route, withRouter, Switch } from 'react-router-dom';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import cx from 'classnames';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import { H1, H3, List, MainHeadline, MainHeadlineScrollable, MainBody } from '@maccabi/m-ui';
import Lobby from './Lobby';
import OrderSummary from './OrderSummary';
import NoDebitCardPopup from './NoDebitCardPopup';
import InvalidAddressPopup from './InvalidAddressPopup';
import reducer from './reducer';
import saga from './saga';
import { orderCostRequest, setReason, onLoad, onUnload, keepStateOnLoad, finishOrder, reset } from './actions';
import { makeSelectOrderMagneticCardData } from './selectors';
import {
    LOBBY_PAGE_NAV,
    SUMMARY_PAGE_NAV,
    SUCCESS_PAGE_NAV,
    MODULE_INFO_TEXT_VALUE,
    TERMS_LINK_TEXT_VALUE,
    MAIN_REMARKS,
    MAGNETIC_CARD_ORDER_STEP,
    TERMS_LINK_URL_TEXT_VALUE,
    COST_REMARKS,
    CARD_ISSUED_UNDER_18,
    CARD_ISSUED_OVER_18,
    ERROR_LOG,
    MAGNETIC_CARD_POPUPS,
    MIN_AGE_TO_ORDER_CARD,
    REMARKS_TITLE,
    ORDER_CARD_TITLE,
    EDIT_INFORMATION_URL,
    ERROR_PAGE_NAV
} from './constants';
import OrderFinished from './OrderFinished';
import { getBestFitAddress } from './utils';
import OrderError from './OrderError/OrderError';
import style from './OrderMagneticCard.scss';

const mapDispatchToProps = dispatch => ({
    orderCostRequest: (reason, activeUser, onAfterMemberDataUpdated, isMobile, redirectAction) =>
        dispatch(orderCostRequest(reason, activeUser, onAfterMemberDataUpdated, isMobile, redirectAction)),
    setReason: reason => dispatch(setReason(reason)),
    onLoad: () => dispatch(onLoad()),
    onUnload: () => dispatch(onUnload()),
    reset: () => dispatch(reset()),
    keepStateOnLoad: () => dispatch(keepStateOnLoad()),
    finishOrder: (memberData, reason, redirectAction) => dispatch(finishOrder(memberData, reason, redirectAction))
});

const mapStateToProps = createStructuredSelector({
    orderMagneticCardData: makeSelectOrderMagneticCardData
});

@withRouter
@mLib.appInfra.injectReducer({ key: 'orderMagneticCardData', reducer })
@mLib.appInfra.injectSaga({ key: 'orderMagneticCard', saga })
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class OrderMagneticCard extends Component {
    constructor(props) {
        super(props);
        this.setCustomerData();
    }

    routeLeavingGuardIsOn = false;
    /* When set to true, route leaving guard func will not work */
    forceRouteLeavingGuardOff = false;

    setCustomerData = () => {
        this.memberData = mLib.saveData.customerData.get();
    };

    turnRouteLeavingGuardOn() {
        const propsLeaving = {
            shouldBlockNavigation: true,
            navigate: this.props.history.push
        };

        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    turnRouteLeavingGuardOff() {
        const propsLeaving = {
            shouldBlockNavigation: false,
            navigate: this.props.history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    componentDidMount() {
        const {
            orderMagneticCardData: { reason = undefined, cost = undefined, moduleStep = undefined },
            history
        } = this.props;

        if (reason && cost >= 0 && moduleStep) {
            if (moduleStep.key === MAGNETIC_CARD_ORDER_STEP.FINAL_CONFIRMATION_STEP.key && history.location.pathname !== `/${SUMMARY_PAGE_NAV}/`) {
                history.push(`/${SUMMARY_PAGE_NAV}/`.toLowerCase());
            } else {
                history.push(`/${LOBBY_PAGE_NAV}/`);
            }
        } else {
            history.push(`/${LOBBY_PAGE_NAV}/`);
        }

        this.props.onLoad(this.memberData.current_customer_info.member_id);
    }

    componentWillUnmount() {
        this.props.onUnload();
    }

    setReason(reason) {
        this.props.setReason(reason);
    }

    navigateTo = url => {
        this.props.history.push(`/go/${encodeURIComponent(url)}`);
    };

    submitOrderCostRequest(isMobile) {
        const {
            orderMagneticCardData: { reason = undefined },
            history
        } = this.props;
        const currentUser = mLib.saveData.customerData.get().current_customer_info;

        /* Re init customers data as cost function sets customers data to session, because update address popup may occur,
            And the user might be updated its info */
        this.props.orderCostRequest(reason, currentUser, this.setCustomerData, isMobile, history.push);
    }

    getRemarks() {
        const {
            orderMagneticCardData: { cost, reason = {}, moduleStep = {} }
        } = this.props;

        /* Different remarks for order card confirmation page */
        if (moduleStep.key === MAGNETIC_CARD_ORDER_STEP.FINAL_CONFIRMATION_STEP.key) {
            if (cost && reason.code === 2) {
                return COST_REMARKS;
            }
        } else {
            const main_remarks2 = MAIN_REMARKS[1] + '<a href="/directorship/CreditsAndDebits/DirectDebit/"> כאן</a>';
            const main_remarks = [MAIN_REMARKS[0], main_remarks2, MAIN_REMARKS[2]];
            return main_remarks;
        }

        return [];
    }

    get address() {
        const addresses = this.memberData.current_customer_info.addresses || this.memberData.logged_customer_info.addresses;
        return getBestFitAddress(addresses);
    }

    showSubContent() {
        const {
            orderMagneticCardData: { moduleStep = {} }
        } = this.props;
        return moduleStep.showSubContent;
    }

    finishOrder() {
        const {
            orderMagneticCardData: { reason = undefined },
            history
        } = this.props;
        this.turnRouteLeavingGuardOff();
        this.props.finishOrder(this.memberData, reason, history.push);
    }

    get cardIssuedText() {
        return this.isTextForOver18 ? CARD_ISSUED_OVER_18 : CARD_ISSUED_UNDER_18;
    }

    get isOver18() {
        const memberData = mLib.saveData.customerData.get();
        return memberData.logged_customer_info.age.years >= MIN_AGE_TO_ORDER_CARD;
    }

    get isTextForOver18() {
        return this.memberData.current_customer_info.age.years >= MIN_AGE_TO_ORDER_CARD;
    }

    updateDebitCardInfo() {
        window.open(process.env.EDIT_DIRECT_DEBIT, '_blank');
    }

    updateValidAddress() {
        /* Keep the state so the customer would return to previous state of magnetic card order */
        this.props.keepStateOnLoad();
        this.updateAddress();
    }

    updateAddress() {
        this.turnRouteLeavingGuardOff();

        /* Preform after a little timeout so setting route leaving guard off will take effect */
        window.setTimeout(
            () =>
                this.props.history.push({
                    pathname: mLib.url.getUrlByVersion(1, EDIT_INFORMATION_URL),
                    search: `?returnUrl=${encodeURIComponent(this.props.history.location.pathname.toLowerCase())}`
                }),
            100
        );
    }

    orderForSibling() {
        this.props.wrapperCommand('maccabi/wrapper/app/OPEN_IMPERSONATION_MODAL');
    }

    renderInnerContent() {
        const {
            orderMagneticCardData: { reason = undefined, loading = undefined, cost = undefined, moduleStep = {} }
        } = this.props;
        const isOver18YearsOld = this.isOver18;
        const isTextForOver18 = this.isTextForOver18;
        const showCardIssued = moduleStep.key === MAGNETIC_CARD_ORDER_STEP.CARD_ISSUED_STEP.key;
        const showUnder18Lobby = moduleStep.key === MAGNETIC_CARD_ORDER_STEP.INITIAL_STEP.key && !isOver18YearsOld;
        const showErrorPage = moduleStep.key === MAGNETIC_CARD_ORDER_STEP.GENERIC_ERROR.key;

        return (
            <Fragment>
                <Switch>
                    <Route
                        path={`/${ERROR_PAGE_NAV}/`.toLowerCase()}
                        render={() => (
                            <OrderError
                                ERROR_LOG={ERROR_LOG}
                                ErrorInModule={this.props.ErrorComponent}
                                navigateTo={this.navigateTo}
                                cardIssuedText={this.cardIssuedText}
                                showCardIssued={showCardIssued}
                                showUnder18Lobby={showUnder18Lobby}
                                showErrorPage={showErrorPage}
                            />
                        )}
                    />
                    <Route
                        path={`/${LOBBY_PAGE_NAV}/`.toLowerCase()}
                        render={() => <Lobby setReason={this.setReason} reason={reason} onClick={this.submitOrderCostRequest} loading={loading} />}
                    />
                    <Route
                        path={`/${SUCCESS_PAGE_NAV}/`.toLowerCase()}
                        render={() => (
                            <OrderFinished
                                onPress={this.orderForSibling}
                                title={ORDER_CARD_TITLE}
                                RouteLeavingGuardOn={this.turnRouteLeavingGuardOn}
                                navigateTo={this.props.history.push}
                                history={this.props.history}
                            />
                        )}
                    />
                    <Route
                        path={`/${SUMMARY_PAGE_NAV}/`.toLowerCase()}
                        render={() => (
                            <OrderSummary
                                onPress={this.finishOrder}
                                onUpdateAddress={this.updateValidAddress}
                                isOver18={isOver18YearsOld}
                                reason={reason}
                                cost={cost}
                                unLoad={this.props.onUnload}
                                routeLeavingGuardOn={this.turnRouteLeavingGuardOn}
                                routeLeavingGuardOff={this.turnRouteLeavingGuardOff}
                                address={this.address}
                                loading={loading}
                                isTextForOver18={isTextForOver18}
                            />
                        )}
                    />
                </Switch>
            </Fragment>
        );
    }

    onClose() {
        const { reset, history } = this.props;
        reset();
        history.push(`/${LOBBY_PAGE_NAV}/`);
    }
    renderPopup() {
        const {
            orderMagneticCardData: { popup = undefined }
        } = this.props;
        const showInvalidAddressPopup = popup === MAGNETIC_CARD_POPUPS.INVALID_ADDRESS_POPUP;
        const showInactiveDebitCardPopup = popup === MAGNETIC_CARD_POPUPS.INACTIVE_DEBIT_CARD_POPUP;

        return (
            <Fragment>
                {showInvalidAddressPopup && (
                    <InvalidAddressPopup isOpen={showInvalidAddressPopup} close={this.onClose} updateAddress={this.updateAddress} />
                )}
                {showInactiveDebitCardPopup && (
                    <NoDebitCardPopup isOpen={showInactiveDebitCardPopup} close={this.onClose} updateDebitCardInfo={this.updateDebitCardInfo} />
                )}
            </Fragment>
        );
    }

    getTitle() {
        const title = mLib.site.getModuleTitle(LOBBY_PAGE_NAV, 'Title', 'הזמנת כרטיס מגנטי');
        return title;
    }

    render() {
        const {
            orderMagneticCardData: { moduleStep = {} }
        } = this.props;
        const remarks = this.getRemarks();
        const hasRemarks = remarks.length > 0;
        const containerClassName = cx(style.wrap, {
            [style.hideSubContentInMobile]: moduleStep.hideSubContentInMobile,
            [style.hideRemarksInMobile]: moduleStep.hideRemarksInMobile
        });

        return (
            <Fragment>
                <MainHeadline>
                    <MainHeadlineScrollable>
                        <H1 className={style.title} hook="title">
                            {this.getTitle()}
                        </H1>
                    </MainHeadlineScrollable>
                </MainHeadline>
                <MainBody scrollClassName={style.scrollCardBody}>
                    <div className={containerClassName}>
                        <div className={style.content}>
                            {this.showSubContent() && (
                                <div className={style.subContentContainer}>
                                    <div className={cx(style.intoContainer, 'text-secondary')}>{MODULE_INFO_TEXT_VALUE}</div>
                                    <a className={style.openTerms} target="_blank" href={TERMS_LINK_URL_TEXT_VALUE}>
                                        {TERMS_LINK_TEXT_VALUE}
                                    </a>
                                </div>
                            )}
                            {this.renderInnerContent()}
                            {this.renderPopup()}
                            {hasRemarks && (
                                <div className={cx('d-xl-block mt-5', style.remarksContainer)}>
                                    <H3 className="mb-5">{REMARKS_TITLE}</H3>
                                    <List className={cx(style.list, 'text-secondary')} list={remarks} />
                                </div>
                            )}
                        </div>
                    </div>
                </MainBody>
            </Fragment>
        );
    }
}

export default OrderMagneticCard;
