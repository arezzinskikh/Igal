import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import mLib from '@maccabi/m-lib';
import Information from '../Information';
import { LOBBY_PAGE_NAV, LOG_IDS } from '../constants';
import style from './OrderAlreadyExist.scss';

const OrderAlreadyExist = ({ title, children, navigateTo }) => {
    useEffect(() => {
        mLib.logs.insertCentralizedLog(LOG_IDS.ORDER_ALREADY_EXISTS_SHOWN, LOBBY_PAGE_NAV, process.env.LOG_ACTION_ID_SCREEN_OPEN, false);
    }, []);

    return (
        <Information type={'danger'} title={title} className={style.container} navigateTo={navigateTo}>
            {children}
        </Information>
    );
};

OrderAlreadyExist.propTypes = {
    title: PropTypes.string.isRequired,
    children: PropTypes.node,
    navigateTo: PropTypes.func
};

export default OrderAlreadyExist;
