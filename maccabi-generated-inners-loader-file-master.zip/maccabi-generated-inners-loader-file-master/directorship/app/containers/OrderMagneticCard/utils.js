const ADDRESS_STATUS = {
    PRIVATE: 'פ',
    FAMILY: 'מ'
};

const ADDRESS_TYPE = {
    PO_BOX: 'ד',
    LIVING_ADDRESS: 'מ'
};

const findAddress = (addresses, status, type) => {
    return addresses.find(adr => adr.address_status === status && adr.address_type === type);
};

export const getBestFitAddress = addresses => {
    let address = null;

    if (addresses) {
        address = findAddress(addresses, ADDRESS_STATUS.PRIVATE, ADDRESS_TYPE.PO_BOX);

        if (!address) {
            address = findAddress(addresses, ADDRESS_STATUS.FAMILY, ADDRESS_TYPE.PO_BOX);
        }

        if (!address) {
            address = findAddress(addresses, ADDRESS_STATUS.FAMILY, ADDRESS_TYPE.LIVING_ADDRESS);
        }
    }

    return address;
};
