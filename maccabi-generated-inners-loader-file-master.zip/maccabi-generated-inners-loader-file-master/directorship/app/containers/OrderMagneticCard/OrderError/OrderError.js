import React, { Fragment, useEffect } from 'react';
import PropTypes from 'prop-types';
import mLib from '@maccabi/m-lib';
import OrderAlreadyExist from '../OrderAlreadyExist';
import Under18Lobby from '../Under18Lobby';
import { LOBBY_PAGE_NAV, LOG_IDS, CARD_ISSUED_WARNING_TITLE } from '../constants';

const OrderError = ({ navigateTo, ErrorInModule, cardIssuedText, ERROR_LOG, showCardIssued, showUnder18Lobby, showErrorPage }) => {
    useEffect(() => {
        mLib.logs.insertCentralizedLog(LOG_IDS.ORDER_ALREADY_EXISTS_SHOWN, LOBBY_PAGE_NAV, process.env.LOG_ACTION_ID_SCREEN_OPEN, false);
    }, []);

    const ErrorInModuleCompoennt = ErrorInModule;
    
    return (
        <Fragment>
            {showErrorPage && <ErrorInModuleCompoennt log={ERROR_LOG} />}
            {showCardIssued && (
                <OrderAlreadyExist navigateTo={navigateTo} title={CARD_ISSUED_WARNING_TITLE}>
                    {cardIssuedText}
                </OrderAlreadyExist>
            )}
            {showUnder18Lobby && <Under18Lobby navigateTo={navigateTo} />}
        </Fragment>
    )
}

OrderError.propTypes = {
    navigateTo: PropTypes.func
};

export default OrderError;