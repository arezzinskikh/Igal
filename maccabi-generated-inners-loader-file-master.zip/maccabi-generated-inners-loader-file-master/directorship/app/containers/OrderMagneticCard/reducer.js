import { fromJS } from 'immutable';
import { DEFAULT_REASON, SET_REASON, ON_LOAD, SET_COST, TOGGLE_LOADING, ORDER_FINISHED, 
    CARD_ISSUED, SET_INACTIVE_DEBIT_CARD, SET_INVALID_ADDRESS, RESET, MAGNETIC_CARD_ORDER_STEP, MAGNETIC_CARD_POPUPS,
    SET_ERROR, ON_UNLOAD, KEEP_STATE_ON_LOAD, } from './constants';

const PROP_NAME = 'orderMagneticCardData';

function getOrderMagneticCardState(customerId, reason) {
    const reasonToSet = reason ? reason : DEFAULT_REASON;

    return {
        reason: reasonToSet,
        loading: false,
        cost: -1,
        moduleStep: MAGNETIC_CARD_ORDER_STEP.INITIAL_STEP,
        popup: null,
        keepStateOnLoad: false
    }
}

export const initialState = fromJS({
    [PROP_NAME]: getOrderMagneticCardState(null, DEFAULT_REASON)
});

export default function orderMagneticCardReducer(state = initialState, action) {
    const orderMagneticCardData = { ...state.get(PROP_NAME) };

    switch (action.type) {
        case ON_LOAD:
            if (orderMagneticCardData.keepStateOnLoad) {
                orderMagneticCardData.keepStateOnLoad = false;
                return state.set(PROP_NAME, orderMagneticCardData);
            }
            return state.set(PROP_NAME, getOrderMagneticCardState(action.currentCustomerId, DEFAULT_REASON));
        case RESET:
            return state.set(PROP_NAME, getOrderMagneticCardState(orderMagneticCardData.currentCustomerId, orderMagneticCardData.reason));
        case ON_UNLOAD:
            if (orderMagneticCardData.keepStateOnLoad) {
                return state;
            }
            return state.set(PROP_NAME, getOrderMagneticCardState(null, DEFAULT_REASON));
        case KEEP_STATE_ON_LOAD:
            orderMagneticCardData.keepStateOnLoad = true;
            return state.set(PROP_NAME, orderMagneticCardData);
        case SET_COST:
            orderMagneticCardData.cost = action.cost;
            orderMagneticCardData.moduleStep = MAGNETIC_CARD_ORDER_STEP.FINAL_CONFIRMATION_STEP;
            return state.set(PROP_NAME, orderMagneticCardData);
        case SET_REASON:
            orderMagneticCardData.reason = action.reason;
            return state.set(PROP_NAME, orderMagneticCardData);
        case TOGGLE_LOADING:
            orderMagneticCardData.loading = !orderMagneticCardData.loading;
            return state.set(PROP_NAME, orderMagneticCardData);
        case ORDER_FINISHED: {
            orderMagneticCardData.moduleStep = MAGNETIC_CARD_ORDER_STEP.ORDER_FINISHED_STEP;
            return state.set(PROP_NAME, orderMagneticCardData);
        }
        case CARD_ISSUED: {
            orderMagneticCardData.moduleStep = MAGNETIC_CARD_ORDER_STEP.CARD_ISSUED_STEP;
            return state.set(PROP_NAME, orderMagneticCardData);
        }
        case SET_INACTIVE_DEBIT_CARD: {
            orderMagneticCardData.popup = MAGNETIC_CARD_POPUPS.INACTIVE_DEBIT_CARD_POPUP;
            return state.set(PROP_NAME, orderMagneticCardData);
        }
        case SET_INVALID_ADDRESS: {
            orderMagneticCardData.popup = MAGNETIC_CARD_POPUPS.INVALID_ADDRESS_POPUP;
            return state.set(PROP_NAME, orderMagneticCardData);
        }
        case SET_ERROR: {
            orderMagneticCardData.moduleStep = MAGNETIC_CARD_ORDER_STEP.GENERIC_ERROR;
            return state.set(PROP_NAME, orderMagneticCardData);
        }
        default:
            return state;
    }
}