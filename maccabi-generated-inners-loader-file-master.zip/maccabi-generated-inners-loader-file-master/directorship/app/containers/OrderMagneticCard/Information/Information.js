import React from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import { Card, H4, Icon, Button } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import { FINISH_BUTTON_TEXT } from '../constants';
import style from './Information.scss';

const TYPES = ['success', 'danger'];
const TYPE_TO_ICON = {
    success: 'success-big',
    danger: 'attention-big'
};

const Information = ({ type, title, children, className, navigateTo }) => {
    const handleFinishClick = () => {
        navigateTo && navigateTo(mLib.url.getUrlByVersion(2, '/home'));
    };

    const iconName = TYPE_TO_ICON[type];

    return (
        <Card visibility="inner" className={cx(style.container, 'mb-0 mb-lg-7', className)}>
            <div className={cx(style.innerContainer, 'mb-0 mb-lg-3')}>
                <Icon name={iconName} iconclassname={style.icon} />
                <H4 className={style.title} hook="h4">
                    {title}
                </H4>
                {children && <div className={cx(style.content, 'mt-3')}>{children}</div>}
            </div>

            {navigateTo && (
                <div className={cx(style.finishBtn, 'd-xl-none d-flex')}>
                    <Button maincta className={style.button} color="primary" onClick={handleFinishClick} hook="ok">
                        {FINISH_BUTTON_TEXT}
                    </Button>
                </div>
            )}
        </Card>
    );
};

Information.propTypes = {
    type: PropTypes.oneOf(TYPES).isRequired,
    title: PropTypes.string.isRequired,
    children: PropTypes.node,
    className: PropTypes.string,
    navigateTo: PropTypes.func
};

export default Information;
