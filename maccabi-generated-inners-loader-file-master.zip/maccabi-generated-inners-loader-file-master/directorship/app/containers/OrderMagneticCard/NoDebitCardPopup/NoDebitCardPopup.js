import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import mLib from '@maccabi/m-lib';
import { Modal } from '@maccabi/m-ui';
import { LOBBY_PAGE_NAV, NO_DEBIT_CARD_TITLE, NO_DEBIT_CARD_BODY, NO_DEBIT_CARD_BODY_KOSHER, NO_DEBIT_CARD_PRIMARY_BUTTON_TEXT,
    NO_DEBIT_CARD_SECONDARY_BUTTON_TEXT, DEBIT_CARD_POPUP_LOG_ID, SHOW_LOG_ID, LOG_IDS } from '../constants';
import style from './NoDebitCardPopup.scss';

@autobind
class NoDebitCardPopup extends Component {
    static propTypes = {
        updateDebitCardInfo: PropTypes.func.isRequired,
        close: PropTypes.func.isRequired,
        isOpen: PropTypes.bool.isRequired
    };

    componentDidMount() {
        mLib.logs.insertCentralizedLog(LOG_IDS.NO_DEBIT_CARD_POPUP_SHOWN, LOBBY_PAGE_NAV, SHOW_LOG_ID, false);
    }

    onClose() {
        const { close } = this.props;
        mLib.logs.insertCentralizedLog(LOG_IDS.NO_DEBIT_CARD_POPUP_CLOSE, LOBBY_PAGE_NAV, DEBIT_CARD_POPUP_LOG_ID);
        close();
    }

    onPrimaryButtonClick() {
        const { updateDebitCardInfo } = this.props;
        mLib.logs.insertCentralizedLog(LOG_IDS.NO_DEBIT_CARD_POPUP_NAVIGATE, LOBBY_PAGE_NAV, DEBIT_CARD_POPUP_LOG_ID);
        updateDebitCardInfo();
    }

    onSecondaryButtonClick() {
        const { close } = this.props;
        mLib.logs.insertCentralizedLog(LOG_IDS.NO_DEBIT_CARD_POPUP_CLOSE, LOBBY_PAGE_NAV), DEBIT_CARD_POPUP_LOG_ID;
        close();
    }

    get content() {
        return mLib.site.isKosher() ? NO_DEBIT_CARD_BODY_KOSHER : NO_DEBIT_CARD_BODY;
    }

    render() {
        const { isOpen } = this.props;
        const isKosher = mLib.site.isKosher();

        return (
            <Modal
                isOpen={isOpen}
                icon={'attention-big'}
                toggle={this.onClose}
                header={NO_DEBIT_CARD_TITLE}
                body={this.content}
                footerClassName={isKosher ? style.hiddenFotter : ''}
                primaryButton={NO_DEBIT_CARD_PRIMARY_BUTTON_TEXT}
                primaryButtonClick={this.onPrimaryButtonClick}
                secondaryButton={NO_DEBIT_CARD_SECONDARY_BUTTON_TEXT}
                secondaryButtonClick={this.onSecondaryButtonClick} />
        )
    }
}

export default NoDebitCardPopup;