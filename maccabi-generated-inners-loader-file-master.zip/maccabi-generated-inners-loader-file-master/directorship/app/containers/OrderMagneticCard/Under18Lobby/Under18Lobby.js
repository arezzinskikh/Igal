import React from 'react';
import Information from '../Information';
import { UNDER_18_LOBBY_TITLE, UNDER_18_LOBBY_CONTENT } from '../constants';
import style from './Under18Lobby.scss';

const Under18Lobby = ({ navigateTo }) => {
    return (
        <Information type={'danger'} className={style.container} title={UNDER_18_LOBBY_TITLE} navigateTo={navigateTo}>
            {UNDER_18_LOBBY_CONTENT}
        </Information>
    );
};

Under18Lobby.propTypes = {
    navigateTo: PropTypes.func
};

export default Under18Lobby;
