import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectOrderMagneticCardData = state => {
  return state.get('orderMagneticCardData', initialState);
};

export const makeSelectOrderMagneticCardData = createSelector(selectOrderMagneticCardData, orderMagneticCardState => {
  return orderMagneticCardState.get('orderMagneticCardData')
});