import mLib from '@maccabi/m-lib';

export const BASE_ELEMENT_PAGE_NAV = 'directorship/OrderMagneticCard/';
export const ORDER_EXITS_PAGE_NAV = `${BASE_ELEMENT_PAGE_NAV}OrderExists`;
export const ERROR_PAGE_NAV = `${BASE_ELEMENT_PAGE_NAV}Error`;
export const MINOR_LOBBY_PAGE_NAV = `${BASE_ELEMENT_PAGE_NAV}Minor`;
export const LOBBY_PAGE_NAV = `${BASE_ELEMENT_PAGE_NAV}Lobby`;
export const SUMMARY_PAGE_NAV = `${BASE_ELEMENT_PAGE_NAV}Summary`;
export const SUCCESS_PAGE_NAV = `${BASE_ELEMENT_PAGE_NAV}Success`;
export const CLICK_LOG_ID = process.env.LOG_ACTION_ID_CLICK;
export const SHOW_LOG_ID = process.env.LOG_ACTION_ID_SCREEN_OPEN;
export const DEBIT_CARD_POPUP_LOG_ID = 1346;

export const LOG_IDS = {
    INVALID_ADDRESS_POPUP_SHOW: 2989,
    LOBBY_SELECT_BTN_CLICK: 2988,
    NO_DEBIT_CARD_POPUP_SHOWN: 2990,
    NO_DEBIT_CARD_POPUP_CLOSE: 2992,
    NO_DEBIT_CARD_POPUP_NAVIGATE: 2991,
    ORDER_ALREADY_EXISTS_SHOWN: 3001,
    ORDER_FINISHED_SHOWN: 3000,
    ORDER_SUMMARY_FINISH_BTN_NO_COST: 2996,
    ORDER_SUMMARY_FINISH_BTN_COST: 2997,
    ORDER_SUMMARY_UPDATE_ADDRESS_BTN: 2995,
    LOST_CARD_BTN: 2985,
    STOLEN_CARD_BTN: 2986,
    INVALID_CARD_BTN: 2987,
    ERROR: 3002
};
export const ERROR_LOG = {
    elementId: LOG_IDS.ERROR,
    actionId: SHOW_LOG_ID,
    elementInPage: SUMMARY_PAGE_NAV
};

export const REASON_CODES = {
    LOST: 2,
    STOLEN: 3,
    NOT_VALID_CARD: 16
};

export const RADIO_BUTTON_TEXT_VALUE = [
    {
        text: mLib.resources.getResource(LOBBY_PAGE_NAV, 'RadioButtonText_1', 'אובדן'),
        value: {
            code: REASON_CODES.LOST,
            log: {
                elementId: LOG_IDS.LOST_CARD_BTN,
                actionId: CLICK_LOG_ID,
                elementInPage: LOBBY_PAGE_NAV
            }
        }
    },
    {
        text: mLib.resources.getResource(LOBBY_PAGE_NAV, 'RadioButtonText_2', 'גניבה'),
        value: {
            code: REASON_CODES.STOLEN,
            log: {
                elementId: LOG_IDS.STOLEN_CARD_BTN,
                actionId: CLICK_LOG_ID,
                elementInPage: LOBBY_PAGE_NAV
            }
        }
    },
    {
        text: mLib.resources.getResource(LOBBY_PAGE_NAV, 'RadioButtonText_3', 'כרטיס לא תקין'),
        value: {
            code: REASON_CODES.NOT_VALID_CARD,
            log: {
                elementId: LOG_IDS.INVALID_CARD_BTN,
                actionId: CLICK_LOG_ID,
                elementInPage: LOBBY_PAGE_NAV
            }
        }
    }
];
export const DEFAULT_REASON = {
    code: 0,
    log: {
        elementId: 1600,
        actionId: process.env.LOG_ACTION_ID_CLICK,
        elementInPage: LOBBY_PAGE_NAV
    }
};
export const ORDER_SUCCESS_SUCCESS_TITLE = mLib.resources.getResource(SUCCESS_PAGE_NAV, 'OrderSuccessMessage', 'בוצעה בהצלחה');
export const MODULE_INFO_TEXT_VALUE = mLib.resources.getResource(
    LOBBY_PAGE_NAV,
    'InfoText',
    'כרטיס חבר מכבי הינו כרטיס אישי המאפשר קבלת שירות בכל המרכזים הרפואיים והמרפאות של מכבי. הזמנת כרטיס מגנטי מתאפשרת עבורך ועבור בני משפחתך. הכרטיסים יישלחו לכתובת הדואר המעודכנת במערכות מכבי. לתשומת ליבך - הכרטיס החדש  יבטל את קודמו  - לא ניתן יהיה להשתמש בכרטיס הישן.'
);
export const TERMS_LINK_TEXT_VALUE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'TermsLinkText', 'למידע נוסף ותנאי השימוש');
export const TERMS_LINK_URL_TEXT_VALUE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'TermsUrl', 'https://www.maccabi4u.co.il/12943-he/Maccabi.aspx');
export const MAIN_REMARKS = [
    mLib.resources.getResource(
        LOBBY_PAGE_NAV,
        'MainRemark1',
        'בהזמנת כרטיס חדש תגבה השתתפות עצמית במידה ועברו פחות משנתיים ממועד הנפקת הכרטיס הקודם.'
    ),
    mLib.resources.getResource(
        LOBBY_PAGE_NAV,
        'MainRemark2',
        'במידה ונדרש תשלום עבור הזמנת כרטיס חדש, התשלום ייגבה באמצעות הוראת הקבע שלך. ניתן לעדכן את הוראת הקבע '
    ),
    mLib.resources.getResource(LOBBY_PAGE_NAV, 'MainRemark3', 'במידה והכרטיס נגנב יש להעביר אישור משטרה למרכז הרופאי במכבי כדי לקבל זיכוי על התשלום.')
];
export const COST_REMARKS = [
    mLib.resources.getResource(LOBBY_PAGE_NAV, 'CostRemark', 'ניתן לקבל זיכוי על התשלום לאחר העברת אישור משטרה למרכז הרפואי במכבי.')
];
export const ORDER_CARD_TITLE = mLib.site.getModuleTitle(LOBBY_PAGE_NAV, 'Title', 'הזמנת כרטיס מגנטי');
export const LOBBY_NOTE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'LobbySubTitle', 'מה הסיבה לבקשה?');
export const LOBBY_BUTTON = mLib.resources.getResource(LOBBY_PAGE_NAV, 'LobbyBtnApproval', 'להזמנת כרטיס');
export const ORDER_SUMMARY_TITLE = mLib.site.getModuleTitle(SUMMARY_PAGE_NAV, 'Title', 'סיכום הזמנת כרטיס');
export const ORDER_SUMMARY_BUTTON_PRICE = mLib.resources.getResource(SUMMARY_PAGE_NAV, 'OrderSummaryBtnTextCostMoney', 'אישור חיוב והזמנה');
export const ORDER_SUMMARY_BUTTON_FREE = mLib.resources.getResource(SUMMARY_PAGE_NAV, 'OrderSummaryBtnTxt', 'אישור');
export const ORDER_SUMMARY_REASON = mLib.resources.getResource(SUMMARY_PAGE_NAV, 'OrderSummaryOrderReason', 'סיבת ההזמנה: {0}');
export const ORDER_SUMMARY_PRICE_NOTE = mLib.resources.getResource(
    SUMMARY_PAGE_NAV,
    'OrderSummaryBtnTxt',
    'סה"כ לתשלום {0} ש"ח (טרם חלפו שנתיים ממועד הנפקת הכרטיס הקודם)'
);
export const ORDER_SUMMARY_UPDATE_ADDRESS = mLib.resources.getResource(SUMMARY_PAGE_NAV, 'OrderSummaryUpdateAddressText', 'לעדכון כתובת');
export const ORDER_FINISHED_BTN = mLib.resources.getResource(SUCCESS_PAGE_NAV, 'OrderFinishedBtnTxt', 'לבחירה');
export const ORDER_FINISHED_NOTE = mLib.resources.getResource(SUCCESS_PAGE_NAV, 'OrderFinishedNote', 'להזמנת כרטיס מגנטי עבור בן משפחה נוסף');
export const REMARKS_TITLE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'RmaeksTitle', 'הערות');
export const FINISH_BUTTON_TEXT = mLib.resources.getResource(LOBBY_PAGE_NAV, 'FinishBtn', 'סיום');
export const MIN_AGE_TO_ORDER_CARD = mLib.resources.getResource(LOBBY_PAGE_NAV, 'MinOrderAge', 18);
export const ORDER_CARD_SUCCESS_CODE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'OrderCardSuccessCode', '1');
export const LOBBY_VALIDATION_MESSAGE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'LobbyValidationMessage', 'יש לבחור סיבה');
export const CARD_ISSUED_WARNING_TITLE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'CardIssuedWarningTitle', 'קיימת הזמנת כרטיס מגנטי במערכת');
export const CARD_ISSUED_UNDER_18 = mLib.resources.getResource(
    LOBBY_PAGE_NAV,
    'CardIssuedUnder18',
    'זוג כרטיסים בדרך אליך. לא ניתן להזמין כעת כרטיס נוסף'
);
export const CARD_ISSUED_OVER_18 = mLib.resources.getResource(
    LOBBY_PAGE_NAV,
    'CardIssuedOver18',
    'כרטיס מגנטי בדרך אליך. לא ניתן להזמין כעת כרטיס נוסף'
);
export const NO_DEBIT_CARD_TITLE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'NoDebitCardTitle', 'חסרה הוראת קבע פעילה');
export const NO_DEBIT_CARD_BODY = mLib.resources.getResource(
    LOBBY_PAGE_NAV,
    'NoDebitCardBody',
    'הזמנה זו כרוכה בתשלום. מאחר וחסרה הוראת קבע פעילה, לא ניתן להשלים את תהליך ההזמנה. ניתן לעדכן הוראת קבע באתר מכבי.'
);
export const NO_DEBIT_CARD_BODY_KOSHER = mLib.resources.getResource(
    LOBBY_PAGE_NAV,
    'NoDebitCardBodyKosher',
    'הזמנה זו כרוכה בתשלום. מאחר וחסרה הוראה קבע פעילה, לא ניתן להשלים את תהליך ההזמנה. ניתן לעדכן הוראת קבע במוקד מכבי ללא הפסקה ב 3555*'
);
export const NO_DEBIT_CARD_PRIMARY_BUTTON_TEXT = mLib.resources.getResource(LOBBY_PAGE_NAV, 'NoDebitCardPrimaryBtnText', 'לעדכון הוראת קבע');
export const NO_DEBIT_CARD_SECONDARY_BUTTON_TEXT = mLib.resources.getResource(LOBBY_PAGE_NAV, 'NoDebitCardSeconrayBtnText', 'סגור');
export const INVALID_ADDRESS_TITLE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'InvalidAddressTitle', 'הכתובת הרשומה במכבי אינה תקינה');
export const INVALID_ADDRESS_BODY = mLib.resources.getResource(
    LOBBY_PAGE_NAV,
    'InvalidAddressBody',
    'על מנת להמשיך בתהליך הזמנת כרטיס מגנטי, וכדי שנדע לאן לשלוח לך את הכרטיסים יש לעדכן כתובת מגורים'
);
export const INVALID_ADDRESS_PRIMARY_BUTTON_TEXT = mLib.resources.getResource(LOBBY_PAGE_NAV, 'InvalidAddressPrimaryBtnText', 'לעדכון כתובת');
export const GENERIC_ERROR_TITLE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'GenericErrorTitle', 'לצערנו לא ניתן להשלים את ההזמנה');
export const UNDER_18_LOBBY_TITLE = mLib.resources.getResource(LOBBY_PAGE_NAV, 'Under18LobbyTitle', 'לתשומת ליבך');
export const UNDER_18_LOBBY_CONTENT = mLib.resources.getResource(LOBBY_PAGE_NAV, 'Under18LobbyContent', 'הזמנת כרטיס מגנטי אפשרית מעל גיל 18');
export const ORDER_SUMMARY_NOTE_UNDER_18 = mLib.resources.getResource(LOBBY_PAGE_NAV, 'OrderSummaryNoteUnder18', 'זוג כרטיסים מגנטיים ישלחו לכתובת');
export const ORDER_SUMMARY_NOTE_OVER_18 = mLib.resources.getResource(LOBBY_PAGE_NAV, 'OrderSummaryNoteOver18', 'כרטיס מגנטי ישלח לכתובת');

// STEPS
export const MAGNETIC_CARD_ORDER_STEP = {
    INITIAL_STEP: {
        key: 'initial_step',
        showSubContent: true,
        hideSubContentInMobile: false,
        hideRemarksInMobile: false
    },
    FINAL_CONFIRMATION_STEP: {
        key: 'final_confirmation_step',
        showSubContent: false,
        hideSubContentInMobile: false,
        hideRemarksInMobile: false
    },
    ORDER_FINISHED_STEP: {
        key: 'order_finished_step',
        showSubContent: false,
        hideSubContentInMobile: false,
        hideRemarksInMobile: false
    },
    CARD_ISSUED_STEP: {
        key: 'card_issued_step',
        showSubContent: true,
        hideSubContentInMobile: true,
        hideRemarksInMobile: true
    },
    GENERIC_ERROR: {
        key: 'generic_error',
        showSubContent: true,
        hideSubContentInMobile: true,
        hideRemarksInMobile: true
    }
};

// POPUPS
export const MAGNETIC_CARD_POPUPS = {
    INACTIVE_DEBIT_CARD_POPUP: 'inactive_debit_card_popup',
    INVALID_ADDRESS_POPUP: 'invalid_address_popup'
};
export const EDIT_INFORMATION_URL = '/directorship/EditInformation/Profile/';
// ACTIONS
export const TOGGLE_LOADING = 'maccabi/directorship/ordermagnetccard/TOGGLE_LOADING';
export const ORDER_COST_REQUEST = 'maccabi/directorship/ordermagnetccard/ORDER_COST_REQUEST';
export const SET_COST = 'maccabi/directorship/ordermagnetccard/SET_COST';
export const SET_REASON = 'maccabi/directorship/ordermagnetccard/SET_REASON';
export const KEEP_STATE_ON_LOAD = 'maccabi/directorship/ordermagnetccard/KEEP_STATE_ON_LOAD';
export const ON_LOAD = 'maccabi/directorship/ordermagnetccard/ON_LOAD';
export const ON_UNLOAD = 'maccabi/directorship/ordermagnetccard/ON_UNLOAD';
export const FINISH_ORDER = 'maccabi/directorship/ordermagnetccard/FINISH_ORDER';
export const ORDER_FINISHED = 'maccabi/directorship/ordermagnetccard/ORDER_FINISHED';
export const CARD_ISSUED = 'maccabi/directorship/ordermagnetccard/CARD_ISSUED';
export const SET_INACTIVE_DEBIT_CARD = 'maccabi/directorship/ordermagnetccard/SET_INACTIVE_DEBIL_CARD';
export const SET_INVALID_ADDRESS = 'maccabi/directorship/ordermagnetccard/SET_INVALID_ADDRESS';
export const RESET = 'maccabi/directorship/ordermagnetccard/RESET';
export const SET_ERROR = 'maccabi/directorship/ordermagnetccard/SET_ERROR';
