import React, { Component } from 'react';
import PropTypes from 'prop-types';
import cx from 'classnames';
import autobind from 'autobind';
import style from './Lobby.scss';
import mLib from '@maccabi/m-lib';
import { H2, Card, Button, ButtonPicker, IconLoader } from '@maccabi/m-ui';
import {
    RADIO_BUTTON_TEXT_VALUE,
    DEFAULT_REASON,
    LOBBY_PAGE_NAV,
    LOBBY_VALIDATION_MESSAGE,
    LOBBY_NOTE,
    LOBBY_BUTTON,
    LOG_IDS,
    CLICK_LOG_ID
} from '../constants';

@autobind
class Lobby extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isSubmited: false,
            showErrorMessage: false
        };
    }

    static propTypes = {
        reason: PropTypes.object.isRequired,
        setReason: PropTypes.func.isRequired,
        loading: PropTypes.bool.isRequired,
        onClick: PropTypes.func.isRequired
    };

    onSelectReason(item, isMobile) {
        this.setState({ showErrorMessage: false });
        const reason = item.value;
        const log = reason.log;
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId);
        this.props.setReason(reason);
        setTimeout(() => {
            isMobile && this.onSubmit(isMobile);
        }, 50);
    }

    onDesktopSubmit() {
        mLib.logs.insertCentralizedLog(LOG_IDS.LOBBY_SELECT_BTN_CLICK, LOBBY_PAGE_NAV, CLICK_LOG_ID);
        this.onSubmit();
    }

    get isValid() {
        return !(this.props.reason.code === DEFAULT_REASON.code);
    }

    get errorMessage() {
        return !this.isValid ? LOBBY_VALIDATION_MESSAGE : '';
    }

    onSubmit(isMobile = false) {
        if (!this.isValid) {
            this.setState({
                isSubmited: true,
                showErrorMessage: true
            });
        } else {
            this.setState({ showErrorMessage: false });
            this.props.onClick(isMobile);
        }
    }

    renderButtons(isMobile) {
        const buttonPickerProps = {
            list: RADIO_BUTTON_TEXT_VALUE,
            color: this.state.showErrorMessage ? 'danger' : 'primary',
            className: 'mb-1',
            nameOfFieldToDisplay: 'text'
        };

        const containerClassName = cx(style.wrapButton, {
            [style.first]: !isMobile,
            'd-none d-xl-flex': !isMobile,
            [style.mobileButtons]: isMobile,
            'd-xl-none d-flex': isMobile
        });

        return (
            <div className={containerClassName} data-hook="ButtonPickerWrapepr">
                <ButtonPicker onClick={item => this.onSelectReason(item, isMobile)} {...buttonPickerProps} />
            </div>
        );
    }

    render() {
        const { loading } = this.props;
        return (
            <Card visibility="inner" className={cx(style.lobby, 'mb-0 mb-lg-7')}>
                <H2 className="mb-5 mb-sm-7" hook="h2">
                    {LOBBY_NOTE}
                </H2>
                {this.renderButtons()}
                {this.renderButtons(true)}
                <div className={cx(style.valid)} data-hook="validation">
                    {this.state.isSubmited && this.errorMessage}
                </div>
                <div className="d-none d-xl-flex">
                    <Button color="primary" onClick={this.onDesktopSubmit} hook="ok" size="md">
                        {loading && <IconLoader size="sm" className={style.iconLoader} />}
                        {LOBBY_BUTTON}
                    </Button>
                </div>
            </Card>
        );
    }
}

export default Lobby;
