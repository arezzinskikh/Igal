import { takeLatest, call, put } from 'redux-saga/effects';
import mLib from '@maccabi/m-lib';

import {joinMyMaccabiError,setAdditionalInsurances,setRegisterToMyMaccabiResponse,sendRequestError} from './actions';
import {getMembersAdditionalInsurances, postAdditionalMembersInsurances} from '../../services/JoinMyMaccabi/apiService';
import {GET_MEMBERS_INSURANCES,POST_ADDITIONAL_INSURANCES} from './constants';
const { setGlobalErrorPopup } = mLib.saveData.globalErrorPopup;

const { setGlobalLoading } = mLib.saveData.globalLoader;

function* getMembers() {
    yield call(setGlobalLoading, true);
    const customerData = mLib.saveData.customerData.get();
    const {logged_customer_info:{member_id,member_id_code}} = customerData
    const request = {
        data:{memberIdCode:member_id_code, memberId:member_id},
        headers:{user:`aaa-${member_id_code}-${member_id}`}
    }
    try{
        const response = yield call(getMembersAdditionalInsurances,request);
        if (!response || !response.members || !response.members.length) {
            yield call(setGlobalErrorPopup, true);
            yield put(joinMyMaccabiError(true))
        } else {
            yield put(setAdditionalInsurances(response));
        }
    }
    catch(error){
        yield call(setGlobalErrorPopup, true);
        yield put(joinMyMaccabiError(true))
    }
    finally{
        yield call(setGlobalLoading, false);
    }
}

function* postMembers(action) {
    yield call(setGlobalLoading, true);
    const customerData = mLib.saveData.customerData.get();
    const {current_customer_info:{member_id,member_id_code},logged_customer_info} = customerData;
    const {savedSelectedMembers,startMyMaccabiFromToday} = action.data;
    const members = savedSelectedMembers.map(member => {
        return {
            memberIdCode: member.member_id_code,
            memberId: member.member_id,
            relationship: member.relationship
        }
    })
    const request = {
        data: {members, start_my_maccabi_from_today: startMyMaccabiFromToday},
        headers:{
            user:`aaa-${logged_customer_info.member_id_code}-${logged_customer_info.member_id}`
        }
    }
    try{
        const response = yield call(postAdditionalMembersInsurances,request,member_id,member_id_code);
        if (!response || !response.members || !response.members.length) {
            yield put(sendRequestError(true))
        } else {
            yield put(setRegisterToMyMaccabiResponse(response));
        }
    }
    catch(error){
        yield put(sendRequestError(true))
    }
    finally{
        yield call(setGlobalLoading, false);
    }
}

export default function* rootSaga() {
    yield [
        takeLatest(GET_MEMBERS_INSURANCES,getMembers),
        takeLatest(POST_ADDITIONAL_INSURANCES,postMembers)
    ];
}