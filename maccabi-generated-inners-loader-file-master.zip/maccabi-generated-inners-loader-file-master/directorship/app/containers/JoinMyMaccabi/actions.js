import {
    JOIN_MY_MACCABI_ERROR,
    GET_MEMBERS_INSURANCES,SET_MEMBERS_INSURANCES,
    DELETE_REQUEST,
    ON_FORM_FIELD_CHANGE,
    POST_ADDITIONAL_INSURANCES,
    SET_REGISTER_RESPONSE,
    SEND_REQUEST_ERROR
} from './constants';

export function joinMyMaccabiError(isError) {
    return {
        type: JOIN_MY_MACCABI_ERROR,
        isError
    };
}

export function getAdditionalInsurances(){
    return{
        type: GET_MEMBERS_INSURANCES
    }
}

export function setAdditionalInsurances(data){
    return{
        type: SET_MEMBERS_INSURANCES,
        data
    }
}

export function onFormFieldChange(data) {
    return{
        type: ON_FORM_FIELD_CHANGE,
        data
    }
}

export function deleteRequestFromState() {
    return {
        type: DELETE_REQUEST
    };
}

export function postAdditionalInsurances(data) {
    return {
        type: POST_ADDITIONAL_INSURANCES,
        data
    };
}

export function setRegisterToMyMaccabiResponse(data) {
    return{
        type: SET_REGISTER_RESPONSE,
        data
    }
}

export function sendRequestError(isError) {
    return {
        type: SEND_REQUEST_ERROR,
        isError
    };
}
