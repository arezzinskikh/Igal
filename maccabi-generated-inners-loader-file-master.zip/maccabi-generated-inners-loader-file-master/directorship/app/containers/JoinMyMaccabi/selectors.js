import { createSelector } from 'reselect';
import { initialState } from './reducer';
import { INSURANCE } from './constants';

const selectGlobalReducer = state => {
    return state.get('GlobalLoading', initialState);
}

export const selectGlobalLoader = createSelector(selectGlobalReducer, loader => {
    return loader.get('isGlobalLoading');
})

const selectJoinMyMaccabiReducer = state => {
    return state.get('myMaccabiReducer', initialState);
};

export const selectJoinMyMaccabiError = createSelector(selectJoinMyMaccabiReducer, err => {
    return err.get('joinMyMaccabiError');
})

export const selectFamilyMembers = createSelector(selectJoinMyMaccabiReducer, familyMembersAndInsurances => {
    return familyMembersAndInsurances.get('familyMembers');
});

export const selectFamilyMemberObjectForBtnPicker = createSelector(
    selectFamilyMembers,
    (membersArr) => {
        const familyMembersToBtnPicker = membersArr.map(member => 
            (
                {
                    field: member.first_name + " " + member.last_name,
                    description: member.existingInsuranceName,
                    disabled: member.existing_insurance === INSURANCE.myMaccabi || !member.loggedUserIsEligiblePayer
                }
            )
        )
        return familyMembersToBtnPicker
    }
)

export const selectFamilyMembersThatAreNotInMyMaccabi = createSelector(
    selectFamilyMembers,
    (membersArr) => {
        return membersArr.filter(member => member.existing_insurance !== INSURANCE.myMaccabi)
    }
);

export const selectShowUserIsNotEligiblePayerMessage = createSelector(
    selectFamilyMembersThatAreNotInMyMaccabi,
    (membersArr) => {
        const loggedUserIsEligiblePayerBoolArr = membersArr.map(member => member.loggedUserIsEligiblePayer)
        return loggedUserIsEligiblePayerBoolArr.filter(Boolean).length === 0
    }
);

export const selectMembersThatCanNotBePayedOn = createSelector(
    selectFamilyMembersThatAreNotInMyMaccabi,
    (members) => {
        const membersCanNotBePayed = members.filter(member => !member.loggedUserIsEligiblePayer)
        return membersCanNotBePayed
    }
);

export const selectNextMonthDate = createSelector(selectJoinMyMaccabiReducer, familyMembersAndInsurances => {
    return familyMembersAndInsurances.get('nextMonthDate');
});

export const selectAllInMyMaccabi = createSelector(selectJoinMyMaccabiReducer, familyMembersAndInsurances => {
    return familyMembersAndInsurances.get('allInMyMaccabi');
});

export const selectChosenTime = createSelector(selectJoinMyMaccabiReducer, formItem => {
    return formItem.get('chosenTime');
});

export const selectChosenMembers = createSelector(selectJoinMyMaccabiReducer, formItem => {
    return formItem.get('chosenMembers');
});

export const selectIsTermsOfUseChecked = createSelector(selectJoinMyMaccabiReducer, formItem => {
    return formItem.get('termsOfUse');
});

export const selectIsStepOneFinished = createSelector(
    selectChosenTime,
    selectChosenMembers,
    selectIsTermsOfUseChecked,
    (chosenTime, familyMembers, termsOfUse) => {return chosenTime >= 0 && familyMembers.length && termsOfUse}
);

export const selectIsAfterSendingRequest = createSelector(selectJoinMyMaccabiReducer, err => {
    return err.get('isAfterSendingRequest');
})

export const selectRegistraionResponse = createSelector(selectJoinMyMaccabiReducer, registraionResponse => {
    return registraionResponse.get('registrationResponse');
});

export const selectRegistraionSuccessed = createSelector(selectJoinMyMaccabiReducer, registraionResponse => {
    const selected = registraionResponse.get('registrationResponse')
    if (selected) {
        const succeedToRegister = registraionResponse.get('registrationResponse').filter(member => member.treatment_status === "1")
        return succeedToRegister
    }
    return registraionResponse.get('registrationResponse')
});

export const selectRegistraionFailed= createSelector(selectJoinMyMaccabiReducer, registraionResponse => {
    const selected = registraionResponse.get('registrationResponse')
    if (selected) {
        const failedToRegister = registraionResponse.get('registrationResponse').filter(member => member.treatment_status === "2")
        return failedToRegister
    }
    return registraionResponse.get('registrationResponse')
});

export const selectErrorInSendingRequest = createSelector(selectJoinMyMaccabiReducer, err => {
    return err.get('errorInSendingRequest');
})