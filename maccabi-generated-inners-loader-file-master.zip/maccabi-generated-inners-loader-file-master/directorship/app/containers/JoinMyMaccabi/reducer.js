import { fromJS } from 'immutable';

import {mergeMembersArraysToAddDetails} from './utils';
import {
    JOIN_MY_MACCABI_ERROR,
    SET_MEMBERS_INSURANCES,
    ON_FORM_FIELD_CHANGE,
    DELETE_REQUEST,
    SET_REGISTER_RESPONSE,
    SEND_REQUEST_ERROR
} from './constants';

const initialState = fromJS({
    joinMyMaccabiError: false,
    familyMembers: [],
    nextMonthDate: "",
    allInMyMaccabi: false,
    chosenTime: -1,
    chosenMembers: [],
    termsOfUse: false,
    isAfterSendingRequest: false,
    registrationResponse: null,
    errorInSendingRequest: false
});

export default function joinMyMaccabiReducer(state = initialState, action) {
    switch (action.type) {
        case JOIN_MY_MACCABI_ERROR: {
            return state.set('joinMyMaccabiError', action.isError);
        }
        case SET_MEMBERS_INSURANCES: {
            const membersWithDetailsArr = mergeMembersArraysToAddDetails(action.data.members)
            const isSingleMember = membersWithDetailsArr.length === 1 ? membersWithDetailsArr : []
            return state
                .set('familyMembers', membersWithDetailsArr)
                .set('nextMonthDate', action.data.next_month_date)
                .set('allInMyMaccabi', action.data.is_all_in_my_maccabi)
                .set('chosenMembers', isSingleMember)
        }
        case ON_FORM_FIELD_CHANGE: {
            return state
                .set(action.data.field, action.data.value)
        }
        case DELETE_REQUEST: {
            return initialState
        }
        case SET_REGISTER_RESPONSE: {
            const membersWithDetailsArr = mergeMembersArraysToAddDetails(action.data.members)
            return state
                .set('registrationResponse', membersWithDetailsArr)
                .set('isAfterSendingRequest', true)
        }
        case SEND_REQUEST_ERROR: {
            return state
                .set('errorInSendingRequest', action.isError)
                .set('isAfterSendingRequest', true)
        }
        default:
            return state;
    }
}