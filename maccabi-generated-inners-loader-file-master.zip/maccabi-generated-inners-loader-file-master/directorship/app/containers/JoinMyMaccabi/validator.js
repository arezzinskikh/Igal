import { STATIC_TXT} from './constants';

export const getFormErrorByField = (field, value) => {
    const isInvalid = value < 0 || value.length === 0 || value === false;
    return isInvalid ? STATIC_TXT.validation[field] : '';
};