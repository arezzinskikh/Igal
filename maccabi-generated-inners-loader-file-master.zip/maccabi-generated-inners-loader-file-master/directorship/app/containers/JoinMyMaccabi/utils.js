import mLib from '@maccabi/m-lib';
import {EXISTING_INSURANCE,PARTNER_STATUS} from './constants';

const createMemberObjWithDetails = (matchMemberWithDetails,memberFromService,loggedUser) => {
    return {
        ...memberFromService,
        member_id_code: matchMemberWithDetails.member_id_code,
        member_id: matchMemberWithDetails.member_id,
        first_name: matchMemberWithDetails.first_name,
        last_name: matchMemberWithDetails.last_name,
        age: matchMemberWithDetails.age,
        existingInsuranceName: EXISTING_INSURANCE[memberFromService.existing_insurance],
        loggedUserIsEligiblePayer: memberFromService.payer_id === loggedUser.member_id.toString() && memberFromService.payer_id_code === loggedUser.member_id_code
    }
}

const sortMembersArrayByPriority = (arr,loggedUser) => {
    let loggedMember = []
    let otherMembersToSortByAge = []
    arr.forEach(element => {
        if (element.member_id === loggedUser.member_id.toString()) {
            loggedMember.push(element)
        } else {
            otherMembersToSortByAge.push(element)
        }
    });
    otherMembersToSortByAge.sort(function(a,b) {
        return b.age && a.age ? b.age.years - a.age.years : {}
    })
    return [...loggedMember,...otherMembersToSortByAge]
}

export const mergeMembersArraysToAddDetails = (apiMembersInsuranceArr) => {
    const customerData = mLib.saveData.customerData.get();
    const {family_data:{family_members},logged_customer_info} = customerData;
    let mergedArrWithMembersDetials = []
    for (let i = 0; i < apiMembersInsuranceArr.length; i++) {
        const memberFromService = apiMembersInsuranceArr[i];
        if (memberFromService.relationship === PARTNER_STATUS) {
            mergedArrWithMembersDetials.push(
                {...memberFromService, 
                    member_id: parseInt(memberFromService.member_id),
                    existingInsuranceName: EXISTING_INSURANCE[memberFromService.existing_insurance],
                    loggedUserIsEligiblePayer: memberFromService.payer_id === logged_customer_info.member_id.toString() && memberFromService.payer_id_code === logged_customer_info.member_id_code
                })
        }
        let matchingMemberFromCustomerDataFamily = family_members.filter(member=> member.member_id.toString() === memberFromService.member_id)
        if (matchingMemberFromCustomerDataFamily[0]) {
            mergedArrWithMembersDetials.push(createMemberObjWithDetails(matchingMemberFromCustomerDataFamily[0],memberFromService,logged_customer_info))
        }
    }
    const sortedByAge = sortMembersArrayByPriority(mergedArrWithMembersDetials,logged_customer_info)
    return sortedByAge
}