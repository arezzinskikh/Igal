import mLib from '@maccabi/m-lib';

export const PAGE_ALIAS = 'directorship/JoinMyMaccabi/lobby/';
export const SUMMARY_PAGE_ALIAS = 'directorship/JoinMyMaccabi/RequestSummary/';

export const LOG_ELEMENT_IN_PAGE_JOIN_MY_MACCABI = PAGE_ALIAS;
export const LOG_ELEMENT_IN_PAGE_SUMMARY_PAGE = SUMMARY_PAGE_ALIAS;

export const JOIN_MY_MACCABI_ERROR = 'maccabi/StatusRequest/JOIN_MY_MACCABI_ERROR';
export const GET_MEMBERS_INSURANCES = 'directorship/JoinMyMaccabi/GET_MEMBERS_INSURANCES';
export const SET_MEMBERS_INSURANCES = 'directorship/JoinMyMaccabi/SET_MEMBERS_INSURANCES';
export const ON_FORM_FIELD_CHANGE = 'directorship/JoinMyMaccabi/ON_FORM_FIELD_CHANGE';
export const DELETE_REQUEST = 'directorship/JoinMyMaccabi/DELETE_REQUEST';
export const POST_ADDITIONAL_INSURANCES = 'directorship/JoinMyMaccabi/POST_ADDITIONAL_INSURANCES';
export const SET_REGISTER_RESPONSE = 'directorship/JoinMyMaccabi/SET_REGISTER_RESPONSE';
export const SEND_REQUEST_ERROR = 'directorship/JoinMyMaccabi/SEND_REQUEST_ERROR';

export const STARTING_DATE = { 0: 'startingToday', 1: 'startingNextMonth', startingToday: 0, startingNextMonth: 1 };
export const EXISTING_INSURANCE = { '00': '', '02': 'במכבי זהב', '03': 'במכבי כסף', '07': 'במכבי שלי' };
export const INSURANCE = { myMaccabi: '07', maccabiSilver: '03', maccabiGold: '02', noInsurance: '00' };
export const MIN_AGE = 18;
export const PARTNER_STATUS = '1';
export const NO_ACTIVE_HOK_CREDIT_STATUS = '0';

export const STATIC_TXT = {
    JoinMyMaccabiTitle: mLib.resources.getResource(PAGE_ALIAS, 'JoinMyMaccabiTitle', 'הצטרפות למכבי שלי'),
    JoinMyMaccabiDescription: mLib.resources.getResource(
        PAGE_ALIAS,
        'JoinMyMaccabiDescription',
        'ההרשמה לביטוח המשלים מכבי שלי מתאפשרת לבעלי הרשאה לחיוב חשבון בלבד. במידה ואין לך אמצעי תשלום, ניתן להצטרף'
    ),
    links: [
        {
            text: mLib.resources.getResource(PAGE_ALIAS, 'benefitDetails', 'פירוט ההטבות'),
            link: 'https://www.maccabi4u.co.il/373-he/Maccabi.aspx?TabId=21331_21299'
        },
        {
            text: mLib.resources.getResource(PAGE_ALIAS, 'myMaccabiPlanRates', 'תעריפי התוכנית'),
            link: 'https://www.maccabi4u.co.il/373-he/Maccabi.aspx?TabId=21331_21334'
        },
        {
            text: mLib.resources.getResource(PAGE_ALIAS, 'additionalInfo', 'למידע נוסף'),
            link: 'https://www.maccabi4u.co.il/373-he/Maccabi.aspx?TabId=21331_21304'
        }
    ],
    title: {
        myMaccabiPlan: mLib.resources.getResource(PAGE_ALIAS, 'myMaccabiPlan', 'מכבי שלי היא תכנית הביטוח המשלימה הטובה בישראל שנותנת מענה לכולנו'),
        joiningRequestSummary: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'joiningRequestSummary', 'סיכום בקשת הצטרפות'),
        joiningRequestSuccess: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'joiningRequestSuccess', 'הצטרפות למכבי שלי בוצעה בהצלחה עבור'),
        errorInProgress: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'errorInProgress', 'אירעה שגיאה בתהליך הרישום עבור:'),
        alreadyInMyMaccabi: mLib.resources.getResource(PAGE_ALIAS, 'alreadyInMyMaccabi', 'על פי הנתונים שבידינו, כבר בוצע תהליך רישום'),
        limitedService: mLib.resources.getResource(PAGE_ALIAS, 'limitedService', 'שירות זה ניתן לבעלי הוראת קבע בלבד'),
        forEligiblePayer: mLib.resources.getResource(PAGE_ALIAS, 'forEligiblePayer', 'ההרשמה למכבי שלי אפשרית לבעלי הרשאה לחיוב החשבון במכבי בלבד')
    },
    subtitle: {
        forAdditionalInfo: mLib.resources.getResource(
            PAGE_ALIAS,
            'forAdditionalInfo',
            'לשינויים ו/או בירורים נוספים באפשרותך לפנות לסניף מכבי הקרוב אליך או למוקד "מכבי שלי" 4535*'
        ),
        toJoin: mLib.resources.getResource(PAGE_ALIAS, 'toJoin', 'להצטרפות ניתן לפנות למרכז הרפואי או למוקד "מכבי ללא הפסקה" 3555*'),
        joiningRequestSuccessText: mLib.resources.getResource(
            SUMMARY_PAGE_ALIAS,
            'joiningRequestSuccessText',
            'אישור הצטרפות נשלח לדוא"ל שלך או באמצעות מסרון'
        ),
        joiningRequestFailText: mLib.resources.getResource(
            SUMMARY_PAGE_ALIAS,
            'joiningRequestSuccessText',
            'ניתן לנסות שנית או לפנות לאחד מסניפי מכבי או למוקד השירות הטלפוני 3555*'
        ),
        becomeEligiblePayer: mLib.resources.getResource(
            PAGE_ALIAS,
            'becomeEligiblePayer',
            'הרישום יכול להתבצע על ידי בעל ההרשאה באתר או באפליקציה, במרכז הרפואי או במוקד 4535*'
        )
    },
    choosingFamilyMembers: {
        Title: mLib.resources.getResource(PAGE_ALIAS, 'choosingFamilyMembers', 'בחירת בני המשפחה'),
        Text: mLib.resources.getResource(PAGE_ALIAS, 'choosingFamilyMembers', 'ניתן לבחור יותר מבן משפחה אחד')
    },
    canNotPayOnMembers: {
        partOne: mLib.resources.getResource(PAGE_ALIAS, 'canNotPayOnMembers_partOne', 'הרשמה של'),
        partTwo: mLib.resources.getResource(
            PAGE_ALIAS,
            'canNotPayOnMembers_partTwo',
            'למכבי שלי יכולה להתבצע על ידי בעלי הרשאה לחיוב החשבון במכבי בלבד, באתר או באפליקציה, במרכז הרפואי או במוקד 4535*'
        )
    },
    chooseTime: {
        text: mLib.resources.getResource(PAGE_ALIAS, 'chooseTime', 'בחירת מועד הצטרפות'),
        startingToday: mLib.resources.getResource(PAGE_ALIAS, 'startingToday', 'החל מהיום'),
        startingFrom: mLib.resources.getResource(PAGE_ALIAS, 'startingFrom', 'החל מה - '),
        log: {
            elementId: 4205,
            elementInPage: LOG_ELEMENT_IN_PAGE_JOIN_MY_MACCABI,
            actionId: 1795
        }
    },
    disclaimer: mLib.resources.getResource(
        PAGE_ALIAS,
        'disclaimer',
        'חודש החברות הקובע לצורך מימוש כלל ההטבות יהיה מעתה חודש ההצטרפות לתכנית מכבי שלי. תשלום דמי החבר עבור חודש ההצטרפות, יבוצע באופן יחסי בהתאם ליום ההצטרפות במהלך החודש'
    ),
    button: {
        continueToApproveForm: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'continueToApproveForm', 'המשך לאישור הזמנה'),
            log: {
                elementId: 4206,
                elementInPage: LOG_ELEMENT_IN_PAGE_JOIN_MY_MACCABI,
                actionId: 1343
            }
        },
        cancelRegistration: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'cancelRegistration', 'ביטול'),
        approveRegistration: {
            text: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'approveRegistration', 'אישור רישום'),
            log: {
                elementId: 4208,
                elementInPage: LOG_ELEMENT_IN_PAGE_SUMMARY_PAGE,
                actionId: 1343
            }
        },
        understood: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'understood', 'הבנתי, תודה')
    },
    validation: {
        chosenTime: mLib.resources.getResource(PAGE_ALIAS, 'savedSelectedChosenTime', 'יש לבחור מועד הצטרפות'),
        chosenMembers: mLib.resources.getResource(PAGE_ALIAS, 'savedSelectedChosenMembers', 'יש לבחור את מי לצרף'),
        termsOfUse: mLib.resources.getResource(PAGE_ALIAS, 'savedSelectTermsOfUse', 'חובה לאשר קריאת תנאי ההצטרפות')
    },
    termsOfUse: {
        link: 'https://online.maccabi4u.co.il/Controls/Shaban/PDF/,DanaInfo=.aoonlrjFtilmlnvG9Pt6S26+ShabanUserRequestDetails.pdf',
        text: {
            partOne: mLib.resources.getResource(PAGE_ALIAS, 'TermsOfUse_partOne', 'קראתי והבנתי את'),
            partTwo: mLib.resources.getResource(PAGE_ALIAS, 'TermsOfUse_partTwo', 'תנאי ההצטרפות'),
            partThree: mLib.resources.getResource(
                PAGE_ALIAS,
                'TermsOfUse_partThree',
                'והם מקובלים עלי, וכי הסימון על ידי ייחשב כחתימתי האישית והסכמתי לתנאים'
            )
        },
        log: {
            elementId: 4207,
            elementInPage: LOG_ELEMENT_IN_PAGE_JOIN_MY_MACCABI,
            actionIdCheck: 1795,
            actionIdUnCheck: 1796
        }
    },
    goBack: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'goBack', 'חזרה לעריכת בקשה'),
    joiningRequest: {
        chosenMembersSubtitle: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'chosenMembersSubtitle', 'בני משפחה שיצורפו למכבי שלי:'),
        chosenTimeSubtitle: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'chosenTimeSubtitle', 'מועד הצטרפות לתוכנית הביטוח')
    },
    modalIsDeleteRequestToggle: {
        onConfirmHandler: 'deleteRequest',
        icon: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'ModalIsDeleteRequest_Icon', 'attention-big'),
        title: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'ModalIsDeleteRequest_Title', 'האם ברצונך לבטל את הבקשה?'),
        body: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'ModalIsDeleteRequest_Body', 'לתשומת ליבך הבקשה תימחק לצמיתות'),
        btnOk: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'ModalIsDeleteRequest_Button_OK', 'כן, אני רוצה'),
        btnCancel: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'ModalIsDeleteRequest_Button_Cancel', 'לא רוצה לבטל'),
        logs: {
            btnClicked: {
                elementId: 4209,
                elementInPage: LOG_ELEMENT_IN_PAGE_SUMMARY_PAGE,
                actionId: 1343
            }
        }
    },
    modalErrorInSendingRequest: {
        onConfirmHandler: 'deleteRequest',
        icon: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'modalErrorInSendingRequest_Icon', 'attention-big'),
        title: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'modalErrorInSendingRequest_Title', 'תהליך שליחת הבקשה לא הושלם'),
        body: mLib.resources.getResource(
            SUMMARY_PAGE_ALIAS,
            'modalErrorInSendingRequest_Body',
            'יש לנו בעיה טכנית שלא מאפשרת את השלמת תהליך שליחת הבקשה. ניתן לנסות ולשלוח שוב או לבירורים נוספים לפנות למוקד השירות הטלפוני 3555*'
        ),
        btnOk: mLib.resources.getResource(SUMMARY_PAGE_ALIAS, 'modalErrorInSendingRequest_Button_OK', 'הבנתי, תודה')
    }
};

export const MODULE_MESSAGE_TEXT = {
    alreadyInMyMaccabi: {
        title: STATIC_TXT.title.alreadyInMyMaccabi,
        subtitle: STATIC_TXT.subtitle.forAdditionalInfo
    },
    unavailableService: {
        title: STATIC_TXT.title.limitedService,
        subtitle: STATIC_TXT.subtitle.toJoin
    },
    validOnlyForEligiblePayer: {
        title: STATIC_TXT.title.forEligiblePayer,
        subtitle: STATIC_TXT.subtitle.becomeEligiblePayer
    }
};

export const FORM_FIELDS = { TERMS_OF_USE: 'termsOfUse', MEMBERS: 'chosenMembers', TIME: 'chosenTime' };
