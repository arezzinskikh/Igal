import React, { Component,Fragment } from 'react';
import { withRouter }from 'react-router-dom';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import {H1, MainBody, MainHeadline, MainHeadlineScrollable} from '@maccabi/m-ui';

import style from './JoinMyMaccabi.scss';
import {STATIC_TXT,MIN_AGE,MODULE_MESSAGE_TEXT,NO_ACTIVE_HOK_CREDIT_STATUS} from './constants';
import saga from './saga';
import reducer from './reducer';
import {getAdditionalInsurances,deleteRequestFromState} from './actions';
import {selectFamilyMembers,selectShowUserIsNotEligiblePayerMessage,selectAllInMyMaccabi,selectIsStepOneFinished,selectJoinMyMaccabiError,selectIsAfterSendingRequest} from './selectors';
import MainDescriptionAndLinks from '../../components/JoinMyMaccabi/MainDescriptionAndLinks/MainDescriptionAndLinks';
import MyMaccabiIcon from '../../components/JoinMyMaccabi/MyMaccabiIcon/MyMaccabiIcon';
import ModuleMessage from '../../components/JoinMyMaccabi/ModuleMessage/ModuleMessage';
import FillRequestForm from '../../components/JoinMyMaccabi/StepOne/FillRequestForm';

const mapDispatchToProps = (dispatch) => ({
    getAdditionalInsurances : () => dispatch(getAdditionalInsurances()),
    deleteRequestFromState: () => dispatch(deleteRequestFromState())
});
const mapStateToProps = createStructuredSelector({
    familyMembers: selectFamilyMembers,
    isStepOneFinished: selectIsStepOneFinished,
    isAfterSendingRequest: selectIsAfterSendingRequest,
    isErrorInModule: selectJoinMyMaccabiError,
    allInMyMaccabi: selectAllInMyMaccabi,
    userIsNotEligiblePayerOfAllMembers: selectShowUserIsNotEligiblePayerMessage
});

@mLib.appInfra.injectReducer({ key: 'myMaccabiReducer', reducer, mode: '@@saga-injector/daemon'})
@mLib.appInfra.injectSaga({ key: 'myMaccabiReducer', saga, mode: '@@saga-injector/daemon'})
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class JoinMyMaccabi extends Component {

    componentDidMount() {
        const memberData = mLib.saveData.customerData.get();
        const currentCustomerAge = memberData.current_customer_info.age.years;
        const {isStepOneFinished,isAfterSendingRequest,deleteRequestFromState,getAdditionalInsurances} = this.props;
        if (currentCustomerAge < MIN_AGE) { 
            const url = mLib.url.getUrlByVersion(2, '/home');
            window.location.href = url;
        }
        if (isStepOneFinished && !isAfterSendingRequest) return; //no need to call api again
        if (isAfterSendingRequest) {
            deleteRequestFromState()
        }
        getAdditionalInsurances();
    }

    sectionToDisplay() {
        const {userIsNotEligiblePayerOfAllMembers,allInMyMaccabi,familyMembers} = this.props;
        const memberData = mLib.saveData.customerData.get();
        const {credit_type} = memberData.logged_customer_info;
        if (!credit_type || credit_type === NO_ACTIVE_HOK_CREDIT_STATUS) return <ModuleMessage message={MODULE_MESSAGE_TEXT.unavailableService}/>;
        if (allInMyMaccabi) return <ModuleMessage message={MODULE_MESSAGE_TEXT.alreadyInMyMaccabi}/>;
        if (userIsNotEligiblePayerOfAllMembers) return <ModuleMessage message={MODULE_MESSAGE_TEXT.validOnlyForEligiblePayer}/>
        if (!familyMembers.length) return null
        return <FillRequestForm/>
    }

    render() {  
        const {isErrorInModule,ErrorComponent} = this.props;
        return (
            <Fragment>
                <MainHeadline>
                    <MainHeadlineScrollable>
                        <H1 hook="JoinMyMaccabiTitle">{STATIC_TXT.JoinMyMaccabiTitle}</H1>
                    </MainHeadlineScrollable>
                </MainHeadline>
                <MainBody scrollClassName={style.scrollCardBody} className={style.mainBody}>
                    <MainDescriptionAndLinks/>
                    {isErrorInModule ? <ErrorComponent/> :
                    <div className={style.myMaccabiCard}>
                        <MyMaccabiIcon/>
                        {this.sectionToDisplay()}
                    </div>
                    }
                </MainBody>        
            </Fragment>
        );
    }
}

export default withRouter(JoinMyMaccabi);