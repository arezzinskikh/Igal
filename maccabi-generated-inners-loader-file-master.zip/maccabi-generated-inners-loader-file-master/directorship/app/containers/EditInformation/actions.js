import {
    ON_LOAD,
    ON_CURRENT_CUSTOMER,
    ON_SHOW_FAILED_UPDATE_REMARKS,
    ON_SHOW_FAILED_UPDATE_DETAILS,
    ON_SHOW_SENIORITY,
    SET_SENIORITY_DATA,
    DISPLAY_SENIORITY_POPUP,
    HIDE_POPUP,
    TOGGLE_LOADING,
    EDIT_INFORMATION,
    PERSONAL_DETAILS_UPDATED,
    HIDE_SUCCESS_MESSAGE,
    SET_SETTINGS,
    SHOW_GLOBAL_ERROR_POPUP,
    UPDATE_PASSWORD,
    PASSWORD_UPDATED,
    AUTHENTICATION_FAILED,
    AUTHENTICATION_SUCCESS,
    EDIT_REMARKS,
    DISPLAY_NO_SENIORITY_HISTORY_POPUP,
    FILTER_CITIES,
    FILTER_STREETS,
    SET_FILTERED_CITIES,
    SET_FILTERED_STREETS
} from './constants';

export function onLoad(activeTabIndex) {
    return {
        type: ON_LOAD,
        activeTabIndex: activeTabIndex
    };
}

export function onCurrentCustomer(memberData, full, onAfterSuccess) {
    return {
        type: ON_CURRENT_CUSTOMER,
        memberData: memberData,
        full: full,
        onAfterSuccess: onAfterSuccess
    };
}

export function onShowSeniorityClick(insuranceGroups, currentCustomerInfo) {
    return {
        type: ON_SHOW_SENIORITY,
        insuranceGroups: insuranceGroups,
        currentCustomerInfo: currentCustomerInfo
    };
}

export function onSetSeniorityData(insuranceGroups, file) {
    return {
        type: SET_SENIORITY_DATA,
        insuranceGroups: insuranceGroups,
        file: file
    };
}

export function onDisplaySeniorityPopup() {
    return {
        type: DISPLAY_SENIORITY_POPUP
    };
}

export function onDisplayNoSeniorityHistoryPopup() {
    return {
        type: DISPLAY_NO_SENIORITY_HISTORY_POPUP
    };
}

export function onDisplayPartialSuccessFailedRemarks() {
    return {
        type: ON_SHOW_FAILED_UPDATE_REMARKS
    };
}

export function onDisplayPartialSuccessFailedDetails() {
    return {
        type: ON_SHOW_FAILED_UPDATE_DETAILS
    };
}

export function onHidePopup() {
    return {
        type: HIDE_POPUP
    };
}

export function toggleLoading() {
    return {
        type: TOGGLE_LOADING
    };
}

export function editInformation(
    eglishNames,
    phones,
    emailAddress,
    activeLanguageId,
    hasVisionLimitations,
    hasHearingLimitations,
    addresses,
    oldMemberData,
    newMemberData,
    onAfterSuccess
) {
    return {
        type: EDIT_INFORMATION,
        eglishNames: eglishNames,
        phones: phones,
        emailAddress: emailAddress,
        activeLanguageId: activeLanguageId,
        hasVisionLimitations: hasVisionLimitations,
        hasHearingLimitations: hasHearingLimitations,
        addresses: addresses,
        oldMemberData: oldMemberData,
        newMemberData: newMemberData,
        onAfterSuccess: onAfterSuccess
    };
}

export function editRemarks(hasVisionLimitations, hasHearingLimitations, memberData, onAfterSuccess) {
    return {
        type: EDIT_REMARKS,
        hasVisionLimitations: hasVisionLimitations,
        hasHearingLimitations: hasHearingLimitations,
        memberData: memberData,
        onAfterSuccess: onAfterSuccess
    };
}

export function updatePassword(oldPassword, newPassword, memberData, onAfterSuccess) {
    return {
        type: UPDATE_PASSWORD,
        oldPassword: oldPassword,
        newPassword: newPassword,
        memberData: memberData,
        onAfterSuccess: onAfterSuccess
    };
}

export function personalDetailsUpdated() {
    return {
        type: PERSONAL_DETAILS_UPDATED
    };
}

export function passwordUpdated() {
    return {
        type: PASSWORD_UPDATED
    };
}

export function authenticationFailed() {
    return {
        type: AUTHENTICATION_FAILED,
    };
}

export function authenticationSuccess() {
    return {
        type: AUTHENTICATION_SUCCESS,
    };
}

export function hideSuccessMessage() {
    return {
        type: HIDE_SUCCESS_MESSAGE
    };
}

export function setSettings(settings) {
    return {
        type: SET_SETTINGS,
        settings: settings
    };
}

export function setError() {
    return {
        type: SHOW_GLOBAL_ERROR_POPUP
    };
}

export function filterCities(addressType, term) {
    return {
        type: FILTER_CITIES,
        addressType: addressType,
        term
    };
}

export function filterStreets(addressType, cityId, term) {
    return {
        type: FILTER_STREETS,
        addressType: addressType,
        cityId: cityId,
        term
    };
}

export function setFilteredCities(addressType, cities) {
    return {
        type: SET_FILTERED_CITIES,
        addressType: addressType,
        cities: cities
    };
}

export function setFilteredStreets(addressType, streets) {
    return {
        type: SET_FILTERED_STREETS,
        addressType: addressType,
        streets: streets
    };
}
