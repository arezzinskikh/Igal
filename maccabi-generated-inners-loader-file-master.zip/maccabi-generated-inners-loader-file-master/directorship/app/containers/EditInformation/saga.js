import { takeLatest, takeEvery, call, put } from 'redux-saga/effects';
import mLib from '@maccabi/m-lib';
import {
    ON_CURRENT_CUSTOMER,
    ON_SHOW_SENIORITY,
    EDIT_INFORMATION,
    PERSONAL_DETAILS_REMARK_CODES,
    UPDATE_PASSWORD,
    FILTER_CITIES,
    FILTER_STREETS,
    EDIT_REMARKS,
    ENDPOINT_POST_VALUES,
    UPDATE_MEMBERSHIP_STATUS_SUCCESS_CODE,
    UPDATE_REMARKS_STATUS_SUCCESS_CODE,
    DEFAULT_MAX_AUTO_COMPLETE_RESULTS
} from './constants';
import {
    toggleLoading,
    onSetSeniorityData,
    onDisplaySeniorityPopup,
    personalDetailsUpdated,
    onDisplayPartialSuccessFailedRemarks,
    onDisplayPartialSuccessFailedDetails,
    setError,
    passwordUpdated,
    authenticationFailed,
    authenticationSuccess,
    onDisplayNoSeniorityHistoryPopup,
    setFilteredCities,
    setFilteredStreets
} from './actions';
import { getCustomerData, getSeniority, updateDetails, updateRemarks, validateUpdatePassword } from '../../services/EditInformation/apiService';
import { getAddressesToUpdate, getPhonesToUpdate, getFieldToUpdate, getRemarksToUpdate } from './utils';

function* handleOnCurrentCustomer(action) {
    try {
        const { memberData, onAfterSuccess } = action;
        const currentCustomerInfo = memberData.current_customer_info;

        const result = yield call(
            getCustomerData,
            currentCustomerInfo.member_id_code,
            currentCustomerInfo.member_id,
            currentCustomerInfo.checksum_id,
            action.full
        );

        if (result !== null) {
            if (action.full) memberData.current_customer_info = result;
            else {
                memberData.current_customer_info.remarks = result.remarks;
                memberData.current_customer_info.insurances_groups= result.insurances_groups;
                memberData.current_customer_info.f_name_english = result.f_name_english;
                memberData.current_customer_info.l_name_english =  result.l_name_english;
            }
            updateCustomer(memberData, onAfterSuccess);
        }
    } catch (err) {
        console.log('err', err);
    }
}

function* handleShowSeniority(action) {
    const currentCustomerInfo = action.currentCustomerInfo;
    const insuranceGroups = action.insuranceGroups;

    try {
        //yield put(toggleLoading());
        let insurances = insuranceGroups;
        let hasSeniorityData = false;
        let file = {};
        if (!insurances) {
            const result = yield call(getSeniority, currentCustomerInfo.member_id_code, currentCustomerInfo.member_id);
            const { insurance_groups, membership_status, timestamp, hash } = result;

            if (membership_status === UPDATE_MEMBERSHIP_STATUS_SUCCESS_CODE && insurance_groups !== null && insurance_groups.length > 0) {
                hasSeniorityData = true;
                insurances = insurance_groups;
                file = {
                    hash: hash,
                    timestamp: timestamp,
                    membership_status: membership_status
                };
            }
        } else {
            hasSeniorityData = true;
        }

        if (hasSeniorityData) {
            yield put(onSetSeniorityData(insurances, file));
            yield put(onDisplaySeniorityPopup());
        } else {
            yield put(onDisplayNoSeniorityHistoryPopup());
        }
    } catch (err) {
        console.error('err', err);
        yield put(setError());
    } finally {
        //yield put(toggleLoading());
    }
}

function getNewRemarksState(remarks, hasVisionLimitations, hasHearingLimitations) {
    let remarksThatShouldExist = [];
    let remarksThatShouldNotExist = [];

    hasHearingLimitations
        ? remarksThatShouldExist.push(PERSONAL_DETAILS_REMARK_CODES.HEARING_LIMITATIONS)
        : remarksThatShouldNotExist.push(PERSONAL_DETAILS_REMARK_CODES.HEARING_LIMITATIONS);
    hasVisionLimitations
        ? remarksThatShouldExist.push(PERSONAL_DETAILS_REMARK_CODES.VISION_LIMITATIONS)
        : remarksThatShouldNotExist.push(PERSONAL_DETAILS_REMARK_CODES.VISION_LIMITATIONS);

    return getRemarksToUpdate(remarks, remarksThatShouldExist, remarksThatShouldNotExist);
}

async function updateCustomer(memberData, onAfterSuccess) {
    await mLib.customer.getCustomerData();
    mLib.saveData.customerData.setCurrent(null);
    mLib.saveData.customerData.setCurrent(memberData.current_customer_info);
    onAfterSuccess && onAfterSuccess();
}

function* handleUpdateInformation(action) {
    const {
        eglishNames,
        phones,
        emailAddress,
        activeLanguageId,
        hasVisionLimitations,
        hasHearingLimitations,
        addresses,
        oldMemberData,
        newMemberData,
        onAfterSuccess
    } = action;
    //const { phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses, oldMemberData, newMemberData } = action;
    let infoUpdated = false;
    let remarksUpdated = false;

    try {
        yield put(toggleLoading());
        let hasError = false;
        const currentCustomerInfo = oldMemberData.current_customer_info;
        const loggedCustomerInfo = oldMemberData.logged_customer_info;
        const phonesToUpdate = phones && getPhonesToUpdate(currentCustomerInfo.phones, phones, ENDPOINT_POST_VALUES);
        const addressesToUpdate = addresses && getAddressesToUpdate(currentCustomerInfo.addresses, addresses, ENDPOINT_POST_VALUES);
        const remarksToUpdate = getNewRemarksState(currentCustomerInfo.remarks, hasVisionLimitations, hasHearingLimitations);
        const emailAddressUpdateField = emailAddress && getFieldToUpdate(currentCustomerInfo.email, emailAddress, 'email');
        const languageIdUpdateField = activeLanguageId && getFieldToUpdate(currentCustomerInfo.language_code, activeLanguageId, 'language_code');
        const firstNameEnglishUpdateField = getFieldToUpdate(currentCustomerInfo.f_name_english, eglishNames.firstNameEnglish, 'f_name_eng');
        const lastNameEnglishUpdateField = getFieldToUpdate(currentCustomerInfo.l_name_english, eglishNames.lastNameEnglish, 'l_name_eng');

        // Check which updates are required
        const hasFieldsToUpdate =
            (phonesToUpdate && phonesToUpdate.length > 0) ||
            (addressesToUpdate && addressesToUpdate.length > 0) ||
            emailAddressUpdateField ||
            languageIdUpdateField ||
            firstNameEnglishUpdateField ||
            lastNameEnglishUpdateField ;
        const hasRemarksToUpdate = remarksToUpdate && remarksToUpdate.length > 0;

        if (hasFieldsToUpdate) {
            let updateDetailsObj = {};

            if (phonesToUpdate && phonesToUpdate.length > 0) {
                updateDetailsObj.phones = phonesToUpdate;
            }
            if (addressesToUpdate && addressesToUpdate.length > 0) {
                updateDetailsObj.addresses = addressesToUpdate;
            }
            if (emailAddressUpdateField) {
                updateDetailsObj.discrete_fields = [];
                updateDetailsObj.discrete_fields.push(emailAddressUpdateField);
            }
            if (languageIdUpdateField) {
                if (!updateDetailsObj.discrete_fields) {
                    updateDetailsObj.discrete_fields = [];
                }
                languageIdUpdateField.field_value = '0' + languageIdUpdateField.field_value;
                updateDetailsObj.discrete_fields.push(languageIdUpdateField);
            }
            if (firstNameEnglishUpdateField) {
                if (!updateDetailsObj.discrete_fields) {
                    updateDetailsObj.discrete_fields = [];
                }
                updateDetailsObj.discrete_fields.push(firstNameEnglishUpdateField);
            }
            if (lastNameEnglishUpdateField) {
                if (!updateDetailsObj.discrete_fields) {
                    updateDetailsObj.discrete_fields = [];
                }
                updateDetailsObj.discrete_fields.push(lastNameEnglishUpdateField);
            }

            //const result = yield call(updateDetails, loggedCustomerInfo.member_id_code, loggedCustomerInfo.member_id, updateDetailsObj);
            const result = yield call(updateDetails, currentCustomerInfo.member_id_code, currentCustomerInfo.member_id, updateDetailsObj);

            // Error occurred
            if (result.errors && result.errors.length > 0) {
                hasError = true;
            } else {
                infoUpdated = true;
            }
        }
        // Update remarks in separate call
        if (hasRemarksToUpdate) {
            const remarksResult = yield call(updateRemarks, currentCustomerInfo.member_id_code, currentCustomerInfo.member_id, remarksToUpdate);

            // Find any failed remarks
            if (remarksResult.remarks && remarksResult.remarks.find(remark => remark.update_status !== UPDATE_REMARKS_STATUS_SUCCESS_CODE)) {
                hasError = true;
            } else {
                remarksUpdated = true;
            }
        }

        if (!infoUpdated && !remarksUpdated && hasError) {
            // BOTH FAILED
            yield put(setError());
        }
        // Partial success
        else if ((infoUpdated || remarksUpdated) && hasError) {
            yield call(updateCustomer, newMemberData, onAfterSuccess);
            if (infoUpdated) {
                yield put(onDisplayPartialSuccessFailedRemarks());
            } else {
                yield put(onDisplayPartialSuccessFailedDetails());
            }
        } else {
            //mLib.logs.insertCentralizedLog(LOG_IDS.SAVE_EDIT_PERSONAL_INFO_CHANGES, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);
            //yield call(updateCustomer, newMemberData, onAfterSuccess);
            onAfterSuccess && onAfterSuccess();
            yield put(personalDetailsUpdated());
        }
    } catch (err) {
        /* Partial success because one succeeded */
        if (infoUpdated || remarksUpdated) {
            yield call(updateCustomer, newMemberData, onAfterSuccess);

            if (infoUpdated) {
                yield put(onDisplayPartialSuccessFailedRemarks());
            } else {
                yield put(onDisplayPartialSuccessFailedDetails());
            }
        } else {
            yield put(setError());
        }
    } finally {
        yield put(toggleLoading());
    }
}

function* handleUpdateRemarks(action) {
    const { hasVisionLimitations, hasHearingLimitations, memberData, onAfterSuccess } = action;
    try {
        yield put(toggleLoading());

        let hasError = false;
        const currentCustomerInfo = memberData.current_customer_info;
        const remarksToUpdate = getNewRemarksState(currentCustomerInfo.remarks, hasVisionLimitations, hasHearingLimitations);
        const hasRemarksToUpdate = remarksToUpdate && remarksToUpdate.length > 0;

        if (hasRemarksToUpdate) {
            const remarksResult = yield call(updateRemarks, currentCustomerInfo.member_id_code, currentCustomerInfo.member_id, remarksToUpdate);

            // Find any failed remarks
            if (remarksResult.remarks && remarksResult.remarks.find(remark => remark.update_status !== UPDATE_REMARKS_STATUS_SUCCESS_CODE)) {
                hasError = true;
            }
        }
        if (hasError) {
            yield put(setError());
        } else {
            //mLib.logs.insertCentralizedLog(LOG_IDS.SAVE_EDIT_PERSONAL_INFO_CHANGES, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);
            // yield call(updateCustomer, memberData, onAfterSuccess);
            onAfterSuccess && onAfterSuccess();
            yield put(personalDetailsUpdated());
        }
    } catch (err) {
        yield put(setError());
    } finally {
        yield put(toggleLoading());
    }
}

function* handleUpdatePassword(action) {
    const { oldPassword, newPassword, memberData, onAfterSuccess } = action;

    try {
        const loggedCustomerInfo = memberData.logged_customer_info;

        yield put(toggleLoading());
        const result = yield call(validateUpdatePassword, loggedCustomerInfo.member_id_code, loggedCustomerInfo.member_id, oldPassword, newPassword);
        const { update_success, authentication_success } = result;

        if (update_success && authentication_success) {
           // mLib.logs.insertCentralizedLog(LOG_IDS.SAVE_CHANGE_PASSWORD_CLICK, EDIT_PASSWORD_PAGE_NAME, CLICK_LOG_ID);
            yield call(updateCustomer, memberData, onAfterSuccess);
            yield put(passwordUpdated());
            yield put(authenticationSuccess());
        } else if (!authentication_success) {
            yield put(authenticationFailed());
        } else {
            yield put(setError());
        }
    } catch (err) {
        console.error('err', err);
        yield put(setError());
    } finally {
        yield put(toggleLoading());
    }
}

function* handleFilterCities(action) {
    const { addressType, term } = action;
    try {
        if (term) {
            const cities = yield call(mLib.demographics.getCities, encodeURIComponent(term), DEFAULT_MAX_AUTO_COMPLETE_RESULTS);
            yield put(setFilteredCities(addressType, cities || []));
        } else {
            yield put(setFilteredCities(addressType, []));
        }
    } catch (err) {
        console.log('err', err);
    }
}

function* handleFilterStreets(action) {
    const { addressType, cityId, term } = action;

    try {
        if (term) {
            const streets = yield call(mLib.demographics.getCityStreets, cityId, encodeURIComponent(term), DEFAULT_MAX_AUTO_COMPLETE_RESULTS);
            yield put(setFilteredStreets(addressType, streets || []));
        } else {
            yield put(setFilteredStreets(addressType, []));
        }
    } catch (err) {
        console.log('err', err);
    }
}

export default function* rootSaga() {
    yield takeLatest(ON_CURRENT_CUSTOMER, handleOnCurrentCustomer);
    yield takeLatest(ON_SHOW_SENIORITY, handleShowSeniority);
    yield takeLatest(EDIT_INFORMATION, handleUpdateInformation);
    yield takeLatest(EDIT_REMARKS, handleUpdateRemarks);
    yield takeLatest(UPDATE_PASSWORD, handleUpdatePassword);
    yield takeEvery(FILTER_CITIES, handleFilterCities);
    yield takeEvery(FILTER_STREETS, handleFilterStreets);
}
