import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Modal } from '@maccabi/m-ui';
import { PARTIAL_SUCCESS_FAILED_DETAILS_TITLE, PARTIAL_SUCCESS_FAILED_DETAILS_SUBTITLE, PARTIAL_SUCCESS_FAILED_DETAILS_BTN } from '../constants';

const ICON = 'attention-big';

@autobind
class PartialSuccessFailedDetailsPopup extends Component {
    static propTypes = {
        close: PropTypes.func.isRequired,
        isOpen: PropTypes.bool.isRequired
    };

    onClose() {
        const { close } = this.props;
        close();
    }

    onPrimaryButtonClick() {
        const { close } = this.props;
        close();
    }

    render() {
        const { isOpen } = this.props;

        return (
            <Modal
                isOpen={isOpen}
                icon={ICON}
                toggle={this.onClose}
                header={PARTIAL_SUCCESS_FAILED_DETAILS_TITLE}
                body={PARTIAL_SUCCESS_FAILED_DETAILS_SUBTITLE}
                primaryButton={PARTIAL_SUCCESS_FAILED_DETAILS_BTN}
                primaryButtonClick={this.onPrimaryButtonClick}>
            </Modal>
        )
    }

}

export default PartialSuccessFailedDetailsPopup;