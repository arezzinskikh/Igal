import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Modal } from '@maccabi/m-ui';
import { NO_SENIORITY_HISTORY_POPUP_TITLE, NO_SENIORITY_HISTORY_POPUP_DESCRIPTION, NO_SENIORITY_HISTORY_POPUP_BTN } from '../constants';

const ICON = 'attention-big';

@autobind
class NoSeniorityHistoryPopup extends Component {
    static propTypes = {
        close: PropTypes.func.isRequired,
        isOpen: PropTypes.bool.isRequired
    };

    onClose() {
        const { close } = this.props;
        close();
    }

    onPrimaryButtonClick() {
        const { close } = this.props;
        close();
    }

    render() {
        const { isOpen } = this.props;

        return (
            <Modal
                isOpen={isOpen}
                icon={ICON}
                toggle={this.onClose}
                header={NO_SENIORITY_HISTORY_POPUP_TITLE}
                body={NO_SENIORITY_HISTORY_POPUP_DESCRIPTION}
                primaryButton={NO_SENIORITY_HISTORY_POPUP_BTN}
                primaryButtonClick={this.onPrimaryButtonClick}>
            </Modal>
        )
    }

}

export default NoSeniorityHistoryPopup;