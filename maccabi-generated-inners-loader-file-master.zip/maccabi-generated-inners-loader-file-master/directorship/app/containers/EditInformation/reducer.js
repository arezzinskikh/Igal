import { fromJS } from 'immutable';
import {
    ON_LOAD,
    ON_SHOW_SENIORITY,
    SET_SENIORITY_DATA,
    DISPLAY_SENIORITY_POPUP,
    HIDE_POPUP,
    TOGGLE_LOADING,
    POPUPS,
    EDIT_INFORMATION,
    ON_SHOW_FAILED_UPDATE_DETAILS,
    ON_SHOW_FAILED_UPDATE_REMARKS,
    PERSONAL_DETAILS_UPDATED,
    HIDE_SUCCESS_MESSAGE,
    SET_SETTINGS,
    SHOW_GLOBAL_ERROR_POPUP,
    UPDATE_PASSWORD,
    PASSWORD_UPDATED,
    AUTHENTICATION_FAILED,
    AUTHENTICATION_SUCCESS,
    EDIT_REMARKS,
    DISPLAY_NO_SENIORITY_HISTORY_POPUP,
    FILTER_CITIES,
    FILTER_STREETS,
    SET_FILTERED_CITIES,
    SET_FILTERED_STREETS,
    EDIT_PASSWORD_NEW_AUTHENICATION_FAILED
} from './constants';

const getInitialState = () => {
    return {
        popup: null,
        insuranceGroups: null,
        loading: false,
        showSuccessMessage: false,
        settings: null,
        authenticationStatus:"",
        addressesAutoComplete: {
            LIVING: {
                cities: [],
                streets: []
            },
            MAIL: {
                cities: [],
                streets: []
            },
            PERSONAL_MAIL: {
                cities: [],
                streets: []
            }
        }
    };
};

export const initialState = fromJS(getInitialState());

export default function noCardVisitReducer(state = initialState, action) {
    let editInformationData = { ...state.get('editInformationData') };

    switch (action.type) {
        case ON_LOAD:
            return state.set('editInformationData', getInitialState());
        case SET_SETTINGS:
            editInformationData.settings = action.settings;
            return state.set('editInformationData', editInformationData);
        case SET_SENIORITY_DATA:
            editInformationData.insuranceGroups = action.insuranceGroups;
            editInformationData.file = action.file;
            return state.set('editInformationData', editInformationData);
        case DISPLAY_SENIORITY_POPUP:
            editInformationData.popup = POPUPS.SENIORITY_POPUP;
            return state.set('editInformationData', editInformationData);
        case DISPLAY_NO_SENIORITY_HISTORY_POPUP:
            editInformationData.popup = POPUPS.NO_SENIORITY_HISTORY_POPUP;
            return state.set('editInformationData', editInformationData);
        case ON_SHOW_FAILED_UPDATE_DETAILS:
            editInformationData.popup = POPUPS.PARTIAL_SUCCESS_FAILED_DETAILS_POPUP;
            return state.set('editInformationData', editInformationData);
        case ON_SHOW_FAILED_UPDATE_REMARKS:
            editInformationData.popup = POPUPS.PARTIAL_SUCCESS_FAILED_REMARKS_POPUP;
            return state.set('editInformationData', editInformationData);
        case SHOW_GLOBAL_ERROR_POPUP:
            editInformationData.popup = POPUPS.GLOBAL_ERROR_POPUP;
            return state.set('editInformationData', editInformationData);
        case HIDE_POPUP:
            editInformationData.popup = null;
            return state.set('editInformationData', editInformationData);
        case TOGGLE_LOADING:
            editInformationData.loading = !editInformationData.loading;
            return state.set('editInformationData', editInformationData);
        case PERSONAL_DETAILS_UPDATED:
        case PASSWORD_UPDATED:
            editInformationData.showSuccessMessage = true;
            return state.set('editInformationData', editInformationData);
        case AUTHENTICATION_FAILED:
            editInformationData.authenticationStatus = EDIT_PASSWORD_NEW_AUTHENICATION_FAILED;
            return state.set('editInformationData', editInformationData);
            case AUTHENTICATION_SUCCESS:
                editInformationData.authenticationStatus = '';
                return state.set('editInformationData', editInformationData);
        case HIDE_SUCCESS_MESSAGE:
            editInformationData.showSuccessMessage = false;
            return state.set('editInformationData', editInformationData);
        case SET_FILTERED_CITIES:
            editInformationData.addressesAutoComplete[action.addressType].cities = action.cities;
            return state.set('editInformationData', editInformationData);
        case SET_FILTERED_STREETS:
            editInformationData.addressesAutoComplete[action.addressType].streets = action.streets;
            return state.set('editInformationData', editInformationData);
        case EDIT_INFORMATION:
        case EDIT_REMARKS:
        case UPDATE_PASSWORD:
        case ON_SHOW_SENIORITY:
        case FILTER_CITIES:
        case FILTER_STREETS:
        default:
            return state;
    }
}
