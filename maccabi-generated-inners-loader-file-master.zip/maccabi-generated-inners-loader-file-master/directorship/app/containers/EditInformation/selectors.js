import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectEditInformationData = state => {
  return state.get('editInformationData', initialState);
};

export const makeSelectEditInformationData = createSelector(selectEditInformationData, editInformationState => {
  return editInformationState.get('editInformationData')
});