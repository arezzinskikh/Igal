import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Modal } from '@maccabi/m-ui';
import { PARTIAL_SUCCESS_FAILED_REMARKS_TITLE, PARTIAL_SUCCESS_FAILED_REMARKS_SUBTITLE, PARTIAL_SUCCESS_FAILED_REMARKS_BTN } from '../constants';
import style from './PartialSuccessFailedRemarksPopup.scss';

const ICON = 'success-big';

@autobind
class PartialSuccessFailedRemarksPopup extends Component {
    static propTypes = {
        close: PropTypes.func.isRequired,
        isOpen: PropTypes.bool.isRequired
    };

    onClose() {
        const { close } = this.props;
        close();
    }

    onPrimaryButtonClick() {
        const { close } = this.props;
        close();
    }

    render() {
        const { isOpen } = this.props;

        return (
            <Modal
                isOpen={isOpen}
                icon={ICON}
                toggle={this.onClose}
                header={PARTIAL_SUCCESS_FAILED_REMARKS_TITLE}
                body={<span className={style.danger}>{PARTIAL_SUCCESS_FAILED_REMARKS_SUBTITLE}</span>}
                primaryButton={PARTIAL_SUCCESS_FAILED_REMARKS_BTN}
                primaryButtonClick={this.onPrimaryButtonClick}>
            </Modal>
        )
    }

}

export default PartialSuccessFailedRemarksPopup;