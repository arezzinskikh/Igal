import React, { Component } from 'react';
import PropTypes from 'prop-types';
import autobind from 'autobind';
import cx from 'classnames';
import { Button, H2, List, IconLoader } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import PasswordInput from '../../../components/PasswordInput';
import {
    EDIT_PASSWORD_DESCRIPTION_FIRST_LINE,
    EDIT_PASSWORD_DESCRIPTION_SECOND_LINE,
    EDIT_PASSWORD_REMARKS_TITLE,
    EDIT_PASSWORD_REMARKS,
    EDIT_PASSWORD_FORGOT_PASSWORD_LINK,
    EDIT_PASSWORD_FORGOT_PASSWORD_LINK_KOSHER,
    EDIT_PASSWORD_FORGOT_PASSWORD,
    EDIT_PASSWORD_PASSWORD_LABEL,
    EDIT_PASSWORD_NEW_PASSWORD_LABEL,
    EDIT_PASSWORD_VALIDATE_PASSWORD_LABEL,
    EDIT_PASSWORD_REQUIRED_ERROR_MESSAGE,
    EDIT_PASSWORD_INVALID_ERROR_MESSAGE,
    EDIT_PASSWORD_MISMATCH_ERROR_MESSAGE,
    EDIT_PASSWORD_SUBMIT_BTN,
    EDIT_PASSWORD_NEW_PASSWORD_TITLE,
    LOG_IDS,
    CLICK_LOG_ID,
    EDIT_PASSWORD_PAGE_NAME
} from '../constants';

import { testPassword } from '../utils';
import style from './EditPassword.scss';

const getDefaultPasswordInputValue = () => {
    return {
        value: '',
        visibility: 'hidden',
        errorMessage: null
    };
};

@autobind
class EditPassword extends Component {
    constructor(props) {
        super(props);

        this.state = {
            leavingGuardIsSet: false,
            password: getDefaultPasswordInputValue(),
            newPassword: getDefaultPasswordInputValue(),
            passwordConfirmation: getDefaultPasswordInputValue()
        };
    }

    static propTypes = {
        setRouteLeavingGuard: PropTypes.func,
        navigateTo: PropTypes.func,
        onUpdatePassword: PropTypes.func,
        loading: PropTypes.func,
        auth: PropTypes.string
    };

    onChange(inputName, e) {
        let input = this.state[inputName];
        input.value = e.target.value;
        this.setState({ [inputName]: input });
    }

    updateFieldVisibility(inputName, newState) {
        let input = this.state[inputName];
        input.visibility = newState;
        this.setState({ [inputName]: input });
    }

    turnOnEscapeGuard() {
        const { setRouteLeavingGuard } = this.props;
        const { leavingGuardIsSet } = this.state;

        if (!leavingGuardIsSet) {
            setRouteLeavingGuard && setRouteLeavingGuard();
        }
    }

    getEmptyError(val) {
        if (!val || val.length === 0) {
            return EDIT_PASSWORD_REQUIRED_ERROR_MESSAGE;
        }

        return null;
    }

    validatePassword(val) {
        /* Validate that the password is not empty */
        let error = this.getEmptyError(val);

        let passwordInput = this.state.password;
        /* Update state only if changed */
        if (passwordInput.errorMessage !== error) {
            passwordInput.errorMessage = error;
            this.setState({ password: passwordInput });
        } else if (this.props.auth !== '') {
            passwordInput.errorMessage = this.props.auth;
            this.setState({ password: passwordInput });
        }

        this.turnOnEscapeGuard();
        return error === null;
    }

    validateNewPassword(val) {
        /* Validate that the password is not empty */
        let error = this.getEmptyError(val);

        /* Preform regex validation */
        if (error === null) {
            error = testPassword(val) ? null : EDIT_PASSWORD_INVALID_ERROR_MESSAGE;
        }

        let passwordInput = this.state.newPassword;
        /* Update state only if changed */
        if (passwordInput.errorMessage !== error) {
            passwordInput.errorMessage = error;

            this.setState({ newPassword: passwordInput });
        }

        this.turnOnEscapeGuard();
        return error === null;
    }

    validatePasswordConfirmation(val) {
        /* Validate that the password is not empty */
        let error = this.getEmptyError(val);

        /* Check if equals to new password */
        if (error === null) {
            error = val === this.state.newPassword.value ? null : EDIT_PASSWORD_MISMATCH_ERROR_MESSAGE;
        }

        let passwordInput = this.state.passwordConfirmation;
        /* Update state only if changed */
        if (passwordInput.errorMessage !== error) {
            passwordInput.errorMessage = error;

            this.setState({ passwordConfirmation: passwordInput });
        }

        this.turnOnEscapeGuard();
        return error === null;
    }

    onSubmit = () => {
        const { onUpdatePassword } = this.props;
        const { password, newPassword, passwordConfirmation } = this.state;

        mLib.logs.insertCentralizedLog(LOG_IDS.SAVE_CHANGE_PASSWORD_CLICK, EDIT_PASSWORD_PAGE_NAME, CLICK_LOG_ID);

        /* Proceed only if all fields are valid */
        if (
            this.validatePassword(password.value) &
            this.validateNewPassword(newPassword.value) &
            this.validatePasswordConfirmation(passwordConfirmation.value)
        ) {
            onUpdatePassword && onUpdatePassword(password.value, newPassword.value);
        }
    };

    onForgetPasswordClick = () => {
        const { navigateTo } = this.props;
        const url = mLib.site.isKosher() ? EDIT_PASSWORD_FORGOT_PASSWORD_LINK_KOSHER : EDIT_PASSWORD_FORGOT_PASSWORD_LINK;
        
        mLib.logs.insertCentralizedLog(LOG_IDS.FORGOT_PASSWORD_CLICK, EDIT_PASSWORD_PAGE_NAME, CLICK_LOG_ID);
        navigateTo && navigateTo(url);
    };

    render() {
        const { password, newPassword, passwordConfirmation } = this.state;
        const { loading } = this.props;

        return (
            <div className={style.container}>
                <div className={style.description}>
                    <span>{EDIT_PASSWORD_DESCRIPTION_FIRST_LINE}</span>
                    <span>{EDIT_PASSWORD_DESCRIPTION_SECOND_LINE}</span>
                </div>
                <div className={style.section}>
                    <H2>{EDIT_PASSWORD_REMARKS_TITLE}</H2>
                    <List className={cx(style.list, 'text-secondary')} list={EDIT_PASSWORD_REMARKS} />
                    <div className={style.row}>
                        <div className={style.item}>
                            <PasswordInput
                                label={EDIT_PASSWORD_PASSWORD_LABEL}
                                inputclassname={style.input}
                                onBlur={e => this.validatePassword(e.target.value)}
                                error={password.errorMessage}
                                onChange={e => this.onChange('password', e)}
                                width={'regular'}
                                value={password.value}
                                visibilityState={password.visibility}
                                updateVisibilityState={newState => this.updateFieldVisibility('password', newState)}
                                hook='currentPassword'
                            />
                        </div>
                        <div className={cx(style.item, style.fullWidth, style.mobileMarginTop)}>
                            <span onClick={this.onForgetPasswordClick} className={style.forgotPassword} data-hook='forgotPassword'>
                                {EDIT_PASSWORD_FORGOT_PASSWORD}
                            </span>
                        </div>
                    </div>
                </div>
                <div>
                    <H2>{EDIT_PASSWORD_NEW_PASSWORD_TITLE}</H2>
                    <div className={style.row}>
                        <div className={style.item}>
                            <PasswordInput
                                label={EDIT_PASSWORD_NEW_PASSWORD_LABEL}
                                inputclassname={style.input}
                                onBlur={e => this.validateNewPassword(e.target.value)}
                                error={newPassword.errorMessage}
                                onChange={e => this.onChange('newPassword', e)}
                                width={'regular'}
                                value={newPassword.value}
                                visibilityState={newPassword.visibility}
                                updateVisibilityState={newState => this.updateFieldVisibility('newPassword', newState)}
                                hook='newPassword'
                            />
                        </div>
                        <div className={cx(style.item, style.mobileMarginTopBig)}>
                            <PasswordInput
                                label={EDIT_PASSWORD_VALIDATE_PASSWORD_LABEL}
                                inputclassname={style.input}
                                onBlur={e => this.validatePasswordConfirmation(e.target.value)}
                                error={passwordConfirmation.errorMessage}
                                onChange={e => this.onChange('passwordConfirmation', e)}
                                width={'regular'}
                                value={passwordConfirmation.value}
                                visibilityState={passwordConfirmation.visibility}
                                updateVisibilityState={newState => this.updateFieldVisibility('passwordConfirmation', newState)}
                                hook='validateNewPassword'
                            />
                        </div>
                    </div>
                </div>
                <div className={style.saveChangesContainer}>
                    <Button hook='submit' maincta color="primary" size={'md'} className={style.btn} onClick={this.onSubmit}>
                        {loading && <IconLoader size="sm" className={style.iconLoader} />}
                        {EDIT_PASSWORD_SUBMIT_BTN}
                    </Button>
                </div>
            </div>
        );
    }
}

export default EditPassword;
