import React, { Fragment, Component } from 'react';
import PropTypes from 'prop-types';
import autobind from 'autobind';
import cx from 'classnames';
import { Input, InputPhone, InputEmail, Icon, Tooltip, Checkbox, InputDrop, Button, IconLoader } from '@maccabi/m-ui';
import mLib from '@maccabi/m-lib';
import {
    AGE_CATEGORY,
    ENGLISH_NAMES_TITLE,
    FIRST_NAME_ENGLISH,
    LAST_NAME_ENGLISH,
    FIRST_NAME_ENGLISH_ERROR,
    LAST_NAME_ENGLISH_ERROR,
    PHONES_EMAILS_TITLE,
    PHONES_EMAILS_DESCRIPTION,
    PHONE_TYPES,
    PHONES_EMAILS_EMAIL_NAME,
    PHONES_EMAILS_EMAIL_VALIDATION,
    PERSONAL_DETAILS_LANGUAGE_TITLE,
    PERSONAL_DETAILS_LANGUAGE_DESCRIPTION,
    LANGUAGES,
    PERSONAL_DETAILS_LANGUAGE_TOOLTIP_NAME,
    PERSONAL_DETAILS_LANGUAGE_TOOLTIP_DESCRIPTION,
    PERSONAL_DETAILS_CHOOSE_LANGUAGE,
    PERSONAL_DETAILS_ACCESSIBILITY_TOOLTIP_NAME,
    PERSONAL_DETAILS_ACCESSIBILITY_TOOLTIP_DESCRIPTION,
    PERSONAL_DETAILS_ACCESSIBILITY_VISION,
    PERSONAL_DETAILS_ACCESSIBILITY_HEARING,
    PERSONAL_DETAILS_REMARK_CODES,
    ADDRESS_SECTION_LIVING_ADDRESS_NAME,
    ADDRESS_SECTION_LIVING_ADDRESS_DESCRIPTION,
    ADDRESS_SECTION_MAIL_ADDRESS_NAME,
    ADDRESS_SECTION_MAIL_ADDRESS_DESCRIPTION,
    ADDRESS_SECTION_PERSONAL_MAIL_ADDRESS_NAME,
    ADDRESS_SECTION_PERSONAL_MAIL_ADDRESS_DESCRIPTION,
    ADDRESS_SECTION_ADDRESS_TYPES,
    PERSONAL_DETAILS_SUBMIT_BTN,
    PHONES_EMAILS_PHONE_VALIDATION,
    PHONES_EMAILS_PHONE_REQUIRED_VALIDATION,
    PERSONAL_DETAILS_EDIT_MINOR_REMARK,
    PERSONAL_DETAILS_EDIT_ADOLESCENT_REMARK,
    LOG_IDS,
    UPDATE_DETAILS_PAGE_NAME,
    CLICK_LOG_ID,
    PERSONAL_DETAILS_AGE,
    PERSONAL_DETAILS_INSURANCE_GROUP,
    PERSONAL_DETAILS_BRANCH,
    PERSONAL_DETAILS_INSURANCE_AGE_AGREEMENT,
    MIN_AGE_BOYGIRL_AVATAR,
    MIN_AGE_GROWN_UP_AVATAR,
    ADDRESS_SECTION_REGULAR_ADDRESS_TYPE_LABEL,
    ADDRESS_SECTION_POBOX_ADDRESS_TYPE_LABEL,
    ADDRESS_SECTION_CITY_TEXTBOX_LABEL,
    ADDRESS_SECTION_STREET_TEXTBOX_LABEL,
    ADDRESS_SECTION_HOUSE_TEXTBOX_LABEL,
    ADDRESS_SECTION_APARTMENT_TEXTBOX_LABEL,
    ADDRESS_SECTION_ENTRANCE_TEXTBOX_LABEL,
    ADDRESS_SECTION_POBOX_TEXTBOX_LABEL,
    ADDRESS_SECTION_ADD_ADDRESS_LABEL,
    ADDRESS_SECTION_REMOVE_ADDRESS_LABEL,
    ADDRESS_SECTION_EMPTY_CITY_VALIDATION,
    ADDRESS_SECTION_EMPTY_STREET_VALIDATION,
    ADDRESS_SECTION_HOUSE_VALIDATION,
    ADDRESS_SECTION_APARTMENT_VALIDATION,
    ADDRESS_SECTION_ENTRANCE_VALIDATION,
    ADDRESS_SECTION_PO_VALIDATION,
    ADDRESS_SECTION_INVALID_CITY,
    ADDRESS_SECTION_INVALID_STREET,
    ADDRESS_SECTION_NO_RESULT_TEST
} from '../constants';
import {
    getPhoneByType,
    getPhonePrefixIndex,
    hasRemark,
    getAddress,
    compareAddresses,
    isPoBoxAddress,
    createPhoneObject,
    createAddressObject
} from '../utils';
import DetailsHeader from '../../../components/DetailsHeader';
import Section from '../../../components/Section';
import AddressSection from '../../../components/AddressSection';
import style from './EditDetails.scss';

const HELP_ICON = 'help';
const ATTENTION_ICON = 'attention-small';
const LIVING_ADDRESS_PROP_NAME = 'LIVING';
const MAIL_ADDRESS_PROP_NAME = 'MAIL';
const PERSONAL_MAIL_ADDRESS_PROP_NAME = 'PERSONAL_MAIL';

@autobind
class EditDetails extends Component {
    constructor(props) {
        super(props);

        this.state = {
            firstNameEnglishValid: true,
            lastNameEnglishValid: true,
            homePhoneNumber: null,
            homePhonePrefixIndex: null,
            homePhoneValid: true,
            cellPhoneNumber: null,
            cellPhonePrefixIndex: null,
            cellPhoneValid: true,
            faxPhoneNumber: null,
            faxPhonePrefixIndex: null,
            faxValid: true,
            emailAddress: null,
            emailValid: true,
            activeLanguageId: null,
            showLanguageTooltip: false,
            showAccessibilityTooltip: false,
            hasVisionLimitations: false,
            hasHearingLimitations: false,
            stateInitialized: false,
            livingAddress: null,
            mailAddress: null,
            addMailAddress: false,
            mailAddressInPoBox: false,
            personalMailAddress: null,
            addPersonalMailAddress: null,
            personalMailAddressIsPoBox: null,
            bothPhonesWereEmpty: false,
            changesWereMade: false
        };

        this.englishNames = React.createRef();
        this.editDetailsRow1 = React.createRef();
        this.editDetailsRow2 = React.createRef();
        this.livingAddressRef = React.createRef();
        this.mailAddressRef = React.createRef();
        this.personalMailAddressRef = React.createRef();
    }

    static propTypes = {
        ageCategory: PropTypes.string.isRequired,
        isImpersonation: PropTypes.bool.isRequired,
        memberData: PropTypes.object,
        onOpenInsuranceHistory: PropTypes.func,
        phonePrefixes: PropTypes.arrayOf(object),
        setRouteLeavingGuard: PropTypes.func,
        onSubmitAdult: PropTypes.func,
        onSubmitNotAdult: PropTypes.func,
        loading: PropTypes.bool,
        filterCities: PropTypes.func,
        filterStreets: PropTypes.func,
        addressesAutoComplete: PropTypes.object
    };

    homePhoneRef = null;
    cellPhoneRef = null;
    emailRef = null;
    faxRef = null;

    validateLivingAddress = null;
    validateMailAddress = null;
    validatePersonalMailAddress = null;

    componentDidMount() {
        const { memberData, phonePrefixes } = this.props;

        if (memberData && phonePrefixes) {
            this.initState();
        }
    }

    componentDidUpdate(prevProps) {
        const { memberData, phonePrefixes } = this.props;

        if ((!prevProps.memberData || !prevProps.phonePrefixes) && memberData && phonePrefixes) {
            this.initState();
        }
    }

    setupRouteLeavingGuard() {
        const { setRouteLeavingGuard } = this.props;

        if (!this.state.changesWereMade) {
            this.setState({ changesWereMade: true });
            setRouteLeavingGuard && setRouteLeavingGuard();
        }
    }

    getPhonePrefixes(phoneType) {
        const { phonePrefixes } = this.props;

        if (!phonePrefixes || phonePrefixes.length === 0) {
            return [];
        }

        let filteredPhonePrefixes = null;

        switch (phoneType) {
            case PHONE_TYPES.CELL.type:
                filteredPhonePrefixes = phonePrefixes
                    .filter(prefix => prefix.is_mobile_code)
                    .sort(function(a, b) {
                        return parseInt(a.id) - parseInt(b.id);
                    });
                break;
            case PHONE_TYPES.FAX.type:
            // filteredPhonePrefixes = phonePrefixes.filter(prefix => !prefix.is_mobile_code);
            // break;
            case PHONE_TYPES.HOME.type:
            default:
                filteredPhonePrefixes = phonePrefixes.sort(function(a, b) {
                    return parseInt(a.id) - parseInt(b.id);
                });
        }

        return filteredPhonePrefixes;
    }

    initState() {
        const { memberData } = this.props;

        let state = {};
        const remarks = memberData.current_customer_info.remarks;
        state.hasVisionLimitations = hasRemark(remarks, PERSONAL_DETAILS_REMARK_CODES.VISION_LIMITATIONS);
        state.hasHearingLimitations = hasRemark(remarks, PERSONAL_DETAILS_REMARK_CODES.HEARING_LIMITATIONS);

        if (this.isAdultPage()) {
            const phones = memberData.current_customer_info.phones;
            const homePhone = getPhoneByType(phones, PHONE_TYPES.HOME.type);
            const cellPhone = getPhoneByType(phones, PHONE_TYPES.CELL.type);
            const fax = getPhoneByType(phones, PHONE_TYPES.FAX.type);
            const addresses = memberData.current_customer_info.addresses;
            const livingAddress = getAddress(addresses, ADDRESS_SECTION_ADDRESS_TYPES.LIVING.status, ADDRESS_SECTION_ADDRESS_TYPES.LIVING.type);
            let mailAddress = getAddress(addresses, ADDRESS_SECTION_ADDRESS_TYPES.MAIL.status, ADDRESS_SECTION_ADDRESS_TYPES.MAIL.type);
            mailAddress = !compareAddresses(livingAddress, mailAddress) ? mailAddress : null;
            let personalMailAddress = getAddress(
                addresses,
                ADDRESS_SECTION_ADDRESS_TYPES.PERSONAL_MAIL.status,
                ADDRESS_SECTION_ADDRESS_TYPES.PERSONAL_MAIL.type
            );
            personalMailAddress = !compareAddresses(livingAddress, personalMailAddress) ? personalMailAddress : null;

            /* Update state */
            state.homePhoneNumber = homePhone ? homePhone.phone_no : '';
            state.homePhonePrefixIndex =
                homePhone && getPhonePrefixIndex(this.getPhonePrefixes(PHONE_TYPES.HOME.type), homePhone.fax_special_prefix + homePhone.phone_prefix);
            state.cellPhoneNumber = cellPhone ? cellPhone.phone_no : '';
            state.cellPhonePrefixIndex =
                cellPhone && getPhonePrefixIndex(this.getPhonePrefixes(PHONE_TYPES.CELL.type), cellPhone.fax_special_prefix + cellPhone.phone_prefix);
            state.faxPhoneNumber = fax ? fax.phone_no : '';
            state.faxPhonePrefixIndex = fax && getPhonePrefixIndex(this.getPhonePrefixes(PHONE_TYPES.FAX.type), '0' + fax.phone_prefix); ////TODO: fax.fax_special_prefix??????
            state.faxSpecialPrefix = fax && fax.fax_special_prefix;
            state.emailAddress = memberData.current_customer_info.email;
            state.activeLanguageId = memberData.current_customer_info.language_code;
            state.livingAddress = livingAddress;
            state.mailAddress = mailAddress;
            state.addMailAddress = mailAddress ? true : false;
            state.mailAddressInPoBox = isPoBoxAddress(mailAddress);
            state.personalMailAddress = personalMailAddress;
            state.addPersonalMailAddress = personalMailAddress ? true : false;
            state.personalMailAddressIsPoBox = isPoBoxAddress(personalMailAddress);
        }

        state.firstNameEnglish = memberData.current_customer_info.f_name_english;
        state.lastNameEnglish = memberData.current_customer_info.l_name_english;

        state.stateInitialized = true;

        this.setState(state);
    }

    getInfoLine = (text, toolTipText, tooltipStateName) => {
        const showTooltip = this.state[tooltipStateName];
        const elementId = `toolTip${tooltipStateName}`;

        return (
            <div>
                <div className={style.toolTipContainer}>
                    <div className={style.iconWrapper} id={elementId} onClick={() => this.setState({ [tooltipStateName]: !showTooltip })}>
                        <Icon name={HELP_ICON} iconclassname={style.tooltipIcon} />
                    </div>
                    <span className={style.text}>{text}</span>
                </div>
                <Tooltip placement="top" isOpen={showTooltip} autohide={false} target={elementId} tooltipTxt={toolTipText} />
            </div>
        );
    };

    onAddressFieldsChange = (addressObjectName, properties) => {
        this.setupRouteLeavingGuard();
        if (properties) {
            let address = this.state[addressObjectName] || {};

            Object.keys(properties).forEach(key => {
                address[key] = properties[key];
            });

            this.setState({ [addressObjectName]: address });
        }
    };

    onAddressTypeChange = (addressIsPoBoxPropName, isPoBox) => {
        this.setupRouteLeavingGuard();
        this.setState({ [addressIsPoBoxPropName]: isPoBox });
    };

    toggleHasAddress = hasAddressPropName => {
        this.setupRouteLeavingGuard();
        const currentState = this.state[hasAddressPropName];

        if (hasAddressPropName === 'addMailAddress') {
            mLib.logs.insertCentralizedLog(
                currentState ? LOG_IDS.REMOVE_ADDRESS_FOR_MAIL_CLICK : LOG_IDS.ADD_ADDRESS_FOR_MAIL_CLICK,
                UPDATE_DETAILS_PAGE_NAME,
                CLICK_LOG_ID
            );
        } else if (hasAddressPropName === 'addPersonalMailAddress') {
            mLib.logs.insertCentralizedLog(
                currentState ? LOG_IDS.REMOVE_PERSONAL_MAIL_ADDRESS : LOG_IDS.ADD_PERSONAL_MAIL_ADDRESS,
                UPDATE_DETAILS_PAGE_NAME,
                CLICK_LOG_ID
            );
        }

        this.setState({ [hasAddressPropName]: !currentState });
    };

    onHomePhoneBlur(e, isInvalid) {
        this.setupRouteLeavingGuard();
        const { homePhoneNumber, cellPhoneNumber, cellPhoneValid } = this.state;
        this.setState({ homePhoneValid: !isInvalid ? true : false });

        if (!e.stopBubblingValidation && ((isInvalid && !homePhoneNumber) || (!cellPhoneValid && !cellPhoneNumber))) {
            this.cellPhoneRef.onBlur({ target: { value: cellPhoneNumber }, stopBubblingValidation: true });
        }
    }

    onCellPhoneBlur(e, isInvalid) {
        this.setupRouteLeavingGuard();
        const { homePhoneNumber, cellPhoneNumber, homePhoneValid } = this.state;
        this.setState({ cellPhoneValid: !isInvalid ? true : false });

        if (!e.stopBubblingValidation && ((isInvalid && !cellPhoneNumber) || (!homePhoneValid && !homePhoneNumber))) {
            this.homePhoneRef.onBlur({ target: { value: homePhoneNumber }, stopBubblingValidation: true });
        }
    }

    onFaxPhoneBlur(e, isInvalid) {
        this.setupRouteLeavingGuard();
        this.setValidationState('faxValid', isInvalid);
    }

    setValidationState(validationStateParamName, isInvalid) {
        this.setState({ [validationStateParamName]: !isInvalid ? true : false });
    }

    togglePhoneValidation(phonesAreEmpty) {
        const { cellPhoneNumber, homePhoneNumber } = this.state;

        this.setState({
            bothPhonesWereEmpty: phonesAreEmpty
        });

        if (phonesAreEmpty) {
            this.cellPhoneRef && this.cellPhoneRef.onBlur({ target: { value: cellPhoneNumber } });
            this.homePhoneRef && this.homePhoneRef.onBlur({ target: { value: homePhoneNumber } });
        }
    }

    onLanguageSelect(item) {
        this.setupRouteLeavingGuard();
        const language = LANGUAGES[item];
        this.setState({ activeLanguageId: language.code });
    }

    getLanguageIndexByCode(code) {
        return LANGUAGES.findIndex(language => language.code === code);
    }

    validateEnglishName(key, isValid) {
        this.setState({ [key]: isValid });
        return isValid;
    }

    isAdultPage() {
        const { ageCategory, isImpersonation } = this.props;
        return ageCategory === AGE_CATEGORY.ADULT && !isImpersonation;
    }

    scrollToRef(ref) {
        ref.current.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'center'
        });
    }

    onSubmit() {
        const { onSubmitAdult, onSubmitNotAdult } = this.props;
        const {
            homePhoneValid,
            cellPhoneValid,
            faxValid,
            emailValid,
            firstNameEnglish,
            lastNameEnglish,
            addMailAddress,
            addPersonalMailAddress,
            homePhoneNumber,
            homePhonePrefixIndex,
            cellPhoneNumber,
            cellPhonePrefixIndex,
            faxPhoneNumber,
            faxPhonePrefixIndex,
            faxSpecialPrefix,
            emailAddress,
            activeLanguageId,
            hasVisionLimitations,
            hasHearingLimitations,
            livingAddress,
            mailAddress,
            personalMailAddress
        } = this.state;

        mLib.logs.insertCentralizedLog(LOG_IDS.SAVE_EDIT_PERSONAL_INFO_CHANGES, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);

        // Validate englishNames
        const eglishNames = { firstNameEnglish: firstNameEnglish, lastNameEnglish: lastNameEnglish };
        let nameEnglishValid = true;
        if (firstNameEnglish == '' && lastNameEnglish != '') {
            nameEnglishValid = false;
            this.validateEnglishName('firstNameEnglishValid', false);
            this.scrollToRef(this.englishNames);
        }
        if (firstNameEnglish != '' && lastNameEnglish == '') {
            nameEnglishValid = false;
            this.validateEnglishName('lastNameEnglishValid', false);
            this.scrollToRef(this.englishNames);
        }

        if (!this.isAdultPage() && nameEnglishValid) {
            onSubmitNotAdult && onSubmitNotAdult(eglishNames, hasVisionLimitations, hasHearingLimitations);
        } else {
            if (!homePhoneValid) this.scrollToRef(this.editDetailsRow1);
            if (!cellPhoneValid) this.scrollToRef(this.editDetailsRow1);
            if (!faxValid) this.scrollToRef(this.editDetailsRow2);
            if (!emailValid) this.scrollToRef(this.editDetailsRow2);

            // Validate living address - which is required
            const livingAddressValid = this.validateLivingAddress && this.validateLivingAddress();
            if (!livingAddressValid) this.scrollToRef(this.livingAddressRef);

            // Validate mail address if selected
            const mailAddressValid = !addMailAddress || (this.validateMailAddress && this.validateMailAddress());
            if (!mailAddressValid) this.scrollToRef(this.mailAddressRef);

            // Validate personal mail address if selected
            const personalMailAddressValid = !addPersonalMailAddress || (this.validatePersonalMailAddress && this.validatePersonalMailAddress());
            if (!personalMailAddressValid) this.scrollToRef(this.personalMailAddressRef);

            // If all is valid
            if (
                nameEnglishValid &&
                homePhoneValid &&
                cellPhoneValid &&
                faxValid &&
                emailValid &&
                livingAddressValid &&
                mailAddressValid &&
                personalMailAddressValid
            ) {
                // Init phone objects
                let phones = [];

                if (homePhoneNumber) {
                    phones.push(
                        createPhoneObject(
                            PHONE_TYPES.HOME.type,
                            this.getPhonePrefixes(PHONE_TYPES.HOME.type)[homePhonePrefixIndex].name,
                            homePhoneNumber
                        )
                    );
                }
                if (cellPhoneNumber) {
                    phones.push(
                        createPhoneObject(
                            PHONE_TYPES.CELL.type,
                            this.getPhonePrefixes(PHONE_TYPES.CELL.type)[cellPhonePrefixIndex].name,
                            cellPhoneNumber
                        )
                    );
                }
                if (faxPhoneNumber) {
                    //TODO:
                    phones.push(
                        createPhoneObject(
                            PHONE_TYPES.FAX.type,
                            this.getPhonePrefixes(PHONE_TYPES.FAX.type)[faxPhonePrefixIndex].name,
                            faxPhoneNumber,
                            faxSpecialPrefix
                        )
                    );
                }

                // Init address objects
                let addresses = [];
                let livingMailAddressObj = createAddressObject(
                    livingAddress,
                    ADDRESS_SECTION_ADDRESS_TYPES.LIVING.status,
                    ADDRESS_SECTION_ADDRESS_TYPES.LIVING.type
                );
                let mailAddressObj = addMailAddress
                    ? createAddressObject(mailAddress, ADDRESS_SECTION_ADDRESS_TYPES.MAIL.status, ADDRESS_SECTION_ADDRESS_TYPES.MAIL.type)
                    : null;
                let personalMailAddressObj = addPersonalMailAddress
                    ? createAddressObject(
                          personalMailAddress,
                          ADDRESS_SECTION_ADDRESS_TYPES.PERSONAL_MAIL.status,
                          ADDRESS_SECTION_ADDRESS_TYPES.PERSONAL_MAIL.type
                      )
                    : null;

                addresses.push(livingMailAddressObj);
                // If exists and different from living mail
                if (mailAddressObj && !compareAddresses(livingMailAddressObj, mailAddressObj)) {
                    addresses.push(mailAddressObj);
                }
                // If exists and different from other mails
                if (
                    personalMailAddressObj &&
                    !compareAddresses(livingMailAddressObj, personalMailAddressObj) &&
                    !compareAddresses(mailAddressObj, personalMailAddressObj)
                ) {
                    addresses.push(personalMailAddressObj);
                }

                onSubmitAdult &&
                    onSubmitAdult(eglishNames, phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses);
            }
        }
    }

    get addressSectionConstants() {
        return {
            regularAddressTypeLabel: ADDRESS_SECTION_REGULAR_ADDRESS_TYPE_LABEL,
            poboxAddressTypeLabel: ADDRESS_SECTION_POBOX_ADDRESS_TYPE_LABEL,
            cityLabel: ADDRESS_SECTION_CITY_TEXTBOX_LABEL,
            streetLabel: ADDRESS_SECTION_STREET_TEXTBOX_LABEL,
            houseLabel: ADDRESS_SECTION_HOUSE_TEXTBOX_LABEL,
            apartmentLabel: ADDRESS_SECTION_APARTMENT_TEXTBOX_LABEL,
            entranceLabel: ADDRESS_SECTION_ENTRANCE_TEXTBOX_LABEL,
            poBoxLabel: ADDRESS_SECTION_POBOX_TEXTBOX_LABEL,
            addAddressLabel: ADDRESS_SECTION_ADD_ADDRESS_LABEL,
            removeAddressLabel: ADDRESS_SECTION_REMOVE_ADDRESS_LABEL,
            emptyCityValidation: ADDRESS_SECTION_EMPTY_CITY_VALIDATION,
            unselectedCityValidation: ADDRESS_SECTION_INVALID_CITY,
            unselectedStreetValidation: ADDRESS_SECTION_INVALID_STREET,
            emptyStreetValidation: ADDRESS_SECTION_EMPTY_STREET_VALIDATION,
            houseValidation: ADDRESS_SECTION_HOUSE_VALIDATION,
            apartmentValidation: ADDRESS_SECTION_APARTMENT_VALIDATION,
            entranceValidation: ADDRESS_SECTION_ENTRANCE_VALIDATION,
            poValidation: ADDRESS_SECTION_PO_VALIDATION,
            noResultsText: ADDRESS_SECTION_NO_RESULT_TEST
        };
    }

    onEmailChange(newVal) {
        this.setupRouteLeavingGuard();
        if (!newVal || (newVal && newVal.length <= 30)) {
            this.setState({
                emailAddress: newVal
            });
        }
    }

    onCheckChangeLimitations(limitation, value) {
        this.setupRouteLeavingGuard();

        this.setState({
            [limitation]: value
        });
    }

    onNameEnglishChange(key, newVal) {
        this.setupRouteLeavingGuard();
        if (!newVal || (newVal && newVal.length <= 15)) {
            this.setState({
                [key]: newVal
            });
        }
    }

    // eslint-disable-next-line max-lines-per-function
    render() {
        const {
            ageCategory,
            isImpersonation,
            memberData,
            onOpenInsuranceHistory,
            loading,
            filterCities,
            filterStreets,
            addressesAutoComplete,
            IsRender,
            isRenderFunction
        } = this.props;
        const {
            firstNameEnglish,
            lastNameEnglish,
            firstNameEnglishValid,
            lastNameEnglishValid,
            homePhoneNumber,
            homePhonePrefixIndex,
            cellPhoneNumber,
            cellPhonePrefixIndex,
            faxPhoneNumber,
            faxPhonePrefixIndex,
            emailAddress,
            activeLanguageId,
            hasVisionLimitations,
            hasHearingLimitations,
            stateInitialized,
            livingAddress,
            mailAddress,
            addMailAddress,
            mailAddressInPoBox,
            personalMailAddress,
            addPersonalMailAddress,
            personalMailAddressIsPoBox,
            homePhoneValid,
            cellPhoneValid,
            bothPhonesWereEmpty
        } = this.state;
        const bothPhonesEmpty = homePhoneValid && cellPhoneValid && !homePhoneNumber && !cellPhoneNumber;
        const phoneRequired = stateInitialized && !homePhoneNumber && !cellPhoneNumber;
        // const urlForDisable = 'subitem_directorship/editinformation/profile/';
        // Phones were previously empty. Needed to deal with possible infinite loop, so the code will be executed only once
        if (bothPhonesEmpty !== bothPhonesWereEmpty) {
            this.togglePhoneValidation(bothPhonesEmpty);
        }
        const showFullPage = this.isAdultPage();
        const showAddress = showFullPage && stateInitialized;
        const showAdolescentPage = ageCategory === AGE_CATEGORY.ADOLESCENT && !isImpersonation;
        const homePhonePrefixes = this.getPhonePrefixes(PHONE_TYPES.HOME.type);
        const cellphonePrefixes = this.getPhonePrefixes(PHONE_TYPES.CELL.type);
        const faxPrefixes = this.getPhonePrefixes(PHONE_TYPES.FAX.type);
        const isDisabledFields = !isRenderFunction('hideToAll');

        return (
            <Fragment>
                <DetailsHeader
                    memberData={memberData}
                    onOpenInsuranceHistory={onOpenInsuranceHistory}
                    constants={{
                        personalDetailsAge: PERSONAL_DETAILS_AGE,
                        personalDetailsInsuranceGroup: PERSONAL_DETAILS_INSURANCE_GROUP,
                        personalDetailsBranch: PERSONAL_DETAILS_BRANCH,
                        personalDetailsInsuranceAgeAgreement: PERSONAL_DETAILS_INSURANCE_AGE_AGREEMENT,
                        minAgeBoyGirlAvatar: MIN_AGE_BOYGIRL_AVATAR,
                        minAgeGrownupAvatar: MIN_AGE_GROWN_UP_AVATAR
                    }}
                />

                <Section title={ENGLISH_NAMES_TITLE}>
                    <div className={style.inputRow} ref={this.englishNames}>
                        <Input
                            inputgroupclass={style.nameGroupInput}
                            onFocus={() => this.setState({ firstNameEnglishValid: true })}
                            onChange={e => this.onNameEnglishChange('firstNameEnglish', e.target.value)}
                            error={!firstNameEnglishValid ? FIRST_NAME_ENGLISH_ERROR : null} //umbraco
                            value={firstNameEnglish}
                            type={'text'}
                            maxlength={15}
                            label={FIRST_NAME_ENGLISH}
                            englishOnly={true}
                            disablePaste={true}
                            hook={'firstName'}
                        />
                        <Input
                            inputgroupclass={style.nameGroupInput}
                            onFocus={() => this.setState({ lastNameEnglishValid: true })}
                            onChange={e => this.onNameEnglishChange('lastNameEnglish', e.target.value)}
                            error={!lastNameEnglishValid ? LAST_NAME_ENGLISH_ERROR : null}
                            value={lastNameEnglish}
                            type={'text'}
                            label={LAST_NAME_ENGLISH}
                            englishOnly={true}
                            disablePaste={true}
                            hook={'lastName'}
                        />
                    </div>
                </Section>

                {showFullPage && (
                    <Section title={PHONES_EMAILS_TITLE} remarks={PHONES_EMAILS_DESCRIPTION}>
                        <div className={style.inputRow} ref={this.editDetailsRow1}>
                            <InputPhone
                                isRequired={phoneRequired}
                                ref={ref => (this.homePhoneRef = ref)}
                                onBlur={(e, m) => this.onHomePhoneBlur(e, m)}
                                className={style.inputContainer}
                                label={PHONE_TYPES.HOME.name}
                                defaultError={PHONES_EMAILS_PHONE_VALIDATION}
                                emptyError={PHONES_EMAILS_PHONE_REQUIRED_VALIDATION}
                                onchange={e => this.setState({ homePhoneNumber: e })}
                                onselect={e => this.setState({ homePhonePrefixIndex: getPhonePrefixIndex(homePhonePrefixes, e) })}
                                phonevalue={homePhoneNumber}
                                selectedindex={homePhonePrefixIndex}
                                prefixlist={homePhonePrefixes}
                                disabled={isDisabledFields}
                                hook="home"
                            />
                            <InputPhone
                                isRequired={phoneRequired}
                                ref={ref => (this.cellPhoneRef = ref)}
                                defaultError={PHONES_EMAILS_PHONE_VALIDATION}
                                emptyError={' '} // Empty space char so validation would be indicated, if message is empty => no validation indication
                                onBlur={(e, m) => this.onCellPhoneBlur(e, m)}
                                className={style.inputContainer}
                                label={PHONE_TYPES.CELL.name}
                                onchange={e => this.setState({ cellPhoneNumber: e })}
                                onselect={e => this.setState({ cellPhonePrefixIndex: getPhonePrefixIndex(cellphonePrefixes, e) })}
                                phonevalue={cellPhoneNumber}
                                selectedindex={cellPhonePrefixIndex}
                                prefixlist={cellphonePrefixes}
                                disabled={isDisabledFields}
                                hook="cellPhone"
                            />
                        </div>
                        <div className={style.inputRow} ref={this.editDetailsRow2}>
                            <InputPhone
                                ref={ref => (this.faxRef = ref)}
                                onBlur={(e, m) => this.onFaxPhoneBlur(e, m)}
                                className={style.inputContainer}
                                defaultError={PHONES_EMAILS_PHONE_VALIDATION}
                                label={PHONE_TYPES.FAX.name}
                                onchange={e => this.setState({ faxPhoneNumber: e })}
                                onselect={e => this.setState({ faxPhonePrefixIndex: getPhonePrefixIndex(faxPrefixes, e) })}
                                phonevalue={faxPhoneNumber}
                                selectedindex={faxPhonePrefixIndex}
                                disabled={isDisabledFields}
                                prefixlist={faxPrefixes}
                                hook="fax"
                            />
                            <div className={style.inputContainer}>
                                <InputEmail
                                    ref={ref => (this.emailRef = ref)}
                                    onBlur={(e, m) => this.setValidationState('emailValid', m)}
                                    isRequired
                                    disabled={isDisabledFields}
                                    className={style.email}
                                    label={PHONES_EMAILS_EMAIL_NAME}
                                    onChange={e => this.onEmailChange(e.target.value)}
                                    emptyError={PHONES_EMAILS_EMAIL_VALIDATION}
                                    defaultError={PHONES_EMAILS_EMAIL_VALIDATION}
                                    value={emailAddress}
                                    hook="email"
                                />
                            </div>
                        </div>
                    </Section>
                )}
                <Section title={PERSONAL_DETAILS_LANGUAGE_TITLE} subTitle={PERSONAL_DETAILS_LANGUAGE_DESCRIPTION}>
                    {showFullPage &&
                        this.getInfoLine(
                            PERSONAL_DETAILS_LANGUAGE_TOOLTIP_NAME,
                            PERSONAL_DETAILS_LANGUAGE_TOOLTIP_DESCRIPTION,
                            'showLanguageTooltip'
                        )}
                    {showFullPage && (
                        <div className={style.inputRow}>
                            <div className={cx(style.inputContainer, style.languagesContainer)}>
                                <InputDrop
                                    disabled={isDisabledFields}
                                    label={PERSONAL_DETAILS_CHOOSE_LANGUAGE}
                                    filterSelected={this.getLanguageIndexByCode(activeLanguageId)}
                                    onSelectItemFilter={(e, item) => this.onLanguageSelect(item)}>
                                    {LANGUAGES.map(language => {
                                        return <div>{language.name}</div>;
                                    })}
                                </InputDrop>
                            </div>
                        </div>
                    )}
                    <div className={showFullPage ? 'mt-7' : 'mt-5'}>
                        {this.getInfoLine(
                            PERSONAL_DETAILS_ACCESSIBILITY_TOOLTIP_NAME,
                            PERSONAL_DETAILS_ACCESSIBILITY_TOOLTIP_DESCRIPTION,
                            'showAccessibilityTooltip'
                        )}
                        {stateInitialized && (
                            <div className={style.inputRow}>
                                <div className={cx(style.inputContainer, style.checkBox)}>
                                    <Checkbox
                                        disabled={isDisabledFields}
                                        hook="accessibilityVision"
                                        labelClassName={style.checkboxLabel}
                                        onCheckChangeCallBack={() => this.onCheckChangeLimitations('hasVisionLimitations', !hasVisionLimitations)}
                                        ischecked={hasVisionLimitations}
                                        label={PERSONAL_DETAILS_ACCESSIBILITY_VISION}
                                    />
                                </div>
                                <div className={cx(style.inputContainer, style.checkBox)}>
                                    <Checkbox
                                        disabled={isDisabledFields}
                                        hook="accessibilityHearing"
                                        labelClassName={style.checkboxLabel}
                                        onCheckChangeCallBack={() => this.onCheckChangeLimitations('hasHearingLimitations', !hasHearingLimitations)}
                                        ischecked={hasHearingLimitations}
                                        label={PERSONAL_DETAILS_ACCESSIBILITY_HEARING}
                                    />
                                </div>
                            </div>
                        )}
                    </div>
                </Section>
                {showAddress && (
                    <div ref={this.livingAddressRef}>
                        <AddressSection
                            filteredCitiesList={addressesAutoComplete[LIVING_ADDRESS_PROP_NAME].cities}
                            filteredStreetsList={addressesAutoComplete[LIVING_ADDRESS_PROP_NAME].streets}
                            setFilteredCitiesList={value => filterCities(LIVING_ADDRESS_PROP_NAME, value)}
                            setFilteredStreetsList={(cityId, value) => filterStreets(LIVING_ADDRESS_PROP_NAME, cityId, value)}
                            setValidationFunction={validationFunction => (this.validateLivingAddress = validationFunction)}
                            required
                            disabled={isDisabledFields}
                            IsRender={IsRender}
                            isPoAddress={false}
                            sectionTitle={ADDRESS_SECTION_LIVING_ADDRESS_NAME}
                            sectionSubTitle={ADDRESS_SECTION_LIVING_ADDRESS_DESCRIPTION}
                            isOpen={true}
                            constants={this.addressSectionConstants}
                            onFieldsChange={properties => this.onAddressFieldsChange('livingAddress', properties)}
                            dataHook="firstSection__"
                            {...(livingAddress || {})}
                        />
                    </div>
                )}
                {showAddress && (
                    <div ref={this.mailAddressRef}>
                        <AddressSection
                            ref={ref => (this.mailAddressRef = ref)}
                            filteredCitiesList={addressesAutoComplete[MAIL_ADDRESS_PROP_NAME].cities}
                            filteredStreetsList={addressesAutoComplete[MAIL_ADDRESS_PROP_NAME].streets}
                            setFilteredCitiesList={value => filterCities(MAIL_ADDRESS_PROP_NAME, value)}
                            setFilteredStreetsList={(cityId, value) => filterStreets(MAIL_ADDRESS_PROP_NAME, cityId, value)}
                            setValidationFunction={validationFunction => (this.validateMailAddress = validationFunction)}
                            canSwitchAddressType={true}
                            disabled={isDisabledFields}
                            IsRender={IsRender}
                            isPoAddress={mailAddressInPoBox}
                            sectionTitle={ADDRESS_SECTION_MAIL_ADDRESS_NAME}
                            sectionSubTitle={ADDRESS_SECTION_MAIL_ADDRESS_DESCRIPTION}
                            isOpen={addMailAddress}
                            onFieldsChange={properties => this.onAddressFieldsChange('mailAddress', properties)}
                            onIsPoAddressChange={isPo => this.onAddressTypeChange('mailAddressInPoBox', isPo)}
                            toggleIsOpen={() => this.toggleHasAddress('addMailAddress')}
                            constants={this.addressSectionConstants}
                            dataHook="secondSection__"
                            {...(mailAddress || {})}
                        />
                    </div>
                )}
                {showAddress && (
                    <div ref={this.personalMailAddressRef}>
                        <AddressSection
                            ref={ref => (this.personalMailAddressRef = ref)}
                            filteredCitiesList={addressesAutoComplete[PERSONAL_MAIL_ADDRESS_PROP_NAME].cities}
                            filteredStreetsList={addressesAutoComplete[PERSONAL_MAIL_ADDRESS_PROP_NAME].streets}
                            setFilteredCitiesList={value => filterCities(PERSONAL_MAIL_ADDRESS_PROP_NAME, value)}
                            setFilteredStreetsList={(cityId, value) => filterStreets(PERSONAL_MAIL_ADDRESS_PROP_NAME, cityId, value)}
                            setValidationFunction={validationFunction => (this.validatePersonalMailAddress = validationFunction)}
                            canSwitchAddressType={true}
                            disabled={isDisabledFields}
                            IsRender={IsRender}
                            isPoAddress={personalMailAddressIsPoBox}
                            sectionTitle={ADDRESS_SECTION_PERSONAL_MAIL_ADDRESS_NAME}
                            sectionSubTitle={ADDRESS_SECTION_PERSONAL_MAIL_ADDRESS_DESCRIPTION}
                            isOpen={addPersonalMailAddress}
                            onFieldsChange={properties => this.onAddressFieldsChange('personalMailAddress', properties)}
                            onIsPoAddressChange={isPo => this.onAddressTypeChange('personalMailAddressIsPoBox', isPo)}
                            toggleIsOpen={() => this.toggleHasAddress('addPersonalMailAddress')}
                            constants={this.addressSectionConstants}
                            dataHook="thirdSection__"
                            {...(personalMailAddress || {})}
                        />
                    </div>
                )}
                <div className={cx(style.saveChangesContainer, !showFullPage ? style.hasRemark : '')}>
                    {!showFullPage && (
                        <div className={style.customerRemark}>
                            <Icon name={ATTENTION_ICON} iconclassname={style.customerRemarkIcon} />
                            <span className={style.remarkText}>
                                {showAdolescentPage ? PERSONAL_DETAILS_EDIT_ADOLESCENT_REMARK : PERSONAL_DETAILS_EDIT_MINOR_REMARK}
                            </span>
                        </div>
                    )}
                    <IsRender uniqueName={'hideToAll'}>
                        <Button hook="submit" className={style.btn} size={'md'} maincta color="primary" onClick={this.onSubmit}>
                            {loading && <IconLoader size="sm" className={style.iconLoader} />}
                            {PERSONAL_DETAILS_SUBMIT_BTN}
                        </Button>
                    </IsRender>
                </div>
            </Fragment>
        );
    }
}

export default EditDetails;
