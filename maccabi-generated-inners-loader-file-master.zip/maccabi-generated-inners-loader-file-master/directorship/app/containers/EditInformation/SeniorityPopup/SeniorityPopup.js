import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import { SpecialModal, H3, List } from '@maccabi/m-ui';
import {
    SENIORITY_POPUP_TITLE,
    SENIORITY_POPUP_DESCRIPTION_LINE1,
    SENIORITY_POPUP_DESCRIPTION_LINE2,
    SENIORITY_POPUP_INSURANCE_TABLE_TITLE,
    LOG_IDS,
    UPDATE_DETAILS_PAGE_NAME,
    CLICK_LOG_ID,
    OPEN_LOG_ID,
    SENIORITY_POPUP_DATES_TABLE_TITLE,
    SENIORITY_POPUP_REMARKS,
    SENIORITY_POPUP_REMARKS_TITLE,
    SENIORITY_POPUP_PRINT_BUTTON,
    SENIORITY_POPUP_SAVE_BUTTON,
    SENIORITY_POPUP_PRINT_BUTTON_MOBILE,
    SENIORITY_POPUP_NO_COMPLIMENTARY_INSURANCE
} from '../constants';
import { formatDate } from '../utils';
import style from './SeniorityPopup.scss';

@autobind
class SeniorityPopup extends Component {
    static propTypes = {
        onPrint: PropTypes.func.isRequired,
        onFileSave: PropTypes.func.isRequired,
        close: PropTypes.func.isRequired,
        isOpen: PropTypes.bool.isRequired,
        insuranceGroups: PropTypes.array.isRequired,
        complementaryInsuranceExists: PropTypes.bool
    };

    componentDidMount() {
        mLib.logs.insertCentralizedLog(LOG_IDS.SENIORITY_POPUP_SHOW, UPDATE_DETAILS_PAGE_NAME, OPEN_LOG_ID);
    }

    onClose() {
        const { close } = this.props;
        close();
    }

    onPrimaryButtonClick() {
        const { onPrint } = this.props;
        mLib.logs.insertCentralizedLog(LOG_IDS.PRINT_BTN_CLICK, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);
        onPrint && onPrint();
    }

    onSecondaryButtonClick() {
        const { onFileSave } = this.props;
        mLib.logs.insertCentralizedLog(LOG_IDS.SAVE_FILE_BTN_CLICK, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);
        onFileSave && onFileSave();
    }

    getBody() {
        const { insuranceGroups, complementaryInsuranceExists } = this.props;

        return (
            <div className={style.contentContainer}>
                <div className={style.subTitle}>
                    <span>{SENIORITY_POPUP_DESCRIPTION_LINE1}</span>
                    <span>{SENIORITY_POPUP_DESCRIPTION_LINE2}</span>
                    {!complementaryInsuranceExists && (
                        <span className={style.noComplimentaryInsurance}>{SENIORITY_POPUP_NO_COMPLIMENTARY_INSURANCE}</span>
                    )}
                </div>
                <div className={style.table}>
                    <div className={style.tableHeader}>
                        <span className={style.tableTitle}>{SENIORITY_POPUP_INSURANCE_TABLE_TITLE}</span>
                        <span className={style.tableTitle}>{SENIORITY_POPUP_DATES_TABLE_TITLE}</span>
                    </div>
                    {insuranceGroups.map(group => (
                        <div className={style.row}>
                            <span className={style.tableItem}>{group.name}</span>
                            <span className={style.tableItem}>{group.date}</span>
                        </div>
                    ))}
                </div>
                <div className={cx('d-xl-block mt-7', style.remarksContainer)}>
                    <H3 className="mb-5">{SENIORITY_POPUP_REMARKS_TITLE}</H3>
                    <List className={cx(style.list, 'text-secondary')} list={SENIORITY_POPUP_REMARKS} />
                </div>
            </div>
        );
    }

    render() {
        const { isOpen } = this.props;

        return (
            <SpecialModal
                className={style.modalClass}
                headerClassName={style.modalTitle}
                isOpen={isOpen}
                toggle={this.onClose}
                header={`${SENIORITY_POPUP_TITLE} ${formatDate(new Date(), '.')}`}
                primaryButton={SENIORITY_POPUP_PRINT_BUTTON}
                primaryButtonClick={this.onPrimaryButtonClick}
                secondaryButton={SENIORITY_POPUP_SAVE_BUTTON}
                secondaryButtonClick={this.onSecondaryButtonClick}
                mobileOneButtonText={SENIORITY_POPUP_PRINT_BUTTON_MOBILE}
                mobileOneButtonFunc={this.onPrimaryButtonClick}>
                {this.getBody()}
            </SpecialModal>
        );
    }
}

export default SeniorityPopup;
