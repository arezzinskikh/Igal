import format from 'string-format';
import mLib from '@maccabi/m-lib';
import moment from 'moment';

export const testPassword = (password) => {
    /* Validate that the password is between 6 and 8 characters, and contains only english letters and numbers */
    return password && password.length >= 6 && password.length <= 8 && /^[a-zA-Z0-9]+$/.test(password);
}

export const getPhoneByType = (phones, type) => {
    return phones  && phones.find(phone => phone.phone_type === type);
}

export const getPhonePrefixIndex = (phonePrefixList, prefix) => {
    //return phonePrefixList.findIndex(currentPrefix => currentPrefix.name === prefix);
   return findArrIndex(phonePrefixList, prefix);
};

const findArrIndex = (arr, item) => {
    for (let i = 0; i < arr.length; ++i) {
        if (arr[i].name.trim() === item.trim()) {
            return i;
        }
    }
}

const getRemark = (remarks, remarkCode) => {
    return remarks && remarks.find(remark => remark.remark_code === remarkCode)
}

export const hasRemark = (remarks, remarkCode) => {
    return getRemark(remarks, remarkCode) ? true : false;
}

export const getAddress = (addresses, addressStatus, addressType) => {
    return addresses && addresses.find(adr => adr.address_status === addressStatus && adr.address_type === addressType);
}

export const compareAddresses = (firstAddress, secondAddress) => {
    if (!firstAddress || !secondAddress) {
        return !firstAddress && !secondAddress;
    }

    return `${firstAddress.city_name}${firstAddress.street_name}${firstAddress.house_num}${firstAddress.apartment_num}${firstAddress.entrance}${firstAddress.po_box}` ===
        `${secondAddress.city_name}${secondAddress.street_name}${secondAddress.house_num}${secondAddress.apartment_num}${secondAddress.entrance}${secondAddress.po_box}`;
}

export const isPoBoxAddress = (address) => {
    return address && address.po_box !== 0;
}

export const padNumber = (number, size) => {
    const sign = Math.sign(this) === -1 ? '-' : '';
    return sign + new Array(size).concat([Math.abs(number)]).join('0').slice(-size);
}

export const formatDate = (date, separator, shortYear) => {
    if (!date) {
        return null;
    }

    const day = padNumber(date.getDate(), 2);
    /* Months are 0 based */
    const month = padNumber(date.getMonth() + 1, 2);
    const year = padNumber(shortYear ? (date.getFullYear() % 100) : date.getFullYear(), 2);

    return `${day}${separator}${month}${separator}${year}`;
}

export const complementarySeniorityExists = (insurances, insuranceTypes) => {
    const shabanExists = insurances.find(insurance => insurance.name === insuranceTypes.SHABAN.text_gold || insurance.name === insuranceTypes.SHABAN.text_silver
        || insurance.name === insuranceTypes.SHABAN.text_mine || insurance.name === insuranceTypes.SHABAN.text_gold_and_silver);
    const otherInsuranceTypesTexts = insuranceTypes.OTHERS.map(insurance => insurance.name);
    const maccabiInsuranceFoundOrLtcExists = insurances.find(insurance => otherInsuranceTypesTexts.find(insuranceType => insuranceType === insurance.name));

    return !(!shabanExists && maccabiInsuranceFoundOrLtcExists);
}

export const getInsuranceHistory = (insuranceGroups, insuranceTypes) => {
    if (!insuranceGroups || insuranceGroups.length === 0) {
        return [];
    }

    // Group by insurance code then order by date descending. Select the most recent dates and 
    const groupedResults = insuranceGroups.reduce((rv, x) => {
        (rv[x.ins_type_code] = rv[x.ins_type_code] || []).push(x);
        return rv;
    }, {});

    let filteredResults = [];

    // Take only the most recent
    for (const value of Object.values(groupedResults)) {
        const mostRecentValue = value.sort((a, b) => {
            return getDateFromInsuranceFormat(a.ins_seniority_date) - new getDateFromInsuranceFormat(b.ins_seniority_date);
        }).slice(0, 1)[0];

        filteredResults.push(mostRecentValue);
    }
    let results = [];

    const goldInsurance = filteredResults.find(r => r.ins_type_code === insuranceTypes.SHABAN.code_gold) || null;
    const silverInsurance = filteredResults.find(r => r.ins_type_code === insuranceTypes.SHABAN.code_silver) || null;
    const mineInsurance = filteredResults.find(r => r.ins_type_code === insuranceTypes.SHABAN.code_mine) || null;

    const generateInsObject = (text, insurance) => {
        return {
            name: text,
            date: getDateFromInsuranceFormat(insurance.ins_seniority_date)
        }
    }

    if (mineInsurance) {
        results.push(generateInsObject(insuranceTypes.SHABAN.text_mine, mineInsurance));
    }

    if (goldInsurance || silverInsurance) {
        if (goldInsurance && silverInsurance) {
            const insuranceWithSoonerDate = getDateFromInsuranceFormat(goldInsurance.ins_seniority_date) < getDateFromInsuranceFormat(silverInsurance.ins_seniority_date)
                ? goldInsurance : silverInsurance;
            results.push(generateInsObject(insuranceTypes.SHABAN.text_gold_and_silver, insuranceWithSoonerDate));
        }
        if (goldInsurance) {
            results.push(generateInsObject(insuranceTypes.SHABAN.text_gold, goldInsurance));
        }
        else {
            results.push(generateInsObject(insuranceTypes.SHABAN.text_silver, silverInsurance));
        }
    }

    // Iterate through other insurance types
    for (let i = 0; i < insuranceTypes.OTHERS.length; i++) {
        const insurance = filteredResults.find(r => r.ins_type_code === insuranceTypes.OTHERS[i].code) || null;
        if (insurance) {
            results.push(generateInsObject(insuranceTypes.OTHERS[i].name, insurance));
        }
    }

    // Sort the response and format the date
    return results.sort((a, b) => {
        return b.date - a.date
    }).map(result => {
        result.date = formatDate(result.date, '/', true);
        return result;
    });
}

const getDateFromInsuranceFormat = (date) => {
    const splicedDate = date.split('-');
    return new Date(splicedDate[0], parseInt(splicedDate[1]) - 1, splicedDate[2], 0, 0, 0);
}

const getFullPdfUrl = (url, memberIdCode, memberId, file, isAttachment) => {
    return format(
        url,
        memberIdCode,
        memberId,
        file.membership_status,
        file.hash,
        file.timestamp,
        isAttachment
    );
}

export const downloadPdf = (memberIdCode, memberId, url, file) => {
    const currentUrl = window.location.href;
    const danainfo = mLib.juniper.getDanaInfo(currentUrl);
    const fullUrl = getFullPdfUrl(url, memberIdCode, memberId, file , true) + danainfo;
    mLib.openPdfNewTab.openPdfNewTab(fullUrl, 'מכבי', true);
    document.activeElement.blur();
}

export const printPdf = (memberIdCode, memberId, url, file) => {
    const currentUrl = window.location.href;
    const danainfo = mLib.juniper.getDanaInfo(currentUrl);
    const fullUrl = getFullPdfUrl(url, memberIdCode, memberId, file) + danainfo;
    mLib.openPdfNewTab.openPdfNewTab(fullUrl, 'מכבי');
    document.activeElement.blur();
    //document.getElementById('Button__ModalPrimaryButton').blur();
}

export const createPhoneObject = (type, prefix, number, specialPrefix) => {
    const prefixSplit = [prefix.substr(0, 1), prefix.substr(1)];

    return {
        phone_type: type,
        fax_special_prefix: type === "פ" ? (specialPrefix ? specialPrefix : "153" ) : prefixSplit[0],
        phone_prefix: prefixSplit[1],
        phone_no: number
    }
};

export const createAddressObject = (addrPartial, status, type) => {
    addrPartial.address_status = status;
    addrPartial.address_type = type;

    return addrPartial;
}

export const getAddressesToUpdate = (initialAddresses, newAddresses, endpointPostValues) => {
    const addressesToUpdate = getUpdatedAddresses(initialAddresses, newAddresses);
    const addressesToDelete = getDeletedAddresses(initialAddresses, newAddresses);
    let addresses = [];

    for (let i = 0; i < addressesToUpdate.length; i++) {
        let currentAddress = addressesToUpdate[i];
        currentAddress.action = endpointPostValues.UPDATE;
        currentAddress.city_code = currentAddress.city_code_maccabi;
        addresses.push(getCurrentAddresses(currentAddress));
    }

    for (let i = 0; i < addressesToDelete.length; i++) {
        let currentAddress = addressesToDelete[i];
        currentAddress.action = endpointPostValues.DELETE;
        currentAddress.city_code = currentAddress.city_code_maccabi;
        addresses.push(getCurrentAddresses(currentAddress));
    }

    return addresses;
}

const getUpdatedAddresses = (initialAddresses, newAddresses) => {
    let addresses = [];

    for (let i = 0; i < newAddresses.length; i++) {
        const currentAdr = newAddresses[i];
        const oldAddress = getAddress(initialAddresses, currentAdr.address_status, currentAdr.address_type);

        // If doesn't exist, that means its a new type of address.
        if (!oldAddress || !compareAddresses(currentAdr, oldAddress)) {
            addresses.push(currentAdr);
        }
    }

    return addresses;
}

const getDeletedAddresses = (initialAddresses, newAddresses) => {
    let addresses = [];

    for (let i = 0; i < initialAddresses.length; i++) {
        const initialAddress = initialAddresses[i];
        const newAddress = getAddress(newAddresses, initialAddress.address_status, initialAddress.address_type);

        // If doesn't exist, that means the address was deleted
        if (!newAddress) {
            addresses.push(initialAddress);
        }
    }

    return addresses;
}

const getCurrentAddresses = (currentAddress) => {
    currentAddress.city_code = currentAddress.city_code_maccabi;
        if(isPoBoxAddress(currentAddress)){
            currentAddress.street_code = '';
            currentAddress.street_name = '';
            currentAddress.appartment_no = '';
            currentAddress.enterance = '';
            currentAddress.house_no = '';
        }
        else{
            currentAddress.appartment_no = currentAddress.apartment_num;
            currentAddress.enterance = currentAddress.entrance;
            currentAddress.house_no = currentAddress.house_num;
        }

    return currentAddress;
}

const fillPhonesArray = (phonesFromArray, phonesToArray, action) => {
    for (let i = 0; i < phonesFromArray.length; i++) {
        let currentPhone = phonesFromArray[i];
        currentPhone.action = action;
        phonesToArray.push(currentPhone);
    }
}

export const getPhonesToUpdate = (initialPhones, newPhones, endpointPostValues) => {

    const phonesToUpdate = getUpdatedPhones(initialPhones, newPhones);
    const phonesToDelete = getDeletedPhones(initialPhones, newPhones);
    let phones = [];

    fillPhonesArray(phonesToUpdate, phones, endpointPostValues.UPDATE);
    fillPhonesArray(phonesToDelete, phones, endpointPostValues.DELETE);

    return phones;
}

const getUpdatedPhones = (initialPhones, newPhones) => {
    let phones = [];

    for (let i = 0; i < newPhones.length; i++) {
        const currentPhone = newPhones[i];
        const oldPhone = getPhoneByType(initialPhones, currentPhone.phone_type);

        // If doesn't exist, that means its a new type of phone.
        if (!oldPhone || !comparePhones(currentPhone, oldPhone)) {
            phones.push(currentPhone);
        }
    }

    return phones;
}

const getDeletedPhones = (initialPhones, newPhones) => {
    let phones = [];

    for (let i = 0; i < initialPhones.length; i++) {
        const initialPhone = initialPhones[i];
        const newPhone = getPhoneByType(newPhones, initialPhone.phone_type);

        // If doesn't exist, that means its a new type of phone.
        if (!newPhone) {
            phones.push(initialPhone);
        }
    }

    return phones;
}

const comparePhones = (firstPhone, secondPhone) => {
    if (!firstPhone || !secondPhone) {
        return !firstPhone && !secondPhone;
    }

    return firstPhone.phone_type === secondPhone.phone_type && firstPhone.phone_prefix === secondPhone.phone_prefix &&
        firstPhone.phone_no === secondPhone.phone_no && firstPhone.fax_special_prefix === secondPhone.fax_special_prefix;
}

export const getFieldToUpdate = (oldVal, newVal, fieldName) => {
    return oldVal !== newVal ? {
        field_name: fieldName,
        field_value: newVal
    } : null;
}

export const getRemarksToUpdate = (remarks, remarkCodesThatShouldExist, remarkCodesThatShouldNotExist) => {
    let remarksToUpdate = [];
    const currentDateIso = new Date().toISOString();

    for (let i = 0; i < remarkCodesThatShouldExist.length; i++) {
        const currentRemarkCode = remarkCodesThatShouldExist[i];
        // if should exist but doesn't, request to add remark
        if (!hasRemark(remarks, currentRemarkCode)) {
            remarksToUpdate.push({
                action_type: 1,
                remark_code: currentRemarkCode,
                remark_start_date: currentDateIso
            });
        }
    }

    const date24 = moment().add(-1, 'day');
    for (let i = 0; i < remarkCodesThatShouldNotExist.length; i++) {
        const currentRemarkCode = remarkCodesThatShouldNotExist[i];
        // if should not exist but does, request to remove remark
        if (hasRemark(remarks, currentRemarkCode)) {
            let currentRemark = getRemark(remarks, currentRemarkCode);
            remarksToUpdate.push({
                action_type: moment(currentRemark.remark_start_date).isAfter(date24) ? 3 : 4,
                remark_code: currentRemarkCode,
                remark_start_date: currentDateIso
            });
        }
    }

    return remarksToUpdate;
}