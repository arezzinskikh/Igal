import React, { Component, Fragment } from 'react';
import { Route, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import autobind from 'autobind';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import { H1, MainHeadline, MainHeadlineScrollable, MainBody, Tab, Fade, Icon } from '@maccabi/m-ui';
import { onLoad, onCurrentCustomer, onShowSeniorityClick, onHidePopup, editInformation, editRemarks, hideSuccessMessage, updatePassword, filterStreets, filterCities } from './actions';
import saga from './saga';
import reducer from './reducer';
import { makeSelectEditInformationData } from './selectors';
import {
    UPDATE_DETAILS_PAGE_NAME_RESOURCE, TABS, AGE_CATEGORY, MIN_ADOLESCENT_AGE, MIN_ADULT_AGE, POPUPS, INSURANCE_TYPES, UPDATE_DETAILS_PAGE_NAME,
    SUCCESS_TAG_TEXT, EDIT_INFORMATION_HELP_LINK, EDIT_PASSWORD_PAGE_NAME, BLOCK_SUBMIT_BTN_AFTER_ACTION_IN_MILI_SECONDS, CLICK_LOG_ID,
    LOG_IDS, EDIT_DETAILS_HEADER_HELP_TEXT
} from './constants';
import { getInsuranceHistory, downloadPdf, printPdf, complementarySeniorityExists } from './utils';
import EditPassword from './EditPassword';
import EditDetails from './EditDetails';
import PartialSuccessFailedDetailsPopup from './PartialSuccessFailedDetailsPopup';
import PartialSuccessFailedRemarksPopup from './PartialSuccessFailedRemarksPopup';
import NoSeniorityHistoryPopup from './NoSeniorityHistoryPopup';
import SeniorityPopup from './SeniorityPopup';
import style from './EditInformation.scss';

const HELP_ICON = 'help';
const APPROVED_ICON = 'approved';

const mapDispatchToProps = dispatch => ({
    onLoad: () => dispatch(onLoad()),
    onCurrentCustomer: (currentCustomerInfo, full, onAfterSuccess) => dispatch(onCurrentCustomer(currentCustomerInfo, full, onAfterSuccess)),
    onShowSeniorityClick: (insuranceGroups, currentCustomerInfo) => dispatch(onShowSeniorityClick(insuranceGroups, currentCustomerInfo)),
    onHidePopup: () => dispatch(onHidePopup()),
    editInformation: (eglishNames, phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses, currentCustomerInfo, newCurrentCustomerInfo, onAfterSuccess) =>
        dispatch(editInformation(eglishNames, phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses, currentCustomerInfo, newCurrentCustomerInfo, onAfterSuccess)),
    editRemarks: (hasVisionLimitations, hasHearingLimitations, memberData, onAfterSuccess) => dispatch(editRemarks(hasVisionLimitations, hasHearingLimitations, memberData, onAfterSuccess)),
    hideSuccessMessage: () => dispatch(hideSuccessMessage()),
    updatePassword: (oldPassword, newPassword, memberData, onAfterSuccess) => dispatch(updatePassword(oldPassword, newPassword, memberData, onAfterSuccess)),
    filterCities: (addressType, term) => dispatch(filterCities(addressType, term)),
    filterStreets: (addressType, cityId, term) => dispatch(filterStreets(addressType, cityId, term)),
});

const mapStateToProps = createStructuredSelector({
    editInformationData: makeSelectEditInformationData
});

@withRouter
@mLib.appInfra.injectReducer({ key: 'editInformationData', reducer })
@mLib.appInfra.injectSaga({ key: 'editInformationData', saga })
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class EditInformation extends Component {
    constructor(props) {
        super(props);

        this.initCustomer();
        if(this.isImpersonation()){
            this.props.onCurrentCustomer(this.memberData, false, this.reloadData);
        }

        const searchQuery = props.history.location.search; 
       
        let returnUrl = null;

        if (searchQuery && searchQuery.indexOf('?returnUrl=') !== -1) {
            returnUrl = searchQuery.substr(searchQuery.indexOf('?returnUrl=') + 11);
        }
        this.state = {
            refreshTabsComponent: false,
            refreshContent: this.isImpersonation() ? true :false,
            returnUrl: returnUrl
        }

    }

    removeSuccessMessageTimeout = null;

    componentDidMount() {
        const {onLoad, editInformationData: { showSuccessMessage = false } = { showSuccessMessage: false } } = this.props;

        onLoad();
        

        this.turnOffRouteLeavingGuard();

        if (showSuccessMessage) {
            this.setupSuccessMessage();
        }
    }

    UNSAFE_componentWillReceiveProps(newProps) {
        if (newProps && newProps.editInformationData && newProps.editInformationData.showSuccessMessage &&
            this.props && this.props.editInformationData && !this.props.editInformationData.showSuccessMessage) {
            if (this.removeSuccessMessageTimeout) {
                window.clearTimeout(this.removeSuccessMessageTimeout);
            }

            this.turnOffRouteLeavingGuard();
            this.setupSuccessMessage();
        }
    }

    componentWillUnmount() {
        if (this.removeSuccessMessageTimeout) {
            window.clearTimeout(this.removeSuccessMessageTimeout);
        }

        //this.props.onLoad();
    }

    updateCustomer(){
        this.props.onCurrentCustomer(this.memberData, true, this.reloadData);
    }

    reloadData() {
        this.initCustomer();
        this.setState({ refreshContent: false });
    }

    initCustomer() {
        this.memberData = mLib.saveData.customerData.get();
    }

    setRouteLeavingGuard() {
        const propsLeaving = {
            shouldBlockNavigation: true,
            navigate: this.props.history.push
        };

        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    turnOffRouteLeavingGuard() {
        const propsLeaving = {
            shouldBlockNavigation: false,
            navigate: this.props.history.push
        };

        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    hideSuccessMessage() {
        const { hideSuccessMessage, history } = this.props;
        const { returnUrl } = this.state;

        hideSuccessMessage && hideSuccessMessage();

        if (this.isCurrentUrlPath(TABS.EDIT_PROFILE) && returnUrl) {
            history.push({
                pathname: decodeURIComponent(returnUrl)
            });
        }
    }

    setupSuccessMessage() {
        const blockTimeInSeconds = parseInt(BLOCK_SUBMIT_BTN_AFTER_ACTION_IN_MILI_SECONDS);
        // Force content refresh to clear inner state
        this.setState({ refreshContent: true });
        this.removeSuccessMessageTimeout = window.setTimeout(() => this.hideSuccessMessage(), blockTimeInSeconds);
    }

    tabsList() {
        const {IsRender} = this.props;
        const editPasswordUrl = (`subitem_${EDIT_PASSWORD_PAGE_NAME}`).toLowerCase();
        let tabsList = [];
        tabsList.push(<span className={cx(style.tabText)}>{TABS.EDIT_PROFILE.name}</span>);
        this.isChangePasswordAllowed() && tabsList.push(
            <IsRender uniqueName={editPasswordUrl}>
                <span className={cx(style.tabText)}>{TABS.UPDATE_PASSWORD.name}</span>
            </IsRender>
        );

        return tabsList;
    }

    navigateTo = (url) => {
        window.location = url;
    }

    onTabChange(tab) {
        /* Navigation occurred */
        if (tab !== this.activeTabIndex()) {
            let url = '';

            if (tab === TABS.EDIT_PROFILE.index) {
                url = UPDATE_DETAILS_PAGE_NAME;
                mLib.logs.insertCentralizedLog(TABS.EDIT_PROFILE.elementId, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);
            }
            else {
                url = EDIT_PASSWORD_PAGE_NAME
                mLib.logs.insertCentralizedLog(TABS.UPDATE_PASSWORD.elementId, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);
            }
           
            this.props.history.push(`/${url.toLowerCase()}`);

            /* Force tabs component refresh as the component has internal state that might be wrong when redirection guard popup blocks the redirect */
            this.setState({ refreshTabsComponent: true });
        }
    }

    onUpdatePersonalDetailsFormSubmit(eglishNames, phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses) {
        const memberData = mLib.saveData.customerData.get();

        window.scrollTo(0, 0);

        //this.props.editInformation(phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses, memberData, this.memberData, this.initCustomer);
        this.props.editInformation(eglishNames, phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses, memberData, this.memberData, this.updateCustomer);
    }

    onUpdatePartialPersonalDetailsFormSubmit(eglishNames, hasVisionLimitations, hasHearingLimitations) {
        const memberData = mLib.saveData.customerData.get();

        window.scrollTo(0, 0);

        //this.props.editInformation(phones, emailAddress, activeLanguageId, hasVisionLimitations, hasHearingLimitations, addresses, memberData, this.memberData, this.initCustomer);
        this.props.editInformation(eglishNames, null, null, null, hasVisionLimitations, hasHearingLimitations, null, memberData, this.memberData, this.updateCustomer);
    }

    onUpdateRemarks(hasVisionLimitations, hasHearingLimitations) {
        const memberData = mLib.saveData.customerData.get();
        //this.props.editRemarks(hasVisionLimitations, hasHearingLimitations, memberData, this.initCustomer);
        this.props.editRemarks(hasVisionLimitations, hasHearingLimitations, memberData, this.updateCustomer);
    }

    isChangePasswordAllowed() {
        return this.ageCategory() === AGE_CATEGORY.ADULT;
    }

    printSeniorityPdf() {
        const customer = this.memberData.current_customer_info;

        printPdf(customer.member_id_code, customer.member_id, process.env.WEB_API_URL_DIRECTORSHIP + process.env.WEB_SENIORITY_PDF_URL, this.props.editInformationData.file);
    }

    downloadSeniorityPdf() {
        const customer = this.memberData.current_customer_info;
        downloadPdf(customer.member_id_code, customer.member_id, process.env.WEB_API_URL_DIRECTORSHIP + process.env.WEB_SENIORITY_PDF_URL, this.props.editInformationData.file);
    }

    ageCategory() {
        const age = this.memberData.current_customer_info.age.years;
        if (age < MIN_ADOLESCENT_AGE.CATEGORY) {
            return AGE_CATEGORY.MINOR
        }
        else if (age < MIN_ADULT_AGE) {
            return AGE_CATEGORY.ADOLESCENT;
        }

        return AGE_CATEGORY.ADULT;
    }

    isImpersonation() {
        return this.memberData.logged_customer_info.member_id !== this.memberData.current_customer_info.member_id;
    }

    onShowSeniorityClick() {
        const { editInformationData: { insuranceGroups = undefined } } = this.props;

        mLib.logs.insertCentralizedLog(LOG_IDS.CLICK_SENIORITY_HISTORY, UPDATE_DETAILS_PAGE_NAME, CLICK_LOG_ID);
        this.props.onShowSeniorityClick(insuranceGroups, this.memberData.current_customer_info);
    }

    onHidePopup() {
        this.props.onHidePopup();
    }

    isCurrentUrlPath(TAB) {
        const { history } = this.props;

        if (TAB && TAB.index === TABS.EDIT_PROFILE.index) {
            return history.location.pathname.toLowerCase() === (`/${UPDATE_DETAILS_PAGE_NAME}`).toLowerCase();
        }
        if (TAB && TAB.index === TABS.UPDATE_PASSWORD.index) {
            return history.location.pathname.toLowerCase() === (`/${EDIT_PASSWORD_PAGE_NAME}`).toLowerCase();
        }

        return false;
    }

    activeTabIndex() {
        if (this.isCurrentUrlPath(TABS.UPDATE_PASSWORD)) {
            return TABS.UPDATE_PASSWORD.index;
        }

        return TABS.EDIT_PROFILE.index;
    }

    updatePassword(oldFunction, newFunction) {
        this.props.updatePassword(oldFunction, newFunction, this.memberData, 
            () => { window.setTimeout(() => this.setState({ refreshContent: false }), 0)});
    }

    getTitle() {
        const title = mLib.site.getModuleTitle(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'Title', 'עדכון פרטים אישיים');
        return title;
    } 

    renderPopup() {
        const { editInformationData: { popup = null, insuranceGroups = undefined } = { popup: null, insuranceGroups: undefined } } = this.props;

        if (popup === null) {
            return null;
        }

        switch (popup) {
            case POPUPS.SENIORITY_POPUP:
                const insurances = getInsuranceHistory(insuranceGroups, INSURANCE_TYPES);
                const complementaryInsuranceExists = complementarySeniorityExists(insurances, INSURANCE_TYPES);

                return (
                    <SeniorityPopup
                        onPrint={this.printSeniorityPdf}
                        onFileSave={this.downloadSeniorityPdf}
                        close={this.onHidePopup}
                        isOpen={true}
                        insuranceGroups={insurances}
                        complementaryInsuranceExists={complementaryInsuranceExists} />);
            case POPUPS.NO_SENIORITY_HISTORY_POPUP:
                return <NoSeniorityHistoryPopup
                    close={this.onHidePopup}
                    isOpen={true} />;
            case POPUPS.PARTIAL_SUCCESS_FAILED_REMARKS_POPUP:
                return (
                    <PartialSuccessFailedRemarksPopup
                        close={this.onHidePopup}
                        isOpen={true} />
                );
            case POPUPS.PARTIAL_SUCCESS_FAILED_DETAILS_POPUP:
                return (
                    <PartialSuccessFailedDetailsPopup
                        close={this.onHidePopup}
                        isOpen={true} />
                );
            case POPUPS.GLOBAL_ERROR_POPUP:
                /* Show popup from mlib. in addition, call close popup function so the popup wont occur over and over again */
                mLib.saveData.globalErrorPopup.setGlobalErrorPopup(true);
                this.onHidePopup();
                return null;
        }
    }

    renderActiveContent() {
        const { editInformationData, editInformationData: { loading = undefined, addressesAutoComplete = {} } = { loading: undefined, addressesAutoComplete: {} } } = this.props;


        const editProfileUrl = (`/${UPDATE_DETAILS_PAGE_NAME}`).toLowerCase();
        const editPasswordUrl = (`/${EDIT_PASSWORD_PAGE_NAME}`).toLowerCase();
        /* Fallback to edit profile as the default url in case of unrecognized navigation */
        const redirectUrl = (this.isChangePasswordAllowed() && this.isCurrentUrlPath(TABS.UPDATE_PASSWORD)) ? editPasswordUrl : editProfileUrl;

        const { refreshContent } = this.state;
        const settings = JSON.parse(sessionStorage.getItem('settings'));
        const {IsRender,isRenderFunction} = this.props;
       

        return (
            <Fragment>
                <Route path={editProfileUrl} render={() => {
                    return !refreshContent ? <EditDetails
                        filterCities={this.props.filterCities}
                        filterStreets={this.props.filterStreets}
                        addressesAutoComplete={addressesAutoComplete}
                        setRouteLeavingGuard={this.setRouteLeavingGuard}
                        phonePrefixes={settings && settings.phone_area_codes}
                        onSubmitAdult={this.onUpdatePersonalDetailsFormSubmit}
                        //onSubmitNotAdult={this.onUpdateRemarks}
                        onSubmitNotAdult={this.onUpdatePartialPersonalDetailsFormSubmit}
                        ageCategory={this.ageCategory()}
                        onOpenInsuranceHistory={this.onShowSeniorityClick}
                        isImpersonation={this.isImpersonation()}
                        loading={loading}
                        isRenderFunction={isRenderFunction}
                        IsRender={IsRender}
                        memberData={this.memberData} /> : null
                }} />
                <IsRender uniqueName={'subitem_'+EDIT_PASSWORD_PAGE_NAME.toLowerCase()}>
                    <Route path={editPasswordUrl} render={() => {
                        return !refreshContent ? <EditPassword
                        auth={editInformationData && editInformationData.authenticationStatus}
                        navigateTo={this.navigateTo}
                        onUpdatePassword={this.updatePassword}
                        loading={loading}
                        setRouteLeavingGuard={this.setRouteLeavingGuard} /> : null
                    }} />
                </IsRender>
                <Redirect to={redirectUrl} />
            </Fragment>
        )
    }

    render() {
        const { editInformationData: { showSuccessMessage = undefined } = { showSuccessMessage: undefined } } = this.props;
        const { refreshTabsComponent } = this.state;
        const activeTabIndex = this.activeTabIndex();

        if (refreshTabsComponent) {
            window.setTimeout(() => this.setState({ refreshTabsComponent: false }), 0);
        }

        return (
            <Fragment>
                <MainHeadline className={style.headLine}>
                    <MainHeadlineScrollable className={style.titleContainer}>
                        <H1 className={style.title}>
                        {/*EDIT_INFORMATION_MODAL_TITLE*/}
                        {this.getTitle()}
                       </H1>
                    </MainHeadlineScrollable>
                    {!refreshTabsComponent && <Tab
                        wrapClassName={style.tabsWrap}
                        className={style.tabs}
                        preToggleClickEvent={this.onTabChange}
                        activeTab={activeTabIndex}
                        list={this.tabsList()} />}
                    <a target='_blank' rel='noopener noreferrer' className={cx(style.helpContainer, 'd-none d-md-flex')} href={EDIT_INFORMATION_HELP_LINK}>
                        <Icon name={HELP_ICON} className={style.helpIcon} />
                        <span>{EDIT_DETAILS_HEADER_HELP_TEXT}</span>
                    </a>
                    {showSuccessMessage && <Fade className={style.successTagContainer} in={showSuccessMessage} hook="successAlertMessage" size="lg">
                        <div className={style.successTagContent}>
                            <Icon name={APPROVED_ICON} className={style.icon} />
                            <span className={style.message}>{SUCCESS_TAG_TEXT}</span>
                        </div>
                    </Fade>}
                </MainHeadline>
                <MainBody layout='regular'>
                    <div className={cx(style.content)}>
                        {this.renderActiveContent()}
                        {this.renderPopup()}
                    </div>
                </MainBody>
            </Fragment>
        );
    }
}

export default EditInformation;