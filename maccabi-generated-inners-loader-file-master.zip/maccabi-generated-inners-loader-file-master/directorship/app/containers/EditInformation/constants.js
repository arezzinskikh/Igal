import mLib from '@maccabi/m-lib';

export const BASE_ELEMENT_PAGE_NAV = 'directorship/EditInformation/';
export const UPDATE_DETAILS_PAGE_NAME = `${BASE_ELEMENT_PAGE_NAV}Profile/`;
export const EDIT_PASSWORD_PAGE_NAME = `${BASE_ELEMENT_PAGE_NAV}Password/`;
export const UPDATE_DETAILS_PAGE_NAME_RESOURCE = `${BASE_ELEMENT_PAGE_NAV}Profile`;
export const EDIT_PASSWORD_PAGE_NAME_RESOURCE = `${BASE_ELEMENT_PAGE_NAV}Password`;
export const CLICK_LOG_ID = process.env.LOG_ACTION_ID_CLICK;
export const OPEN_LOG_ID = process.env.LOG_ACTION_ID_SCREEN_OPEN;
export const LOG_IDS = {
    CLICK_EDIT_PROFILE_TAB: 3008,
    CLICK_UPDATE_PASSWORD_TAB: 3009,
    CLICK_SENIORITY_HISTORY: 3010,
    SENIORITY_POPUP_SHOW: 3011,
    PRINT_BTN_CLICK: 3012,
    SAVE_FILE_BTN_CLICK: 3013,
    ADD_ADDRESS_FOR_MAIL_CLICK: 3016,
    REMOVE_ADDRESS_FOR_MAIL_CLICK: 3015,
    ADD_PERSONAL_MAIL_ADDRESS: 3019,
    REMOVE_PERSONAL_MAIL_ADDRESS: 3018,
    SAVE_EDIT_PERSONAL_INFO_CHANGES: 3020,
    SAVE_CHANGE_PASSWORD_CLICK: 3021
    // SUCCESS_EDIT_PERSONAL_INFO: 3021,
    // FORGOT_PASSWORD_CLICK: 3022,
    // CHANGE_PASSWORD_CLICK: 3023,
};
export const TABS = {
    EDIT_PROFILE: {
        index: 0,
        name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EditProfileTabName', 'עדכון פרטים'),
        elementId: LOG_IDS.CLICK_EDIT_PROFILE_TAB
    },
    UPDATE_PASSWORD: {
        index: 1,
        name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'ChangePasswordTabName', 'עדכון סיסמה'),
        elementId: LOG_IDS.CLICK_UPDATE_PASSWORD_TAB
    }
};
export const MIN_ADOLESCENT_AGE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'MinAdolescentAge', 16);
export const MIN_ADULT_AGE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'MinAdultAge', 18);
export const AGE_CATEGORY = {
    MINOR: 'minor',
    ADOLESCENT: 'adolescent',
    ADULT: 'adult'
};
export const EDIT_DETAILS_HEADER_HELP_TEXT = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EditDetailsHeaderHelpText', 'עזרה');
//export const EDIT_INFORMATION_MODAL_TITLE = mLib.site.getModuleTitle(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'Title', 'עדכון פרטים אישיים');
export const EDIT_INFORMATION_MODAL_TITLE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'Title', 'עדכון פרטים אישיים');
export const BLOCK_SUBMIT_BTN_AFTER_ACTION_IN_MILI_SECONDS = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'BlockSubmitBtnAfterActionInMiliSeconds',
    3000
);
export const SUCCESS_TAG_TEXT = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'SuccessTagText', 'השינויים נשמרו בהצלחה');
export const MIN_AGE_BOYGIRL_AVATAR = 1;
export const MIN_AGE_GROWN_UP_AVATAR = 17;
export const PERSONAL_DETAILS_EDIT_MINOR_REMARK = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'EditMinorRemark',
    'פרטי הקשר של ילדך הם פרטי הקשר המעודכנים עבורך'
);
export const PERSONAL_DETAILS_EDIT_ADOLESCENT_REMARK = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'EditAdolescentRemark',
    'פרטי הקשר שלך הם פרטי הקשר המעודכנים עבור הוריך'
);
export const PERSONAL_DETAILS_AGE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'Age', 'גיל');
export const PERSONAL_DETAILS_INSURANCE_GROUP = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'Insurance', 'כיסוי ביטוחי');
export const PERSONAL_DETAILS_BRANCH = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'Branch', 'מרכז רפואי');
export const PERSONAL_DETAILS_INSURANCE_AGE_AGREEMENT = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'InsuranceAgeAgreement',
    'אישור וותק ביטוחי'
);
export const ENGLISH_NAMES_TITLE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EnglishNameTitle', 'שם באנגלית');
export const PHONES_EMAILS_TITLE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'PhonesEmailsTitle', 'טלפונים וכתובות דואר אלקטרוני');
export const PHONES_EMAILS_DESCRIPTION = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'PhonesEmailsDescription', 'חובה לפחות מספר טלפון אחד');
const PHONES_EMAILS_HOME_PHONE_NAME = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'HomePhoneName', 'טלפון בבית');
const PHONES_EMAILS_HOME_PHONE_TYPE_SIGN = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'HomePhoneTypeSign', 'ב');
const PHONES_EMAILS_CELLPHONE_NAME = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'CellPhoneName', 'טלפון נייד');
const PHONES_EMAILS_CELLPHONE_PHONE_TYPE_SIGN = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'CellPhoneTypeSign', 'נ');
const PHONES_EMAILS_FAX_NAME = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'FaxName', 'פקס');
const PHONES_EMAILS_FAX_TYPE_SIGN = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'FaxTypeSign', 'פ');
export const PHONES_EMAILS_EMAIL_NAME = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EmailName', 'דואר אלקטרוני');
export const PHONES_EMAILS_EMAIL_VALIDATION = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EmailValidation', 'יש להזין כתובת דואר אלקטרוני');
export const PHONES_EMAILS_PHONE_VALIDATION = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'PhonelValidation', 'מספר הטלפון אינו תקין');
export const PHONES_EMAILS_PHONE_REQUIRED_VALIDATION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PhoneRequiredValidation',
    "יש להזין מס' טלפון בבית או נייד"
);
export const FIRST_NAME_ENGLISH = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'FirstNameEnglish', 'שם פרטי');
export const LAST_NAME_ENGLISH = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'LastNameEnglish', 'שם משפחה');
export const FIRST_NAME_ENGLISH_ERROR = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'LastNameEnglish', 'חובה למלא שם פרטי');
export const LAST_NAME_ENGLISH_ERROR = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'LastNameEnglish', 'חובה למלא שם משפחה');

export const PHONE_TYPES = {
    HOME: {
        name: PHONES_EMAILS_HOME_PHONE_NAME,
        type: PHONES_EMAILS_HOME_PHONE_TYPE_SIGN
    },
    CELL: {
        name: PHONES_EMAILS_CELLPHONE_NAME,
        type: PHONES_EMAILS_CELLPHONE_PHONE_TYPE_SIGN
    },
    FAX: {
        name: PHONES_EMAILS_FAX_NAME,
        type: PHONES_EMAILS_FAX_TYPE_SIGN
    }
};
export const PERSONAL_DETAILS_LANGUAGE_TITLE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'LanguageTitle', 'שירותי מכבי מותאמים לך אישית');
export const PERSONAL_DETAILS_LANGUAGE_DESCRIPTION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'LanguageDescription',
    'בחירת שירותים מותאמים יסייע למכבי לתת לך שירות מיטבי ומותאם לצרכיך'
);
export const LANGUAGES = [
    {
        name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'HebrewLanguage', 'עברית'),
        code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'HebrewLanguageCode', 1)
    },
    {
        name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'RussianLanguage', 'רוסית'),
        code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'RussianLanguageCode', 2)
    },
    {
        name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EnglishLanguage', 'אנגלית'),
        code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EnglishLanguageCode', 3)
    },
    {
        name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'FrenchLanguage', 'צרפתית'),
        code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'FrenchLanguageCode', 4)
    },
    {
        name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'ArabLanguage', 'ערבית'),
        code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'ArabLanguageCode', 6)
    }
];
export const PERSONAL_DETAILS_LANGUAGE_TOOLTIP_NAME = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'LanguageTooltipName',
    'בחירת שפה לקבלת שירות?'
);
export const PERSONAL_DETAILS_LANGUAGE_TOOLTIP_DESCRIPTION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'LanguageTooltipDescription',
    'בחירת שפה תסייע למכבי  לתת לך שירות מיטבי '
);
export const PERSONAL_DETAILS_CHOOSE_LANGUAGE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'ChooseLanguage', 'בחירת שפה');
export const PERSONAL_DETAILS_ACCESSIBILITY_TOOLTIP_NAME = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AccessibilityTooltipName',
    'סימון נגישות'
);
export const PERSONAL_DETAILS_ACCESSIBILITY_TOOLTIP_DESCRIPTION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AccessibilityTooltipDescription',
    'סימון מתאים יסייע למכבי  לתת לך שירות מיטבי ומותאם לצרכיך'
);
export const PERSONAL_DETAILS_ACCESSIBILITY_VISION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AccessibilityVisionCheckbox',
    'מוגבלות בראייה / קריאה'
);
export const PERSONAL_DETAILS_ACCESSIBILITY_HEARING = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AccessibilityHearingCheckbox',
    'מוגבלות בשמיעה / דיבור'
);
export const PERSONAL_DETAILS_REMARK_CODES = {
    HEARING_LIMITATIONS: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'HearingLimitationsRemarkCode', 4112),
    VISION_LIMITATIONS: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'VisionLimitationsRemarkCode', 4113)
};
export const PERSONAL_DETAILS_SUBMIT_BTN = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'PersonalDetailsSubmitBtn', 'שמירת שינויים');
export const ADDRESS_SECTION_LIVING_ADDRESS_NAME = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'LivingAddressName', 'כתובת מגורים');
export const ADDRESS_SECTION_LIVING_ADDRESS_DESCRIPTION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'LivingAddressDescription',
    'לכתובת זו יישלחו דברי דואר עבור כל בני המשפחה'
);
export const ADDRESS_SECTION_MAIL_ADDRESS_NAME = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'MailAddressName',
    'כתובת שונה לקבלת דברי דואר'
);
export const ADDRESS_SECTION_MAIL_ADDRESS_DESCRIPTION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'MailAddressDescription',
    'לכתובת זו אנחנו נשלח דואר הנוגע לכל בני המשפחה'
);
export const ADDRESS_SECTION_PERSONAL_MAIL_ADDRESS_NAME = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PersonalMailAddressName',
    'כתובת אישית לקבלת דברי דואר'
);
export const ADDRESS_SECTION_PERSONAL_MAIL_ADDRESS_DESCRIPTION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PersonalMailAddressDescription',
    'לכאן נשלח דברי דואר רק בעניינך'
);
export const ADDRESS_SECTION_REGULAR_ADDRESS_TYPE_LABEL = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionRegularAddressLabel',
    'שליחה לכתובת דואר'
);
export const ADDRESS_SECTION_POBOX_ADDRESS_TYPE_LABEL = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionPoboxAddressLabel',
    'שליחה לתא דואר'
);
export const ADDRESS_SECTION_CITY_TEXTBOX_LABEL = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'AddressSectionCityTexboxLabel', 'ישוב');
export const ADDRESS_SECTION_STREET_TEXTBOX_LABEL = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'AddressSectionStreetTexboxLabel', 'רחוב');
export const ADDRESS_SECTION_HOUSE_TEXTBOX_LABEL = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'AddressSectionHouseTexboxLabel', 'מספר בית');
export const ADDRESS_SECTION_APARTMENT_TEXTBOX_LABEL = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionApartmentTexboxLabel',
    'דירה'
);
export const ADDRESS_SECTION_ENTRANCE_TEXTBOX_LABEL = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionEntranceTexboxLabel',
    'כניסה'
);
export const ADDRESS_SECTION_POBOX_TEXTBOX_LABEL = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'AddressSectionPoBoxTexboxLabel', 'תא דואר');
export const ADDRESS_SECTION_ADD_ADDRESS_LABEL = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'AddressSectionAddAddressLabel', 'הוספה');
export const ADDRESS_SECTION_REMOVE_ADDRESS_LABEL = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'AddressSectionRemoveAddressLabel', 'הסרה');
export const DEFAULT_MAX_AUTO_COMPLETE_RESULTS = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'DefaultMaxAutoCompleteResults', 30);
export const ADDRESS_TYPES = ['LIVING', 'MAIL', 'PERSONAL_MAIL'];
export const ADDRESS_SECTION_ADDRESS_TYPES = {
    LIVING: {
        type: 'מ',
        status: 'מ'
    },
    MAIL: {
        type: 'ד',
        status: 'מ'
    },
    PERSONAL_MAIL: {
        type: 'ד',
        status: 'פ'
    }
};
export const ADDRESS_SECTION_EMPTY_CITY_VALIDATION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionValidationEmptyCity',
    'יש להזין ישוב'
);
export const ADDRESS_SECTION_INVALID_CITY = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionInvalidCity',
    'יש לבחור יישוב מהרשימה'
);
export const ADDRESS_SECTION_EMPTY_STREET_VALIDATION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionValidationEmptyStreet',
    'יש להזין רחוב'
);
export const ADDRESS_SECTION_INVALID_STREET = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionInvalidStreet',
    'יש לבחור רחוב מהרשימה'
);
export const ADDRESS_SECTION_HOUSE_VALIDATION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionValidationHouse',
    'יש להזין מספר בית תקין'
);
export const ADDRESS_SECTION_APARTMENT_VALIDATION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionValidationApartment',
    'יש להזין מספר דירה תקינה'
);
export const ADDRESS_SECTION_ENTRANCE_VALIDATION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionValidationEntrance',
    'יש להזין כניסה תקינה'
);
export const ADDRESS_SECTION_PO_VALIDATION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'AddressSectionValidationPo',
    'יש להזין מספר תא דואר תקין'
);
export const ADDRESS_SECTION_NO_RESULT_TEST = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'AddressSectionNoResultText', 'אין תוצאות');
export const SENIORITY_POPUP_TITLE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'SeniorityPopupTitle', 'אישור וותק ל');
export const SENIORITY_POPUP_DESCRIPTION_LINE1 = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'SeniorityPopupDescription1',
    'המידע המוצג נכון לתאריך הנוכחי.'
);
export const SENIORITY_POPUP_DESCRIPTION_LINE2 = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'SeniorityPopupDescription2',
    'רובד ביטוחי קודם מוצג רק אם קיים רצף ביטוחי'
);
export const SENIORITY_POPUP_INSURANCE_TABLE_TITLE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'SeniorityPopupTableInsurance',
    'רובד ביטוחי'
);
export const SENIORITY_POPUP_DATES_TABLE_TITLE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'SeniorityPopupTableDates', 'תאריך תחילת וותק');
export const SENIORITY_POPUP_REMARKS = [
    mLib.resources.getResource(
        UPDATE_DETAILS_PAGE_NAME_RESOURCE,
        'SeniorityPopupRemark1',
        'תאריך תחילת וותק מתייחס לחישוב הזכויות בשב"ן ויתכן וכולל וותק בקופות חולים אחרות.'
    ),
    mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'SeniorityPopupRemark2', 'תאריך הוותק המוצג הוא של ההורה עם תקופת הוותק הארוכה יותר.'),
    mLib.resources.getResource(
        UPDATE_DETAILS_PAGE_NAME_RESOURCE,
        'SeniorityPopupRemark3',
        'החברות הינה בכפוף לתקנון תוכניות הבריאות הנוספות ולפוליסה מכבי סיעודי למי שהיה/הינו חבר.'
    )
];
export const SENIORITY_POPUP_NO_COMPLIMENTARY_INSURANCE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'SeniorityPopupNoComplimentaryInsurance',
    'לא קיים וותק בביטוח משלים'
);
export const SENIORITY_POPUP_REMARKS_TITLE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'SeniorityPopupRemarksTitle', 'הערות');
export const SENIORITY_POPUP_PRINT_BUTTON = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'SeniorityPopupPrintBtn', 'הדפס');
export const SENIORITY_POPUP_SAVE_BUTTON = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'SeniorityPopupSaveBtn', 'שמירה כקובץ');
export const SENIORITY_POPUP_PRINT_BUTTON_MOBILE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'SeniorityPopupPrintBtnMobile',
    'שמירה / הדפסה'
);
export const INSURANCE_TYPES = {
    SHABAN: {
        code_gold: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceGoldTypeCode', '02'),
        code_silver: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceSilverTypeCode', '03'),
        code_mine: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceMyTypeCode', '07'),
        text_gold: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceGoldTypeName', 'מכבי זהב'),
        text_silver: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceSilverTypeName', 'מכבי כסף'),
        text_mine: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceMyTypeName', 'מכבי שלי'),
        text_gold_and_silver: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceGoldAndSilverTypeName', 'מכבי זהב/כסף')
    },
    OTHERS: [
        {
            code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType1Code', '04'),
            name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType1Name', 'קרן מכבי')
        },
        {
            code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType2Code', '05'),
            name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType2Name', 'סיעודי זהב')
        },
        {
            code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType3Code', '06'),
            name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType3Name', 'סיעודי כסף')
        },
        {
            code: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType4Code', '08'),
            name: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'InsuranceAdditionalType4Name', 'מכבי סיעודי')
        }
    ]
};
export const PARTIAL_SUCCESS_FAILED_DETAILS_TITLE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PartialSuccessFailedDetailsTitle',
    'השינויים לא נשמרו'
);
export const PARTIAL_SUCCESS_FAILED_DETAILS_SUBTITLE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PartialSuccessFailedDetailsSubtitle',
    'יש לנו בעיה טכנית שלא מאפשרת את שמירת השינויים. לתשומת לבך, סימון הנגישות שעודכן נשמר בהצלחה.'
);
export const PARTIAL_SUCCESS_FAILED_DETAILS_BTN = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PartialSuccessFailedDetailsBtn',
    'הבנתי, תודה'
);
export const PARTIAL_SUCCESS_FAILED_REMARKS_TITLE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PartialSuccessFailedRemarksTitle',
    'השינויים נשמרו בהצלחה'
);
export const PARTIAL_SUCCESS_FAILED_REMARKS_SUBTITLE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PartialSuccessFailedRemarksSubtitle',
    'לתשומת לבך, עקב כשל טכני, סימון הנגישות לא עודכן'
);
export const PARTIAL_SUCCESS_FAILED_REMARKS_BTN = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'PartialSuccessFailedRemarksBtn',
    'הבנתי, תודה'
);
export const EDIT_INFORMATION_HELP_LINK = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'EditInformationHelpLink',
    'https://www.maccabi4u.co.il/15971-he/maccabi.aspx'
);
export const EDIT_PASSWORD_FORGOT_PASSWORD_LINK = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordForgotPasswordLink',
    'https://mac.maccabi4u.co.il/forgot?indexApp=2'
);
export const EDIT_PASSWORD_FORGOT_PASSWORD_LINK_KOSHER = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordForgotPasswordLinkKohser',
    'https://2go.maccabi-health.co.il/dana-na/auth/url_40/welcome.cgi'
);
export const EDIT_PASSWORD_DESCRIPTION_FIRST_LINE = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordDescriptionFirstLine',
    'הסיסמה לשירותי מכבי Online היא אישית וסודית. אנא הקפידו לא לרשום או למסור אותה לאף גורם.'
);
export const EDIT_PASSWORD_DESCRIPTION_SECOND_LINE = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordDescriptionSecondLine',
    'מומלץ להחליף סיסמה אחת לשלושה חודשים'
);
export const EDIT_PASSWORD_REMARKS_TITLE = mLib.resources.getResource(EDIT_PASSWORD_PAGE_NAME_RESOURCE, 'EditPasswordRemarksTitle', 'כללים לבחירת סיסמה');
export const EDIT_PASSWORD_REMARKS = [
    mLib.resources.getResource(EDIT_PASSWORD_PAGE_NAME_RESOURCE, 'EditPasswordRemark1', 'הסיסמה חייבת להיות מורכבת מ- 6-8 תווים'),
    mLib.resources.getResource(EDIT_PASSWORD_PAGE_NAME_RESOURCE, 'EditPasswordRemark2', 'יש לבחור אותיות באנגלית ו/או ספרות בלבד')
];
export const EDIT_PASSWORD_FORGOT_PASSWORD = mLib.resources.getResource(EDIT_PASSWORD_PAGE_NAME_RESOURCE, 'EditPasswordForgotPassword', 'שכחתי סיסמה');
export const EDIT_PASSWORD_PASSWORD_LABEL = mLib.resources.getResource(EDIT_PASSWORD_PAGE_NAME_RESOURCE, 'EditPasswordPasswordLabel', 'סיסמה נוכחית');
export const EDIT_PASSWORD_NEW_PASSWORD_LABEL = mLib.resources.getResource(EDIT_PASSWORD_PAGE_NAME_RESOURCE, 'EditPasswordNewPasswordLabel', 'סיסמה חדשה');
export const EDIT_PASSWORD_VALIDATE_PASSWORD_LABEL = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordValidatePasswordLabel',
    'אימות סיסמה'
);
export const EDIT_PASSWORD_REQUIRED_ERROR_MESSAGE = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordRequriedErrorMessage',
    'שדה חובה'
);
export const EDIT_PASSWORD_INVALID_ERROR_MESSAGE = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordInvalidErrorMessage',
    'יש למלא סיסמה בין 6 ל 8 ספרות או אותיות באנגלית'
);
export const EDIT_PASSWORD_MISMATCH_ERROR_MESSAGE = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordMismatchErrorMessage',
    'אימות הסיסמה אינו תואם'
);
export const EDIT_PASSWORD_SUBMIT_BTN = mLib.resources.getResource(EDIT_PASSWORD_PAGE_NAME, 'EditPasswordSubmitBtn', 'שמירת שינויים');
export const EDIT_PASSWORD_NEW_PASSWORD_TITLE = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordNewPasswordTitle',
    'בחירת סיסמה חדשה'
);
export const EDIT_PASSWORD_NEW_AUTHENICATION_FAILED = mLib.resources.getResource(
    EDIT_PASSWORD_PAGE_NAME_RESOURCE,
    'EditPasswordAuthenticationFailed',
    'סיסמא נוכחית שגויה'
);
export const NO_SENIORITY_HISTORY_POPUP_TITLE = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'NoSenirotyHistoryPopupTitle',
    'לא קיים וותק בביטוח משלים'
);
export const NO_SENIORITY_HISTORY_POPUP_DESCRIPTION = mLib.resources.getResource(
    UPDATE_DETAILS_PAGE_NAME_RESOURCE,
    'NoSenirotyHistoryPopupDescription',
    'לבירורים ניתן לפנות למלה ב 3555*'
);
export const NO_SENIORITY_HISTORY_POPUP_BTN = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME, 'NoSenirotyHistoryPopupBtn', 'הבנתי, תודה');
export const ENDPOINT_POST_VALUES = {
    UPDATE: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EndpointPostValuesUpdate', 'ע'),
    DELETE: mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'EndpointPostValuesDelete', 'מ')
};
export const UPDATE_MEMBERSHIP_STATUS_SUCCESS_CODE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'UpdateMembershipStatusSuccessCode', 1);
export const UPDATE_REMARKS_STATUS_SUCCESS_CODE = mLib.resources.getResource(UPDATE_DETAILS_PAGE_NAME_RESOURCE, 'UpdateRemarksStatusSuccessCode', '0');

// POPUPS
export const POPUPS = {
    SENIORITY_POPUP: 'SENIORITY_POPUP',
    NO_SENIORITY_HISTORY_POPUP: 'NO_SENIORITY_HISTORY_POPUP',
    PARTIAL_SUCCESS_FAILED_REMARKS_POPUP: 'PARTIAL_SUCCESS_FAILED_REMARKS_POPUP',
    PARTIAL_SUCCESS_FAILED_DETAILS_POPUP: 'PARTIAL_SUCCESS_FAILED_DETAILS_POPUP',
    GLOBAL_ERROR_POPUP: 'GLOBAL_ERROR_POPUP'
};

// ACTIONS
export const ON_LOAD = 'maccabi/directorship/editinformation/ON_LOAD';
export const ON_CURRENT_CUSTOMER = 'maccabi/directorship/editinformation/ON_CURRENT_CUSTOMER';
export const ON_SHOW_SENIORITY = 'maccabi/directorship/editinformation/ON_SHOW_SENIORITY';
export const ON_SHOW_FAILED_UPDATE_DETAILS = 'maccabi/directorship/editinformation/ON_SHOW_FAILED_UPDATE_DETAILS';
export const ON_SHOW_FAILED_UPDATE_REMARKS = 'maccabi/directorship/editinformation/ON_SHOW_FAILED_UPDATE_REMARKS';
export const SET_SENIORITY_DATA = 'maccabi/directorship/editinformation/SET_SENIORITY_DATA';
export const DISPLAY_SENIORITY_POPUP = 'maccabi/directorship/editinformation/DISPLAY_SENIORITY_POPUP';
export const DISPLAY_NO_SENIORITY_HISTORY_POPUP = 'maccabi/directorship/editinformation/DISPLAY_NO_SENIORITY_HISTORY_POPUP';
export const SHOW_GLOBAL_ERROR_POPUP = 'maccabi/directorship/editinformation/SHOW_GLOBAL_ERROR_POPUP';
export const HIDE_POPUP = 'maccabi/directorship/editinformation/HIDE_POPUP';
export const TOGGLE_LOADING = 'maccabi/directorship/editinformation/TOGGLE_LOADING';
export const EDIT_INFORMATION = 'maccabi/directorship/editinformation/EDIT_INFORMATION';
export const EDIT_REMARKS = 'maccabi/directorship/editinformation/EDIT_REMARKS';
export const PERSONAL_DETAILS_UPDATED = 'maccabi/directorship/editinformation/PERSONAL_DETAILS_UPDATED';
export const UPDATE_PASSWORD = 'maccabi/directorship/editinformation/UPDATE_PASSWORD';
export const PASSWORD_UPDATED = 'maccabi/directorship/editinformation/PASSWORD_UPDATED';
export const AUTHENTICATION_FAILED = 'maccabi/directorship/editinformation/AUTHENTICATION_FAILED';
export const AUTHENTICATION_SUCCESS = 'maccabi/directorship/editinformation/AUTHENTICATION_SUCCESS';
export const HIDE_SUCCESS_MESSAGE = 'maccabi/directorship/editinformation/HIDE_SUCCESS_MESSAGE';
export const SET_SETTINGS = 'maccabi/directorship/editinformation/SET_SETTINGS';
export const FILTER_CITIES = 'maccabi/directorship/editinformation/FILTER_CITIES';
export const FILTER_STREETS = 'maccabi/directorship/editinformation/FILTER_STREETS';
export const SET_FILTERED_CITIES = 'maccabi/directorship/editinformation/SET_FILTERED_CITIES';
export const SET_FILTERED_STREETS = 'maccabi/directorship/editinformation/SET_FILTERED_STREETS';
