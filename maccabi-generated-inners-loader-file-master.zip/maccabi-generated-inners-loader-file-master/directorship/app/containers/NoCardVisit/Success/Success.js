import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import style from './Success.scss';
import { H4, Card, CardText, Icon, Button } from '@maccabi/m-ui';
import cx from 'classnames';
import format from 'string-format';
import mLib from '@maccabi/m-lib';
import { MAGNETIC_CARD_LINK_RELEVANT_REASON_CODES, LOG_ELEMENT_IN_PAGE } from '../constants';
import autobind from 'autobind';

@autobind
class Success extends Component {
    constructor(props) {
        super(props);

        this.state = {
            date: mLib.date.formatDate(props.validUntilDate),
            hour: mLib.date.formatHour(props.validUntilDate)
        };
    }

    static propTypes = {
        validUntilDate: PropTypes.string.isRequired,
        isLoadedFromCookie: PropTypes.bool.isRequired,
        reason: PropTypes.object
    };

    componentDidMount() {
        mLib.logs.insertCentralizedLog(1524, LOG_ELEMENT_IN_PAGE, process.env.LOG_ACTION_ID_SCREEN_OPEN, false);
    }

    goTo(version, link) {
        const url = mLib.url.getUrlByVersion(version, link);

        window.location.href = url;
    }

    goToMagneticCard(e) {
        e.preventDefault();

        mLib.logs.insertCentralizedLog(1528, LOG_ELEMENT_IN_PAGE);
        this.goTo(4, process.env.MAGNETIC_CARD_URL);
    }

    goToHome(e) {
        e.preventDefault();

        mLib.logs.insertCentralizedLog(1527, LOG_ELEMENT_IN_PAGE);
        this.goTo(2, '/home');
    }

    isGoToMagnticCardRelevant() {
        const relevant = !this.props.isLoadedFromCookie && MAGNETIC_CARD_LINK_RELEVANT_REASON_CODES.indexOf(this.props.reason.code) !== -1;
        return relevant;
    }

    render() {
        return (
            <Fragment>
                <Card visibilty="inner" className={cx(style.success, 'mb-lg-7 mb-5')}>
                    <Icon name="success-big" className="mb-5" />
                    <H4 className="mb-5" tag="h2">
                        {mLib.resources.getResource('directorship/NoCardVisit/Lobby', 'Success_Title', 'ביקור ללא כרטיס אושר בהצלחה')}
                    </H4>
                    <div className="mb-2">
                        האישור תקף עד ה- {this.state.date} בשעה {this.state.hour}
                    </div>
                    <CardText className="text-secondary">
                        {mLib.resources.getResource(
                            'directorship/NoCardVisit/Lobby',
                            'Success_Description',
                            'האישור ניתן במסגרת זכויות המבוטח בזהה לביקור עם כרטיס (לביקורים להם היטל רבעוני ייגבה תשלום ע”פ דיווח הביקור ע”י הרופא או נותן שירות אחר)'
                        )}
                    </CardText>
                </Card>

                {this.isGoToMagnticCardRelevant() && (
                    <div className={cx(style.comment, 'pb-8 mb-5')}>
                        <div className="ml-0 ml-lg-3 mb-2 mb-lg-0">
                            {format(
                                mLib.resources.getResource(
                                    'directorship/NoCardVisit/Lobby',
                                    'Success_Button_Description',
                                    ' במידה וכרטיסך {0} יש אפשרות להזמין כרטיס חדש'
                                ),
                                this.props.reason.magneticCardText
                            )}
                        </div>
                        <Button size="sm" color="primary" onClick={e => this.goToMagneticCard(e)} hook='success'>
                            {mLib.resources.getResource('directorship/NoCardVisit/Lobby', 'Success_Button_Title', 'להזמנה')}
                        </Button>
                    </div>
                )}
                <div className={cx(style.buttonWrap, 'd-xl-none')}>
                    <Button className={cx(style.button)} color="primary" size="lg" onClick={e => this.goToHome(e)} hook='finish'>
                        {mLib.resources.getResource('Global', 'End', 'סיום')}
                    </Button>
                </div>
            </Fragment>
        );
    }
}

export default Success;
