import { IS_ALLOWED, SET_VALID_UNTIL_DATE, ALLOW, SET_IS_SERVICE_FAILED, SET_REASON, ON_LOAD } from './constants';

export function onLoad() {
    return {
        type: ON_LOAD
    };
}

export function isAllowed(currentCustomerInfo) {
    return {
        type: IS_ALLOWED,
        currentCustomerInfo
    };
}

export function allow(currentCustomerInfo) {
    return {
        type: ALLOW,
        currentCustomerInfo
    };
}

export function setValidUntilDate(valid_until_date, is_loaded_from_cookie = false) {
    return {
        type: SET_VALID_UNTIL_DATE,
        validUntilDate: valid_until_date,
        isLoadedFromCookie: is_loaded_from_cookie
    };
}

export function setIsServiceFailed(isServiceFailed) {
    return {
        type: SET_IS_SERVICE_FAILED,
        isServiceFailed
    };
}

export function setReason(reason) {
    return {
        type: SET_REASON,
        reason
    };
}
