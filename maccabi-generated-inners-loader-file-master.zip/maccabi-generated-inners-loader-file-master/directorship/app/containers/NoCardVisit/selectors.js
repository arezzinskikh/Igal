import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectNoCardVisitData = state => {
  return state.get('noCardVisitData', initialState);
};

export const makeSelectNoCardVisitData = createSelector(selectNoCardVisitData, noCardVisitState => {
  return noCardVisitState.get('noCardVisitData')
});