import { takeLatest, call, put, select } from 'redux-saga/effects';
import { IS_ALLOWED, COOKIE_FORMAT, ALLOW, COOKIE_EXPIRATION_TIME } from './constants';
import { setValidUntilDate, setIsServiceFailed } from './actions';
import mLib from '@maccabi/m-lib';
import format from 'string-format';
import { makeSelectNoCardVisitData } from './selectors';
import { allowNoCardVisit } from '../../services/NoCardVisit/apiService';

function* handleIsAllowed(action) {
    const currentCustomerInfo = action.currentCustomerInfo;
    const cookieKey = format(COOKIE_FORMAT, currentCustomerInfo.member_id_code, currentCustomerInfo.member_id);

    try {
        const cookieValue = mLib.cookie.get(cookieKey);
        const valid_until_date = cookieValue !== undefined ? new Date(cookieValue) : null;

        if (valid_until_date != null) {
            yield put(setValidUntilDate(valid_until_date, true));
        }
    } catch (err) {
        console.log('err', err);
    }
}

function* handleAllow(action) {
    const currentCustomerInfo = action.currentCustomerInfo;
    const noCardVisitData = yield select(makeSelectNoCardVisitData);
    const reasonCode = noCardVisitData.reason.code;

    try {
        const result = yield call(allowNoCardVisit, reasonCode, currentCustomerInfo.member_id_code, currentCustomerInfo.member_id);
        const { valid_until_date } = result;

        if (valid_until_date) {
            const cookieKey = format(COOKIE_FORMAT, currentCustomerInfo.member_id_code, currentCustomerInfo.member_id);

            mLib.cookie.set(cookieKey, valid_until_date, COOKIE_EXPIRATION_TIME);
            yield put(setValidUntilDate(valid_until_date));
        } else {
            yield put(setIsServiceFailed(true));
        }
    } catch (err) {
        console.error('err', err);
        yield put(setIsServiceFailed(true));
    }
}

export default function* rootSaga() {
    yield takeLatest(IS_ALLOWED, handleIsAllowed);
    yield takeLatest(ALLOW, handleAllow);
}
