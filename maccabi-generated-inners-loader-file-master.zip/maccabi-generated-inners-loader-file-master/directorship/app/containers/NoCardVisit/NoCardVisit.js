import React, { Component, Fragment } from 'react';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import mLib from '@maccabi/m-lib';
import style from './NoCardVisit.scss';
import { H1, H3, List, MainHeadline, MainHeadlineScrollable, MainBody } from '@maccabi/m-ui';
import Success from './Success/Success';
import Lobby from './Lobby/Lobby';
import cx from 'classnames';
import reducer from './reducer';
import saga from './saga';
import { isAllowed, allow, setReason, onLoad } from './actions';
import { makeSelectNoCardVisitData } from './selectors';
import { REMARKS, ERROR_LOG, LOG_ELEMENT_IN_PAGE } from './constants';
import autobind from 'autobind';

const mapDispatchToProps = dispatch => ({
    isAllowed: currentCustomerInfo => dispatch(isAllowed(currentCustomerInfo)),
    allow: currentCustomerInfo => dispatch(allow(currentCustomerInfo)),
    setReason: reason => dispatch(setReason(reason)),
    onLoad: () => dispatch(onLoad())
});

const mapStateToProps = createStructuredSelector({
    noCardVisitData: makeSelectNoCardVisitData
});

@mLib.appInfra.injectReducer({ key: 'noCardVisitData', reducer })
@mLib.appInfra.injectSaga({ key: 'noCardVisit', saga })
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class NoCardVisit extends Component {
    constructor(props) {
        super(props);
        this.memberData = mLib.saveData.customerData.get();
    }

    componentDidMount() {
        this.props.onLoad();
        this.props.isAllowed(this.memberData.current_customer_info);
        mLib.logs.insertCentralizedLog(1526, LOG_ELEMENT_IN_PAGE, process.env.LOG_ACTION_ID_SCREEN_OPEN, false);
    }

    componentWillUnmount() {
        this.props.onLoad();
    }

    setReason(reason) {
        this.props.setReason(reason);
    }

    allow() {
        this.props.allow(this.memberData.current_customer_info);
    }

    getTitle() {
        const title = mLib.site.getModuleTitle('directorship/NoCardVisit/Lobby', 'Title', 'ביקור ללא כרטיס');
        return title;
    }

    render() {
        const { noCardVisitData } = { ...this.props };
        const { validUntilDate, isServiceFailed, reason, isLoadedFromCookie } = { ...noCardVisitData };
        const isServiceSucceeded = validUntilDate != null;
        const ErrorInModule = this.props.ErrorComponent;

        return (
            <Fragment>
                <MainHeadline>
                    <MainHeadlineScrollable>
                        <H1 hook="title">{this.getTitle()}</H1>
                    </MainHeadlineScrollable>
                </MainHeadline>
                {isServiceFailed && <ErrorInModule log={ERROR_LOG} />}
                <MainBody scrollClassName={cx(style.scrollCardBody)}>
                    <div className={cx(style.wrap)}>
                        <div className={cx(style.content)}>
                            {isServiceSucceeded && (
                                <Success validUntilDate={validUntilDate} reason={reason} isLoadedFromCookie={isLoadedFromCookie} />
                            )}
                            {!isServiceSucceeded && !isServiceFailed && <Lobby setReason={this.setReason} reason={reason} allow={this.allow} />}
                            <div className={cx('d-none d-xl-block mt-5')}>
                                <H3 className="mb-5">הערות</H3>
                                <List className={cx(style.list, 'text-secondary')} list={REMARKS} />
                            </div>
                        </div>
                    </div>
                </MainBody>
            </Fragment>
        );
    }
}

export default NoCardVisit;
