import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import style from './Lobby.scss';
import { H2, Card, CardText, Button, ButtonPicker, IconLoader } from '@maccabi/m-ui';
import cx from 'classnames';
import { RADIO_BUTTON_TEXT_VALUE, DEFAULT_REASON, LOG_ELEMENT_IN_PAGE } from '../constants';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';

@autobind
class Lobby extends Component {
    constructor(props) {
        super(props);
        this.state = {
            noneSelectedAndAllowButtonClicked: false,
            showLoader: false
        };
    }

    static propTypes = {
        reason: PropTypes.object.isRequired,
        setReason: PropTypes.func.isRequired,
        allow: PropTypes.func.isRequired
    };

    desktopOnReasonClicked(item) {
        const reason = item.value;
        const noneSelectedAndAllowButtonClicked = false;
        const log = reason.log;

        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage);
        this.props.setReason(reason);
        this.setState({ noneSelectedAndAllowButtonClicked });
    }

    responsiveOnReasonClicked(item) {
        const reason = item.value;
        const noneSelectedAndAllowButtonClicked = false;
        const log = reason.log;

        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage);
        this.props.setReason(reason);
        this.setState({ noneSelectedAndAllowButtonClicked }, () => this.allow());
    }

    handleAllowClick() {
        mLib.logs.insertCentralizedLog(1521, LOG_ELEMENT_IN_PAGE);
        this.allow();
    }

    allow() {
        const noneSelectedAndAllowButtonClicked = this.props.reason === DEFAULT_REASON;

        if (noneSelectedAndAllowButtonClicked) {
            this.setState({ noneSelectedAndAllowButtonClicked: true });
        } else {
            this.props.allow();
            this.setState({ showLoader: true });
        }
    }

    render() {
        const buttonPickerProps = {
            list: RADIO_BUTTON_TEXT_VALUE,
            color: this.state.noneSelectedAndAllowButtonClicked ? 'danger' : 'primary',
            className: 'mb-1',
            nameOfFieldToDisplay: 'text'
        };

        return (
            <Fragment>
                <Card visibility="inner" className={cx(style.lobby, 'mb-0 mb-lg-7')}>
                    <H2 className="mb-3" hook="h2">
                        {mLib.resources.getResource('directorship/NoCardVisit/Lobby', 'SubTitle', 'בחר סיבת הזמנת ביקור ללא כרטיס')}
                    </H2>
                    <CardText className="mb-7">
                        {mLib.resources.getResource(
                            'directorship/NoCardVisit/Lobby',
                            'Description',
                            'לאחר קבלת אישור יעמדו לרשותכם שלוש שעות לביצוע הביקור, לכן חשוב להפעיל את "קבלת האישור" קרוב ככל האפשר למועד הביקור.'
                        )}
                    </CardText>
                    <div data-hook='desktop' className={cx(style.wrapButton, 'd-none d-lg-flex')}>
                        <ButtonPicker onClick={this.desktopOnReasonClicked} {...buttonPickerProps} />
                    </div>
                    <div data-hook='responsive' className={cx(style.wrapButton, 'd-lg-none d-flex')}>
                        <ButtonPicker onClick={this.responsiveOnReasonClicked} {...buttonPickerProps} />
                    </div>
                    <div className={cx(style.valid)} data-hook="validation">
                        {this.state.noneSelectedAndAllowButtonClicked ? 'יש לבחור סיבה' : ''}
                    </div>
                    <div className="d-none d-xl-flex">
                        <Button color="primary" onClick={this.handleAllowClick} hook="ok">
                            {this.state.showLoader && <IconLoader size="sm" className={cx(style.iconLoader)} />}
                            {mLib.resources.getResource('directorship/NoCardVisit/Lobby', 'BtnApproval', 'לקבלת אישור')}
                        </Button>
                    </div>
                </Card>
            </Fragment>
        );
    }
}

export default Lobby;
