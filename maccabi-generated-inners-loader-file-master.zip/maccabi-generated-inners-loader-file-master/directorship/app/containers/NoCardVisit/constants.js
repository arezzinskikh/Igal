import mLib from '@maccabi/m-lib';
export const LOG_ELEMENT_IN_PAGE = 'directorship/NoCardVisit/Lobby';
export const ERROR_LOG = {
    elementId: 1525,
    actionId: process.env.LOG_ACTION_ID_SCREEN_OPEN,
    elementInPage: LOG_ELEMENT_IN_PAGE
};

export const RADIO_BUTTON_TEXT_VALUE = [
    {
        text: mLib.resources.getResource('directorship/NoCardVisit/Lobby','RadioButtonText_1','שכחתי כרטיס'),
        value: {
            code: 1,
            magneticCardText: "",
            log: {
                elementId: 1516,
                actionId: process.env.LOG_ACTION_ID_CLICK,
                elementInPage: LOG_ELEMENT_IN_PAGE
            }
        }
    },
    {
        text: mLib.resources.getResource('directorship/NoCardVisit/Lobby','RadioButtonText_2','הכרטיס אבד'),
        value: {
            code: 2,
            magneticCardText: "אבד",
            log: {
                elementId: 1517,
                actionId: process.env.LOG_ACTION_ID_CLICK,
                elementInPage: LOG_ELEMENT_IN_PAGE
            }
        }
    },
    {
        text: mLib.resources.getResource('directorship/NoCardVisit/Lobby','RadioButtonText_3','כרטיס לא תקין'),
        value: {
            code: 3,
            magneticCardText: "לא תקין",
            log: {
                elementId: 1518,
                actionId: process.env.LOG_ACTION_ID_CLICK,
                elementInPage: LOG_ELEMENT_IN_PAGE
            }
        }
    }, {
        text: mLib.resources.getResource('directorship/NoCardVisit/Lobby','RadioButtonText_4','הכרטיס נגנב'),
        value: {
            code: 4,
            magneticCardText: "נגנב",
            log: {
                elementId: 1519,
                actionId: process.env.LOG_ACTION_ID_CLICK,
                elementInPage: LOG_ELEMENT_IN_PAGE
            }
        }
    },
    {
        text: mLib.resources.getResource('directorship/NoCardVisit/Lobby','RadioButtonText_5','אחר'),
        value: {
            code: 5,
            magneticCardText: "",
            log: {
                elementId: 1520,
                actionId: process.env.LOG_ACTION_ID_CLICK,
                elementInPage: LOG_ELEMENT_IN_PAGE
            }
        }
    }
];
export const COOKIE_FORMAT = 'NoCardVisit_{0}_{1}';
export const COOKIE_EXPIRATION_TIME = 30;
export const DEFAULT_REASON = {};
export const MAGNETIC_CARD_LINK_RELEVANT_REASON_CODES = [2, 3, 4];
export const IS_ALLOWED = 'maccabi/directorship/nocardvisit/IS_ALLOWED';
export const SET_VALID_UNTIL_DATE = 'maccabi/directorship/nocardvisit/SET_VALID_UNTIL_DATE';
export const ALLOW = 'maccabi/directorship/nocardvisit/ALLOW';
export const SET_IS_SERVICE_FAILED = 'maccabi/directorship/nocardvisit/SET_IS_SERVICE_FAILED';
export const SET_REASON = 'maccabi/directorship/nocardvisit/SET_REASON';
export const ON_LOAD = 'maccabi/directorship/nocardvisit/ON_LOAD';
export const REMARKS = [
    'האישור תקף ל-14 שעות ונרשם במערכות מכבי',
    'האישור ניתן במסגרת זכויות חבר מכבי באופן זהה לביקור עם כרטיס (לביקורים להם היטל רבעוני ייגבה תשלום על פי דיווח הביקור על ידי הרופא או נותן שירות אחר)',
    'השימוש בשירות אינו מהווה את זימון וקביעת התור בפועל.',
    'לא תקף עבור בדיקות מעבדה.'
];
