export { default } from './NoCardVisit';
