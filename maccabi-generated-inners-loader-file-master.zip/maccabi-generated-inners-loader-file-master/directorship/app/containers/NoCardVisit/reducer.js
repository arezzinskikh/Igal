import { fromJS } from 'immutable';
import { IS_ALLOWED, ALLOW, DEFAULT_REASON, SET_VALID_UNTIL_DATE, SET_IS_SERVICE_FAILED, SET_REASON, ON_LOAD } from './constants';

export const initialState = fromJS({
    noCardVisitData: {
        validUntilDate: null,
        reason: DEFAULT_REASON,
        isServiceFailed: false
    }
});

export default function noCardVisitReducer(state = initialState, action) {
    let noCardVisitData = { ...state.get('noCardVisitData') };

    switch (action.type) {
        case ON_LOAD:
            return state.set('noCardVisitData', {
                validUntilDate: null,
                reason: DEFAULT_REASON,
                isServiceFailed: false
            });
        case IS_ALLOWED:
            return state;
        case ALLOW:
            return state;
        case SET_VALID_UNTIL_DATE:
            noCardVisitData.validUntilDate = action.validUntilDate;
            noCardVisitData.isLoadedFromCookie = action.isLoadedFromCookie;
            return state.set('noCardVisitData', noCardVisitData);
        case SET_IS_SERVICE_FAILED:
            noCardVisitData.isServiceFailed = action.isServiceFailed;
            return state.set('noCardVisitData', noCardVisitData);
        case SET_REASON:
            noCardVisitData.reason = action.reason;
            return state.set('noCardVisitData', noCardVisitData);
        default:
            return state;
    }
}
