import React, { Component, Fragment } from 'react';
//import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import autobind from 'autobind-decorator';
import style from './Biobank.scss';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import saga from './saga';
import reducer from './reducer';
import { H1, MainBody, MainHeadline, MainHeadlineScrollable, QuickLinks } from '@maccabi/m-ui';
import cx from 'classnames';
import { getBiobankStats, getBiobankMember } from './actions';
import { makeSelectStats, makeSelectBiobankMember } from './selectors';

// import Links from '../../components/Biobank/Links/Links';
import Researches from '../../components/Biobank/Researches/Researches';
import SamplesType from '../../components/Biobank/SamplesType/SamplesType';
import Carusel from '../../components/Biobank/Carusel/Carusel';
import Header from '../../components/Biobank/Header/Header';
import Table from '../../components/Biobank/Table/Table';

import format from 'string-format';

const mapDispatchToProps = dispatch => ({
    getBiobankStats: () => dispatch(getBiobankStats()),
    getBiobankMember: () => dispatch(getBiobankMember())
});

const mapStateToProps = createStructuredSelector({
    biobankStats: makeSelectStats,
    biobankMember: makeSelectBiobankMember
});

@mLib.appInfra.injectReducer({ key: 'biobankReducer', reducer })
@mLib.appInfra.injectSaga({ key: 'biobankSaga', saga })
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class Biobank extends Component {
    constructor(props) {
        super(props);

        this.props.getBiobankStats();
        this.props.getBiobankMember();

        let samplesType = this.getResourceByAlias('SamplesTypeItem');
        let researches = this.getResourceByAlias('ResearchItem');
        let links = this.getResourceByAlias('LinkItem');
        let carusel = this.getResourceByAlias('CaruselItem');

        this.state = {
            samplesType: samplesType,
            researches: researches,
            links: links,
            carusel: carusel,
            interactions: null
        };
    }

    getResourceByAlias(key) {
        const alias = 'directorship/biobank';
        let resources = JSON.parse(localStorage.getItem('resource'));
        let byAlias = resources.filter(res => res.alias.toLowerCase() === alias.toLowerCase());
        return byAlias.length > 0 ? byAlias.filter(res => res.key.startsWith(key)) : null;
    }

    getTitle() {
        const enrollment_status_code = !!this.props.biobankMember ? this.props.biobankMember.enrollment_status_code : 0;
        switch (enrollment_status_code) {
            case 0:
                return mLib.resources.getResource(
                    'directorship/biobank',
                    'Bionank_Title_EnrollmentStatusCode_0',
                    'תודה על התעניינותך במיזם טיפה למחקר'
                );
            case 1:
                return mLib.resources.getResource(
                    'directorship/biobank',
                    'Bionank_Title_EnrollmentStatusCode_1',
                    'תודה על הצטרפותך למיזם טיפה למחקר !'
                );
            case 2:
                return mLib.resources.getResource(
                    'directorship/biobank',
                    'Bionank_Title_EnrollmentStatusCode_2',
                    'תודה על התעניינותך במיזם טיפה למחקר'
                );
            case 3:
                return mLib.resources.getResource(
                    'directorship/biobank',
                    'Bionank_Title_EnrollmentStatusCode_2',
                    'תודה על התעניינותך במיזם טיפה למחקר'
                );
        }
    }

    openPdf(doc_id) {

        const memberData = mLib.saveData.customerData.get();
        const {hash, timestamp } = this.props.biobankMember;

        const webApiSuffix = format(
            process.env.WEB_API_URL_GET_BIOBANK_DOCUMENT,
            memberData.current_customer_info.member_id_code,
            memberData.current_customer_info.member_id,
            doc_id,
            hash,
            timestamp
        );
    
        const currentUrl = window.location.href;
        const danainfo = mLib.juniper.getDanaInfo(currentUrl);
        const pdfUrl = process.env.WEB_API_URL_DIRECTORSHIP + webApiSuffix + danainfo;

        mLib.openPdfNewTab.openPdfNewTab(pdfUrl, hash);
    }

    componentDidUpdate(prevProps) {
        if (prevProps.biobankMember !== this.props.biobankMember) {
            this.setState({
                interactions: this.props.biobankMember.interactions
            });
        }
    }

    render() {
        const isKosher = mLib.site.isKosher();
        const { carusel, samplesType, researches, links, interactions } = this.state;
        const statuses = [1, 2, 3];
        const enrollment_status_code = !!this.props.biobankMember ? this.props.biobankMember.enrollment_status_code : 0;

        let newLinks = [];
        links &&
            links.map(item => {
                let newItem = { Image: process.env.MEDIA_DOMAIN + item.value.Image, Link: item.value.Link, Title: item.value.Title };
                newLinks.push(newItem);
            });


        return (
            <Fragment>
                <MainHeadline>
                    <MainHeadlineScrollable className={cx(style.headline)}>
                        <H1 tag="h1" hook="title" className={cx(style.headlineText)}>
                            {this.getTitle()}
                        </H1>
                    </MainHeadlineScrollable>
                </MainHeadline>

                <MainBody layout="spread" className={cx(style.mainBody)} classNameScroll={cx(style.cardBody)}>
                    <Header biobankStats={this.props.biobankStats} />
                    {!!interactions && <Table interactions = {interactions} openPdf = {this.openPdf}/>}
                    {!!carusel && <Carusel carusel={carusel} />}
                    <div>
                        {!!samplesType && statuses.indexOf(enrollment_status_code) > -1 && <SamplesType samplesType={samplesType} />}
                        {!!researches && statuses.indexOf(enrollment_status_code) > -1 && <Researches researches={researches} />}
                        {!!newLinks && !isKosher && <QuickLinks className={cx(style.quickLinks)} list={newLinks} />}
                    </div>
                    <div className={cx(style.additionalText)}>
                        <div>{mLib.resources.getResource('directorship/biobank', 'Email_Title', 'לפרטים נוספים פנו אלינו במייל')}</div>
                        <a
                            className={cx(style.link)}
                            href={`mailto:${mLib.resources.getResource('directorship/biobank', 'Email_To', 'tipa@mac.org.il')}`}>
                            {mLib.resources.getResource('directorship/biobank', 'Email_To', 'tipa@mac.org.il')}
                        </a>
                    </div>
                </MainBody>
            </Fragment>
        );
    }
}

export default Biobank;
