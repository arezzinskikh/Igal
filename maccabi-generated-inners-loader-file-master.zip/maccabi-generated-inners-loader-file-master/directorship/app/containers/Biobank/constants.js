export const GET_BIOBANK_STATS = 'maccabi/directorship/letters/GET_BIOBANK_STATS';
export const SET_BIOBANK_STATS = 'maccabi/directorship/letters/SET_BIOBANK_STATS';

export const GET_BIOBANK_MEMBER= 'maccabi/directorship/letters/GET_BIOBANK_MEMBER';
export const SET_BIOBANK_MEMBER= 'maccabi/directorship/letters/SET_BIOBANK_MEMBER';