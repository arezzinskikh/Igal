import { GET_BIOBANK_STATS, SET_BIOBANK_STATS, GET_BIOBANK_MEMBER, SET_BIOBANK_MEMBER } from './constants';

export function getBiobankStats() {
    return {
        type: GET_BIOBANK_STATS
    };
}

export function setBiobankStats(data) {
    return {
        type: SET_BIOBANK_STATS,
        data
    };
}

export function getBiobankMember() {
    return {
        type: GET_BIOBANK_MEMBER
    };
}

export function setBiobankMember(data) {
    return {
        type: SET_BIOBANK_MEMBER,
        data
    };
}