import { takeLatest, call, put } from 'redux-saga/effects';
import mLib from '@maccabi/m-lib';
import { GET_BIOBANK_STATS, GET_BIOBANK_MEMBER } from './constants';
import { setBiobankStats, setBiobankMember } from './actions';
import { biobankStats, biobankMember } from '../../services/Biobank/apiService';

function* handleGetBiobankStats() {
    try {
        const result = yield call(biobankStats);

        yield put(setBiobankStats(result));
    } catch (err) {
        yield put(setBiobankStats(null));
    }
}

function* handleGetBiobankMember() {
    try {
        const memberData = mLib.saveData.customerData.get();
        const params = {
            member_id_code: memberData.current_customer_info.member_id_code,
            member_id: memberData.current_customer_info.member_id
        };
        const result = yield call(biobankMember, params);

        yield put(setBiobankMember(result));
    } catch (err) {
        yield put(setBiobankMember(null));
    }
}

export default function* rootSaga() {
    yield takeLatest(GET_BIOBANK_STATS, handleGetBiobankStats);
    yield takeLatest(GET_BIOBANK_MEMBER, handleGetBiobankMember);
}
