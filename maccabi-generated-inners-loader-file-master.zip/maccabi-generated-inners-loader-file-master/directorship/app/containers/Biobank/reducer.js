import { fromJS } from 'immutable';

import { SET_BIOBANK_STATS, SET_BIOBANK_MEMBER } from './constants';

const initialState = fromJS({
    biobankStats: null,
    biobankMember: null
});

export default function biobankReducer(state = initialState, action) {
    switch (action.type) {
        case SET_BIOBANK_STATS:
            return state.set('biobankStats', action.data);
        case SET_BIOBANK_MEMBER:
            return state.set('biobankMember', action.data);
        default:
            return state;
    }
}