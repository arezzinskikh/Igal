import {createSelector} from 'reselect';
import { initialState} from './reducer';

const selectBiobank = state => {
    return state.get('biobankReducer', initialState);
};

export const makeSelectStats = createSelector(selectBiobank, biobankStats => biobankStats.get('biobankStats'));

export const makeSelectBiobankMember = createSelector(selectBiobank, biobankMember => biobankMember.get('biobankMember'));