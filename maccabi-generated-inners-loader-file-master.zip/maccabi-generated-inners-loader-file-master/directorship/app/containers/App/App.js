import React from 'react';
import { Provider } from 'react-redux';
import Immutable from 'immutable';
import { ConnectedRouter } from 'connected-react-router/immutable';
import { ModuleRegistry } from 'react-module-container';
import mLib from '@maccabi/m-lib';
import configureStore from '../../configureStore';
import AppInner from '../AppInner';

const history = mLib.history;

const initialState = Immutable.Map();
const store = configureStore(initialState, history);
const App = props => {
    return (
        <Provider store={store}>
            <ConnectedRouter history={props.history}>
                <AppInner {...props} />
            </ConnectedRouter>
        </Provider>
    );
};

ModuleRegistry.registerComponent('DirectorshipApp', () => App);

export default App;
