import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectGlobalReducer = state => {
    return state.get('GlobalLoading', initialState);
}

export const selectGlobalLoader = createSelector(selectGlobalReducer, loader => {
    return loader.get('isGlobalLoading');
})

const selectBabyRegistrationReducer = state => {
    return state.get('babyRegistration', initialState);
};

export const selectFirstStepBabyInfoForm = createSelector(selectBabyRegistrationReducer, stepOne => {
    return stepOne.get('formFirstStep').toJS();
});

export const selectIsFirstStepFinished= createSelector(selectBabyRegistrationReducer, stepOne => {
    return stepOne.get('isFirstStepFinished');
});

export const selectEligibilityResponse = createSelector(selectBabyRegistrationReducer, stepOne => {
    return stepOne.get('eligibilityResponse');
});

export const selectSecondStepSavedForm = createSelector(selectBabyRegistrationReducer, stepTwo => {
    return stepTwo.get('formSecondStep').toJS();
});

export const selectIsSecondStepFinished= createSelector(selectBabyRegistrationReducer, stepTwo => {
    return stepTwo.get('isSecondStepFinished');
});

export const selectBabyRegistrationResponse = createSelector(selectBabyRegistrationReducer, registration => {
    return registration.get('registrationResponse');
});

export const selectCanContinueToConfirmationPage = createSelector(selectBabyRegistrationReducer, registration => {
    return registration.get('canContinueToConfirmationPage');
});

export const selectIsKeepStateOn = createSelector(selectBabyRegistrationReducer, registration => {
    return registration.get('keepState');
});