import mLib from '@maccabi/m-lib';

export const PAGE_ALIAS = 'directorship/BabyRegistration/';
export const SUMMARY_AND_REGISTRATION_PAGE_ALIAS = "directorship/BabyRegistration/RegistrationSummary/";

export const UPDATE_FORM_VALUE="directorship/BabyRegistration/UPDATE_FORM_VALUE";
export const UPDATE_FORM_ERROR="directorship/BabyRegistration/UPDATE_FORM_ERROR";
export const UPDATE_DEFAULT_VALUES="directorship/BabyRegistration/UPDATE_DEFAULT_VALUES";
export const CLEAN_FORM="directorship/BabyRegistration/CLEAN_FORM";
export const SET_RESET_STEPS = 'directorship/BabyRegistration/SET_RESET_STEPS'
export const GET_BABY_INSURANCE_ELIGIBILITY = 'directorship/BabyRegistration/GET_BABY_INSURANCE_ELIGIBILITY';
export const SAVE_BABY_ELIGIBILITY_RESPONSE = 'directorship/BabyRegistration/SAVE_BABY_ELIGIBILITY_RESPONSE';
export const UPDATE_INSURANCE_NOT_CHOSEN = 'directorship/BabyRegistration/UPDATE_INSURANCE_NOT_CHOSEN';
export const UPDATE_TERMS_OF_USE = 'directorship/BabyRegistration/UPDATE_TERMS_OF_USE'
export const SET_SECOND_STEP_FINISHED = 'directorship/BabyRegistration/RegistrationSummary/SET_SECOND_STEP_FINISHED';
export const REGISTER_BABY = 'directorship/BabyRegistration/RegistrationSummary/REGISTER_BABY';
export const SAVE_BABY_REGISTRATION_RESPONSE = 'directorship/BabyRegistration/RegistrationSummary/SAVE_BABY_REGISTRATION_RESPONSE';
export const KEEP_STATE = 'directorship/BabyRegistration/RegistrationSummary/KEEP_STATE';
export const RESET_STATE = 'directorship/BabyRegistration/RESET_STATE';

export const EDIT_INFORMATION_URL = '/directorship/EditInformation/Profile/';
export const MIN_AGE = 18;
export const NOT_ISRAELI_CITIZEN_CODE = ["9", 9, "09"];

export const FORM = {
    FIRST_PART: "formFirstStep", SECOND_PART: "formSecondStep", SURNAME: "babySurname", 
    FIRST_NAME: "babyFirstName", ID: "babyId", BIRTHDATE: "babyBirthDate", GENDER: "babyGender",
    TIME: "time", INSURANCE: "insurance", DISABILITY_INSURANCE: "disabilityInsurance", 
    TERMS_OF_USE_MY_MACCABI: "termsOfUseMyMaccabi",TERMS_OF_USE_MACCABI_GOLD:"termsOfUseMaccabiGold",
    KEREN_MACCABI: "kerenMaccabi"
}

export const GENDER_LIST = [
    {text: "תינוק", iconName: "baby-boy", value: 0 , valueName: "boy"}, 
    {text:"תינוקת", iconName: "baby-girl", value: 1, valueName: "girl"}
]

export const VALIDATION_ERRORS = { 
    babyGender: 'יש לסמן את מין הילוד',
    babyId: 'יש להזין 9 ספרות כולל ספרת ביקורת',
    babyBirthDate: 'ניתן לרשום תינוקות עד גיל 6 חודשים',
    time: "חובה לבחור מועד הצטרפות",
    termsOfUse: "חובה לאשר קריאת תנאי ההצטרפות",
    noError: ""
}

export const TERMS_OF_USE_INDEX_TO_TITLE = {
    0:"termsOfUseMyMaccabi",
    1:"termsOfUseMaccabiGold",
    termsOfUseMyMaccabi: 0,
    termsOfUseMaccabiGold: 1
}

export const ELIGIBILITY_RESPONSE_VALUES = {
    basicEligibilityStatus: "RegBasicEligibility",
    btlRequiredStatus: "BtlRequired",
    shabanEligibility: "ShabanEligibility",
    kerenMaccabiEligibility: "KerenMacEligibility",
    shabanFromDob: "ShabanFromDOB",
    IsFAddressValid: "IsFAddressValid"
}

export const SHABAN_NOT_CHOSEN_CODE_TO_API = "00";

export const ADDRESS_SECTION_ADDRESS_TYPES = {
    LIVING: {
        type: 'מ',
        status: 'מ'
    },
    MAIL: {
        type: 'ד',
        status: 'מ'
    },
    PERSONAL_MAIL: {
        type: 'ד',
        status: 'פ'
    }
};

export const shabanInsuranceTypes = [
    {   name: "myMaccabi",
        index:0,
        text: mLib.resources.getResource(PAGE_ALIAS, 'myMaccabi', 'תוכנית הביטוח המשלימה הטובה בישראל שנותנת מענה לכולנו.'),
        icon: mLib.resources.getResource(PAGE_ALIAS, 'myMaccabi_Icon', "my-maccabi"),
        link: mLib.resources.getResource(PAGE_ALIAS, 'myMaccabi_link', 'https://www.maccabi4u.co.il/373-he/Maccabi.aspx'),
        moreInfo: mLib.resources.getResource(PAGE_ALIAS, 'myMaccabi_moreInfo', 'למידע נוסף על מכבי שלי'),
        shabanTypeToApi: "07",
        moreInfoLog: {elementId: 4390, elementInPage: PAGE_ALIAS, actionId: 1343}
    },
    {
        name: "maccabiGold",
        index:1,
        text: mLib.resources.getResource(PAGE_ALIAS, 'maccabiGold', 'תוכנית הביטוח משלים המעניקה הטבות במגוון תחומים וטיפולים.'),
        icon: mLib.resources.getResource(PAGE_ALIAS, 'maccabiGold_Icon', "maccabi-gold"),
        link: mLib.resources.getResource(PAGE_ALIAS, 'maccabiGold_link', 'https://www.maccabi4u.co.il/431-he/Maccabi.aspx?TabId=2507_432'),
        moreInfo: mLib.resources.getResource(PAGE_ALIAS, 'maccabiGold_moreInfo', 'למידע נוסף על מכבי זהב'),
        shabanTypeToApi: "02",
        moreInfoLog: {elementId: 4391, elementInPage: PAGE_ALIAS, actionId: 1343}
    }

]

export const SURNAME_DEFAULT_VALUE = "מכבי";

export const STATIC_TXT = {
    BabyRegistrationTitle: mLib.resources.getResource(PAGE_ALIAS, 'BabyRegistrationTitle', 'רישום תינוק חדש'),
    BabyRegistrationDescription: mLib.resources.getResource(PAGE_ALIAS,'BabyRegistrationDescription',"ניתן לרשום באתר מכבי online תינוקות עד גיל 6 חודשים"),
    additionalInfoLinksText: mLib.resources.getResource(PAGE_ALIAS,'additionalInfoText',"מידע נוסף שעשוי לעניין אותך:"),
    additionalInfoLinks: [
        {
            text: mLib.resources.getResource(PAGE_ALIAS, 'birthgivingParentingWorkshop', 'סדנאות הורות ולידה'),
            link: "https://www.maccabi4u.co.il/20387-he/Maccabi.aspx"
        },
        {
            text: mLib.resources.getResource(PAGE_ALIAS, 'breastfeedingGuide', 'מדריך הנקה'),
            link: "https://www.maccabi4u.co.il/10324-he/Maccabi.aspx?TabId=10325_10326"
        },
        {
            text: mLib.resources.getResource(PAGE_ALIAS, 'tipatChalav', 'טיפת חלב'),
            link: "https://www.maccabi4u.co.il/5166-he/Maccabi.aspx"
        },
        {
            text: mLib.resources.getResource(PAGE_ALIAS, 'vaccinationsInfo', 'מידע נוסף על חיסונים'),
            link: "https://www.maccabi4u.co.il/10115-he/Maccabi.aspx"
        }
    ],
    
    title: {
        israeliCitizenOnly: mLib.resources.getResource(PAGE_ALIAS, 'israeliCitizenOnly', 'רישום תינוק אפשרי לתושב ישראל בלבד'),
        congratulations: mLib.resources.getResource(PAGE_ALIAS, 'congratulations', 'מכבי מאחלת לך מזל טוב!'),
        errorInProgress: mLib.resources.getResource(PAGE_ALIAS, 'errorInProgress', 'לצערנו לא ניתן להשלים את פעולת הרישום'),
    },

    subtitle: {
        forAdditionalInfo: mLib.resources.getResource(PAGE_ALIAS, 'forAdditionalInfo', 'לכל שאלה נוספת ניתן לפנות למוקד מכבי ב 3555* או למרכז הרפואי הקרוב'), 
        registerBabyAsMaccabiMember: mLib.resources.getResource(PAGE_ALIAS, 'registerBabyAsMaccabiMember', 'רישום התינוק כחבר מכבי'),
        canChooseInsurance: mLib.resources.getResource(PAGE_ALIAS, 'canChooseInsurance', 'ניתן לבחור כיסוי ביטוחי משלים'),
        notMust: mLib.resources.getResource(PAGE_ALIAS,'notMust', "(לא חובה)"),
        chooseTime: mLib.resources.getResource(PAGE_ALIAS,'chooseTime', "בחירת מועד הצטרפות"),
        needHOKtoJoin: mLib.resources.getResource(PAGE_ALIAS, 'needHOKtoJoin', 'על מנת להצטרף לכיסוי ביטוחי משלים, יש להסדיר הוראת קבע במרכז הרפואי הקרוב אליך'),
        noKerenMaccabi: mLib.resources.getResource(PAGE_ALIAS,'noKerenMaccabi', "רישום תינוק לשירות הנוסף יתאפשר רק כאשר אחד ההורים מבוטח בביטוח זה. להצטרפות ניתן לפנות למוקד 'מכבי ללא הפסקה' 3555* או למרכז הרפואי"),
        canNotChooseInsurance: mLib.resources.getResource(PAGE_ALIAS, 'canNotChooseInsurance', 'מועד הצטרפות')
    },
    
    button: {
        cleanForm: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'cleanForm', 'ניקוי טופס'),
            log: {
                elementId: 4361,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        },
        continueToInsuranceCoverage: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'continueToInsuranceCoverage', 'המשך לכיסוי ביטוחי'),
            log: {
                elementId: 4358,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        },
        returnBabyInfo: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'returnBabyInfo', 'חזרה לפרטי תינוק'),
            log: {
                elementId: 4375,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        },
        continueToApproveRegistration: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'continueToApproveRegistration', 'המשך לאישור רישום'),
            log: { 
                elementId: 4374,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        },
        termsOfUseBtn: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'termsOfUseBtn', "קראתי והבנתי את תנאי ההצטרפות"),
            log: { 
                closeBtn: 4396,
                primaryBtn: 4397,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        } 
    },

    maccabiDisability: {
        text: mLib.resources.getResource(PAGE_ALIAS, 'maccabiDisability', ' כיסוי מכבי סיעודי הכולל זכויות נרחבות למבוטח בעת מצב סיעודי.'),
        icon: mLib.resources.getResource(PAGE_ALIAS, 'maccabiDisability_Icon', "maccabi-siudi"),
        remark: mLib.resources.getResource(PAGE_ALIAS, 'maccabiDisability_remark', '(מכיוון שהינך במכבי, יש לך גם מכבי סיעודי)')
    },
  
    chooseTime: {
        startingBirthDate: {
            index: 0,
            text: mLib.resources.getResource(PAGE_ALIAS, 'startingBirthDate_Text', 'החל מתאריך הלידה'),
            remark: mLib.resources.getResource(PAGE_ALIAS, 'startingBirthDate_Remark', 'דמי הלידה ייגבו מתאריך הלידה'),

        },
        startingToday: {
            index: 1,
            text: mLib.resources.getResource(PAGE_ALIAS, 'startingToday_Text', 'החל מהיום'),
            remark: mLib.resources.getResource(PAGE_ALIAS, 'startingToday_Remark', 'על מנת לממש זכויות תידרש תקופת המתנה.'),
        }
    },

    termsOfUseMyMaccabi: {
        title: mLib.resources.getResource(PAGE_ALIAS, 'title', "לכבוד: שירותי הבריאות הנוספים"),
        body: [
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_1', '1 .אני/ו וילדי/נו הקטינים שפרטי/נו מפורטים בבקשת ההצטרפות מבקש/ים בזה להצטרף לשב“ן כמפורט לעיל.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_2', '2 .הנני/ו מצהיר/ים ומסכים/ים שבהיותי/נו חבר/ים זכאי/ים בשב“ן יחולו עלי/נו כל החובות והזכויות המפורטות בתקנון השב“ן, בנהלים ובהחלטות של מוסדותיהם המוסמכים כפי שהם קיימים ו/או כפי שהם יתוקנו או ישונו מזמן לזמן. אני/ו מתחייב/ים לקיים את הוראות התקנון, הנהלים וההחלטות כלשונן.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_3', '3 .הנני/ו מתחייב/ים לשלם לשב“ן ו/או לכל מי שהוסמך על ידם במועדים שייקבעו מעת לעת על ידם, בהתאמה, את דמי החבר שלי/נו ושל ילדי/נו הקטינים, וכן את התשלומים שיחולו עלי/נו בהתאם לתקנון השב“ן וכן נהליהם והחלטותיהם, כפי שיתקבלו מעת לעת על ידי מוסדותיהם המוסמכים.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_4', '4 .הנני/ו מייפה/ים את כוחה של מכבי, ישירות או באמצעות מוסדותיה, לקבל בשמי/נו ובמקומי/נו מידע שוטף מגורמים כלשהם וממאגרי מידע בכל הנוגע לפרטי/נו האישיים, ובכלל זה פרטיהם האישיים של ילדינו/נו הקטינים בנושאים שיוחלט עליהם מזמן לזמן ע“י מכבי ו/או שב“ן בהקשר לחברותי/נו, זכויותיי/נו וחובותיי/נו, וכן זכויות וחובות ילדי/נו הקטינים בהם או הנובע מכך.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_5', '5 .הריני/נו מצהיר/ים בזה שידוע לי/לנו כי זכויותיי/נו וזכויות ילדי/נו הקטינים הינן כפופות לתקופות המתנה כמפורט בתקנון השב“ן ונהליו.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_6', '6 .במקרה שאחליט/נחליט לבטל את הצטרפותי/נו לשב“ן, מכל סיבה שהיא, פטורים מכבי ו/או שב“ן מלהחזיר לי/ לנו את דמי החבר,אם יהיו שכבר שולמו על ידי/נו ו/או חלק מהם.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_7', '7. תינוק שיצורף למכבי שלי תוך 6 חודשים מיום לידתו והצירוף הוא רטרואקטיבי מיום הלידה, יהיה פטור מתקופת המתנה, כמשך תקופת חברותם של הוריו בתכנית. גביית דמי החבר תהא בהתאם למועד הצירוף.')}
        ],
        log: {elementId: 4394, elementInPage: PAGE_ALIAS, actionId: 1343}
    },
    
    termsOfUseMaccabiGold: {
        title: mLib.resources.getResource(PAGE_ALIAS, 'title', "לכבוד: שירותי הבריאות הנוספים"),
        body: [
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_1', '1 .אני/ו וילדי/נו הקטינים שפרטי/נו מפורטים בבקשת ההצטרפות מבקש/ים בזה להצטרף לשב“ן כמפורט לעיל.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_2', '2 .הנני/ו מצהיר/ים ומסכים/ים שבהיותי/נו חבר/ים זכאי/ים בשב“ן יחולו עלי/נו כל החובות והזכויות המפורטות בתקנון השב“ן, בנהלים ובהחלטות של מוסדותיהם המוסמכים כפי שהם קיימים ו/או כפי שהם יתוקנו או ישונו מזמן לזמן. אני/ו מתחייב/ים לקיים את הוראות התקנון, הנהלים וההחלטות כלשונן.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_3', '3 .הנני/ו מתחייב/ים לשלם לשב“ן ו/או לכל מי שהוסמך על ידם במועדים שייקבעו מעת לעת על ידם, בהתאמה, את דמי החבר שלי/נו ושל ילדי/נו הקטינים, וכן את התשלומים שיחולו עלי/נו בהתאם לתקנון השב“ן וכן נהליהם והחלטותיהם, כפי שיתקבלו מעת לעת על ידי מוסדותיהם המוסמכים.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_4', '4 .הנני/ו מייפה/ים את כוחה של מכבי, ישירות או באמצעות מוסדותיה, לקבל בשמי/נו ובמקומי/נו מידע שוטף מגורמים כלשהם וממאגרי מידע בכל הנוגע לפרטי/נו האישיים, ובכלל זה פרטיהם האישיים של ילדינו/נו הקטינים בנושאים שיוחלט עליהם מזמן לזמן ע“י מכבי ו/או שב“ן בהקשר לחברותי/נו, זכויותיי/נו וחובותיי/נו, וכן זכויות וחובות ילדי/נו הקטינים בהם או הנובע מכך.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_5', '5 .הריני/נו מצהיר/ים בזה שידוע לי/לנו כי זכויותיי/נו וזכויות ילדי/נו הקטינים הינן כפופות לתקופות המתנה כמפורט בתקנון השב“ן ונהליו.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_6', '6 .במקרה שאחליט/נחליט לבטל את הצטרפותי/נו לשב“ן, מכל סיבה שהיא, פטורים מכבי ו/או שב“ן מלהחזיר לי/ לנו את דמי החבר,אם יהיו שכבר שולמו על ידי/נו ו/או חלק מהם.')},
            {text: mLib.resources.getResource(PAGE_ALIAS, 'sentence_7', '7 .תינוק שיצורף לתכניות הביטוחים המשלימים תוך 6 חודשים מיום לידתו, והצירוף הוא רטרואקטיבי מיום הלידה, יהיה פטור מתקופת המתנה, כמשך תקופת חברותם של הוריו בתכנית הרלבנטית. גביית דמי החבר תהא בהתאם למועד הצירוף.')}
        ],
        log: {elementId: 4395, elementInPage: PAGE_ALIAS, actionId: 1343}
    },

    kerenMaccabi: {
        text: mLib.resources.getResource(PAGE_ALIAS, 'kerenMaccabi_Text', 'הצטרפות לקרן מכבי'),
        remark: mLib.resources.getResource(PAGE_ALIAS, 'kerenMaccabi_Remark', 'עמותה הפועלת לצידה של ״מכבי״ ועוסקת בתחום רווחת חברי ״מכבי״'),
    }

};