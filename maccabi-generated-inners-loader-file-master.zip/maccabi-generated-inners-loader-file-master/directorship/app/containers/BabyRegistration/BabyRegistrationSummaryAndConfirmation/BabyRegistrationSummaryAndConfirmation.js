import React, { Component,Fragment } from 'react';
import { withRouter,Redirect }from 'react-router-dom';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import {H1, MainBody, MainHeadline, MainHeadlineScrollable} from '@maccabi/m-ui';

import style from './BabyRegistrationSummaryAndConfirmation.scss'

import {STATIC_TXT,EDIT_INFORMATION_URL} from '../constants';
import {SUMMARY_STATIC_TXT} from './constants';
import {STATIC_TXT_MODALS} from '../../../components/BabyRegistration/BabyRegistrationModal/constants';
import {selectFirstStepBabyInfoForm, selectSecondStepSavedForm, 
    selectIsFirstStepFinished,selectEligibilityResponse, selectIsSecondStepFinished,
    selectBabyRegistrationResponse,selectIsKeepStateOn,selectCanContinueToConfirmationPage} from '../selectors';
import {registerBaby,keepStateAfterAddressRedirect,getBabyInsuranceEligibility} from '../actions';
import {getAddressToPresent} from '../utils';
import AdditionalInfoLinks from '../../../components/BabyRegistration/AdditionalInfoLinks/AdditionalInfoLinks';
import Summary from '../../../components/BabyRegistration/SummaryAndConfirmation/Summary/Summary';
import Confirmation from '../../../components/BabyRegistration/SummaryAndConfirmation/Confirmation/Confirmation';
import BabyRegistrationModal from '../../../components/BabyRegistration/BabyRegistrationModal/BabyRegistrationModal';
import { insertLog } from '../logFile';

const mapDispatchToProps = (dispatch) => ({
    registerBaby: (payload) => dispatch(registerBaby(payload)),
    keepStateAfterAddressRedirect: (bool) => dispatch(keepStateAfterAddressRedirect(bool)),
    getBabyInsuranceEligibility: (payload) => dispatch(getBabyInsuranceEligibility(payload))
});

const mapStateToProps = createStructuredSelector({
    firstStepSavedForm: selectFirstStepBabyInfoForm,
    secondStepSavedForm: selectSecondStepSavedForm,
    isFirstStepFinished: selectIsFirstStepFinished,
    eligibilityResponse: selectEligibilityResponse,
    isSecondStepFinished: selectIsSecondStepFinished,
    ragistrationResponse: selectBabyRegistrationResponse,
    isAfterAddressChange: selectIsKeepStateOn,
    canContinueToConfirmationPage: selectCanContinueToConfirmationPage
});
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class BabyRegistrationSummaryAndConfirmation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            addressToPresent: getAddressToPresent(),
            showWrongAddressModal: false
        }
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        const {isAfterAddressChange,keepStateAfterAddressRedirect,getBabyInsuranceEligibility,firstStepSavedForm} = this.props;
        this.setRouteLeavingGuard();
        if (isAfterAddressChange) {
            keepStateAfterAddressRedirect(false);
            getBabyInsuranceEligibility(firstStepSavedForm.babyId.value)
        }
    }

    setRouteLeavingGuard =()=> {
        const propsLeaving = {
            shouldBlockNavigation: true,
            navigate: this.props.history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    goBackToFillRegistrationForm(){
        this.turnOffRouteLeavingGuard();
        setTimeout(() => {
            this.props.history.push("/directorship/BabyRegistration/")
        }, 50);
    }

    approveRegistration(){
        const log = SUMMARY_STATIC_TXT?.button?.approveRegistration?.log;
        log && insertLog(log)
   
        this.turnOffRouteLeavingGuard();
        const {eligibilityResponse,firstStepSavedForm,secondStepSavedForm,registerBaby} = this.props;
        setTimeout(() => {
            if (eligibilityResponse && !eligibilityResponse.isAddressValidInResponse) {
                this.setState({showWrongAddressModal: true})
            } else {
                registerBaby({...firstStepSavedForm,...secondStepSavedForm})
            }
        }, 50);
    }

    turnOffRouteLeavingGuard =()=> {
        const propsLeaving = {
            shouldBlockNavigation: false,
            navigate: this.props.history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }

    onContinueToApproveRegistrationAfterModal(){
        const {firstStepSavedForm,secondStepSavedForm,registerBaby} = this.props;
        this.setState({showWrongAddressModal: false},
        () => registerBaby({...firstStepSavedForm,...secondStepSavedForm}))
    }

    onContinueToChangeAddress() {
        const log = SUMMARY_STATIC_TXT?.button?.changeAddress?.log;
        log && insertLog(log)

        this.props.keepStateAfterAddressRedirect(true);
        this.turnOffRouteLeavingGuard();
        setTimeout(() => {
            /* Preform after a little timeout so setting route leaving guard off will take effect */
            this.props.history.push({
                pathname: mLib.url.getUrlByVersion(1, EDIT_INFORMATION_URL),
                search: `?returnUrl=${encodeURIComponent(this.props.history.location.pathname)}`
            });
        }, 50);
    }

    render() {  
        const {firstStepSavedForm,secondStepSavedForm,eligibilityResponse,ragistrationResponse,
            isSecondStepFinished,isFirstStepFinished,canContinueToConfirmationPage} = this.props;
        const isAddressValid = eligibilityResponse && eligibilityResponse.isAddressValidInResponse;
        const {showWrongAddressModal,addressToPresent} = this.state;
        if (!isSecondStepFinished || !isFirstStepFinished) { 
            return <Redirect to="/directorship/BabyRegistration/"/> 
        }

        const mutualProps = {
            firstStepSavedForm,
            secondStepSavedForm,
            isAddressValid,
            addressToPresent,
            chosenShabanInsurance: secondStepSavedForm.insurance.value > -1,
            chosenStartDate: secondStepSavedForm.time.value > -1 ? secondStepSavedForm.time.value : STATIC_TXT.chooseTime.startingToday.index
        }

        return (
            <Fragment>

                <MainHeadline className={style.headlineSummaryAndSuccessPage}>
                    <MainHeadlineScrollable>
                        <H1 className={style.headlineTitle} hook="BabyRegistrationTitle">{STATIC_TXT.BabyRegistrationTitle}</H1>
                    </MainHeadlineScrollable>
                </MainHeadline>

                <MainBody layout="spread" className={style.mainBody}>

                    <BabyRegistrationModal isOpen={showWrongAddressModal}
                    modalName={STATIC_TXT_MODALS.addressNotValid.name} 
                    primaryBtnClick={this.onContinueToApproveRegistrationAfterModal}
                    onToggle={() => this.setState({showWrongAddressModal:false})}
                    secondaryBtnClick={this.onContinueToChangeAddress}/>
                
                    <p className={style.description}>{STATIC_TXT.BabyRegistrationDescription}</p>

                    <AdditionalInfoLinks/>

                    <div className={style.registrationSummaryAndSuccessCard}>
                        {!canContinueToConfirmationPage && 
                            <Summary {...mutualProps}
                                approveRegistration={this.approveRegistration}
                                goBackToFillRegistrationForm={this.goBackToFillRegistrationForm}
                                onContinueToChangeAddress = {this.onContinueToChangeAddress}
                            />
                        }
                        
                        {ragistrationResponse && canContinueToConfirmationPage &&
                            <Confirmation {...mutualProps}/>
                        }
                    </div>
    
                </MainBody>   

            </Fragment>
        );
    }
}

export default withRouter(BabyRegistrationSummaryAndConfirmation);