import mLib from '@maccabi/m-lib';

export const PAGE_ALIAS = 'directorship/BabyRegistration/RegistrationSummary';
export const LOG_ELEMENT_IN_PAGE = PAGE_ALIAS;

export const INSURANCE = {
    "0": "myMaccabi",
    "1": "maccabiGold"
}

export const REGISTRATION_RESPONSE_VALUES = {
    registrationStatus: "RegStatus",
    shabanStatus: "ShabanStatus",
    kerenMaccabiStatus: "KerenStatus",
    magneticCardsStatus: "MCardStatus",
}

export const SUMMARY_STATIC_TXT = {
    SummaryPageTitleBoy: mLib.resources.getResource(PAGE_ALIAS, 'SummaryPageTitleBoy', 'סיכום בקשה לרישום תינוק חדש'),
    SummaryPageTitleGirl: mLib.resources.getResource(PAGE_ALIAS, 'SummaryPageTitleGirl', 'סיכום בקשה לרישום תינוקת חדשה'),
    SuccessPageTitle: mLib.resources.getResource(PAGE_ALIAS, 'SuccessPageTitle', 'תהליך הרישום הסתיים בהצלחה עבור '),
    SuccessPageDisclaimer: mLib.resources.getResource(PAGE_ALIAS, 'SuccessPageTitle', '*כניסה לפרטי התינוקת דרך ההורה תתאפשר תוך 24 שעות מהשלמת הרישום'),
    subtitle: {
        failMessage: mLib.resources.getResource(PAGE_ALIAS, 'failMessage', 'ניתן לפנות למוקד מכבי ללא הפסקה 3555* או למרכז הרפואי'),
        magneticCardsFailRemark: mLib.resources.getResource(PAGE_ALIAS, 'magneticCardsFailRemark', 'אנא פנה למוקד מכבי ללא הפסקה ב 3555*'),
        selectedInsurance: mLib.resources.getResource(PAGE_ALIAS, 'selectedInsurance', 'כיסוי ביטוחי משלים נבחר'), 
        selectedInsuranceFail: mLib.resources.getResource(PAGE_ALIAS, 'selectedInsuranceFail', 'תהליך הרישום לכיסוי ביטוחי משלים נכשל'), 
        selectedDate: mLib.resources.getResource(PAGE_ALIAS, 'selectedDate', 'תאריך הצטרפות: החל מתאריך '),
        kerenMaccabiFail: mLib.resources.getResource(PAGE_ALIAS, 'kerenMaccabiFail', 'תהליך הרישום לקרן מכבי נכשל'),
        magneticCards: mLib.resources.getResource(PAGE_ALIAS,'magneticCards', "זוג כרטיסים מגנטיים ישלחו לכתובת"),
        magneticCardsFail: mLib.resources.getResource(PAGE_ALIAS,'magneticCardsFail', "בקשת ההנפקה לכרטיסים מגנטיים נכשלה"),
        addressNotValid: mLib.resources.getResource(PAGE_ALIAS,'addressNotValid', "על מנת לקבל כרטיסים מגנטיים, יש לעדכן את הכתובת במכבי"),
        emailConfirmation: mLib.resources.getResource(PAGE_ALIAS,'emailConfirmation', 'אישור הצטרפות נשלח לדוא״ל שלך'),
    },
    button: {
        returnToEditRegistration: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'returnToEditRegistration', 'חזרה לעריכת רישום')
        },
        approveRegistration: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'approveRegistration', 'אישור רישום'),
            log: { 
                elementId: 4379,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        },
        changeAddress: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'changeAddress', 'לעדכון כתובת'),
            log: { 
                elementId: 4378,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        },
        finish: {
            text: mLib.resources.getResource(PAGE_ALIAS, 'finish', 'סיום'),
            log: { 
                elementId: 4387,
                elementInPage: PAGE_ALIAS,
                actionId: 1343
            }
        }
    }
}