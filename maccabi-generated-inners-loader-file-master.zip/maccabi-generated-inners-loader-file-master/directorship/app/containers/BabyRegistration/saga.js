import { takeLatest, call, put } from 'redux-saga/effects';
import mLib from '@maccabi/m-lib';

import {GET_BABY_INSURANCE_ELIGIBILITY,REGISTER_BABY} from './constants';
import {saveBabyRegistrationResponse,saveBabyEligibilityResponse} from './actions';
import {getInfantEligibility,infantRegistration} from '../../services/BabyRegistration/apiService';
import {REGISTRATION_RESPONSE_VALUES} from './BabyRegistrationSummaryAndConfirmation/constants';
import {getRegistrationResponseFieldValue,getWantedValuesObjFromRegistrationResponse,getWantedValuesObjFromEligibilityResponse} from './utils';

const { setGlobalLoading } = mLib.saveData.globalLoader;
const { setGlobalErrorPopup } = mLib.saveData.globalErrorPopup;

function* handleInsuranceEligibility(action) {
    yield call(setGlobalLoading,true);
    const memberData = mLib.saveData.customerData.get();
    try{
        const data = {
            babyId: action.babyId,
            member_id:memberData.current_customer_info.member_id,
            member_id_code:memberData.current_customer_info.member_id_code
        }
        const result = yield call(getInfantEligibility,data);
        if (!result.values || !result.values.length) {
            yield call(setGlobalErrorPopup, true);
        } else {
            const eligibilityResponse = yield call(getWantedValuesObjFromEligibilityResponse,result.values)
            yield put(saveBabyEligibilityResponse(eligibilityResponse));
        }
    }catch(e){
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading,false);
    }
}

function* handleRegisterBaby(action) {
    yield call(setGlobalLoading,true);
    const memberData = mLib.saveData.customerData.get();
    try{
        const data = {
            ...action.data,
            member_id:memberData.current_customer_info.member_id,
            member_id_code:memberData.current_customer_info.member_id_code
        }
        const result = yield call(infantRegistration,data);
        if (result.statuses && result.statuses.length && getRegistrationResponseFieldValue(result.statuses,REGISTRATION_RESPONSE_VALUES.registrationStatus) === "01") {
            const registrationResponse = yield call(getWantedValuesObjFromRegistrationResponse,result.statuses)
            yield put(saveBabyRegistrationResponse(registrationResponse));
        } else {
            yield call(setGlobalErrorPopup, true);
        }
    }catch(e){
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading,false);
    }
}

export default function* rootSaga() {
    yield [
        takeLatest(GET_BABY_INSURANCE_ELIGIBILITY,handleInsuranceEligibility),
        takeLatest(REGISTER_BABY,handleRegisterBaby)
    ];
}