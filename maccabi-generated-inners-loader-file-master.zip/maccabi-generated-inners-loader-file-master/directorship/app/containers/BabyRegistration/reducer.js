import { fromJS } from 'immutable';
import {
    UPDATE_FORM_VALUE,
    UPDATE_FORM_ERROR,
    CLEAN_FORM,
    UPDATE_DEFAULT_VALUES,
    SAVE_BABY_ELIGIBILITY_RESPONSE,
    UPDATE_INSURANCE_NOT_CHOSEN,
    UPDATE_TERMS_OF_USE,
    SAVE_BABY_REGISTRATION_RESPONSE,
    SET_SECOND_STEP_FINISHED,
    SET_RESET_STEPS,
    KEEP_STATE,
    RESET_STATE
} from './constants';

const initialState = fromJS({
    formFirstStep: {
        babyFirstName: {value: "",error: "", mustEnterField: false, default:""},
        babySurname: {value: "",error: "", mustEnterField: false, default:""},
        babyId: {value: "",error: "", mustEnterField: true},
        babyBirthDate: {value: "", error: "", mustEnterField: true},
        babyGender: {value: "", error: "", mustEnterField: true},
    },
    formSecondStep: {
        insurance: {value: -1},
        time: {value: -1, error: ""},
        disabilityInsurance: {value: 0, error: ""},
        kerenMaccabi: {value: false, error: ""},
        termsOfUseMyMaccabi: {value: false, error: ""},
        termsOfUseMaccabiGold: {value: false, error: ""}
    },
    eligibilityResponse: null,
    isFirstStepFinished: false,
    isSecondStepFinished:false,
    canContinueToConfirmationPage: false,
    keepState: false,
    registrationResponse: null,
});

export default function babyRegistrationReducer(state = initialState, action) {
    switch (action.type) {
        case UPDATE_FORM_VALUE: 
            return state.setIn([action.formPart,action.field, 'value'], action.value)
        case UPDATE_FORM_ERROR: 
            return state.setIn([action.formPart,action.field, 'error'], action.value)
        case UPDATE_DEFAULT_VALUES: 
            return state.setIn([action.formPart,action.field, 'default'], action.value)
        case CLEAN_FORM:
            return state
                    .setIn(['formFirstStep', 'babyFirstName'], {value: "",error: "", mustEnterField: false})
                    .setIn(['formFirstStep', 'babySurname'], {value: "",error: "", mustEnterField: false})
                    .setIn(['formFirstStep', 'babyId'], {value: "",error: "", mustEnterField: true})
                    .setIn(['formFirstStep', 'babyBirthDate'], {value: "",error: "", mustEnterField: true})
                    .setIn(['formFirstStep', 'babyGender'], {value: "",error: "", mustEnterField: true})                
                    .setIn(['formSecondStep', 'insurance'], {value: -1})
                    .setIn(['formSecondStep', 'time'], {value: -1,error: ""})
                    .setIn(['formSecondStep', 'disabilityInsurance'], {value: 0,error: ""})
                    .setIn(['formSecondStep', 'kerenMaccabi'], {value: false,error: ""})
                    .setIn(['formSecondStep', 'termsOfUseMyMaccabi'], {value: false,error: ""})
                    .setIn(['formSecondStep', 'termsOfUseMaccabiGold'], {value: false,error: ""})
        case SAVE_BABY_ELIGIBILITY_RESPONSE:
            const {eligibilityResponse} = action;
            return state
                .set('eligibilityResponse', eligibilityResponse)
                .set('isFirstStepFinished',true)
        case UPDATE_INSURANCE_NOT_CHOSEN: 
            return state   
                    .setIn(['formSecondStep', 'time', 'value'], -1)
                    .setIn(['formSecondStep', 'termsOfUseMyMaccabi', 'value'], false)
                    .setIn(['formSecondStep', 'termsOfUseMaccabiGold', 'value'], false)
                    .setIn(['formSecondStep', 'termsOfUseMyMaccabi', 'error'], "")
                    .setIn(['formSecondStep', 'termsOfUseMaccabiGold', 'error'], "")
                    .setIn(['formSecondStep', 'time', 'error'], "")
        case UPDATE_TERMS_OF_USE:
            return state
                    .setIn(['formSecondStep', 'termsOfUseMyMaccabi', 'value'], false)
                    .setIn(['formSecondStep', 'termsOfUseMaccabiGold', 'value'], false)
                    .setIn(['formSecondStep', 'termsOfUseMyMaccabi', 'error'], "")
                    .setIn(['formSecondStep', 'termsOfUseMaccabiGold', 'error'], "")
        case SET_RESET_STEPS:
            return state
                    .set('isFirstStepFinished', false)
                    .set('isSecondStepFinished', false)
                    .set('canContinueToConfirmationPage', false);
        case SET_SECOND_STEP_FINISHED:
            return state.set('isSecondStepFinished', true);
        case SAVE_BABY_REGISTRATION_RESPONSE:
            const {regiResponse} = action;
            return state
                    .set('registrationResponse', regiResponse)
                    .set('canContinueToConfirmationPage', true)
        case KEEP_STATE: 
            return state.set('keepState', action.bool)
        case RESET_STATE:
            return state = initialState
        default:
            return state;
    }
}