import React, { Component,Fragment } from 'react';
import { withRouter }from 'react-router-dom';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import {H1, MainBody, MainHeadline,MainHeadlineScrollable} from '@maccabi/m-ui';

import style from './BabyRegistrationForm.scss';
import {STATIC_TXT,MIN_AGE,NOT_ISRAELI_CITIZEN_CODE} from '../constants';
import AdditionalInfoLinks from '../../../components/BabyRegistration/AdditionalInfoLinks/AdditionalInfoLinks';
import FillRegistrationForm from '../../../components/BabyRegistration/FillRegistrationForm/FillRegistrationForm';
import IsraeliCitizenMessage from '../../../components/BabyRegistration/IsraeliCitizenMessage/IsraeliCitizenMessage';

@autobind
class BabyRegistrationForm extends Component {

    componentDidMount() {
        const memberData = mLib.saveData.customerData.get();
        const currentCustomerAge = memberData.current_customer_info.age.years
        if (currentCustomerAge < MIN_AGE) { 
            const url = mLib.url.getUrlByVersion(2, '/home');
            this.props.history.push(`/go/${encodeURIComponent(url)}`);
        }
    }

    sectionToDisplay() {
        const memberData = mLib.saveData.customerData.get();
        const {member_id_code} = memberData.logged_customer_info;
        if (NOT_ISRAELI_CITIZEN_CODE.includes(member_id_code)) return <IsraeliCitizenMessage/>;
        return <FillRegistrationForm/>
    }

    render() {  
        return (
            <Fragment>
                <MainHeadline>
                    <MainHeadlineScrollable className={style.babyRegisterHeadline}>
                        <H1 className={style.headlineTitle} hook="BabyRegistrationTitle">{STATIC_TXT.BabyRegistrationTitle}</H1>
                    </MainHeadlineScrollable>
                </MainHeadline>

                <MainBody layout="spread" className={style.mainBody}>
                    <p className={style.description}>{STATIC_TXT.BabyRegistrationDescription}</p>
                    <AdditionalInfoLinks/>
                    {this.sectionToDisplay()}
                </MainBody>      
            </Fragment>
        );
    }
}

export default withRouter(BabyRegistrationForm);