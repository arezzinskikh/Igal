import {
    STATIC_TXT,
    UPDATE_FORM_ERROR,
    UPDATE_FORM_VALUE,
    UPDATE_DEFAULT_VALUES,
    GET_BABY_INSURANCE_ELIGIBILITY,
    SAVE_BABY_ELIGIBILITY_RESPONSE,
    UPDATE_INSURANCE_NOT_CHOSEN,
    UPDATE_TERMS_OF_USE,
    SET_SECOND_STEP_FINISHED,
    SET_RESET_STEPS,
    REGISTER_BABY,
    SAVE_BABY_REGISTRATION_RESPONSE,
    KEEP_STATE,
    RESET_STATE,
    CLEAN_FORM
} from './constants';
import {insertLog} from './logFile'

export function updateFormValue(field,value,formPart) {
    return{
        type: UPDATE_FORM_VALUE,
        formPart,
        field,
        value
    }
}

export function updateFormError(field,value,formPart) {
    return{
        type: UPDATE_FORM_ERROR,
        formPart,
        field,
        value
    }
}

export function updateDefaultValues(field,value,formPart) {
    return{
        type: UPDATE_DEFAULT_VALUES,
        formPart,
        field,
        value
    }
}

export function updateInsuranceNotChosen() {
    return{
        type: UPDATE_INSURANCE_NOT_CHOSEN,
    }
}

export function updateTermsOfUse() {
    return {
        type: UPDATE_TERMS_OF_USE
    }
}

export function cleanForm() {
    const log = STATIC_TXT?.button?.cleanForm?.log;
    log && insertLog(log)
    return{
        type: CLEAN_FORM
    }
}

export function getBabyInsuranceEligibility(babyId) {
    return{
        type: GET_BABY_INSURANCE_ELIGIBILITY,
        babyId
    }
}


export function saveBabyEligibilityResponse(eligibilityResponse){
    return{
        type:SAVE_BABY_ELIGIBILITY_RESPONSE,
        eligibilityResponse
    }
}


export function setSecondStepFinished(){
    return{
        type: SET_SECOND_STEP_FINISHED
    }
}

export function registerBaby(data) {
    return{
        type: REGISTER_BABY,
        data
    }
}

export function setResetSteps() {
    return {
        type: SET_RESET_STEPS
    }
}

export function saveBabyRegistrationResponse(regiResponse){
    return{
        type:SAVE_BABY_REGISTRATION_RESPONSE,
        regiResponse
    }
}

export function keepStateAfterAddressRedirect(bool){
    return{
        type:KEEP_STATE,
        bool
    }
}

export function resetState(){
    return{
        type: RESET_STATE
    }
}