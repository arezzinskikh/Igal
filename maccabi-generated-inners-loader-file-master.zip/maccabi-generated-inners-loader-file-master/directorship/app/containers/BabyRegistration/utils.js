import mLib from '@maccabi/m-lib';

import {ADDRESS_SECTION_ADDRESS_TYPES,ELIGIBILITY_RESPONSE_VALUES} from './constants';
import {REGISTRATION_RESPONSE_VALUES} from "./BabyRegistrationSummaryAndConfirmation/constants";


export const getEligibilityFieldValue = (eligibilityValueArray,wantedField) => {
    return eligibilityValueArray.filter(field => field.field_name === wantedField)[0].field_value;
}

export const getWantedValuesObjFromEligibilityResponse = (response) => {
    let obj = {}

    for (const [key, value] of Object.entries(ELIGIBILITY_RESPONSE_VALUES)) {
        const recievedValue = getEligibilityFieldValue(response,value)
        obj[key] = recievedValue;
    }   

    const wantedValuesObj = {
        kerenMaccabiActive: obj.kerenMaccabiEligibility === "01",
        activeHokScreen: (obj.shabanEligibility === "01" || obj.kerenMaccabiEligibility === "01") && (obj.basicEligibilityStatus === "01"),
        canChooseTime: obj.shabanFromDob === "1",
        isAddressValidInResponse: obj.IsFAddressValid === "0",
        values: response,
        ...obj
    }
    return wantedValuesObj;
}

const getAddress = (addresses, addressStatus, addressType) => {
    return addresses && addresses.find(adr => adr.address_status === addressStatus && adr.address_type === addressType);
}

const withPO = (address) => {
    const {po_box,city_name} = address;
    const cityName = city_name ? ', ' + city_name : ""
    return `ת.ד: ${po_box}${cityName}`
}

const withoutPO = (address) => {
    const {house_num,street_name,apartment_num,entrance,city_name} = address;
    const getApartment = () => {
        let apt = ""
        if (apartment_num && entrance) {
            return "דירה " + apartment_num + ","
        } else if (apartment_num) {
            return "דירה " + apartment_num
        }
        return apt 
    } 
    const getEntrance = () => {
        let ent = ""
        if (entrance && city_name) {
            return "כניסה " + entrance + ","
        } else if (entrance) {
            return "כניסה " + entrance
        }
        return ent
    }
    return `${street_name} ${house_num} ${getApartment()} ${getEntrance()} ${city_name}`
}

export const getAddressToPresent = () => {
    let addressToPresent="";
    const memberData = mLib.saveData.customerData.get();   
    const addresses = memberData.current_customer_info.addresses;

    const personalMailAddress = getAddress(addresses, ADDRESS_SECTION_ADDRESS_TYPES.PERSONAL_MAIL.status, ADDRESS_SECTION_ADDRESS_TYPES.PERSONAL_MAIL.type);
    const mailAddress = getAddress(addresses, ADDRESS_SECTION_ADDRESS_TYPES.MAIL.status, ADDRESS_SECTION_ADDRESS_TYPES.MAIL.type);
    const livingAddress = getAddress(addresses, ADDRESS_SECTION_ADDRESS_TYPES.LIVING.status, ADDRESS_SECTION_ADDRESS_TYPES.LIVING.type);

    if (personalMailAddress) {
        const {po_box} = personalMailAddress;
        addressToPresent = (!po_box || po_box === "0") ? withoutPO(personalMailAddress) : withPO(personalMailAddress)
    } else if (mailAddress) {
        const {po_box} = mailAddress;
        addressToPresent = (!po_box || po_box === "0") ? withoutPO(mailAddress) : withPO(mailAddress)
    } else {
        addressToPresent = withoutPO(livingAddress)
    }
    return addressToPresent
}

export const getRegistrationResponseFieldValue = (registrationObjArray,wantedField) => {
    return registrationObjArray.filter(field => field.name === wantedField)[0].value;
}

export const getWantedValuesObjFromRegistrationResponse = (response) => {
        let obj = {}

        for (const [key, value] of Object.entries(REGISTRATION_RESPONSE_VALUES)) {
            const recievedValue = getRegistrationResponseFieldValue(response,value)
            obj[key] = recievedValue;
        }   

        const wantedValuesObj = {
            shabanRegistrationFailed: obj.shabanStatus !== "01",
            kerenMaccabiRegistrationFailed: obj.kerenMaccabiStatus !== "01",
            magneticCardsFailed: obj.magneticCardsStatus !== "01",
            ...obj
        }
        return wantedValuesObj;
}