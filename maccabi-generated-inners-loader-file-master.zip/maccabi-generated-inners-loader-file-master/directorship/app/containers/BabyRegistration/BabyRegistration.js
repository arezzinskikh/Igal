import React, { Component } from 'react';
import { Switch, Route, withRouter, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import autobind from 'autobind';
import { createStructuredSelector } from 'reselect';
import mLib from '@maccabi/m-lib';

import saga from './saga';
import reducer from './reducer';
import {resetState} from './actions';
import {selectIsKeepStateOn} from './selectors';
import BabyRegistrationSummaryAndConfirmation from './BabyRegistrationSummaryAndConfirmation/BabyRegistrationSummaryAndConfirmation';
import BabyRegistrationForm from './BabyRegistrationForm/BabyRegistrationForm';

const mapDispatchToProps = (dispatch) => ({
    resetState: () => dispatch(resetState())
});
const mapStateToProps = createStructuredSelector({
    keepState: selectIsKeepStateOn
});
@mLib.appInfra.injectReducer({ key: 'babyRegistration', reducer, mode: '@@saga-injector/daemon'})
@mLib.appInfra.injectSaga({ key: 'babyRegistration', saga, mode: '@@saga-injector/daemon'})
@connect(mapStateToProps,mapDispatchToProps)
@autobind
class BabyRegistration extends Component {

    componentWillUnmount(){
        const {keepState} = this.props
        if (!keepState) {this.props.resetState()}
    }

    render() {
        return (
            <Switch>
                <Route path={`${this.props.baseRoute}BabyRegistration/RegistrationSummary/`} render={() => <BabyRegistrationSummaryAndConfirmation {...this.props} />} />
                <Route path={`${this.props.baseRoute}BabyRegistration/`} render={() => <BabyRegistrationForm {...this.props} />} />
                <Redirect to="/error/404/" />
            </Switch>
        );
    }
}

export default withRouter(BabyRegistration);