import mLib from '@maccabi/m-lib';
import {FORM,GENDER_LIST} from './constants';

export const FORM_PAGE_ALIAS = 'directorship/BabyRegistration/';

export const FORM_FIELDS_TO_LOG = {
    babySurname: {
        log: {
            elementId: 4373,
            elementInPage: FORM_PAGE_ALIAS,
            actionId: 1344
        }
    }, 
    babyFirstName: {
        log: { 
            elementId: 4372,
            elementInPage: FORM_PAGE_ALIAS,
            actionId: 1344
        }
    }, 
    babyId: {
        log: {
            elementId: 4371,
            elementInPage: FORM_PAGE_ALIAS,
            actionId: 1344
        }
    },
    babyBirthDate: {
        log: { 
            elementId: 4370,
            elementInPage: FORM_PAGE_ALIAS,
            actionId: 1345
        }
    }, 
    babyGender: {
        boy: {
            log: { 
                elementId: 4376,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1345
            }
        },
        girl: {
            log: { 
                elementId: 4377,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1345
            }    
        }
    },
    time: {
        0: {
            log: { 
                elementId: 4382,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1345,
                name: "STARTING_BIRTHDATE"
            }
        },
        1: {
            log: { 
                elementId: 4383,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1345,
                name: "STARTING_TODAY"
            }
        }
    },
    insurance: {
        0: {
            log: { 
                elementId: 4388,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1345,
                name: "myMaccabi"
            }
        },
        1: {
            log: { 
                elementId: 4389,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1345,
                name: "maccabiGold"
            }
        }
    },
    termsOfUseMyMaccabi: {
        log: { 
            elementId: 4392,
            elementInPage: FORM_PAGE_ALIAS,
            actionId: 1795,
        }
    },
    termsOfUseMaccabiGold: {
        log: { 
            elementId: 4393,
            elementInPage: FORM_PAGE_ALIAS,
            actionId: 1795,
        }
    },
    kerenMaccabi: {
        check: {
            log: { 
                elementId: 4380,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1795,
            }
        },
        uncheck: {
            log: { 
                elementId: 4381,
                elementInPage: FORM_PAGE_ALIAS,
                actionId: 1796,
            }
        }
    }
}

export const insertLog = (log) => {
    if (log.elementId && log.elementInPage && log.actionId) {
        return mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId, true, 0, log?.variables);
    }
}

export const insertFormLog = (formField, value) => {
    let log;
    switch (formField) {
        case FORM.GENDER:
            log = (value === GENDER_LIST[0].text) ? FORM_FIELDS_TO_LOG.babyGender.boy.log : FORM_FIELDS_TO_LOG.babyGender.girl.log;
            break;
        case FORM.INSURANCE: 
            log = FORM_FIELDS_TO_LOG.insurance[value].log
            break;
        case FORM.KEREN_MACCABI: 
            log = value ? FORM_FIELDS_TO_LOG.kerenMaccabi.check.log : FORM_FIELDS_TO_LOG.kerenMaccabi.uncheck.log 
            break;
        case FORM.TIME: 
            log = FORM_FIELDS_TO_LOG.time[value].log
            break;
        default:
            log = FORM_FIELDS_TO_LOG[formField].log
            break;
    }
    if (log) return insertLog(log)
}