import { fromJS } from 'immutable';
import { 
    SET_PAYER_BILLING_SUBJECTS, 
    SET_PAYER_DEBIT_AUTHORIZATION, 
    SET_PAYER_TOTAL_DEBTS, 
    SET_IS_LOADING, 
    SET_BANKS,
    SET_BRANCHES,
    SET_NOT_VALID_BANK_DETAILS,
    SET_VALID_BANK_DETAILS,
    CLEAR_BANK_DETAILS,
    SET_DEBTS_DETAILS_FOR_PAYER,
    SET_CREATE_BANK_HOK_SUCCESS,
    SET_TRANSACTION_DETAILS,
    SET_CREATE_CREDIT_CARD_HOK_SUCCESS
} from './constants';

export const initialState = fromJS({
    transactionDetails: null,
    payerBillingSubjects: [],
    payerDebitAuthorization: {},
    payerTotalDebts: {},
    isLoading: true,
    debtsDetailsForPayer: null,
    banks:[],
    bankBranches:{},
    selectedBankDetails:{
        bankCode:-1,
        branchCode:-1,
        accountNumber:'',
        accountOwnerName:'',
        bankDetailsError:false,
        moneyValue:0,
        dateString:null
    },
    afterBankDetailsPage: false,
    bankHokSuccessResponse: null,
    creditCardDirectDebitSuccessResponse:{},
});

export default function creditsAndDebitsReducer(state = initialState, action) {
    switch (action.type) {
        case SET_TRANSACTION_DETAILS:
            return state.set('transactionDetails', action.transactionDetails);
        case SET_PAYER_BILLING_SUBJECTS:
            return state.set('payerBillingSubjects', action.payerBillingSubjects);
        case SET_PAYER_DEBIT_AUTHORIZATION:
            return state.set('payerDebitAuthorization', action.payerDebitAuthorization);
        case SET_PAYER_TOTAL_DEBTS:
            return state.set('payerTotalDebts', action.payerTotalDebts);
        case SET_IS_LOADING:
            return state.set('isLoading', action.isLoading);
        case SET_DEBTS_DETAILS_FOR_PAYER:
            return state.set('debtsDetailsForPayer', action.debtsDetailsForPayer);
        case SET_BANKS:
            return state.set('banks',action.banks);
        case SET_BRANCHES:
            const currentBranchers = state.get('bankBranches');
            let newBranches = {...currentBranchers};
            if(currentBranchers.size === 0){
                newBranches = {[action.bankId]:action.branches} 
            }else{
                newBranches[action.bankId] = action.branches;
            }
            return state.set('bankBranches',newBranches);
        case SET_NOT_VALID_BANK_DETAILS:
            return state.setIn(['selectedBankDetails','bankDetailsError'],true);
        case SET_VALID_BANK_DETAILS:
            const { bankCode,branchCode,accountNumber,accountOwnerName,moneyValue,dateString} = action;
            return state
                    .set('afterBankDetailsPage',true)
                    .set('selectedBankDetails',{
                        bankCode,
                        branchCode,
                        accountNumber,
                        accountOwnerName,
                        moneyValue,
                        dateString,
                        bankDetailsError:false
                    });
        case CLEAR_BANK_DETAILS:
                return state
                    .set('selectedBankDetails',{
                        bankCode:-1,
                        branchCode:-1,
                        accountNumber:'',
                        accountOwnerName:'',
                        bankDetailsError:false,
                        moneyValue:0,
                        dateString:null          
                    });
        
        case SET_CREATE_BANK_HOK_SUCCESS:
            return state.set('bankHokSuccessResponse',action.response);
        case SET_CREATE_CREDIT_CARD_HOK_SUCCESS:
            return state.set('creditCardDirectDebitSuccessResponse',action.response);
        default:
            return state;
    }
}
