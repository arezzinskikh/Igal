import mLib from '@maccabi/m-lib';
export const BASE_ELEMENT_PAGE_NAV = 'הסדרת הרשאה לחיוב חשבון (הוראת קבע)';
export const DIRECT_ֹDEBIT = 'directDebit';
export const ConfirmationDirectDebitsUrl = 'directorship/creditsAndDebits/ConfirmationDirectDebits';
export const URL_DIRECT_DEBIT = 'directorship/creditsAndDebits/directdebit';
export const URL_BANK_DEBIT = 'directorship/CreditsAndDebits/BankDebit';

export const POST_DEBIT_AUTHORIZATION_CREDITCARD = 'maccabi/directorship/creditsAndDebits/GET_DEBIT_AUTHORIZATION_CREDITCARD';
export const SET_PAYER_BILLING_SUBJECTS = 'maccabi/directorship/creditsAndDebits/SET_PAYER_BILLING_SUBJECTS';
export const SET_PAYER_DEBIT_AUTHORIZATION = 'maccabi/directorship/creditsAndDebits/SET_PAYER_DEBIT_AUTHORIZATION';
export const SET_PAYER_TOTAL_DEBTS = 'maccabi/directorship/creditsAndDebits/SET_PAYER_TOTAL_DEBTS';
export const GET_DIRECT_DEBIT_DATA = 'maccabi/directorship/creditsAndDebits/GET_DIRECT_DEBIT_DATA';
export const PREPARE_TRANSACTION = 'maccabi/directorship/creditsAndDebits/PREPARE_TRANSACTION';
export const GET_TRANSACTION_DETAILS = 'maccabi/directorship/creditsAndDebits/GET_TRANSACTION_DETAILS';
export const SET_TRANSACTION_DETAILS = 'maccabi/directorship/creditsAndDebits/SET_TRANSACTION_DETAILS';

export const GET_DEBTS_DETAILS_FOR_PAYER = 'maccabi/directorship/creditsAndDebits/GET_DEBTS_DETAILS_FOR_PAYER';
export const SET_DEBTS_DETAILS_FOR_PAYER = 'maccabi/directorship/creditsAndDebits/SET_DEBTS_DETAILS_FOR_PAYER';
export const SET_IS_LOADING = 'maccabi/directorship/creditsAndDebits/SET_IS_LOADING';
export const CONFIRMATION_CREDITCARD_DEBITS = 'maccabi/directorship/creditsAndDebits/CONFIRMATION_CREDITCARD_DEBITS';

export const SET_BANKS = 'maccabi/directorship/creditsAndDebits/SET_BANKS';
export const GET_BANKS = 'maccabi/directorship/creditsAndDebits/GET_BANKS';
export const SET_BRANCHES = 'maccabi/directorship/creditsAndDebits/SET_BRANCHES';
export const GET_BRANCHES = 'maccabi/directorship/creditsAndDebits/GET_BRANCHES';
export const VALIDATE_BANK_DETAILS = 'maccabi/directorship/creditsAndDebits/VALIDATE_BANK_DETAILS';
export const SET_VALID_BANK_DETAILS = 'maccabi/directorship/creditsAndDebits/SET_VALID_BANK_DETAILS';
export const CLEAR_BANK_DETAILS = 'maccabi/directorship/creditsAndDebits/CLEAR_BANK_DETAILS'
export const SET_NOT_VALID_BANK_DETAILS = 'maccabi/directorship/creditsAndDebits/SET_NOT_VALID_BANK_DETAILS';
export const CREATE_BANK_HOK = 'maccabi/directorship/creditsAndDebits/CREATE_BANK_HOK';
export const SET_CREATE_BANK_HOK_SUCCESS = 'maccabi/directorship/creditsAndDebits/SET_CREATE_BANK_HOK_SUCCESS';
export const SET_CREATE_CREDIT_CARD_HOK_SUCCESS = 'maccabi/directorship/creditsAndDebits/SET_CREATE_CREDIT_CARD_HOK_SUCCESS';

export const CONFIRMATION_PAGE_TYPE = {
    CREDIT_CARD: 'creditCardConfirmationPage',
    BANK: 'bankConfirmationPage'
}

// const