import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import autobind from 'autobind';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import {
    H1,
    MainHeadline,
    MainHeadlineScrollable,
    MainBody,
    Fade,
    Icon,
    Card,
    Button,
    H2,
    ButtonPicker,
    Checkbox,
    H6,
    IconLoader,
    ExpandableReadMore
} from '@maccabi/m-ui';
import style from './DirectDebit.scss';
import FamilyList from '../../../components/DebitAndCredits/FamilyList/FamilyList';
import BankDetails from '../../../components/DebitAndCredits/BankDetails/BankDetails';
import CreditCardDetails from '../../../components/DebitAndCredits/CreditCardDetails/CreditCardDetails';
import PaidByAnotherPayer from '../../../components/DebitAndCredits/PaidByAnotherPayer/PaidByAnotherPayer';
import staticTxt from '../assets/staticText.json';
import { createStructuredSelector } from 'reselect';
import { makeSelectDebtsDetailsForPayer } from '../selectors';
import { prepareTransaction, getDebtsDetailsForPayer,clearBankDetailsAfterValidation } from '../actions';
import Dashes from '../../../components/DebitAndCredits/Dashes/Dashes';
import { WithDirectDebitProps } from '../../../HOC/WithDirectDebit';
import MessagePaidByAnotherPayer from '../../../components/DebitAndCredits/MessagePaidByAnotherPayer/MessagePaidByAnotherPayer';
import {
    DIRECT_DEBIT_TITLE_UPDATE,
    DIRECT_DEBIT_TITLE_ARRANGMENT,
    CREDIT_CARD_DEBIT_AUTHORIZATION,
    AUTHORIZATION_TO_DEBIT_A_BANK_ACCOUNT,
    DIRECT_DEBIT_INFORMATION_TEXT,
    DIRECT_DEBIT_SELECT_PREMISSION_TYPE,
    DIRECT_DEBIT_AUTHORIZATION_TYPE_MUST_BE_SELECTED,
    DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS,
    DIRECT_DEBIT_DEBT_COLLECTION_AGREEMENT,
    DIRECT_DEBIT_FOR_FULL_DEBT_DETAILS,
    DIRECT_DEBIT_SELECT_DEBT_PAYMENT_CONFIRMATION,
    DIRECT_DEBIT_NIS,
    DIRECT_DEBIT_MESSAGE_PAID_BY_YOU,
    DIRECT_DEBIT_TOTAL_DEBT_IN_YOUR_MACCABI_ACCOUNT,
    DIRECT_DEBIT_STARTֹ_DATE,
    CONTINUED_BUTTON,
    CONTINUED_VALIDATION_MESSAGE,
    KUPA_DEBT_FIRST_TEXT,
    KUPA_DEBT_SECOND_TEXT
} from './constants';
import DebtsDetails from '../../../components/DebitAndCredits/DebtsDetails';
import { withRouter } from 'react-router-dom';
import { insertLog, FORM_FIELDS_TO_LOG } from './logFile';

const mapDispatchToProps = { prepareTransaction, getDebtsDetailsForPayer, clearBankDetailsAfterValidation };

const mapStateToProps = createStructuredSelector({
    debtsDetailsForPayer: makeSelectDebtsDetailsForPayer
});
@withRouter
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class DirectDebit extends Component {
    constructor(props) {
        super(props);

        this.state = {
            toggleLongText: false,
            showErrorMessage: {
                selectPaymentTypeNotMarked: false,
                DebtPaymentConfirmationNotMarked: false
            },
            checkBoxesNotSelected: {
                checkBoxChoosePaymentOfDebtSelected: false,
                isDebtsCheckBoxSelected: false
            },
            showDebtsDetailsModal: false,
            showOnlyDebtsDetails: false,
            isNewDebitDisclaimerApproved: false,
            newDebitDisclaimerApprovalNeeded: false
        };
    }

    static propTypes = {
        payerBillingSubjects: PropTypes.array.isRequired,
        paymentMethods: PropTypes.array.isRequired,
        payerDebitAuthorization: PropTypes.object.isRequired,
        payerTotalDebts: PropTypes.object.isRequired,
        onDirectDebitLoad: PropTypes.func.isRequired,
        isLoading: PropTypes.bool.isRequired,
        onClick: PropTypes.func.isRequired
    };

    componentDidMount() {
        const {clearBankDetailsAfterValidation} = this.props
        clearBankDetailsAfterValidation()
        if (mLib.customer.isParentAsChild()) {
            mLib.saveData.globalLoader.setGlobalLoading(true);
            const url = mLib.url.getUrlByVersion(2, '/home');
            history.push(`/go/${encodeURIComponent(url)}`);
        } else {
            this.props.onDirectDebitLoad();
        }
    }

    componentDidUpdate(prevProps) {
        if (!this.props.isLoading && this.props.isLoading !== prevProps.isLoading) {
            this.familyListItems &&
                this.familyListItems.length > 0 &&
                mLib.logs.insertCentralizedLog(2178, null, process.env.LOG_ACTION_ID_DISPLAY_ELEMENT, false);
        }
        if (
            this.showJoinDirectDebit &&
            this.props.payerDebitAuthorization.is_active_auth_exists !== prevProps.payerDebitAuthorization.is_active_auth_exists
        ) {
            insertLog(FORM_FIELDS_TO_LOG.loadingRegistrationToHok);
        }
    }

    get title() {
        const {
            payerDebitAuthorization: { is_active_auth_exists }
        } = this.props;
        return is_active_auth_exists ? DIRECT_DEBIT_TITLE_UPDATE : DIRECT_DEBIT_TITLE_ARRANGMENT;
    }

    get date() {
        const {
            payerDebitAuthorization: { is_active_auth_exists, auth_start_date }
        } = this.props;
        const date = is_active_auth_exists ? mLib.date.formatDate(auth_start_date) : null;
        if (!date) {
            return null;
        }
        return `${DIRECT_DEBIT_STARTֹ_DATE} ${date}`;
    }

    get totalDebt() {
        const { payerTotalDebts } = this.props;
        if (!payerTotalDebts) return 0;
        return payerTotalDebts.additional_charges_debt + payerTotalDebts.kupa_debt + payerTotalDebts.shaban_debt;
    }

    get totalDebtToShow() {
        const totalDebtSum = this.totalDebt;
        return this.amountWithoutDecimalPoint(totalDebtSum);
    }

    get totalkupaDebt() {
        const {
            payerTotalDebts: { kupa_debt }
        } = this.props;

        if (!kupa_debt) return 0;
        return this.amountWithoutDecimalPoint(kupa_debt);
    }

    amountWithoutDecimalPoint(amount) {
        return amount % 1 !== 0 ? amount.toFixed(2) : amount.toFixed(0);
    }

    get showJoinDirectDebit() {
        const {
            payerDebitAuthorization: { is_active_auth_exists }
        } = this.props;
        return !is_active_auth_exists && !this.isPaymentByOther;
    }

    get isCreditCardPayment() {
        const {
            payerDebitAuthorization: { is_active_auth_exists, payment_method }
        } = this.props;
        return is_active_auth_exists && payment_method === 60;
    }

    get isBankAccountPayment() {
        const {
            payerDebitAuthorization: { is_active_auth_exists, payment_method }
        } = this.props;
        return is_active_auth_exists && payment_method === 10;
    }

    get hasFamily() {
        return this.familyListItems.length > 0;
    }

    get familyListItems() {
        const { payerBillingSubjects } = this.props;
        const { logged_customer_info } = mLib.saveData.customerData.get();
        return payerBillingSubjects && payerBillingSubjects.filter(({ member_id }) => member_id !== logged_customer_info.member_id);
    }

    get isPaymentByOther() {
        const { logged_customer_info } = mLib.saveData.customerData.get();
        return logged_customer_info.pays_id !== logged_customer_info.member_id;
    }

    get familyListItems() {
        const { payerBillingSubjects } = this.props;
        const { logged_customer_info } = mLib.saveData.customerData.get();
        return payerBillingSubjects && payerBillingSubjects.filter(({ member_id }) => member_id !== logged_customer_info.member_id);
    }

    get paymentOptionTextBtn() {
        return [
            {
                textToDisplay: CREDIT_CARD_DEBIT_AUTHORIZATION,
                descToDisplay: ''
            },
            {
                textToDisplay: AUTHORIZATION_TO_DEBIT_A_BANK_ACCOUNT,
                descToDisplay: ''
            }
        ];
    }

    renderButtons(isMobile) {
        const buttonPickerProps = {
            color: this.state.showErrorMessage.selectPaymentTypeNotMarked ? 'danger' : 'primary',
            nameOfFiledToDisplay: 'textToDisplay',
            descOfFiledToDisplay: 'descToDisplay',
            list: this.paymentOptionTextBtn,
            selectedIndex: 2
        };

        const containerClassName = cx({
            'd-none d-xl-flex': !isMobile,
            'd-xl-none d-flex': isMobile
        });
        return (
            <div className={cx(style.btnsContainer, containerClassName)} data-hook="ButtonPickerWrapepr">
                <ButtonPicker className={style.btnsGroup} onClick={item => this.onSelectPaymentMethods(item, isMobile)} {...buttonPickerProps} />
            </div>
        );
    }

    renderjoiningButtons(loading, isMobile = false) {
        const btnJoiningCls = cx({
            'd-none': isMobile && this.totalDebt <= 0,
            'd-flex': isMobile && this.totalDebt > 0,
            'd-none d-md-flex': !isMobile,
            'd-md-none': isMobile
        });

        return (
            <Fragment>
                <Button onClick={() => this.validateAndMove()} size="md" color="primary" maincta className={cx(style.continueButton, btnJoiningCls)}>
                    {loading && <IconLoader size="sm" className={style.iconLoader} />}
                    {CONTINUED_BUTTON}
                </Button>
            </Fragment>
        );
    }

    moveToBankDebit = () => {
        this.props.history.push('/directorship/CreditsAndDebits/bankDebit/');
    };

    moveToCreditCardDebit = () => {
        this.props.prepareTransaction(this.props.history.push);
    };

    onSelectPaymentMethods(item, isMobile = false) {
        const editErrorMessage = { ...this.state.showErrorMessage };
        item.textToDisplay === CREDIT_CARD_DEBIT_AUTHORIZATION
            ? insertLog(FORM_FIELDS_TO_LOG.clickingOnCreditCardHokBtn)
            : insertLog(FORM_FIELDS_TO_LOG.clickingOnBankHokBtn);
        editErrorMessage.selectPaymentTypeNotMarked = false;
        this.setState({ showErrorMessage: editErrorMessage, paymentMethods: item.textToDisplay }, () => {
            if (isMobile && this.totalDebt <= 0) {
                this.validateAndMove(isMobile);
            }
        });
    }

    validateAndMove = (isMobile = false) => {
        const { paymentMethods } = this.state;
        const log = FORM_FIELDS_TO_LOG.hokClickTheContinueBtn;
        log.variables = paymentMethods ? [{ key: 'element_id', description: paymentMethods }] : null;
        insertLog(log);
        if (this.onSubmit(isMobile)) {
            this.isBankDebit && this.moveToBankDebit();
            this.isCreditCardDebit && this.moveToCreditCardDebit();
        }
    };

    get isCreditCardDebit() {
        const { paymentMethods } = this.state;
        return paymentMethods === CREDIT_CARD_DEBIT_AUTHORIZATION;
    }

    get isBankDebit() {
        const { paymentMethods } = this.state;
        return paymentMethods === AUTHORIZATION_TO_DEBIT_A_BANK_ACCOUNT;
    }

    get isValid() {
        const isCorrectPaymentMethod = this.isCreditCardDebit || this.isBankDebit;
        return isCorrectPaymentMethod && (this.totalDebt > 0 ? this.state.checkBoxesNotSelected.checkBoxChoosePaymentOfDebtSelected : true);
    }

    onSubmit(isMobile = false) {
        const { paymentMethods } = this.state;
        const hasPaymentMethod = paymentMethods !== undefined;

        if ((isMobile && hasPaymentMethod) || !isMobile) {
            this.setState(
                ({ checkBoxesNotSelected: { checkBoxChoosePaymentOfDebtSelected } }) => ({
                    showErrorMessage: {
                        selectPaymentTypeNotMarked: !hasPaymentMethod,
                        DebtPaymentConfirmationNotMarked: !checkBoxChoosePaymentOfDebtSelected
                    }
                }),
                () => {
                    const {
                        checkBoxesNotSelected: { checkBoxChoosePaymentOfDebtSelected }
                    } = this.state;
                    if (!checkBoxChoosePaymentOfDebtSelected && this.totalDebt > 0) {
                        insertLog(FORM_FIELDS_TO_LOG.validationPleaseApproveDebtCollection);
                    }
                    if (!hasPaymentMethod) {
                        insertLog(FORM_FIELDS_TO_LOG.validationPleaseChooseHokOption);
                    }
                }
            );
            return this.isValid;
        }
        return false;
    }

    goToCreditsAndDebitsLobby() {
        insertLog(FORM_FIELDS_TO_LOG.clickingOnBillingAndCreditInfo);
        const url = mLib.url.getUrlByVersion(2, '/directorship/DebitsAndCredits');
        var win = window.open(url, '_blank');
        win.focus();
    }

    onLongTextExpandOrCollapse = () => {
        this.setState({ toggleLongText: !this.state.toggleLongText });
    };

    changeErrorMessageOfPayment() {
        const { showErrorMessage } = this.state;
        insertLog(FORM_FIELDS_TO_LOG.debtCollectionApprovalMarking);
        this.setState(
            ({ checkBoxesNotSelected: { checkBoxChoosePaymentOfDebtSelected } }) => ({
                checkBoxesNotSelected: { checkBoxChoosePaymentOfDebtSelected: !checkBoxChoosePaymentOfDebtSelected }
            }),
            () => {
                if (showErrorMessage.DebtPaymentConfirmationNotMarked) {
                    this.setState({
                        showErrorMessage: {
                            DebtPaymentConfirmationNotMarked: false,
                            selectPaymentTypeNotMarked: showErrorMessage.selectPaymentTypeNotMarked
                        }
                    });
                }
            }
        );
    }

    toggleDebtsDetails(showOnlyDebtsDetails = true) {
        const { debtsDetailsForPayer } = this.props;
        this.setState(
            ({ showDebtsDetailsModal }) => ({ showDebtsDetailsModal: !showDebtsDetailsModal, showOnlyDebtsDetails }),
            () => {
                const {
                    showDebtsDetailsModal,
                    checkBoxesNotSelected: { isDebtsCheckBoxSelected }
                } = this.state;
                if (isDebtsCheckBoxSelected) {
                    this.setState({ checkBoxesNotSelected: { isDebtsCheckBoxSelected: false } });
                }
                showDebtsDetailsModal && !debtsDetailsForPayer && this.props.getDebtsDetailsForPayer();
            }
        );
    }

    toggleIsNewDebitDisclaimerApproved() {
        this.setState(({ isNewDebitDisclaimerApproved }) => ({
            isNewDebitDisclaimerApproved: !isNewDebitDisclaimerApproved,
            newDebitDisclaimerApprovalNeeded: false
        }));
    }

    toggleDebtsCheckBox() {
        this.setState(({ checkBoxesNotSelected: { isDebtsCheckBoxSelected } }) => ({
            checkBoxesNotSelected: { isDebtsCheckBoxSelected: !isDebtsCheckBoxSelected }
        }));
    }

    debtsDetailsPrimaryButtonClick() {
        const {
            checkBoxesNotSelected: { isDebtsCheckBoxSelected }
        } = this.state;
        const goToUpdateDebit = isDebtsCheckBoxSelected;
        isDebtsCheckBoxSelected && this.toggleDebtsDetails() && insertLog(FORM_FIELDS_TO_LOG.clickingOnForDebtDetails);
        goToUpdateDebit && this.goToUpdateDebit();
    }

    changeDebitDetails(isUpdate) {
        this.setState({ isChangeDebitDetails: !isUpdate }, () => {
            this.totalDebt > 0 && this.toggleDebtsDetails(false);
            this.totalDebt === 0 && this.goToUpdateDebit();
        });
    }

    goToUpdateDebit() {
        const { isChangeDebitDetails } = this.state;
        const sholdMoveToCG = (this.isCreditCardPayment && !isChangeDebitDetails) || (this.isBankAccountPayment && isChangeDebitDetails);
        const sholdMoveToBankDebit = (this.isCreditCardPayment && isChangeDebitDetails) || (this.isBankAccountPayment && !isChangeDebitDetails);
        if (sholdMoveToBankDebit) {
            !isChangeDebitDetails
                ? insertLog(FORM_FIELDS_TO_LOG.accountDetailsUpdateButton)
                : insertLog(FORM_FIELDS_TO_LOG.paymentMethodSwitchButton);
        }
        if (sholdMoveToCG) {
            !isChangeDebitDetails
                ? insertLog(FORM_FIELDS_TO_LOG.clickingOnChangeCreditCardBtn)
                : insertLog(FORM_FIELDS_TO_LOG.clickingOnReplacementpaymentCG);
        }

        sholdMoveToCG && this.moveToCreditCardDebit();
        sholdMoveToBankDebit && this.moveToBankDebit();
    }

    renderJoinDebitCard() {
        const {
            payerDebitAuthorization: { is_shaban_auth_only },
            payerTotalDebts: { kupa_debt }
        } = this.props;

        const { loading } = this.props;
        const {
            showErrorMessage: { selectPaymentTypeNotMarked, DebtPaymentConfirmationNotMarked }
        } = this.state;
        const title = this.totalDebt > 0 ? DIRECT_DEBIT_SELECT_PREMISSION_TYPE : DIRECT_DEBIT_AUTHORIZATION_TYPE_MUST_BE_SELECTED;
        const validClassName = cx({
            [style.valid]: !selectPaymentTypeNotMarked,
            [style.notValid]: selectPaymentTypeNotMarked
        });

        const checkBoNotValid = cx({
            [style.checkBoNotValid]: DebtPaymentConfirmationNotMarked,
            [style.disclaimer]: true
        });

        return (
            <Fragment>
                <Card className={cx(style.card, 'mt-7', 'mb-7')}>
                    <H2 className={style.title}>{title}</H2>
                    {this.renderButtons()}
                    {this.renderButtons(true)}
                    <div className={validClassName} data-hook="validation">
                        {selectPaymentTypeNotMarked ? CONTINUED_VALIDATION_MESSAGE : ''}
                    </div>
                    {this.totalDebt > 0 && (
                        <Fragment>
                            <div className={style.text}>
                                {DIRECT_DEBIT_TOTAL_DEBT_IN_YOUR_MACCABI_ACCOUNT} {this.totalDebtToShow} {DIRECT_DEBIT_NIS}
                            </div>
                            <Button className={style.linkDetails} size="sm" color="link" reverse onClick={this.toggleDebtsDetails}>
                                {DIRECT_DEBIT_FOR_FULL_DEBT_DETAILS}
                            </Button>
                            <div className={checkBoNotValid}>{DIRECT_DEBIT_DEBT_COLLECTION_AGREEMENT}</div>
                            <Checkbox
                                onChange={this.changeErrorMessageOfPayment}
                                invalid={DebtPaymentConfirmationNotMarked ? 'invalid' : ''}
                                className={style.checkbox}>
                                {DIRECT_DEBIT_SELECT_DEBT_PAYMENT_CONFIRMATION}
                            </Checkbox>
                            {is_shaban_auth_only && kupa_debt > 0 && (
                                <div className={style.kupaDebtText}>
                                    {KUPA_DEBT_FIRST_TEXT} {this.totalkupaDebt} {KUPA_DEBT_SECOND_TEXT}
                                </div>
                            )}
                        </Fragment>
                    )}
                    {this.renderjoiningButtons(loading)}
                    {this.renderjoiningButtons(loading, true)}
                </Card>
                <Dashes cls="mb-7 d-md-none d-flex " />
            </Fragment>
        );
    }

    renderJoinDirect() {
        if (!this.showJoinDirectDebit) return null;
        return (
            <Fragment>
                <ExpandableReadMore
                    textToOpen={staticTxt.readMore}
                    textToClose={staticTxt.close}
                    toggleLongText={this.state.toggleLongText}
                    clickLongText={this.onLongTextExpandOrCollapse}
                    children={DIRECT_DEBIT_INFORMATION_TEXT}
                />
            </Fragment>
        );
    }

    render() {
        const {
            editInformationData: { showSuccessMessage } = {},
            payerDebitAuthorization,
            isLoading,
            debtsDetailsForPayer,
            payerTotalDebts: { kupa_debt }
        } = this.props;

        if (isLoading) return null;
        return (
            <Fragment>
                <MainHeadline className={style.headLine}>
                    <MainHeadlineScrollable className={style.titleContainer}>
                        <H1>{this.title}</H1>
                        <date className={style.startDate}>{this.date}</date>
                    </MainHeadlineScrollable>

                    {showSuccessMessage && (
                        <Fade className={style.successTagContainer} in={showSuccessMessage} hook="successAlertMessage" size="lg">
                            <div className={style.successTagContent}>
                                <Icon name={APPROVED_ICON} className={style.icon} />
                                <span className={style.message}>{SUCCESS_TAG_TEXT}</span>
                            </div>
                        </Fade>
                    )}
                </MainHeadline>
                <MainBody className={style.mainBody} layout="regular">
                    {this.renderJoinDirect()}
                    {(!this.isPaymentByOther || (this.isPaymentByOther && this.hasFamily)) && (
                        <Button
                            rel="noopener noreferrer"
                            className={style.detailsOfChargesAndCredits}
                            onClick={this.goToCreditsAndDebitsLobby}
                            color="link">
                            {DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS}
                        </Button>
                    )}
                    {this.showJoinDirectDebit && this.renderJoinDebitCard()}
                    {this.isPaymentByOther && !this.hasFamily && (
                        <Fragment>
                            <Card className={cx(style.card, 'mt-3')}>
                                <MessagePaidByAnotherPayer />
                            </Card>
                        </Fragment>
                    )}
                    {this.isPaymentByOther && this.hasFamily && (
                        <Fragment>
                            <PaidByAnotherPayer />
                            <H6 className={cx(style.secoundTitle, 'mt-3', 'mb-5')}>{DIRECT_DEBIT_MESSAGE_PAID_BY_YOU}</H6>
                            <FamilyList items={this.familyListItems} className={style.fanilyList} />
                            <Dashes cls={style.afterFamilyList} />
                        </Fragment>
                    )}

                    {this.isBankAccountPayment && (
                        <BankDetails
                            bankName={payerDebitAuthorization.bank_name}
                            bankCode={payerDebitAuthorization.bank_code}
                            branchCode={payerDebitAuthorization.branch_code}
                            accountNumber={payerDebitAuthorization.account_number}
                            primaryButtonClick={this.changeDebitDetails}
                            secondaryButtonClick={this.changeDebitDetails}
                        />
                    )}
                    {this.isCreditCardPayment && (
                        <CreditCardDetails
                            creditCardType={payerDebitAuthorization.credit_card_type}
                            lastFourDigitsCreditCard={payerDebitAuthorization.last_four_digits_credit_card}
                            primaryButtonClick={this.changeDebitDetails}
                            secondaryButtonClick={this.changeDebitDetails}
                        />
                    )}

                    {!this.isPaymentByOther && this.hasFamily && (
                        <Fragment>
                            {!this.showJoinDirectDebit && <Dashes cls={'mb-7 mt-7'} />}
                            <FamilyList items={this.familyListItems} className={style.fanilyList} />
                        </Fragment>
                    )}

                    {this.state.showDebtsDetailsModal && debtsDetailsForPayer && (
                        <DebtsDetails
                            debtsDetails={debtsDetailsForPayer}
                            isOpen={this.state.showDebtsDetailsModal}
                            onClose={this.toggleDebtsDetails}
                            primaryButtonClick={this.debtsDetailsPrimaryButtonClick}
                            isShowOnlyDetails={this.state.showOnlyDebtsDetails}
                            newDebitDisclaimerApprovalNeeded={this.state.newDebitDisclaimerApprovalNeeded}
                            toggleIsNewDebitDisclaimerApproved={this.toggleIsNewDebitDisclaimerApproved}
                            toggleDebtsCheckBox={this.toggleDebtsCheckBox}
                            kupaDebt={kupa_debt}
                            isShabanAuthOnly={payerDebitAuthorization.is_shaban_auth_only}
                            paymentMethodsName={this.isBankAccountPayment}
                        />
                    )}
                </MainBody>
            </Fragment>
        );
    }
}
export default WithDirectDebitProps(DirectDebit);
