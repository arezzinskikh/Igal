import mLib from '@maccabi/m-lib';

export const FORM_PAGE_ALIAS = 'directorship/CreditsAndDebits/DirectDebit/';


export const FORM_FIELDS_TO_LOG = {
    loadingRegistrationToHok: {
        elementId: 4425,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674
    }, 
    clickingOnBillingAndCreditInfo: {      
        elementId: 4426,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    clickingOnCreditCardHokBtn: {
        elementId: 4427,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    clickingOnBankHokBtn: {
        elementId: 4428,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    clickingOnForDebtDetails: {
        elementId: 4429,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
        
    debtCollectionApprovalMarking: {
        elementId: 4430,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1936
           
    },
    validationPleaseApproveDebtCollection: {  
        elementId: 4431,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674
  
    },
                
    validationPleaseChooseHokOption : {
        elementId: 4432,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674
  
    },
    hokClickTheContinueBtn: {
        elementId: 4433,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 4145                 
    },
    viewDetailsOfBankDirectDebit: {
        elementId: 4434,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674
                   
    },
    paymentMethodSwitchButton: {
        elementId: 4435,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343                     
    },   
    accountDetailsUpdateButton: {
        elementId: 4436,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343                  
    },   
    
    DetailsOnCreditDirectDebit: {
        elementId: 4437,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674                      
    },   
    clickingOnReplacementpaymentCG: {
        elementId: 4438,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343                    
    },   
    clickingOnChangeCreditCardBtn: {
        elementId: 4439,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
        
                            
    },   
    paidNonPaying: {
        elementId: 4440,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674                    
    },   
    paidPays: {               
        elementId: 4441,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674                     
    },   
    // paidPaysclickingOnChargesAndCredits: {
                           
    //     log: { 
    //         elementId: 2258,
    //         elementInPage: FORM_PAGE_ALIAS,
    //         actionId: 1343
    //     }
                            
    // },   
    detailsOfFamilyList: {
        elementId: 4442,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674                     
    },   
    openDebtModal: {
        elementId: 4443,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674                     
    },   
    debtModalclickingOnIUnderstood: {
        elementId: 4444,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343                  
    },   
    debtModalclickingOnClose: {
        elementId: 4445,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343                    
    },   
    openDebtCollectionApprovalModal: {
        elementId: 4446,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674                  
    },
    
    debtCollectionApprovalbtn: {
            elementId: 4447,
            elementInPage: FORM_PAGE_ALIAS,
            actionId: 1343                 
    },
    PleaseConfirmDebtCollectionApprovalModal: {
        elementId: 4448,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674                    
    },
    DebtCollectionApprovalModalClickContinueBtn: {             
        elementId: 4449,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 4145                         
    },
}

export const insertLog = (log) => {
    mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId, true, 0, log.variables);   
}


