import mLib from '@maccabi/m-lib';
import { URL_DIRECT_DEBIT } from '../constants';

export const DIRECT_DEBIT_TITLE_UPDATE = mLib.site.getModuleTitle(
    URL_DIRECT_DEBIT,
    `DIRECT_DEBIT_TITLE_UPDATE`,
    'עדכון הרשאה לחיוב חשבון (הוראת קבע)'
);

export const DIRECT_DEBIT_TITLE_ARRANGMENT = mLib.site.getModuleTitle(
    URL_DIRECT_DEBIT,
    `DIRECT_DEBIT_TITLE_ARRANGMENT`,
    'הסדרת הרשאה לחיוב חשבון (הוראת קבע)'
);
export const CREDIT_CARD_DEBIT_AUTHORIZATION = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'CREDIT_CARD_DEBIT_AUTHORIZATION',
    'הרשאה לחיוב כרטיס אשראי'
);
export const AUTHORIZATION_TO_DEBIT_A_BANK_ACCOUNT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'AUTHORIZATION_TO_DEBIT_A_BANK_ACCOUNT',
    'הרשאה לחיוב חשבון בנק'
);
export const DIRECT_DEBIT_INFORMATION_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_INFORMATION_TEXT',
    'הסדרת אמצעי תשלום לחיוב חשבון (הוראת קבע) מאפשרת לחברי מכבי יתרונות ורבים, ביניהם : רכישת תרופות בבתי מרקחת מכבי פארם באמצעות הכרטיס המגנטי, תשלום היטלים באופן נוח ומהיר, קבלת החזרים ישירות לחשבון הבנק ועוד. עדכון הוראת הקבע באמצעותה משולמים דמי החברות, תכניות הביטוח המשלימות והשתתפויות העצמיות, אפשרי בכל עת'
);
export const DIRECT_DEBIT_SELECT_PREMISSION_TYPE = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_SELECT_PREMISSION_TYPE',
    'בחירת סוג להוראת קבע'
);
export const DIRECT_DEBIT_AUTHORIZATION_TYPE_MUST_BE_SELECTED = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_AUTHORIZATION_TYPE_MUST_BE_SELECTED',
    'יש לבחור את סוג ההרשאה לחיוב'
);
export const DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS',
    'לפרטי חיובים וזיכויים'
);
export const DIRECT_DEBIT_DEBT_COLLECTION_AGREEMENT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_DEBT_COLLECTION_AGREEMENT',
    'על מנת להצטרף יש להסכים לגביית החוב באמצעי פרטי תשלום בהוראת קבע, או לשלם את החוב במרכז הרפואי'
);
export const DIRECT_DEBIT_FOR_FULL_DEBT_DETAILS = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_FOR_FULL_DEBT_DETAILS',
    'לפרטי החוב המלאים'
);

export const DIRECT_DEBIT_SELECT_DEBT_PAYMENT_CONFIRMATION = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_SELECT_DEBT_PAYMENT_CONFIRMATION',
    'הסימון מהווה אישור לגביית סך החוב בהוראת קבע בתשלום אחד'
);
export const DIRECT_DEBIT_NIS = mLib.resources.getResource(URL_DIRECT_DEBIT, 'DIRECT_DEBIT_NIS', 'ש״ח');
export const DIRECT_DEBIT_MESSAGE_PAID_BY_YOU = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_MESSAGE_PAID_BY_YOU',
    'הוראת הקבע המשולמת על ידך עבור:'
);
export const DIRECT_DEBIT_TOTAL_DEBT_IN_YOUR_MACCABI_ACCOUNT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_TOTAL_DEBT_IN_YOUR_MACCABI_ACCOUNT',
    'בחשבונך במכבי קיים חוב בסה״כ'
);
export const DIRECT_DEBIT_STARTֹ_DATE = mLib.resources.getResource(URL_DIRECT_DEBIT, 'DIRECT_DEBIT_STARTֹ_DATE', 'תאריך הצטרפות:');
export const CONTINUED_BUTTON = mLib.resources.getResource(URL_DIRECT_DEBIT, 'CONTINUED_BUTTON', 'המשך');
export const CONTINUED_VALIDATION_MESSAGE = mLib.resources.getResource(URL_DIRECT_DEBIT, 'CONTINUED_VALIDATION_MESSAGE', 'יש לבחור סוג הרשאה לחיוב');

export const KUPA_DEBT_FIRST_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'KUPA_DEBT_FIRST_TEXT',
    'בהתאם להסכם שלך עם מכבי, בהוראת הקבע ייגבו חובות בגין דמי ביטוח בלבד. אם ברצונך לשלם את יתרת החוב בסך'
);

export const KUPA_DEBT_SECOND_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'KUPA_DEBT_SECOND_TEXT',
    'ש"ח, ניתן לפנות למוקד השירות הטלפוני'
);