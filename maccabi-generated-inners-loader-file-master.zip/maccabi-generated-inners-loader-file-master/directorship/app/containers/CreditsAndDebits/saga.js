import { takeLatest, call, put, all,select } from 'redux-saga/effects';
import { push } from 'connected-react-router';

import {
    getPayerTotalDebts,
    getPayerBillingSubjects,
    getPayerDebitAuthorization,
    PrepeareTransaction,
    getDebtsDetailsForPayer,
    getBanks,
    getBanksBranches,
    createBankHokService,
    getTransactionDetails,
    validateBankDetails,
    postDebitAuthorizationCreditcard
} from '../../services/CreditsAndDebits/apiService';
import { 
    GET_DIRECT_DEBIT_DATA , 
    PREPARE_TRANSACTION,
    GET_BANKS,
    GET_BRANCHES,
    GET_DEBTS_DETAILS_FOR_PAYER,
    CREATE_BANK_HOK,
    GET_TRANSACTION_DETAILS,
    VALIDATE_BANK_DETAILS,
    POST_DEBIT_AUTHORIZATION_CREDITCARD
} from './constants';
import { 
    setPayerTotalDebts, 
    setPayerBillingSubjects, 
    setPayerDebitAuthorization, 
    setIsLoading, 
    setBanks,
    setBankBranches,
    setDebtsDetailsForPayer,
    setTransactionDetails,
    setBankDetailsAfterValidation,
    clearBankDetailsAfterValidation,
    setBankDetailsNotValid,
    setCreateBankHokSuccess,
    setCreditCardSuccessReponse
} from './actions';
import mLib from '@maccabi/m-lib';
import {makeSelectBankBranches} from './selectors';
import { insertLog, FORM_FIELDS_TO_LOG } from './ConfirmationDirectDebits/logFile';

const { setGlobalLoading } = mLib.saveData.globalLoader;
const { setGlobalErrorPopup } = mLib.saveData.globalErrorPopup;

function* handlePrepeareTransaction(action) {
    const {
        current_customer_info: { member_id, member_id_code }
    } = mLib.saveData.customerData.get();
    const {push} = action;
    yield call(setGlobalLoading, true);
    try{
        var res = yield call(PrepeareTransaction, member_id_code, member_id);
        const {
            terminal_number,
            time_interval,
            token,
            mid,
            mpi_hosted_page_url,
            number_of_retries_esb,
        } = res;
        const payerCgData = {
            terminal_number: terminal_number,
            mid: mid,
            token: token,
            time_interval: time_interval,
            number_of_retries_esb: number_of_retries_esb
        };
        if(mpi_hosted_page_url !== ""){
            sessionStorage.setItem('cg', JSON.stringify(payerCgData));
            push(`/go/${encodeURIComponent(mpi_hosted_page_url)}`) ;
        }else{
            yield call(setGlobalErrorPopup, true);
        }
        
    }catch(e){
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
    }
}

function* handleGetDirectDebitData({isConfirmatioPageOfCC}) {
    const {
        current_customer_info: { member_id, member_id_code }
    } = mLib.saveData.customerData.get();

    try {
        yield call(setGlobalLoading, true);
        yield put(setIsLoading(true));
        yield all([
            call(handleGetPayerTotalDebts, member_id_code, member_id),
            call(handleGetPayerBillingSubjects, member_id_code, member_id),
            call(handleGetPayerDebitAuthorization, member_id_code, member_id)
        ]);
    } catch (err) {
        yield call(setGlobalErrorPopup, true);
    } finally {
        if(!isConfirmatioPageOfCC){
            yield call(setGlobalLoading, false);
            yield put(setIsLoading(false));
        }
    }
}

function* handleGetPayerTotalDebts(memberIdCode, memberId) {
    const result = yield call(getPayerTotalDebts, memberIdCode, memberId);

    yield put(setPayerTotalDebts(result));
}

function* handleGetPayerBillingSubjects(memberIdCode, memberId) {
    const result = yield call(getPayerBillingSubjects, memberIdCode, memberId);

    yield put(setPayerBillingSubjects(result.payer_billing_subjects));
}

function* handleGetPayerDebitAuthorization(memberIdCode, memberId) {
    const result = yield call(getPayerDebitAuthorization, memberIdCode, memberId);
    yield put(setPayerDebitAuthorization(result))
}

function* handleGetDebtsDetailsForPayer() {
    const {
        current_customer_info: { member_id, member_id_code }
    } = mLib.saveData.customerData.get();
    const result = yield call(getDebtsDetailsForPayer, member_id_code, member_id);

    yield put(setDebtsDetailsForPayer(result));
}

function* handleGetBanks(){
    const {current_customer_info:{member_id,member_id_code}}= mLib.saveData.customerData.get();
    yield call(setGlobalLoading, true);

    try{
        const result = yield call(getBanks, member_id_code, member_id);
        yield put(setBanks(result));
    }catch(e){
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
    }
}

function* handleGetBanksBranches(action){
    const {current_customer_info:{member_id,member_id_code}}= mLib.saveData.customerData.get();
    const {bankId} = action;
    const branches = yield select(makeSelectBankBranches);
    if(branches[bankId] && branches[bankId].length) return;
    yield call(setGlobalLoading, true);

    try{
        const result = yield call(getBanksBranches, member_id_code, member_id,action.bankId);
        yield put(setBankBranches({bankId,branches:result}));
    }catch(e){
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
    }
}

function* handleValidateBankDetails(action){
    yield call(setGlobalLoading, true);
    const {bankCode,branchCode,accountNumber,accountOwnerName,push,moneyValue,dateString} = action;
    const {current_customer_info:{member_id,member_id_code}}= mLib.saveData.customerData.get();
    try{
        const result = yield call(validateBankDetails,member_id_code,member_id,bankCode,branchCode,accountNumber);
        
        if(result.is_valid){
            yield put(setBankDetailsAfterValidation(bankCode,branchCode,accountNumber,accountOwnerName,moneyValue,dateString));
            push('/directorship/CreditsAndDebits/ConfirmationDirectDebits/bankConfirmationPage/');
        }else{
            yield put(setBankDetailsNotValid());
        }
    }catch(e){
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
    }
}

function* handleCreateBankHok(action){
    const {data} = action;
    const {logged_customer_info} = mLib.saveData.customerData.get();
    yield call(setGlobalLoading, true);
    try{
        const hokToCreate = {
            bank_number: data.bankCode,
            branch_number: data.branchCode,
            account_number: parseInt(data.accountNumber),
            account_owner: data.accountOwnerName,
            max_bill_amount: data.moneyValue ? parseInt(data.moneyValue) : 0,
            authorization_end_date: data.dateString ? data.dateString : "",
            is_collect_debt: data.is_collect_debt
        }
        const result = yield call(createBankHokService,logged_customer_info.member_id_code,logged_customer_info.member_id, hokToCreate);
        if (!result) {
            yield call(setGlobalErrorPopup, true);
        } else {
            yield put(setCreateBankHokSuccess(result));
            yield put(push('/directorship/CreditsAndDebits/DirectDebitSuccess/bankConfirmationPage/'))
        }
    }catch(e){
            yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
    }
}

function* handleGetTransactionDetails(action){
    yield call(setGlobalLoading, true);
    try{
        const {current_customer_info:{member_id,member_id_code}}= mLib.saveData.customerData.get();
        const res = yield call(getTransactionDetails, member_id_code, member_id, action.cgData);
        yield put(setTransactionDetails(res));
    }catch(e){
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
        yield put(setIsLoading(false));
    }
}

function* handlePostDebitAuthorizationCreditcard(action){
    const {current_customer_info:{member_id,member_id_code}}= mLib.saveData.customerData.get();
    const {lastFourDigits,token,isCollectDebth,cardName} = action;
    yield call(setGlobalLoading, true);
    try{
        const res = yield call(postDebitAuthorizationCreditcard, member_id_code, member_id, token, isCollectDebth,lastFourDigits,cardName);
        yield put(setCreditCardSuccessReponse(res));
        yield put(push('/directorship/CreditsAndDebits/DirectDebitSuccess/creditCardConfirmationPage/'))
    }catch(e){
        insertLog(FORM_FIELDS_TO_LOG.failureToCreateHok);
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
    }
}

export default function* rootSaga() {
    yield takeLatest(PREPARE_TRANSACTION, handlePrepeareTransaction);
    yield takeLatest(GET_DIRECT_DEBIT_DATA, handleGetDirectDebitData);
    yield takeLatest(GET_DEBTS_DETAILS_FOR_PAYER, handleGetDebtsDetailsForPayer);
    yield takeLatest(GET_BANKS, handleGetBanks);
    yield takeLatest(GET_BRANCHES, handleGetBanksBranches);
    yield takeLatest(CREATE_BANK_HOK, handleCreateBankHok);
    yield takeLatest(GET_TRANSACTION_DETAILS, handleGetTransactionDetails);
    yield takeLatest(VALIDATE_BANK_DETAILS,handleValidateBankDetails);
    yield takeLatest(POST_DEBIT_AUTHORIZATION_CREDITCARD, handlePostDebitAuthorizationCreditcard);
}
