import React, { Component, Fragment } from 'react';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import cx from 'classnames';
import { withRouter, Redirect } from 'react-router-dom';
import Dashes from '../../../components/DebitAndCredits/Dashes/Dashes';
import { createBankHok, getTransactionDetails, postDebitAuthorizationCreditcard } from '../actions';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import { WithDirectDebitProps } from '../../../HOC/WithDirectDebit';
import { H1, MainHeadline, MainHeadlineScrollable, MainBody, CoupleButtons, ExpandableReadMore, Button } from '@maccabi/m-ui';
import style from './ConfirmationDirectDebits.scss';
import FamilyList from '../../../components/DebitAndCredits/FamilyList/FamilyList';
import BankDetails from '../../../components/DebitAndCredits/BankDetails/BankDetails';
import staticTxt from '../assets/staticText.json';
import CreditCardDetails from '../../../components/DebitAndCredits/CreditCardDetails/CreditCardDetails';
import JoiningConfirmation from '../../../components/DebitAndCredits/JoiningConfirmation/JoiningConfirmation';
import { CONFIRMATION_PAGE_TYPE } from '../constants';
import { TITLE_JOINING_CONFIRMATION_BANK, TITLE_JOINING_CONFIRMATION_CREDIT_CARD, JOIN, CANCEL } from './constants';
import { UPDATE_DIRECTDEBIT, DIERCT_DEBIT_AUTHORIZATION } from '../DirectDebitSuccess/constants';
import { DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS, DIRECT_DEBIT_INFORMATION_TEXT } from '../DirectDebit/constants';
import { makeSelectSelectedBankDetails, makeSelectAfterBankDetailsPage, makeSelectPayerCgData, makeSelectTransactionDetails } from '../selectors';
import { insertLog, FORM_FIELDS_TO_LOG } from './logFile';
import CgTransactionTimeout from '../../../components/DebitAndCredits/CgTransactionTimeout/CgTransactionTimeout';
const mapStateToProps = createStructuredSelector({
    payerCgData: makeSelectPayerCgData,
    selectedBankDetails: makeSelectSelectedBankDetails,
    afterBankDetailsPage: makeSelectAfterBankDetailsPage,
    transactionDetails: makeSelectTransactionDetails
});

const mapDispatchToProps = { postDebitAuthorizationCreditcard, getTransactionDetails, createBankHok };

@withRouter
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class ConfirmationDirectDebits extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isValid: false,
            agreeToTermsOfUse: false,
            agreeToTermsOfUseError: false,
            toggleLongText: false,

            errors: {
                modalErrortermsOfUse: false,
                errorMessageTerms: false,
                errorMessageSignature: false
            },
            checkBoxesChosen: {
                checkBoxSignature: false,
                checkBoxTerms: false
            }
        };
        this.agreeToTermsRef = React.createRef();
    }

    static propTypes = {
        isLoading: PropTypes.bool.isRequired
    };

    componentDidMount() {
        const { onDirectDebitLoad, getTransactionDetails, afterBankDetailsPage, match } = this.props;
        const confirmationPageType = match.params.type;
        this.setRouteLeavingGuard();
        if (mLib.customer.isParentAsChild()) {
            const url = mLib.url.getUrlByVersion(2, '/home');
            this.props.history.push(`/go/${encodeURIComponent(url)}`);
        } else {
            const isCretidCard = confirmationPageType === CONFIRMATION_PAGE_TYPE.CREDIT_CARD;
            const isBank = confirmationPageType === CONFIRMATION_PAGE_TYPE.BANK;
            onDirectDebitLoad(isCretidCard);
            if (isCretidCard) {
                const cg = sessionStorage.getItem('cg');
                getTransactionDetails(JSON.parse(cg));
                insertLog(FORM_FIELDS_TO_LOG.loadingConfirmationScreenCcHok);
            }
            if (isBank) {
                if (!afterBankDetailsPage) {
                    this.props.history.push('/directorship/CreditsAndDebits/DirectDebit/');
                }
                insertLog(FORM_FIELDS_TO_LOG.loadingConfirmationScreenBankHok);
            }
        }
    }

    get title() {
        const { payerDebitAuthorization } = this.props;
        return payerDebitAuthorization.is_active_auth_exists ? DIERCT_DEBIT_AUTHORIZATION : UPDATE_DIRECTDEBIT;
    }

    onCloseTermsOfUse(fromAgreeBtn) {
        this.isCreditCardDebit ? insertLog(FORM_FIELDS_TO_LOG.CcHokModelCreditcardTermsOk) : insertLog(FORM_FIELDS_TO_LOG.bankHokModelBankTermsOk);
        this.setState({
            agreeToTermsOfUse: fromAgreeBtn,
            agreeToTermsOfUseError: fromAgreeBtn ? '' : this.state.agreeToTermsOfUseError
        });
    }
    ClickTermsOfUseClose = () => {
        this.isCreditCardDebit
            ? insertLog(FORM_FIELDS_TO_LOG.CcHokModelCreditcardTermsClose)
            : insertLog(FORM_FIELDS_TO_LOG.bankHokModelBankTermsClose);
        this.setState({ agreeToTermsOfUse: false, checkBoxesChosen: { checkBoxTerms: false } });
    };
    handleAgreeTermsOfUse(event) {
        this.isCreditCardDebit ? insertLog(FORM_FIELDS_TO_LOG.CcHokModelCreditcardTerms) : insertLog(FORM_FIELDS_TO_LOG.bankHokModelBankTerms);
        const value = event.target.checked;
        !value && this.setState({ agreeToTermsOfUse: false });
    }

    clickLongText = () => {
        this.setState({ toggleLongText: !this.state.toggleLongText });
    };

    changeErrorMessageOfTermsOfUse = () => {
        this.isCreditCardDebit
            ? insertLog(FORM_FIELDS_TO_LOG.CcHokClickOnApprovalHokTerms)
            : insertLog(FORM_FIELDS_TO_LOG.bankHokClickOnApprovalHokTerms);
        this.setState(
            ({ checkBoxesChosen: { checkBoxTerms, checkBoxSignature } }) => ({
                checkBoxesChosen: { checkBoxTerms: !checkBoxTerms, checkBoxSignature }
            }),
            () => {
                if (this.state.checkBoxesChosen.checkBoxTerms) {
                    this.setState(({ errors: { errorMessageSignature } }) => ({
                        errors: { errorMessageTerms: false, errorMessageSignature }
                    }));
                }
            }
        );
    };

    changeErrorMessageSignature = () => {
        this.isCreditCardDebit
            ? insertLog(FORM_FIELDS_TO_LOG.CcHokClickOnHokConfirmationSignature)
            : insertLog(FORM_FIELDS_TO_LOG.bankHokClickOnHokConfirmationSignature);
        this.setState(
            ({ checkBoxesChosen: { checkBoxSignature, checkBoxTerms } }) => ({
                checkBoxesChosen: { checkBoxSignature: !checkBoxSignature, checkBoxTerms }
            }),
            () => {
                if (this.state.checkBoxesChosen.checkBoxSignature) {
                    this.setState(({ errors: { errorMessageTerms } }) => ({
                        errors: { errorMessageSignature: false, errorMessageTerms }
                    }));
                }
            }
        );
    };

    setRouteLeavingGuard = (shouldShow = true) => {
        const propsLeaving = {
            shouldBlockNavigation: shouldShow,
            navigate: this.props.history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    };

    get familyListItems() {
        const { payerBillingSubjects } = this.props;
        const { logged_customer_info } = mLib.saveData.customerData.get();
        return payerBillingSubjects && payerBillingSubjects.filter(({ member_id }) => member_id !== logged_customer_info.member_id);
    }

    goToCreditsAndDebitsLobby() {
        this.isCreditCardDebit
            ? insertLog(FORM_FIELDS_TO_LOG.CcHokClickDetailsOfCharges)
            : insertLog(FORM_FIELDS_TO_LOG.bankHokClickDetailsOfCharges);
        const url = mLib.url.getUrlByVersion(2, '/directorship/DebitsAndCredits');
        var win = window.open(url, '_blank');
        win.focus();
    }

    clickOnCancel() {
        this.isCreditCardDebit ? insertLog(FORM_FIELDS_TO_LOG.CcHokClickOnCancelBtn) : insertLog(FORM_FIELDS_TO_LOG.bankHokClickOnCancelBtn);
        this.props.history.push('/directorship/CreditsAndDebits/DirectDebit/');
    }

    onChangeBank() {
        this.setRouteLeavingGuard(false);
        insertLog(FORM_FIELDS_TO_LOG.bankHokClickOnEditBtn);
        setTimeout(() => this.props.history.push('/directorship/CreditsAndDebits/BankDebit/'), 50);
    }

    get activeHok() {
        const {
            payerDebitAuthorization: { is_active_auth_exists }
        } = this.props;
        return is_active_auth_exists;
    }

    onSubmit() {
        const {
            checkBoxesChosen: { checkBoxSignature, checkBoxTerms }
        } = this.state;
        this.setRouteLeavingGuard(false);
        this.isCreditCardDebit ? insertLog(FORM_FIELDS_TO_LOG.CcHokClickOnJoinBtn) : insertLog(FORM_FIELDS_TO_LOG.bankHokClickOnJoinBtn);
        if (!this.isValid) {
            !checkBoxTerms &&
                this.setState(({ errors: { errorMessageSignature } }) => ({ errors: { errorMessageTerms: true, errorMessageSignature } }));
            this.isCreditCardDebit
                ? insertLog(FORM_FIELDS_TO_LOG.CcHokTermsMustBeApproved)
                : insertLog(FORM_FIELDS_TO_LOG.bankHokTermsMustBeApproved);

            !checkBoxSignature &&
                this.setState(({ errors: { errorMessageTerms } }) => ({ errors: { errorMessageSignature: true, errorMessageTerms } }));
            this.isCreditCardDebit
                ? insertLog(FORM_FIELDS_TO_LOG.CcHokjoiningMustBeConfirmed)
                : insertLog(FORM_FIELDS_TO_LOG.bankHokjoiningMustBeConfirmed);

            return;
        }

        if (this.isBankDebit) {
            const {
                createBankHok,
                selectedBankDetails,
                payerTotalDebts = {},
                payerDebitAuthorization: { is_shaban_auth_only }
            } = this.props;
            const { shaban_debt = 0, additional_charges_debt = 0, kupa_debt = 0 } = payerTotalDebts;

            const shouldCollectDebts = additional_charges_debt + shaban_debt + (is_shaban_auth_only ? 0 : kupa_debt) > 0;

            return createBankHok({ ...selectedBankDetails, is_collect_debt: shouldCollectDebts });
        }
        if (this.isCreditCardDebit) {
            const {
                payerTotalDebts = {},
                postDebitAuthorizationCreditcard,
                transactionDetails,
                payerDebitAuthorization: { is_shaban_auth_only }
            } = this.props;
            const { shaban_debt = 0, additional_charges_debt = 0, kupa_debt = 0 } = payerTotalDebts;
            const is_collect_debt = additional_charges_debt + shaban_debt + (is_shaban_auth_only ? 0 : kupa_debt) > 0;
            const fourLastDigits =
                transactionDetails && transactionDetails.card_mask ? transactionDetails.card_mask.slice(transactionDetails.card_mask.length - 4) : '';
            const cardName = transactionDetails ? transactionDetails.card_name : '';
            const cg = sessionStorage.getItem('cg');
            postDebitAuthorizationCreditcard(JSON.parse(cg).token, is_collect_debt, fourLastDigits, cardName);
        }
    }

    get isBankDebit() {
        const confirmationPageType = this.props.match.params.type;
        return confirmationPageType === CONFIRMATION_PAGE_TYPE.BANK;
    }

    get isCreditCardDebit() {
        const confirmationPageType = this.props.match.params.type;
        return confirmationPageType === CONFIRMATION_PAGE_TYPE.CREDIT_CARD;
    }

    get isValid() {
        return this.state.checkBoxesChosen.checkBoxTerms && this.state.checkBoxesChosen.checkBoxSignature;
    }

    render() {
        const { isLoading, selectedBankDetails, transactionDetails } = this.props;
        const {
            errors: { errorMessageTerms, errorMessageSignature },
            agreeToTermsOfUse
        } = this.state;
        const fourLastDigits =
            transactionDetails && transactionDetails.card_mask ? transactionDetails.card_mask.slice(transactionDetails.card_mask.length - 4) : '';
        const creditCardType = transactionDetails ? transactionDetails.card_name : '';
        const joiningConfirmTitle = this.isBankDebit ? TITLE_JOINING_CONFIRMATION_BANK : TITLE_JOINING_CONFIRMATION_CREDIT_CARD;

        const needMarginOrNot = cx({
            [style.detailsOfChargesAndCreditsWithoutMargin]: this.activeHok,
            [style.detailsOfChargesAndCredits]: !this.activeHok
        });

        return (
            !isLoading && (
                <Fragment>
                    <MainHeadline className={style.headLine}>
                        <MainHeadlineScrollable className={style.titleContainer}>
                            <H1>{this.title}</H1>
                        </MainHeadlineScrollable>
                    </MainHeadline>
                    <MainBody className={style.mainBody} layout="regular">
                        {!this.activeHok && (
                            <ExpandableReadMore
                                textToOpen={staticTxt.readMore}
                                textToClose={staticTxt.close}
                                toggleLongText={this.state.toggleLongText}
                                clickLongText={this.clickLongText}
                                children={DIRECT_DEBIT_INFORMATION_TEXT}
                            />
                        )}

                        <Button
                            className={cx(needMarginOrNot, style.detailsOfChargesAndCredits)}
                            rel="noopener noreferrer"
                            color="link"
                            onClick={this.goToCreditsAndDebitsLobby}>
                            {DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS}
                        </Button>

                        {this.isCreditCardDebit && (
                            <CreditCardDetails
                                creditCardType={creditCardType}
                                lastFourDigitsCreditCard={fourLastDigits}
                                showErrorMessage={errorMessageTerms}
                                changeErrorMessage={this.changeErrorMessageOfTermsOfUse}
                                fromConfirmationCreditCardHokPage={true}
                                clickTremOfUseOk={this.onCloseTermsOfUse}
                                ClickTermsOfUseClose={this.ClickTermsOfUseClose}
                                agreeToTermsRef={this.agreeToTermsRef}
                                onCheckChangeCallBack={this.handleAgreeTermsOfUse}
                                agreeToTermsOfUse={agreeToTermsOfUse}
                                fromConfirmationHokPage={true}
                            />
                        )}
                        {this.isBankDebit && (
                            <BankDetails
                                bankCode={selectedBankDetails.bankCode}
                                branchCode={selectedBankDetails.branchCode}
                                accountNumber={selectedBankDetails.accountNumber}
                                onChangeBank={this.onChangeBank}
                                fromConfirmationBankHokPage={true}
                                showErrorMessage={errorMessageTerms}
                                changeErrorMessage={this.changeErrorMessageOfTermsOfUse}
                                clickTremOfUseOk={this.onCloseTermsOfUse}
                                ClickTermsOfUseClose={this.ClickTermsOfUseClose}
                                agreeToTermsRef={this.agreeToTermsRef}
                                onCheckChangeCallBack={this.handleAgreeTermsOfUse}
                                agreeToTermsOfUse={agreeToTermsOfUse}
                                fromConfirmationHokPage={true}
                            />
                        )}
                        {this.familyListItems && this.familyListItems.length > 0 && (
                            <Fragment>
                                <Dashes cls={'mb-7 mt-7'} />
                                <FamilyList items={this.familyListItems} className={style.familyList} fromConfirmationHokPage={true} />
                            </Fragment>
                        )}
                        <JoiningConfirmation
                            showErrorMessage={errorMessageSignature}
                            changeErrorMessage={this.changeErrorMessageSignature}
                            title={joiningConfirmTitle}
                        />
                        <CoupleButtons
                            secondText={CANCEL}
                            firstText={JOIN}
                            firstOnClick={this.onSubmit}
                            secondOnClick={this.clickOnCancel}
                            classname={style.coupleButtonsWrap}
                            firstclassname={style.firstclassname}
                        />
                    </MainBody>
                    <CgTransactionTimeout isCreditCardPage={this.isCreditCardDebit} />
                </Fragment>
            )
        );
    }
}

export default WithDirectDebitProps(ConfirmationDirectDebits);
