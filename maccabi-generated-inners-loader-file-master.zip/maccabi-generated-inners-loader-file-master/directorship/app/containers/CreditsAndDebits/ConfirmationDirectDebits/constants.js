import mLib from '@maccabi/m-lib';
import {ConfirmationDirectDebitsUrl,URL_DIRECT_DEBIT} from '../constants';

export const CANCEL = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'CANCEL', 'ביטול');
export const DIERCT_DEBIT_AUTHORIZATION = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'DIERCT_DEBIT_AUTHORIZATION',
    'הסדרת הרשאה לחיוב חשבון (הוראת קבע)'
);
export const DIRECT_DEBIT_INFORMATION_TEXT = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_INFORMATION_TEXT',
    'הסדרת אמצעי תשלום לחיוב חשבון (הוראת קבע) מאפשרת לחברי מכבי יתרונות ורבים, ביניהם : רכישת תרופות בבתי מרקחת מכבי פארם באמצעות הכרטיס המגנטי, תשלום היטלים באופן נוח ומהיר, קבלת החזרים ישירות לחשבון הבנק ועוד. עדכון הוראת הקבע באמצעותה משולמים דמי החברות, תכניות הביטוח המשלימות והשתתפויות העצמיות, אפשרי בכל עת'
);

export const JOIN = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'JOIN', 'הצטרפות');
export const DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS = mLib.resources.getResource(
    URL_DIRECT_DEBIT,
    'DIRECT_DEBIT_FOR_DETAILS_OF_CHARGES_AND_CREDITS',
    'לפרטי חיובים וזיכויים'
);
export const UPDATE_DIRECTDEBIT = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'UPDATE_DIRECTDEBIT',
    'עדכון הרשאה לחיוב חשבון (הוראת קבע)'
);
export const TITLE_JOINING_CONFIRMATION_CREDIT_CARD = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'TITLE_JOINING_CONFIRMATION_CREDIT_CARD',
    'אישור הרשאה לכרטיס אשראי'
);
export const TITLE_JOINING_CONFIRMATION_BANK = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'TITLE_JOINING_CONFIRMATION_BANK',
    'אישור הרשאה לחשבון בנק'
);