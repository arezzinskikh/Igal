import mLib from '@maccabi/m-lib';

export const FORM_PAGE_ALIAS = 'directorship/CreditsAndDebits/ConfirmationDirectDebits/';

export const FORM_FIELDS_TO_LOG = {
    loadingConfirmationScreenBankHok: {
        elementId: 4469,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1000
    }, 
    bankHokClickDetailsOfCharges: {
        elementId: 4470,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    bankHokClickOnEditBtn: {      
        elementId: 4471,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    bankHokClickOnApprovalHokTerms: {
        elementId: 4472,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    bankHokClickOnHokConfirmationSignature: {
        elementId: 4473,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    bankHokClickOnCancelBtn: {
        elementId: 4474,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    bankHokClickOnJoinBtn: {
        elementId: 4475,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    bankHokTermsMustBeApproved: {
        elementId: 4476,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674   
    },
    bankHokjoiningMustBeConfirmed: {
        elementId: 4477,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674   
    },
    bankHokModelBankTerms: {
        elementId: 4478,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674   
    },
    bankHokModelBankTermsClose: {
        elementId: 4479,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    bankHokModelBankTermsPrintSave: {
        elementId: 4480,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    bankHokModelBankTermsOk: {
        elementId: 4481,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    loadingConfirmationScreenCcHok: {
        elementId: 4456,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1000
    }, 
    CcHokClickDetailsOfCharges: {
        elementId: 4457,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    CcHokClickOnEditBtn: {      
        elementId: 4458,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    CcHokClickOnApprovalHokTerms: {
        elementId: 4459,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    CcHokClickOnHokConfirmationSignature: {
        elementId: 4460,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    CcHokClickOnCancelBtn: {
        elementId: 4461,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    CcHokClickOnJoinBtn: {
        elementId: 4462,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    CcHokTermsMustBeApproved: {
        elementId: 4463,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674   
    },
    CcHokjoiningMustBeConfirmed: {
        elementId: 4464,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674   
    },
    CcHokModelCreditcardTerms: {
        elementId: 4465,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1674   
    },
    CcHokModelCreditcardTermsClose: {
        elementId: 4466,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    CCHokModelCreditcardTermsPrintSave: {
        elementId: 4467,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    CcHokModelCreditcardTermsOk: {
        elementId: 4468,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    failureToCreateHok: {
        elementId: 4505,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1347   
    }
}

export const insertLog = (log) => {
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId, log.variables);   
}

