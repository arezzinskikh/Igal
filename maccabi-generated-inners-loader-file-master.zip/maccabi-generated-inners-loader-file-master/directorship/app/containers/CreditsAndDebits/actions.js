import { 
    PREPARE_TRANSACTION , 
    GET_DIRECT_DEBIT_DATA, 
    SET_PAYER_BILLING_SUBJECTS, 
    SET_PAYER_DEBIT_AUTHORIZATION, 
    SET_PAYER_TOTAL_DEBTS, 
    SET_IS_LOADING, 
    GET_BANKS,
    SET_BANKS,
    GET_BRANCHES,
    SET_BRANCHES,
    GET_DEBTS_DETAILS_FOR_PAYER,
    SET_DEBTS_DETAILS_FOR_PAYER,
    VALIDATE_BANK_DETAILS,
    SET_VALID_BANK_DETAILS,
    CLEAR_BANK_DETAILS,
    SET_NOT_VALID_BANK_DETAILS,
    CREATE_BANK_HOK,
    SET_CREATE_BANK_HOK_SUCCESS,
    GET_TRANSACTION_DETAILS,
    SET_TRANSACTION_DETAILS,
    POST_DEBIT_AUTHORIZATION_CREDITCARD,
    SET_CREATE_CREDIT_CARD_HOK_SUCCESS
} from './constants';

export function postDebitAuthorizationCreditcard(token , isCollectDebth,lastFourDigits,cardName){
    return {
        type:POST_DEBIT_AUTHORIZATION_CREDITCARD,
        token ,
        isCollectDebth,
        lastFourDigits,
        cardName
    }
}

export function getTransactionDetails(cgData){
    return{
        type:GET_TRANSACTION_DETAILS,
        cgData
    }
}

export function setTransactionDetails(transactionDetails){
    return{
        type:SET_TRANSACTION_DETAILS,
        transactionDetails
    }
}

export function setBankDetailsNotValid(){
    return{
        type:SET_NOT_VALID_BANK_DETAILS
    }
}

export function setBankDetailsAfterValidation(bankCode,branchCode,accountNumber,accountOwnerName,moneyValue,dateString){
    return{
        type:SET_VALID_BANK_DETAILS,
        bankCode,
        branchCode,
        accountNumber,
        accountOwnerName,
        moneyValue,
        dateString
    }
}
export function clearBankDetailsAfterValidation(){
    return{
        type:CLEAR_BANK_DETAILS,
  
    }
}



export function validateBankDetails({bankCode,branchCode,accountNumber,accountOwnerName,push, moneyValue,dateString}){
    return{
        type:VALIDATE_BANK_DETAILS,
        push,
        bankCode,
        branchCode,
        accountNumber,
        accountOwnerName,
        moneyValue,
        dateString
    }
}

export function setBankBranches({bankId,branches}){
    return{
        type:SET_BRANCHES,
        bankId,
        branches
    }
}

export function setBanks(banks){
    return{
        type:SET_BANKS,
        banks
    }
}

export function getBanksBranches(bankId){
    return{
        type:GET_BRANCHES,
        bankId
    }
}

export function getBanks(){
    return{
        type:GET_BANKS
    }
}

export function getDirectDebitData(isConfirmatioPageOfCC=false) {
    return {
        type: GET_DIRECT_DEBIT_DATA,
        isConfirmatioPageOfCC
    };
}

export function prepareTransaction(push) {
    return {
        type: PREPARE_TRANSACTION,
        push
    };
}


export function setPayerBillingSubjects(payerBillingSubjects) {
    return {
        type: SET_PAYER_BILLING_SUBJECTS,
        payerBillingSubjects
    };
}

export function setPayerDebitAuthorization(payerDebitAuthorization) {
    return {
        type: SET_PAYER_DEBIT_AUTHORIZATION,
        payerDebitAuthorization
    };
}

export function setPayerTotalDebts(payerTotalDebts) {
    return {
        type: SET_PAYER_TOTAL_DEBTS,
        payerTotalDebts
    };
}

export function setIsLoading(isLoading) {
    return {
        type: SET_IS_LOADING,
        isLoading
    };
}

export function getDebtsDetailsForPayer() {
    return {
        type: GET_DEBTS_DETAILS_FOR_PAYER
    };
}

export function setDebtsDetailsForPayer(debtsDetailsForPayer) {
    return {
        type: SET_DEBTS_DETAILS_FOR_PAYER,
        debtsDetailsForPayer
    };
}

export function createBankHok(data) {
    return {
        type: CREATE_BANK_HOK,
        data
    };
}

export function setCreateBankHokSuccess(response){
    return {
        type: SET_CREATE_BANK_HOK_SUCCESS,
        response
    };
}

export function setCreditCardSuccessReponse(response){
    return{
        type:SET_CREATE_CREDIT_CARD_HOK_SUCCESS,
        response
    }
}