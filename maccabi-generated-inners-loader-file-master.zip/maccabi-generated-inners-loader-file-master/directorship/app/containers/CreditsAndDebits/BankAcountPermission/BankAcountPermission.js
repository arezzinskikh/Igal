import React, { Component, Fragment } from 'react';
import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import { connect } from 'react-redux';
import style from './BankAcountPermission.scss';
import staticTxt from '../assets/staticText.json';
import {
    MainHeadline,
    MainHeadlineScrollable,
    H1,
    ExpandableReadMore,
    MainBody,
    H2,
    Input,
    InputMoney,
    DatePicker,
    CheckboxGroup,
    CoupleButtons
} from '@maccabi/m-ui';
import { makeSelectBankBranches, makeSelectBanks, makeSelectBankDetailsError, makeSelectSelectedBankDetails } from '../selectors';
import { createStructuredSelector } from 'reselect';
import { getBanks, getBanksBranches, validateBankDetails, clearBankDetailsAfterValidation } from '../actions';
import MemoBankDropDown from '../../../HOC/MemoBankDropDown';
import {
    ACCOUNT_NUMBER_VALIDATION_ERROR,
    FORM_ACCOUNT_NUMBER_LABEL,
    FORM_ACCOUNT_OWNER,
    FORM_HEADLINE,
    ACCOUNT_OWNER_VALIDATION_ERROR,
    BANK_CODE_VALIDATION_ERROR,
    BRANCH_CODE_VALIDATION_ERROR,
    FORM_ACCOUNT_MAX_LIMIT_TO_CHARGE,
    DETAILS_OF_BANK_DEBIT_HJEADLINE,
    BANK_DETAILS_DISCLIMER,
    GENERAL_AUTH,
    LIMIT_AUTH,
    GENERAL_DISCLIME,
    END_DATE_LABEL,
    GENERAL_FOTTER_DICLIMER,
    VALIDATE_BTN_TEXT,
    BANK_DEBIT_WITH_aCTIVE,
    BANK_DEBIT_TITLE,
    CANCEL,
    BANK_DEBIT_SUB_TITLE
} from './constatns';
import { withRouter } from 'react-router-dom';
import Dashes from '../../../components/DebitAndCredits/Dashes/Dashes';
import BankNoDigitalPopup from '../../../components/DebitAndCredits/BankNoDigitalPopup/BankNoDigitalPopup';
import { WithDirectDebitProps } from '../../../HOC/WithDirectDebit';
import BranchesAutoComplete from '../../../components/DebitAndCredits/BranchesAutoComplete/BranchesAutoComplete';
import { insertLog, FORM_FIELDS_TO_LOG } from './logFile';

const mapDispatchToProps = { getBanks, getBanksBranches, validateBankDetails, clearBankDetailsAfterValidation };

const mapStateToProps = createStructuredSelector({
    banks: makeSelectBanks,
    banksBranches: makeSelectBankBranches,
    bankDetailsError: makeSelectBankDetailsError,
    selectedBankDetails: makeSelectSelectedBankDetails
});

@withRouter
@WithDirectDebitProps
@connect(mapStateToProps, mapDispatchToProps)
class BankAcountPermission extends Component {
    constructor(props) {
        super(props);
        const {
            logged_customer_info: { f_name_hebrew, l_name_hebrew }
        } = mLib.saveData.customerData.get();
        this.state = {
            selectedBankCode: -1,
            selectedBankBranchCode: -1,
            accountNumber: '',
            accountOwnerName: `${f_name_hebrew} ${l_name_hebrew}`,
            accountNumberError: '',
            accountOwnerNameError: '',
            bankError: '',
            branchError: '',
            openLimitaions: false,
            selectedIndex: 0,
            moneyValue: 0,
            dateString: null,
            noDigitalBank: false,
            toggleLongText: false,
            bankNameForLog: ''
        };
    }

    componentDidMount() {
        this.props.getBanks();
        this.props.onDirectDebitLoad();
        const { bankCode, branchCode, accountNumber, accountOwnerName, moneyValue, dateString } = this.props.selectedBankDetails;
        const hasAccountNumber = accountNumber && accountNumber !== '';
        const hasBankCode = bankCode && bankCode !== -1;
        const hasBranchCode = branchCode && branchCode !== -1;
        const hasAccountOwnerName = accountOwnerName && accountOwnerName !== '';
        const hasMoneyValue = moneyValue && moneyValue !== 0;
        const hasDateString = dateString && dateString !== null;
        bankCode ?    this.setRouteLeavingGuard() :''
        hasAccountNumber && this.setState({ accountNumber });
        hasAccountOwnerName && this.setState({ accountOwnerName });
        hasMoneyValue && this.setState({ moneyValue });
        hasDateString && this.setState({ dateString });
        hasBankCode && this.setState({ selectedBankCode: bankCode });
        hasBranchCode && this.setState({ selectedBankBranchCode: branchCode });
    }

    onBankSelect = (bankCode, bank_name) => {
        const { selectedBankCode } = this.state;
        const log = FORM_FIELDS_TO_LOG.dropDownSelectBank;
        log.variables = [{ key: 'element_id', description: bank_name }];
        insertLog(log);
        if (bankCode === selectedBankCode) return;
        const { getBanksBranches, banks } = this.props;
        const {bank_code = -1, automatic_reporting_ind= true} = banks.find(({ bank_code }) => bank_code === bankCode) || {};
        if (!automatic_reporting_ind) {
            this.setState({
                noDigitalBank: true,
                bankNameForLog: bank_name
            });
            return;
        }
        this.setState({
            selectedBankCode: bankCode,
            selectedBankBranchCode: -1,
            bankError: '',
            branchError: ''
        });
        setTimeout(()=>bankCode !== -1? this.setRouteLeavingGuard(): this.didShowRouteLeavingGuard(),50);
        bank_code !== -1 && getBanksBranches(bank_code);
    };

    onBankBranchSelect = brachCode => {
        const log = FORM_FIELDS_TO_LOG.dropDownSelectBranch;
        log.variables = [{ key: 'element_id', description: brachCode }];
        insertLog(log);
        this.setState({
            selectedBankBranchCode: brachCode,
            branchError: ''
        });
        setTimeout(()=>brachCode !== -1? this.setRouteLeavingGuard(): this.didShowRouteLeavingGuard(),50);
    };

    accountNumberChange = accountNumber => {
        const { selectedBankBranchIndex } = this.state;
        if (selectedBankBranchIndex === -1) return;
        if (accountNumber.length > 9 ) return;
        this.setState({
            accountNumber,
            accountNumberError:  '' 
        });
        setTimeout(()=>accountNumber !== ''? this.setRouteLeavingGuard(): this.didShowRouteLeavingGuard(),50);
    };

    validateBankDetails = () => {
        insertLog(FORM_FIELDS_TO_LOG.continuButton);
        const { accountNumber, accountOwnerName, moneyValue, dateString, selectedBankBranchCode, selectedBankCode } = this.state;
        const { validateBankDetails } = this.props;
        this.setRouteLeavingGuard(false);   
        if (selectedBankCode === -1 || selectedBankBranchCode === -1 || accountNumber === '' || accountOwnerName === '') {
            this.setState({
                accountNumberError: accountNumber === '' ? ACCOUNT_NUMBER_VALIDATION_ERROR : '',
                accountOwnerNameError: accountOwnerName === '' ? ACCOUNT_OWNER_VALIDATION_ERROR : '',
                bankError: selectedBankCode === -1 ? BANK_CODE_VALIDATION_ERROR : '',
                branchError: selectedBankBranchCode === -1 ? BRANCH_CODE_VALIDATION_ERROR : ''
            });
            return;
        }
        validateBankDetails({
            push: this.props.history.push,
            bankCode: selectedBankCode,
            branchCode: selectedBankBranchCode,
            accountNumber: accountNumber,
            accountOwnerName,
            moneyValue,
            dateString
        });
    };

    clickOnCancel = () => {
        insertLog(FORM_FIELDS_TO_LOG.cancelButton);
        const {clearBankDetailsAfterValidation} = this.props
        this.props.history.push('/directorship/CreditsAndDebits/DirectDebit/');
        clearBankDetailsAfterValidation()
    };

    changeApprovalWithLimitaions = index => {
        this.setState({ openLimitaions: index === 1, selectedIndex: index });
        const isUnrestrictedPermission = index === 0;
        const isPermissionIncludesRestrictions = index === 1;
        if (isUnrestrictedPermission) {
            insertLog(FORM_FIELDS_TO_LOG.unrestrictedPermission);
            this.setState({ moneyValue: 0, dateString: null });
        }
        isPermissionIncludesRestrictions && insertLog(FORM_FIELDS_TO_LOG.permissionIncludesRestrictions);
    };

    onDateChange = e => {
        insertLog(FORM_FIELDS_TO_LOG.selectLlastDateLimitBilling);
        const dateString = e && e._d && e._d.toISOString().slice(0, -5);
        this.setState({ dateString });
        this.setRouteLeavingGuard();
    };

    createInputMoneyLog = () => {
        insertLog(FORM_FIELDS_TO_LOG.selectBillableAmountCeiling);
    };

    onMonenyChange = event => {
        const { value } = event.target;
        if (value.length > 9) return;
        this.setState({ moneyValue: value !== '' ? value : 0 });
        setTimeout(()=>value !== ''? this.setRouteLeavingGuard(): this.didShowRouteLeavingGuard(),50);
    };

    didShowRouteLeavingGuard = ()=>{
        const { selectedBankCode, selectedBankBranchCode, accountNumber, moneyValue, dateString } = this.state;
        if (selectedBankCode   === -1 && selectedBankBranchCode ===-1 && accountNumber === '' && moneyValue === 0 && dateString === null )
        {
            this.setRouteLeavingGuard(false)
        }
    }

    get mainTitle() {
        const {
            payerDebitAuthorization: { is_active_auth_exists },
            isLoading
        } = this.props;
        if (isLoading) return '';
        if (is_active_auth_exists) return BANK_DEBIT_WITH_aCTIVE;
        return BANK_DEBIT_TITLE;
    }

    get subTItle() {
        const {
            payerDebitAuthorization: { is_active_auth_exists },
            isLoading
        } = this.props;
        if (isLoading) return '';
        if (!is_active_auth_exists) return BANK_DEBIT_SUB_TITLE;
        return '';
    }

    createAccountLog = () => {
        const { accountNumber } = this.state;
        if (accountNumber.length > 0) {
            insertLog(FORM_FIELDS_TO_LOG.enterAccountNumber);
        }
    };

    onLongTextExpandOrCollapse = () => {
        this.setState({ toggleLongText: !this.state.toggleLongText });
    };

    setRouteLeavingGuard =(shouldShow=true)=> {
        const propsLeaving = {
            shouldBlockNavigation: shouldShow,
            navigate: this.props.history.push
        };
        mLib.routeLeavingGuard.route.setRouteLeavingGuard(propsLeaving);
    }



    render() {
        const { banks = [], banksBranches = {}, bankDetailsError } = this.props;
        const {
            selectedBankCode,
            selectedBankBranchCode,
            accountNumber,
            accountOwnerName,
            accountNumberError,
            accountOwnerNameError,
            bankError,
            branchError,
            moneyValue,
            noDigitalBank,
            dateString
        } = this.state;
        const branchesByBankCode = banksBranches[selectedBankCode] || [];

        const maxDate = new Date(new Date().getFullYear() + 20, new Date().getMonth(), new Date().getDate());
        const subtitleDindntExist = cx({
            'mt-5': this.subTItle === ''
        });

        return (
            <Fragment>
                <MainHeadline className={style.headLine}>
                    <MainHeadlineScrollable className={style.titleContainer}>
                        <H1>{this.mainTitle}</H1>
                    </MainHeadlineScrollable>
                </MainHeadline>
                <MainBody className="" layout="regular">
                    {this.subTItle !== '' && (
                        <div className={style.subTItleWrap}>
                            <ExpandableReadMore
                                textToOpen={staticTxt.readMore}
                                textToClose={staticTxt.close}
                                toggleLongText={this.state.toggleLongText}
                                clickLongText={this.onLongTextExpandOrCollapse}
                                children={this.subTItle}
                            />
                        </div>
                    )}
                    <H2 className={subtitleDindntExist}>{FORM_HEADLINE}</H2>
                    <div className={cx(style.inputsRow, 'mt-5')}>
                        <div className={style.inputCol}>
                            <MemoBankDropDown
                                onBankSelect={this.onBankSelect}
                                bankDetailsError={bankError || bankDetailsError}
                                banks={banks}
                                selectedBankCode={selectedBankCode}
                            />
                        </div>
                        <div className={style.inputCol}>
                            <BranchesAutoComplete
                                branchError={branchError || bankDetailsError}
                                branches={branchesByBankCode}
                                selectedBranchCode={selectedBankBranchCode}
                                onBranchSelect={this.onBankBranchSelect}
                                selectedBankCode={selectedBankCode}
                            />
                        </div>
                    </div>
                    <div className={cx(style.inputsRow, style.secondRow)}>
                        <div className={style.inputCol}>
                            <Input
                                onChange={e => {
                                    this.accountNumberChange(e.target.value);
                                }}
                                onBlur={this.createAccountLog}
                                width={'regular'}
                                value={accountNumber}
                                type={'text'}
                                label={FORM_ACCOUNT_NUMBER_LABEL}
                                hook={'accountNumber'}
                                error={!!accountNumberError ? accountNumberError : bankDetailsError ? 'אחד מהפרטים שהזנת אינו תקין' : ''}
                                inputclassname={bankDetailsError ? style.errorDrop : ''}
                                errorclassname={style.removePadding}
                            />
                        </div>
                        <div className={style.inputCol}>
                            <Input
                                disabled={true}
                                width={'regular'}
                                value={accountOwnerName}
                                type={'text'}
                                label={FORM_ACCOUNT_OWNER}
                                hook={'accountOwnername'}
                                error={accountOwnerNameError}
                                errorclassname={style.removePadding}
                            />
                        </div>
                    </div>
                    <Dashes cls="mb-7" />
                    <H2>{DETAILS_OF_BANK_DEBIT_HJEADLINE}</H2>
                    <div className="mb-7 mt-2">{BANK_DETAILS_DISCLIMER}</div>
                    <div className={cx(style.limitationsAlert, 'mb-5')}>סוג ההרשאה</div>
                    <div>
                        <CheckboxGroup
                            classnamecheckboxgroup={style.radioContainer}
                            classnamecheckboxradio={style.radioLabel}
                            selectedindex={this.state.selectedIndex}
                            onCheck={this.changeApprovalWithLimitaions}>
                            <label className="mb-5"> {GENERAL_AUTH}</label>
                            <label className="mb-5"> {LIMIT_AUTH}</label>
                        </CheckboxGroup>
                    </div>

                    <div className={cx(style.limitationsAlert, 'mb-5')}>{GENERAL_DISCLIME}</div>
                    {this.state.openLimitaions && (
                        <Fragment>
                            <div className={style.limitaionsConatiner}>
                                <InputMoney
                                    wrapClassName={style.inputMoney}
                                    label={FORM_ACCOUNT_MAX_LIMIT_TO_CHARGE}
                                    value={moneyValue}
                                    onChange={this.onMonenyChange}
                                    onBlur={this.createInputMoneyLog}
                                />
                                <DatePicker
                                    className="mr-5"
                                    minDate={new Date()}
                                    maxDate={maxDate}
                                    placeholder={END_DATE_LABEL}
                                    getDate={this.onDateChange}
                                    date={dateString}
                                />
                            </div>
                            <div className="mb-7">{GENERAL_FOTTER_DICLIMER}</div>
                        </Fragment>
                    )}
                    <div>
                        <CoupleButtons
                            secondText={CANCEL}
                            firstText={VALIDATE_BTN_TEXT}
                            firstOnClick={this.validateBankDetails}
                            secondOnClick={this.clickOnCancel}
                            classname={style.coupleButtonsWrap}
                            firstclassname={style.firstclassname}
                        />
                    </div>
                </MainBody>
                <BankNoDigitalPopup
                    isOpen={noDigitalBank}
                    onClose={() => this.setState({ noDigitalBank: false })}
                    selectedBankName={this.state.bankNameForLog}
                />
            </Fragment>
        );
    }
}

export default BankAcountPermission;
