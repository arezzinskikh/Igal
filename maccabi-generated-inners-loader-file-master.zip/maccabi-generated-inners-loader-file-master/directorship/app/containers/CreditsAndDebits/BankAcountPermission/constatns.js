import mLib from '@maccabi/m-lib';
import { URL_BANK_DEBIT } from '../constants';
const URL = URL_BANK_DEBIT;

const ACCOUNT_NUMBER_VALIDATION_ERROR_KEY = 'ACCOUNT_NUMBER_VALIDATION_ERROR';
const ACCOUNT_NUMBER_VALIDATION_ERROR_VALUE = 'יש להזין מספר חשבון';
export const ACCOUNT_NUMBER_VALIDATION_ERROR = mLib.resources.getResource(
    URL,
    ACCOUNT_NUMBER_VALIDATION_ERROR_KEY,
    ACCOUNT_NUMBER_VALIDATION_ERROR_VALUE
);

const ACCOUNT_OWNER_VALIDATION_ERROR_KEY = 'ACCOUNT_OWNER_VALIDATION_ERROR';
const ACCOUNT_OWNER_VALIDATION_ERROR_VALUE = 'יש להזין את בעל החשבון';
export const ACCOUNT_OWNER_VALIDATION_ERROR = mLib.resources.getResource(
    URL,
    ACCOUNT_OWNER_VALIDATION_ERROR_KEY,
    ACCOUNT_OWNER_VALIDATION_ERROR_VALUE
);

const BANK_CODE_VALIDATION_ERROR_KEY = 'BANK_CODE_VALIDATION_ERROR';
const BANK_CODE_VALIDATION_ERROR_VALUE = 'יש להזין מספר בנק';
export const BANK_CODE_VALIDATION_ERROR = mLib.resources.getResource(URL, BANK_CODE_VALIDATION_ERROR_KEY, BANK_CODE_VALIDATION_ERROR_VALUE);

const BRANCH_CODE_VALIDATION_ERROR_KEY = 'BRANCH_CODE_VALIDATION_ERROR';
const BRANCH_CODE_VALIDATION_ERROR_VALUE = 'יש להזין מספר סניף';
export const BRANCH_CODE_VALIDATION_ERROR = mLib.resources.getResource(URL, BRANCH_CODE_VALIDATION_ERROR_KEY, BRANCH_CODE_VALIDATION_ERROR_VALUE);

const FORM_HEADLINE_KEY = 'FORM_HEADLINE';
const FORM_HEADLINE_VALUE = 'פרטי חשבון לחיוב';
export const FORM_HEADLINE = mLib.resources.getResource(URL, FORM_HEADLINE_KEY, FORM_HEADLINE_VALUE);

const FORM_BANK_LABEL_KEY = 'FORM_BANK_LABEL';
const FORM_BANK_LABEL_VALUE = 'בנק';
export const FORM_BANK_LABEL = mLib.resources.getResource(URL, FORM_BANK_LABEL_KEY, FORM_BANK_LABEL_VALUE);

const FORM_BRANCH_LABEL_KEY = 'FORM_BRANCH_LABEL';
const FORM_BRANCH_LABEL_VALUE = 'סניף';
export const FORM_BRANCH_LABEL = mLib.resources.getResource(URL, FORM_BRANCH_LABEL_KEY, FORM_BRANCH_LABEL_VALUE);

const FORM_ACCOUNT_NUMBER_LABEL_KEY = 'FORM_ACCOUNT_NUMBER_LABEL';
const FORM_ACCOUNT_NUMBER_LABEL_VALUE = 'מספר חשבון';
export const FORM_ACCOUNT_NUMBER_LABEL = mLib.resources.getResource(URL, FORM_ACCOUNT_NUMBER_LABEL_KEY, FORM_ACCOUNT_NUMBER_LABEL_VALUE);

const FORM_ACCOUNT_OWNER_KEY = 'FORM_ACCOUNT_OWNER';
const FORM_ACCOUNT_OWNER_VALUE = 'שם בעל החשבון';
export const FORM_ACCOUNT_OWNER = mLib.resources.getResource(URL, FORM_ACCOUNT_OWNER_KEY, FORM_ACCOUNT_OWNER_VALUE);

const FORM_ACCOUNT_MAX_LIMIT_TO_CHARGE_KEY = 'FORM_ACCOUNT_OWNER';
const FORM_ACCOUNT_MAX_LIMIT_TO_CHARGE_VALUE = 'תקרת סכום לחיוב';
export const FORM_ACCOUNT_MAX_LIMIT_TO_CHARGE = mLib.resources.getResource(
    URL,
    FORM_ACCOUNT_MAX_LIMIT_TO_CHARGE_KEY,
    FORM_ACCOUNT_MAX_LIMIT_TO_CHARGE_VALUE
);

const DETAILS_OF_BANK_DEBIT_HJEADLINE_KEY = 'DETAILS_OF_BANK_DEBIT_HJEADLINE';
const DETAILS_OF_BANK_DEBIT_HJEADLINE_VALUE = 'פרטי הוראת קבע';
export const DETAILS_OF_BANK_DEBIT_HJEADLINE = mLib.resources.getResource(
    URL,
    DETAILS_OF_BANK_DEBIT_HJEADLINE_KEY,
    DETAILS_OF_BANK_DEBIT_HJEADLINE_VALUE
);

const BANK_DETAILS_DISCLIMER_KEY = 'BANK_DETAILS_DISCLIMER';
const BANK_DETAILS_DISCLIMER_VALUE =
    'אם יישלחו על ידי המוטב חיובים שאינם עומדים בהגבלות שקבע הלקוח, הם יוחזרו על ידי הבנק, על כל המשמעויות הכרוכות בכך.';
export const BANK_DETAILS_DISCLIMER = mLib.resources.getResource(URL, BANK_DETAILS_DISCLIMER_KEY, BANK_DETAILS_DISCLIMER_VALUE);

const GENERAL_AUTH_KEY = 'GENERAL_AUTH';
const GENERAL_AUTH_VALUE = 'הרשאה כללית שאינה כוללת הגבלות';
export const GENERAL_AUTH = mLib.resources.getResource(URL, GENERAL_AUTH_KEY, GENERAL_AUTH_VALUE);

const LIMIT_AUTH_KEY = 'LIMIT_AUTH';
const LIMIT_AUTH_VALUE = 'הרשאה הכוללת לפחות אחת מההגבלות הבאות:';
export const LIMIT_AUTH = mLib.resources.getResource(URL, LIMIT_AUTH_KEY, LIMIT_AUTH_VALUE);

const GENERAL_DISCLIME_KEY = 'GENERAL_DISCLIME';
const GENERAL_DISCLIME_VALUE = 'לתשומת לבכם: אי סימון אחת מהחלופות המוצגות לעיל, משמעה בחירה בהרשאה כללית, שאינה כוללת הגבלות.';
export const GENERAL_DISCLIME = mLib.resources.getResource(URL, GENERAL_DISCLIME_KEY, GENERAL_DISCLIME_VALUE);

const END_DATE_LABEL_KEY = 'END_DATE_LABEL';
const END_DATE_LABEL_VALUE = 'תאריך סיום הוראת הקבע';
export const END_DATE_LABEL = mLib.resources.getResource(URL, END_DATE_LABEL_KEY, END_DATE_LABEL_VALUE);

const GENERAL_FOTTER_DICLIMER_KEY = 'GENERAL_FOTTER_DICLIMER';
const GENERAL_FOTTER_DICLIMER_VALUE = '* לידיעתך, במידה והחיוב יעלה על התקרה שהוזנה כל החיוב לא יבוצע ויירשם חוב במערכות מכבי שיהיה עליך להסדיר';
export const GENERAL_FOTTER_DICLIMER = mLib.resources.getResource(URL, GENERAL_FOTTER_DICLIMER_KEY, GENERAL_FOTTER_DICLIMER_VALUE);

const VALIDATE_BTN_TEXT_KEY = 'VALIDATE_BTN_TEXT';
const VALIDATE_BTN_TEXT_VALUE = 'המשך';
export const VALIDATE_BTN_TEXT = mLib.resources.getResource(URL, VALIDATE_BTN_TEXT_KEY, VALIDATE_BTN_TEXT_VALUE);


const CANCEL_KEY = 'CANCEL';
const CANCEL_VALUE = 'ביטול';
export const CANCEL = mLib.resources.getResource(URL, CANCEL_KEY, CANCEL_VALUE);

const BANK_DEBIT_WITH_aCTIVE_KEY = 'BANK_DEBIT_WITH_aCTIVE';
const BANK_DEBIT_WITH_aCTIVE_VALUE = 'עדכון הרשאה לחיוב חשבון (הוראת קבע)';
export const BANK_DEBIT_WITH_aCTIVE = mLib.resources.getResource(URL, BANK_DEBIT_WITH_aCTIVE_KEY, BANK_DEBIT_WITH_aCTIVE_VALUE);

export const BANK_DEBIT_TITLE = mLib.resources.getResource(URL, 'BANK_DEBIT_TITLE', 'הסדרת הרשאה לחיוב חשבון (הוראת קבע)');
export const BANK_DEBIT_SUB_TITLE = mLib.resources.getResource(
    URL,
    'BANK_DEBIT_SUB_TITLE',
    'הסדרת אמצעי תשלום לחיוב חשבון (הוראת קבע) מאפשרת לחברי מכבי יתרונות ורבים, ביניהם : רכישת תרופות בבתי מרקחת מכבי פארם באמצעות הכרטיס המגנטי, תשלום היטלים באופן נוח ומהיר, קבלת החזרים ישירות לחשבון הבנק ועוד. עדכון הוראת הקבע באמצעותה משולמים דמי החברות, תכניות הביטוח המשלימות והשתתפויות העצמיות, אפשרי בכל עת'
);

export const DEBTS_DETAILS_APPROVE_ONE_PAYMENT = mLib.resources.getResource(
    URL,
    'DEBTS_DETAILS_APPROVE_ONE_PAYMENT',
    'הסימון מהווה אישור לגביית החוב בתשלום אחד בהוראת הקבע החדשה המעודכנת'
);
