import mLib from '@maccabi/m-lib';

export const FORM_PAGE_ALIAS = 'directorship/CreditsAndDebits/BankDebit/';


export const FORM_FIELDS_TO_LOG = {
    dropDownBankName: {
        elementId: 4483,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    dropDownSelectBank: {      
        elementId: 4484,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 4487
    },
    dropDownSelectBranchOpen: {
        elementId: 4485,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    dropDownSelectBranch: {
        elementId: 4486,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 4487
    },
    enterAccountNumber: {
        elementId: 4488,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    openModalIsNotSupportedDigitally: {
        elementId: 4489,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 4146   
    },
    ModalNotSupportedBtnManualForm: {
        elementId: 4490,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    ModalNotSupportedBtnNewBank: {
        elementId: 4491,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    unrestrictedPermission: {
        elementId: 4492,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1345   
    },
    permissionIncludesRestrictions: {
        elementId: 4493,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1345   
    },
    selectBillableAmountCeiling: {
        elementId: 4494,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1344   
    },
    selectLlastDateLimitBilling: {
        elementId: 4495,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    continuButton: {
        elementId: 4496,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    clickOnXbtn: {
        elementId: 4504,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
    cancelButton: {
        elementId: 4516,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },

}

export const insertLog = (log) => {
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId, true, 0, log.variables);   
}


