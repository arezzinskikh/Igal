import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectCreditsAndDebitsData = state => {
    return state.get('CreditsAndDebitsData', initialState);
};

export const makeSelectPayerBillingSubjects = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('payerBillingSubjects');
});

export const makeSelectPayerDebitAuthorization = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('payerDebitAuthorization');
});

export const makeSelectPayerTotalDebts = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('payerTotalDebts');
});

export const makeSelectIsLoading = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('isLoading');
});

export const makeSelectPayerCgData = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('payerCgData');
});

export const makeSelectDebtsDetailsForPayer = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('debtsDetailsForPayer');
});

export const makeSelectBanks = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('banks');
});

export const makeSelectBankBranches = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('bankBranches');
});

export const makeSelectBankDetailsError = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.getIn(['selectedBankDetails','bankDetailsError']);
});


export const makeSelectTransactionDetails = createSelector(selectCreditsAndDebitsData, documentsData => {
    var transactionD =  documentsData.get('transactionDetails');
    return transactionD;
});

export const makeSelectSelectedBankDetails = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('selectedBankDetails');
});

export const makeSelectAfterBankDetailsPage = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('afterBankDetailsPage');
});

export const makeSelectBankHokResponse = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('bankHokSuccessResponse');
});

export const makeSelectCreditCardHokResponse = createSelector(selectCreditsAndDebitsData, documentsData => {
    return documentsData.get('creditCardDirectDebitSuccessResponse');
});
