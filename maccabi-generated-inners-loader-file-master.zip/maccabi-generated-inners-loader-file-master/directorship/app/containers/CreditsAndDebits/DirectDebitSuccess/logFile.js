import mLib from '@maccabi/m-lib';

export const FORM_PAGE_ALIAS = 'directorship/CreditsAndDebits/DirectDebitSuccess/';


export const FORM_FIELDS_TO_LOG = {
    hokBankSuccess: {
        elementId: 4450,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1000
    }, 
    hokBankSuccessClickFinishBtn: {
        elementId: 4451,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    }, 
    hokBankSuccessClickSaveOrPrint: {      
        elementId: 4452,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    hokCreditCardSuccess: {
        elementId: 4453,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1000
    }, 
    hokCreditCardSuccessClickFinishBtn: {
        elementId: 4454,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343
    },
    hokCreditCardSuccessClickSaveOrPrint: {
        elementId: 4455,
        elementInPage: FORM_PAGE_ALIAS,
        actionId: 1343   
    },
}

export const insertLog = (log) => {
        mLib.logs.insertCentralizedLog(log.elementId, log.elementInPage, log.actionId, log.variables);   
}

