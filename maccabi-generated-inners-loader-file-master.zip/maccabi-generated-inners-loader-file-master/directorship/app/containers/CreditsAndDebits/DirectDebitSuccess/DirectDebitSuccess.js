import React, { Fragment, useEffect } from 'react';
import { withRouter, useParams, Redirect } from 'react-router-dom';
import { compose } from 'recompose';
import { saveAs } from 'file-saver';
import cx from 'classnames';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { MainHeadline, MainHeadlineScrollable, MainBody, H4, H1, Icon, CoupleButtons, Card } from '@maccabi/m-ui';
import style from './DirectDebitSuccess.scss';
import {CONFIRMATION_PAGE_TYPE} from '../constants';
import {
    SUCCESS_TITLE_TYPE_BANK,
    SUCCESS_TITLE_TYPE_CREDITCARD,
    SUCCESS_BANK_REMARK,
    FINISH,
    SAVE_PRINT_CONFIRMATION,
    DEBT_REMARK_ON_SUCCESS_PAGE,
    DIERCT_DEBIT_AUTHORIZATION,
    UPDATE_DIRECTDEBIT
} from './constants';
import { makeSelectBankHokResponse,makeSelectCreditCardHokResponse,makeSelectPayerDebitAuthorization } from '../selectors';
import mLib from '@maccabi/m-lib';
import {insertLog , FORM_FIELDS_TO_LOG} from './logFile';

const mapStateToProps = createStructuredSelector({
    bankHokResponse: makeSelectBankHokResponse,
    creditCardHokResponse: makeSelectCreditCardHokResponse,
    payerDebitAuthorization: makeSelectPayerDebitAuthorization
});

const DirectDebitSuccess = (props) => {


    useEffect(() => {
        isBankDebit ? insertLog(FORM_FIELDS_TO_LOG.hokBankSuccess) : insertLog(FORM_FIELDS_TO_LOG.hokCreditCardSuccess)
    }, []);


    const { type } = useParams();
    const isBankDebit = type === CONFIRMATION_PAGE_TYPE.BANK;
    const response = isBankDebit ? props.bankHokResponse : props.creditCardHokResponse;
    if (!response || typeof response !== 'object') return <Redirect to="/directorship/CreditsAndDebits/DirectDebit/"/> 
    const pageTitle = props.payerDebitAuthorization?.is_active_auth_exists ? UPDATE_DIRECTDEBIT : DIERCT_DEBIT_AUTHORIZATION;

    const debtRemark = () => { 
        const {collect_debt_status} = response;
        const text = collect_debt_status ? DEBT_REMARK_ON_SUCCESS_PAGE[collect_debt_status] : ""
        return text;
    }

    const onFinish = () => {
        isBankDebit ? insertLog(FORM_FIELDS_TO_LOG.hokBankSuccessClickFinishBtn) : insertLog(FORM_FIELDS_TO_LOG.hokCreditCardSuccessClickFinishBtn)
        props.history.push(`/directorship/CreditsAndDebits/DirectDebit/`);
    }

    const onSaveOrPrint = () => {
        isBankDebit ? insertLog(FORM_FIELDS_TO_LOG.hokBankSuccessClickSaveOrPrint) : insertLog(FORM_FIELDS_TO_LOG.hokCreditCardSuccessClickSaveOrPrint)
        const {user_pdf} = response;
        if(user_pdf) {
            const blob = mLib.openPdfNewTab.b64toBlob(user_pdf, 'application/pdf')
            saveAs(blob, "ConfirmationDirectDebits.pdf");
        } 
    }

    return (
        <Fragment>
            <MainHeadline className={style.headLine}>
                <MainHeadlineScrollable className={style.titleContainer}>
                    <H1>{pageTitle}</H1>
                </MainHeadlineScrollable>
            </MainHeadline>
            <MainBody className={style.successPageWrap} layout="regular">
                <Card className={style.successPageCard}>
                    <Icon name="success-big" iconclassname={cx(style.successIcon, 'ml-3')} />
                    <H4 className={style.successTitle}>{isBankDebit ? SUCCESS_TITLE_TYPE_BANK : SUCCESS_TITLE_TYPE_CREDITCARD}</H4>
                    <p className={style.successRemark}>{isBankDebit ? SUCCESS_BANK_REMARK : ''}</p>
                    {debtRemark() && 
                        <div className="d-flex flex-column">
                            <div className={style.smallSep}></div>
                            <p className={style.debtRemark}>{debtRemark()}</p>
                        </div>
                    }
                    <CoupleButtons
                        secondText={SAVE_PRINT_CONFIRMATION}
                        firstText={FINISH}
                        firstOnClick={() => onFinish()}
                        secondOnClick={() => onSaveOrPrint()}
                        classname={style.coupleButtonsWrapSuccessPage}
                        firstclassname={style.firstBtnSuccess}
                    />
                </Card>
            </MainBody>
        </Fragment>
    );
}

export default compose(
    withRouter,
    connect(mapStateToProps, null)
)(DirectDebitSuccess);
