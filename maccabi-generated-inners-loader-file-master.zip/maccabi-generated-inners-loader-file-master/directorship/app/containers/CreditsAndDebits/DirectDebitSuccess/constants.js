import mLib from '@maccabi/m-lib';
import { ConfirmationDirectDebitsUrl } from '../constants';

export const UPDATE_DIRECTDEBIT = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'UPDATE_DIRECTDEBIT',
    'עדכון הרשאה לחיוב חשבון (הוראת קבע)'
);
export const SUCCESS_TITLE_TYPE_BANK = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'SUCCESS_TITLE_TYPE',
    'קבלנו את בקשתך להסדרת החיוב באמצעות חיוב חשבון הבנק'
);
export const SUCCESS_TITLE_TYPE_CREDITCARD = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'SUCCESS_TITLE_TYPE_CREDITCARD',
    'קבלנו את בקשתך להסדרת החיוב באמצעות כרטיס אשראי'
);
export const SUCCESS_BANK_REMARK = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'SUCCESS_BANK_REMARK',
    'הוראת הקבע תיכנס לתוקף בכפוף לאישור הבנק'
);
export const FINISH = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'FINISH', 'סיום');
export const SAVE_PRINT_CONFIRMATION = mLib.resources.getResource(ConfirmationDirectDebitsUrl, 'SAVE_PRINT_CONFIRMATION', 'שמירה / הדפסת האישור');

export const DEBT_REMARK_ON_SUCCESS_PAGE = {
    '1': mLib.resources.getResource(
        ConfirmationDirectDebitsUrl,
        'DEBT_REMARK_ON_SUCCESS_PAGE_1',
        'לתשומת לבך, לא ניתן לגבות את החוב באמצעות הוראת הקבע. נציג מכבי יצור אתך קשר בנושא'
    ),
    '2': mLib.resources.getResource(
        ConfirmationDirectDebitsUrl,
        'DEBT_REMARK_ON_SUCCESS_PAGE_2',
        'לתשומת לבך, לא ניתן לגבות את החוב באמצעות הוראת הקבע. נציג מכבי יצור אתך קשר בנושא'
    ),
    '4': mLib.resources.getResource(
        ConfirmationDirectDebitsUrl,
        'DEBT_REMARK_ON_SUCCESS_PAGE_3',
        'לתשומת לבך, הטיפול בחוב הועבר לגורם חיצוני ולא ניתן לגבות אותו באמצעות הוראת הקבע. נציג מכבי יצור אתך קשר בנושא.'
    ),
    '5': mLib.resources.getResource(
        ConfirmationDirectDebitsUrl,
        'DEBT_REMARK_ON_SUCCESS_PAGE_4',
        'לתשומת לבך, החוב נגבה באופן חלקי. נציג מכבי יצור אתך קשר בנושא'
    )
};

export const DIERCT_DEBIT_AUTHORIZATION = mLib.resources.getResource(
    ConfirmationDirectDebitsUrl,
    'DIERCT_DEBIT_AUTHORIZATION',
    'הסדרת הרשאה לחיוב חשבון (הוראת קבע)'
);
