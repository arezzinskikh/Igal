import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectTeavelInsurence = state => {
    return state.get('travelReducer', initialState);
};


export const makeSelectHash = createSelector(selectTeavelInsurence, documentsData => {
    return documentsData.get('hash');
});
export const makeSelectTimestamp = createSelector(selectTeavelInsurence, documentsData => {
    return documentsData.get('timestamp');
});