import { GET_TOKEN, SET_TOKEN,GET_HASH_AND_TIMESTAMP,SET_HASH_AND_TIMESTAMP} from './constants';

export function getToken() {
    return {
        type: GET_TOKEN
    };
}

export function setToken(data) {
    return {
        type: SET_TOKEN,
        data
    };
}

export function getHashAndTimestamp(){
    return{
        type:GET_HASH_AND_TIMESTAMP
    }
}

export function setTimestampAndHash(timestamp,hash){
    return {
        type:SET_HASH_AND_TIMESTAMP,
        timestamp,
        hash
    }
}
