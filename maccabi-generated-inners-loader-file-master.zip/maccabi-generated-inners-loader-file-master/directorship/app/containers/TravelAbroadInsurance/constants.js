export const GET_TOKEN = 'maccabi/directorship/letters/GET_TOKEN';
export const SET_TOKEN = 'maccabi/directorship/letters/SET_TOKEN';
export const GET_HASH_AND_TIMESTAMP = 'maccabi/directorship/letters/GET_HASH_AND_TIMESTAMP';
export const SET_HASH_AND_TIMESTAMP = 'maccabi/directorship/letters/SET_HASH_AND_TIMESTAMP';


export const CLAL_BIT_URL_1 = 'https://www.clalbit.co.il/travelingisurance/travelmacabi/?txtCompID=4&txtItemID=3d954cf4-51d7-4f00-a146-54c42b2be23e&txtInfoID={0}'
export const CLAL_BIT_URL_2 = 'https://www.clalbit.co.il/travelingisurance/travelmacabi/?txtCompID=6&txtItemID=fddc0707-3389-4f75-991e-7328ab05c79c&txtInfoID={0}'
export const CLAL_BIT_URL_3 = 'https://www.clalbit.co.il/travelingisurance/travelmacabi/?txtCompID=3&txtItemID=717372db-54c7-43c4-b995-10feb1b55a55&txtInfoID={0}'
