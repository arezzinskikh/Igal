import React, { Component, Fragment } from 'react';
//import cx from 'classnames';
import mLib from '@maccabi/m-lib';
import autobind from 'autobind-decorator';
import style from './TravelAbroadInsurance.scss';
import { getToken,getHashAndTimestamp } from './actions';
import { createStructuredSelector } from 'reselect';
import { H1, MainBody, MainHeadline, MainHeadlineScrollable, Button, QuickLinks } from '@maccabi/m-ui';
import cx from 'classnames';
import { connect } from 'react-redux';
import saga from './saga';
import reducer from './reducer';
import {makeSelectHash,makeSelectTimestamp} from './selectors';
import Header from '../../components/TravelAbroadInsurance/Header/Header';
import ClalButton from '../../components/TravelAbroadInsurance/ClalButton/ClalButton';
import PolicyInclude from '../../components/TravelAbroadInsurance/PolicyInclude/PolicyInclude';
import Box from '../../components/TravelAbroadInsurance/Box/Box';
import Age70Popup from '../../components/TravelAbroadInsurance/Age70Popup';

const { withFeatureToggles } = mLib.featureToggles;

const mapDispatchToProps = {getToken,getHashAndTimestamp};

@mLib.appInfra.injectReducer({ key: 'travelReducer', reducer })
@mLib.appInfra.injectSaga({ key: 'travelSaga', saga })
@connect(null, mapDispatchToProps)
@autobind
@withFeatureToggles
class TravelAbroadInsurance extends Component {
    constructor(props) {
        super(props);
        this.state = {
            clalButton: this.getResourceByAlias('ClalButton'),
            policyIncludes: this.getResourceByAlias('PolicyIncludes'),
            areaQuestions: this.getResourceByAlias('AreaQuestions'),
            links: this.getQuickLinkslist(this.getResourceByAlias('Links')),
            isOpen: false
        };
    }

    componentDidMount(){
        this.props.getHashAndTimestamp();
    }

    getResourceByAlias(key) {
        const alias = 'directorship/travelabroadinsurance';
        let resources = JSON.parse(localStorage.getItem('resource'));
        let byAlias = resources.filter(res => res.alias.toLowerCase() === alias.toLowerCase());
        return byAlias.length > 0 ? byAlias.filter(res => res.key.startsWith(key)) : null;
    }

    getTitle() {
        return mLib.resources.getResource(
            'directorship/TravelAbroadInsurance',
            'TravelAbroadInsurance_Title',
            'מדיכלל עולמי של כלל חברה לביטוח בע"מ'
        );
    }

    getQuickLinkslist(links) {
        let quickLinks = [];
        links.map(link => {
            link.value.Image = process.env.MEDIA_DOMAIN + link.value.Image;
            return quickLinks.push(link.value);
        });

        return quickLinks;
    }

    buttonOnClick = () => {
        mLib.logs.insertCentralizedLog(4183);
        const memberData = mLib.saveData.customerData.get();
        if(memberData.current_customer_info.age.years >= 70 ){
            this.setState({ isOpen: true });
        }
        else{
            this.props.getToken();
        }
    }

    onClose = () => {
        this.setState({ isOpen: false });
    }

    onAreaQuestionsClick(item){
        const log = item && item.Log;
        if (log) {
            mLib.logs.insertCentralizedLog(log);
        }
    }

    render() {
        const memberData = mLib.saveData.customerData.get();

      

        return (
            <Fragment>

                <Age70Popup isOpen = {this.state.isOpen} close = {this.onClose}/>
                <MainHeadline>
                    <MainHeadlineScrollable className={cx(style.headline)}>
                        <H1 tag="h1" hook="title" className={cx(style.headlineText)}>
                            {this.getTitle()}
                           
                        </H1>
                    </MainHeadlineScrollable>
                </MainHeadline>

                <MainBody layout="regular" className={cx(style.mainBody)} classNameScroll={cx(style.cardBody)}>
                    
                    <Header isAdult={memberData.current_customer_info.age.years > 18} buttonOnClick={this.buttonOnClick} />
                   
                    <ClalButton clalButton={this.state.clalButton} isAdult={memberData.current_customer_info.age.years > 18}/>
                    <PolicyInclude policyInclude={this.state.policyIncludes} />
                    <Box box={this.state.areaQuestions}/>
                    {memberData.current_customer_info.age.years > 18 && <Button size="md" color="primary" onClick={() => this.buttonOnClick()} className={cx(style.button)}>
                        {mLib.resources.getResource('directorship/TravelAbroadInsurance', 'TravelAbroadInsurance_Button', 'לקבלת הצעה והצטרפות באתר כלל')}
                    </Button>}

                    <QuickLinks list={this.state.links} onClick={this.onAreaQuestionsClick} className={cx(style.quickLinks)}/>

                    <div className={cx(style.additionalText)}>
                        {mLib.resources.getResource('directorship/TravelAbroadInsurance', 'TravelAbroadInsurance_AdditionalText', 'כל האמור כפוף לתנאי הפוליסה, הנספחים, סייגים וחריגיהם. המבטחת היא כלל חברה לביטוח בע"מ ("המבטח"). מכירת הביטוח נעשית על ידי המבטח. ההצטרפות לביטוח כפופה לתשלום דמי ביטוח ולאישור המבטח.')}
                    </div>
                    {/*this.props.featureToggles.TravelAbroadInsuranceSample && <div>TravelAbroadInsuranceSample!!!!</div>*/}
                </MainBody>
            </Fragment>
        );
    }
}

export default TravelAbroadInsurance;
