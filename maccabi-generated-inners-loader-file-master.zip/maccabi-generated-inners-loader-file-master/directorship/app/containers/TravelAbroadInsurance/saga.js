import { takeLatest, call, put } from 'redux-saga/effects';
import mLib from '@maccabi/m-lib';
import { GET_TOKEN, CLAL_BIT_URL_1, CLAL_BIT_URL_2, CLAL_BIT_URL_3,GET_HASH_AND_TIMESTAMP} from './constants';
import { setToken,setTimestampAndHash } from './actions';
import { getToken,getHashAndTimestamp } from '../../services/TravelAbroadInsurance/apiService';

const { setGlobalErrorPopup } = mLib.saveData.globalErrorPopup;
const { setGlobalLoading } = mLib.saveData.globalLoader;

function* handleGetToken() {
    try {
        const memberData = mLib.saveData.customerData.get();
        const params = {
            member_id_code: memberData.current_customer_info.member_id_code,
            member_id: memberData.current_customer_info.member_id
        };
        const result = yield call(getToken, params);

        const format = require('string-format');
        switch (result.is_maccabi_employee) {
            case 1:
                mLib.openPdfNewTab.openPdfNewTab(format(CLAL_BIT_URL_1, result.member_token), result.member_token);
                return;
            case 2:
                mLib.openPdfNewTab.openPdfNewTab(format(CLAL_BIT_URL_2, result.member_token), result.member_token);
                return;
            case 3:
                mLib.openPdfNewTab.openPdfNewTab(format(CLAL_BIT_URL_3, result.member_token), result.member_token);
                return;

        }

        yield put(setToken(result));

    } catch (err) {
        yield call(setGlobalErrorPopup, true);
        yield put(setToken(null));
    }
}

function* handleGetHashAndTimestamp(){
    const memberData = mLib.saveData.customerData.get();
    const params = {
        member_id_code: memberData.current_customer_info.member_id_code,
        member_id: memberData.current_customer_info.member_id
    };
    yield call(setGlobalLoading, true);
    try{
        const response = yield call(getHashAndTimestamp,params);
        yield put(setTimestampAndHash(response.timestamp,response.hash));
    }catch{
        yield call(setGlobalErrorPopup, true);
    }finally{
        yield call(setGlobalLoading, false);
    }
}


export default function* rootSaga() {
    yield takeLatest(GET_TOKEN, handleGetToken);
    yield takeLatest(GET_HASH_AND_TIMESTAMP,handleGetHashAndTimestamp)
}
