import { fromJS } from 'immutable';
import { 
    SET_HASH_AND_TIMESTAMP
} from './constants';

export const initialState = fromJS({
  hash:'',
  timestamp:''
});

export default function travelabroadinsuranceReducer(state = initialState, action) {
    switch (action.type) {
        case SET_HASH_AND_TIMESTAMP: {
            return state
                .set('hash', action.hash)
                .set('timestamp', action.timestamp);

        }
        default:
            return state;
    }
}
