import { fromJS } from 'immutable';
import { SET_CUSTOMER_DATA } from './constants';

export const initialState = fromJS({
    customerData: null,
    isKosher: false,
    settings: null,
    currentCustomerInfo: null,
    loggedCustomerInfo: null
});

export default function appReducer(state = initialState, action) {
    switch (action.type) {
        case SET_CUSTOMER_DATA:
            return state
                .set('customerData', action.customerData)
                .set('currentCustomerInfo', action.customerData.customer_info)
                .set('loggedCustomerInfo', action.customerData.customer_info);
        default:
            return state;
    }
}
