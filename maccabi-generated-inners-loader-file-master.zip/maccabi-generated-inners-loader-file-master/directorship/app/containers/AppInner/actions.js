import {
  GET_CUSTOMER_DATA,
  SET_CUSTOMER_DATA,
  ON_LOAD
} from './constants';

export function getCustomerData(onSuccess) {
  return {
    type: GET_CUSTOMER_DATA,
    onSuccess
  };
}

export function setCustomerData(customerData) {
  return {
    type: SET_CUSTOMER_DATA,
    customerData
  };
}

export function onLoad(onSuccess) {
  return {
    type: ON_LOAD,
    onSuccess: onSuccess
  };
}
