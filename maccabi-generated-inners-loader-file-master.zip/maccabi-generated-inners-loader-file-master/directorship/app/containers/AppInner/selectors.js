import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectGlobal = state => state.get('directorshipInnerGlobal', initialState);

export const makeSelectCustomerData = createSelector(selectGlobal, globalState => globalState.get('customerData'));

export const makeSelectCurrentCustomerInfo = createSelector(selectGlobal, globalState => globalState.get('currentCustomerInfo'));

export const makeSelectLoggedCustomerInfo = createSelector(selectGlobal, globalState => globalState.get('loggedCustomerInfo'));
