export const SET_CUSTOMER_DATA= 'maccabi/directorship/app/SET_CUSTOMER_DATA';
export const ON_LOAD= 'maccabi/directorship/app/ON_LOAD';


