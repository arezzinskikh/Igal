import { takeLatest, call } from 'redux-saga/effects';
import { ON_LOAD } from './constants';
import mLib from '@maccabi/m-lib';

function* onLoad(action) {
    try {
        const settings = yield call(mLib.settings.getSettings);

        if (settings !== null && settings.settings !== null && settings.menu !== null) {
            yield call(getCustomerAndFamily, action);
        }
    } catch (err) {
        console.log('err', err);
    }
}

function* getCustomerAndFamily(action) {
    try {
        console.log('inner - getCustomerData!!!!');
        yield call(mLib.customer.getCustomerData);

        action.onSuccess();
    } catch (err) {
        console.log('err!!!!!');
    }
}

export default function* rootSaga() {
    yield takeLatest(ON_LOAD, onLoad);
}
