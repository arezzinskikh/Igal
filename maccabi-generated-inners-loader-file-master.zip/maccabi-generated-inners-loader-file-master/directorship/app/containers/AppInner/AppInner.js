import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { Switch, Route, withRouter, Redirect } from 'react-router-dom';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import { Version, Loadable } from '@maccabi/m-ui';
import reducer from './reducer';
import saga from './saga';
import { onLoad } from './actions';
import { makeSelectCustomerData, makeSelectCurrentCustomerInfo, makeSelectLoggedCustomerInfo } from './selectors';
import Header from 'components/Header';
import loadableManifest from '../../loadableManifest';

import debitSage from '../CreditsAndDebits/saga';
import debitReducer from '../CreditsAndDebits/reducer';

const { FeatureTogglesProvider } = mLib.featureToggles;

const mapDispatchToProps = dispatch => ({
    onLoad: onSuccess => dispatch(onLoad(onSuccess))
});

const mapStateToProps = createStructuredSelector({
    customerDataNoFullRun: makeSelectCustomerData,
    currentCustomerInfoNoFullRun: makeSelectCurrentCustomerInfo,
    loggedCustomerInfoNoFullRun: makeSelectLoggedCustomerInfo
});

@withRouter
@mLib.appInfra.injectReducer({ key: 'directorshipInnerGlobal', reducer })
@mLib.appInfra.injectSaga({ key: 'directorshipInnerGlobal', saga })
@mLib.appInfra.injectReducer({ key: 'CreditsAndDebitsData', reducer:debitReducer, mode: '@@saga-injector/daemon' })
@mLib.appInfra.injectSaga({ key: 'CreditsAndDebitsData', saga:debitSage, mode: '@@saga-injector/daemon' })
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class AppInner extends Component {
    static propTypes = {
        topology: PropTypes.object.isRequired,
        menuItems: PropTypes.object.isRequired,
        featureToggles: PropTypes.object.isRequired
    };

    // static defaultProps = {
    //   topology: {
    //     baseRoute: '/'
    //   }
    // };

    constructor(props) {
        super(props);

        this.state = {
            isFullRun: props.isFullRun !== undefined ? props.isFullRun : false,
            isSettingsReceived: false
        };

        if (this.state.isFullRun) {
            const { setGlobalLoading, setRouteLeavingGuard, setGlobalErrorPopup } = props;
            mLib.saveData.globalLoader.init(setGlobalLoading);
            mLib.routeLeavingGuard.route.init(setRouteLeavingGuard);
            mLib.saveData.globalErrorPopup.init(setGlobalErrorPopup);
        }
    }

    componentDidMount() {
        if (!this.props.isFullRun) {
            this.props.onLoad(this.onLoadSuccess_NoFullRun);
        } else {
            this.setState(() => ({
                isSettingsReceived: true
            }));
        }
    }

    onLoadSuccess_NoFullRun() {
        this.setState(() => ({
            isSettingsReceived: true
        }));
    }

    render() {
        const {
            isFullRun,
            IsRender,
            isRenderFunction,
            topology: { baseRoute }
        } = this.props;

        const { currentCustomerInfo, isSettingsReceived } = this.state;

        const commonProps = {
            ErrorComponent: this.props.ErrorsComp,
            setGlobalLoading: this.props.setGlobalLoading,
            location: this.props.location,
            manifest: loadableManifest,
            menuItems: this.props.menuItems,
            flattedMenuItems: mLib.site.getFlattedMenuItems(),
            position: 'main',
            IsRender,
            isRenderFunction,
            wrapperCommand: this.props.wrapperCommand,
            setGlobalErrorPopup: this.props.setGlobalErrorPopup, 
            baseRoute
        };

        return (
            <FeatureTogglesProvider featureToggles={this.props.featureToggles}>
                {!isFullRun && mLib.site.isDevelopment() && <Header name={currentCustomerInfo != null ? currentCustomerInfo.f_name_hebrew : ''} />}
                {isSettingsReceived && (
                    <Switch>
                        <Route path={`${baseRoute}NoCardVisit/Lobby/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}LettersForMember/Lobby/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}OrderMagneticCard/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}Biobank/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}EditInformation/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}CreditsAndDebits/DirectDebit/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}CreditsAndDebits/ConfirmationDirectDebits/:type`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}CreditsAndDebits/DirectDebitSuccess/:type`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}CreditsAndDebits/BankDebit/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}JoinMyMaccabi/RequestSummary/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}JoinMyMaccabi/lobby/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}TravelAbroadInsurance/`} render={() => <Loadable {...commonProps} />} />
                        <Route path={`${baseRoute}BabyRegistration/`} render={() => <Loadable {...commonProps} />} />

                        <Redirect to="/error/404/" />
                    </Switch>
                )}
                <Version />
            </FeatureTogglesProvider>
        );
    }
}

export default AppInner;
