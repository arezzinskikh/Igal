export const LetterType = {
    LettersForMembers: 1, //דיוור ממכבי
    MembersPhrRecord: 2, //תיק רפואי
    MembersTutorials: 3 //ממטפלים
};
