import { fromJS } from 'immutable';
import staticTxt from './staticText.json';

import {
    SET_LETTERS_FOR_MEMBER,
    ERROR_LETTERS_FOR_MEMBER,
    SET_GLOBAL_LOADING,
    ACTIVE_INDEX,
    ACTIVE_PERIOD,
    ACTIVE_MESSAGE_INDEX,
    ACTIVE_MESSAGE
} from './constants';

// The initial state of the App
const initialState = fromJS({
    lettersForMember: [],
    lettersForMemberListError: null,
    globalLoader: null,
    activeIndex: 1,
    activePeriod: staticTxt.filterPeriod[1].txt,
    activeMessageIndex: 0,
    activeMessage: staticTxt.messageFilter[0].txt
});

export default function lettersForMemberReducer(state = initialState, action) {
    // step 7
    switch (action.type) {
        case SET_LETTERS_FOR_MEMBER:
            return state.set('lettersForMemberList', action.lettersForMember);
        case SET_GLOBAL_LOADING:
            return state.set('globalLoader', action.boolVal);
        case ERROR_LETTERS_FOR_MEMBER:
            return state.set('lettersForMemberListError', action.error);
        case ACTIVE_INDEX:
            return state.set('activeIndex', action.periodIndex);
        case ACTIVE_PERIOD:
            return state.set('activePeriod', action.activePeriod);
        case ACTIVE_MESSAGE_INDEX:
            return state.set('activeMessageIndex', action.messageIndex);
        case ACTIVE_MESSAGE:
            return state.set('activeMessage', action.activeMessage);
        default:
            return state;
    }
}
