import React, { Component, Fragment } from 'react';
import style from './LettersForMemberResults.scss';
import { TimeLineItem, CustomerTimeLineItem, HeaderTimeLineItem, DateTimeLineItem, BadgeTimeLineItem, Badge, Icon, LazyLoading } from '@maccabi/m-ui';

import { Row, Col } from 'reactstrap';
import cx from 'classnames';
import autobind from 'autobind';
import mLib from '@maccabi/m-lib';
import ButtonDocuments from '../../../components/Letters/ButtonDocuments/ButtonDocuments';
import Customer from '../../../components/Letters/Customer/Customer';
import { LetterType } from '../../AppInner/Enums';

@autobind
class LettersForMemberResults extends Component {
    constructor(props) {
        super(props);
        this.state = {
            limit: 10,
            items: this.props.lettersForMemberList
        };
    }

    onLoadMore = () => {
        this.setState({
            limit: this.state.limit + 10
        });
    };

    get list() {
        const { lettersForMemberList } = this.props;
        return lettersForMemberList && lettersForMemberList.slice(0, this.state.limit);
    }

    color = item => {
        let member_id;
        let index;
        switch (item.letter_type) {
            case 1:
                member_id = item.recipient_id;
            default:
                member_id = item.member_id;
        }

        this.props.familyData.family_members.some(function(el, i) {
            if (el.member_id === member_id) {
                index = i;
                return true;
            }
        });
        return index;
    };

    isChildInfo(item) {
        if (item.member_id !== this.props.loggedCustomerInfo.member_id) return true;
        else return false;
    }

    isDisplayButtonDocuments(item){
        let isDisplay = false;
        if(item.letter_type !== LetterType.MembersPhrRecord)
            isDisplay= true;
        else if(item.letter_type === LetterType.MembersPhrRecord && item.status === 1)
            isDisplay= true;

        return isDisplay;
    }

    getText(item) {
        switch (item.status) {
            case 0:
                return mLib.resources.getResource('directorship/lettersformember/lobby', 'Text_Status_0', 'התיק הרפואי יצורף להודעה זו בתום הטיפול');
            case 1:
                return mLib.resources.getResource(
                    'directorship/lettersformember/lobby',
                    'Text_Status_1',
                    'מומלץ לשמור את המסמך. במידה ויוזמן תיק רפואי נוסף, התיק הנוכחי יוחלף'
                );
            case 2:
                return (
                    <Fragment>
                        {mLib.resources.getResource(
                            'directorship/lettersformember/lobby',
                            'Text_Status_2',
                            ' אין באפשרותנו להפיק מסמך עקב בעיה טכנית. ניתן לנסות שנית להזמין את התיק הרפואי'
                        )}
                        <a href={mLib.url.getUrlByVersion(2, 'medicalfile/summary/')}> מכאן</a>
                    </Fragment>
                );
            case 3:
                return mLib.resources.getResource(
                    'directorship/lettersformember/lobby',
                    'Text_Status_3',
                    'בקשתך נבדקה ונמצא כי לא קיימים נתונים עבור התאריכים המבוקשים'
                );
        }
    }

    getHeadline(letterType, item) {
        switch (letterType) {
            case LetterType.LettersForMembers:
                return item.letter_desc;
            case LetterType.MembersPhrRecord:
                return 'הזמנת תיק רפואי';
            case LetterType.MembersTutorials:
                return ' הודעה בנושא ' + item.service_type_text;
        }
    }

    updateLimit(limit) {
        this.setState({ limit });
    }

    updateItems(items) {
        this.setState({ items });
    }

    render() {
        return (
            <LazyLoading
                className={cx(style.resultlist)}
                list={this.props.lettersForMemberList}
                items={this.state.items}
                updateItems={items => this.updateItems(items)}
                limit={this.state.limit}
                updateLimit={limit => this.updateLimit(limit)}>
                <div className={cx(style.col12Width)}>
                    {this.list.map((item, i) => (
                        <TimeLineItem
                            status="unread"
                            SideStripeNumber={this.color(item)}
                            key={'timeLineItem' + i}
                            className={cx(style.timeLineItem)}
                            hook={i}>
                            <Row>
                                <Col xs={{ size: 'auto', order: 1 }} sm={{ size: 8, order: 1 }}>
                                    <Customer
                                        item={item}
                                        loggedCustomerInfo={this.props.loggedCustomerInfo}
                                        staticTxt={this.props.staticTxt}
                                        isChildInfo={this.isChildInfo(item)}
                                        index={i}
                                        familyData={this.props.familyData}
                                    />
                                </Col>
                                <Col className={cx(style.prodDate)} xs={{ size: 'auto', order: 2 }} sm={{ size: 4, order: 2 }}>
                                    {item.letter_type === LetterType.MembersPhrRecord && item.status === 2 && (
                                        <Badge size="md" color="primary" className={cx('ml-3')}>
                                            <Icon name="attention-2" />
                                        </Badge>
                                    )}
                                    <DateTimeLineItem data-hook={`date__${i}`}>{item.item_date}</DateTimeLineItem>
                                </Col>
                                {item.letter_type === LetterType.LettersForMembers && (
                                    <Col className={cx(style.importToKnow)} xs={{ size: 'auto', order: 3 }} sm={{ size: 3, order: 4 }}>
                                        <BadgeTimeLineItem>חשוב לדעת</BadgeTimeLineItem>
                                    </Col>
                                )}
                                <Col xs={{ size: 12, order: 4 }} sm={{ size: 9, order: 3 }}>
                                    <HeaderTimeLineItem className={cx(style.headerTimeLineItem)}>
                                        {this.getHeadline(item.letter_type, item)}
                                    </HeaderTimeLineItem>
                                </Col>
                            </Row>
                            {item.letter_type === LetterType.MembersTutorials && (
                                <Row>
                                    <Col className="mt-3">
                                        <CustomerTimeLineItem data-hook={`text__${i}`}>{item.practitioner_name}</CustomerTimeLineItem>
                                    </Col>
                                </Row>
                            )}

                            {this.isDisplayButtonDocuments(item) &&
                            <ButtonDocuments
                                item={item}
                                index={i}
                                openPdfHandler={this.props.openPdfHandler}
                                openPdfByLinkHandler={this.props.openPdfByLinkHandler}
                                openTutorialsHandler={this.props.openTutorialsHandler}
                            />}

                            {item.letter_type === LetterType.MembersPhrRecord && (
                                <Row>
                                    <Col className="mt-3">
                                        <CustomerTimeLineItem className={cx(style.comment)} data-hook={`text__${i}`}>
                                            {this.getText(item)}
                                        </CustomerTimeLineItem>
                                    </Col>
                                </Row>
                            )}
                        </TimeLineItem>
                    ))}
                </div>
            </LazyLoading>
        );
    }
}

export default LettersForMemberResults;
