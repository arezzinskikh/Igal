import React, { Component, Fragment } from 'react';
import staticTxt from './staticText.json';
import style from './LettersForMember.scss';
import { H1, MainBody, MainHeadline, MainHeadlineScrollable, Button, Filter, FilterItem, Expandable, Clickable, Collapsible } from '@maccabi/m-ui';
import cx from 'classnames';
import LettersForMemberNoMsg from './LettersForMemberNoMsg/LettersForMemberNoMsg';
import LettersForMemberResults from './LettersForMemberResults/LettersForMemberResults';
import { getLettersForMember, getAllLettersForMember, activeIndex, activeMessageIndex } from './actions';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import saga from './saga';
import reducer from './reducer';
import {
    makeSelectLettersForMember,
    makeSelectLettersForMemberErr,
    makeSelectActiveIndex,
    makeSelectActivePeriod,
    makeSelectActiveMessageIndex,
    makeSelectActiveMessage
} from './selectors';
import mLib from '@maccabi/m-lib';
import autobind from 'autobind';
import LettersForMemberMsgForParents from './LettersForMemberMsgForParents/LettersForMemberMsgForParents';
import format from 'string-format';
import moment from 'moment';

const mapDispatchToProps = dispatch => ({
    getLettersForMember: data => dispatch(getLettersForMember(data)),
    getAllLettersForMember: data => dispatch(getAllLettersForMember(data)),
    setActivePeriod: data => dispatch(activeIndex(data)),
    setActiveMessage: data => dispatch(activeMessageIndex(data)) // step 2
});

const mapStateToProps = createStructuredSelector({
    lettersForMemberList: makeSelectLettersForMember,
    lettersListError: makeSelectLettersForMemberErr,
    activePeriodIndex: makeSelectActiveIndex,
    activePeriod: makeSelectActivePeriod,
    activeMessageIndex: makeSelectActiveMessageIndex,
    activeMessage: makeSelectActiveMessage
});

@mLib.appInfra.injectReducer({ key: 'lettersForMemberList', reducer })
@mLib.appInfra.injectSaga({ key: 'lettersForMember', saga })
@connect(mapStateToProps, mapDispatchToProps)
@autobind
class LettersForMember extends Component {
    constructor(props) {
        super(props);
        this.memberData = mLib.saveData.customerData.get();
        this.props.getAllLettersForMember();

        this.state = {
            toggleFilter: false
        };
    }

    hrefHeandler() {
        mLib.openPdfNewTab.openPdfNewTab('https://www.maccabi4u.co.il/8186-he/Maccabi.aspx?TabId=5466_5273', 'מכבי');
    }

    selectFilterValue(index) {
        this.props.setActivePeriod(index);
    }

    selectFilterMessageValue(index) {
        this.props.setActiveMessage(index);
    }

    toggleFilter() {
        this.setState({ toggleFilter: !this.state.toggleFilter });
    }

    filter(indexPeriod, indexMessage) {
        let filterResults = [];
        indexMessage = staticTxt.messageFilter[indexMessage].id;
        const exits =
            this.props.lettersForMemberList && this.props.lettersForMemberList.letters && this.props.lettersForMemberList.letters.length > 0;
        if (exits) {
            filterResults = this.props.lettersForMemberList.letters;
            const month = staticTxt.filterPeriod[indexPeriod].month;
            const fromDate = moment(mLib.date.setDateForService(month), 'YYYY-MM-DD');
            let toDate = new Date();
            filterResults = filterResults.filter(item =>
                mLib.date.isDateBetween(moment(item.original_item_date.substring(0, 10), 'YYYY-MM-DD'), fromDate, toDate)
            );
            filterResults = indexMessage === 0 ? filterResults : filterResults.filter(item => item.letter_type === indexMessage);
        }
        return filterResults;
    }

    clearFilter() {
        this.props.setActivePeriod(1);
        this.props.setActiveMessage(0);
    }

    openPdfHandler(docParam, id) {
        const webApiSuffix = format(
            process.env.WEB_API_URL_GET_PDF_FOR_MEMBER,
            docParam.recipient_id_code,
            docParam.recipient_id,
            docParam.reference_id,
            docParam.name_document,
            docParam.timestamp,
            docParam.hash
        );

        const currentUrl = window.location.href;
        const danainfo = mLib.juniper.getDanaInfo(currentUrl);
        const pdfUrl = process.env.WEB_API_URL_DIRECTORSHIP + webApiSuffix + danainfo;

        mLib.openPdfNewTab.openPdfNewTab(pdfUrl, docParam.hash);
        document.getElementById(id).blur();
    }

    openPdfByLinkHandler(docParam, id) {
        const webApiSuffix = format(
            process.env.WEB_API_URL_GET_PDF_FOR_MEMBER_BY_LINK,
            docParam.member_id_code,
            docParam.member_id,
            docParam.link,
            docParam.timestamp,
            docParam.hash
        );

        const currentUrl = window.location.href;
        const danainfo = mLib.juniper.getDanaInfo(currentUrl);
        const pdfUrl = process.env.WEB_API_URL_MAIN + webApiSuffix + danainfo;

        mLib.openPdfNewTab.openPdfNewTab(pdfUrl, docParam.hash);
        document.getElementById(id).blur();
    }

    openPdfWithHttpByLinkHandler(docParam, id) {
        const webApiSuffix = format(
            process.env.WEB_API_URL_GET_PDF_WITH_HTTP_FOR_MEMBER_BY_LINK,
            this.memberData.current_customer_info.member_id_code,
            this.memberData.current_customer_info.member_id,
            docParam.url,
            docParam.timestamp,
            docParam.hash
        );

        const currentUrl = window.location.href;
        const danainfo = mLib.juniper.getDanaInfo(currentUrl);
        const pdfUrl = process.env.WEB_API_URL_MAIN + webApiSuffix + danainfo;

        mLib.openPdfNewTab.openPdfNewTab(pdfUrl, docParam.hash);
        document.getElementById(id).blur();
    }

    openTutorialsHandler(tutorial, id) {
        switch (tutorial.tutorial_type) {
            case 'pdf':
                mLib.logs.insertCentralizedLog(1820);
                this.openPdfWithHttpByLinkHandler(tutorial, id);
                return;
            case 'webpage':
                mLib.logs.insertCentralizedLog(1821);
                mLib.openPdfNewTab.openPdfNewTab(tutorial.url, tutorial.hash);
                document.getElementById(id).blur();
                return;
            case 'video':
                mLib.logs.insertCentralizedLog(1822);
                mLib.openPdfNewTab.openPdfNewTab(tutorial.url, tutorial.hash);
                document.getElementById(id).blur();
                return;
            default:
                mLib.logs.insertCentralizedLog(1820);
                this.openPdfWithHttpByLinkHandler(tutorial, id);
                return;
        }
    }

    // eslint-disable-next-line max-lines-per-function
    render() {
        const { lettersListError, lettersForMemberList, activePeriod, activePeriodIndex, activeMessage, activeMessageIndex } = this.props;
        const currentCustomerInfo = this.memberData.current_customer_info;
        const familyData = this.memberData.family_data;
        const loggedCustomerInfo = this.memberData.logged_customer_info;
        const ErrorInModule = this.props.ErrorComponent;
        const isLoading = lettersForMemberList === null;
        const filteredLetters = this.filter(this.props.activePeriodIndex, this.props.activeMessageIndex);
        const resultExist =
            lettersForMemberList && lettersForMemberList.letters && lettersForMemberList.letters.length > 0 && filteredLetters.length > 0;
        const isCurrentCustomerInfoExist = currentCustomerInfo && currentCustomerInfo.age && currentCustomerInfo.age.years > 17;
        const isShowLettersForMemberNoMsg =
            !lettersListError &&
            isCurrentCustomerInfoExist &&
            lettersForMemberList &&
            (lettersForMemberList.result_message || !resultExist) &&
            filteredLetters.length === 0;
        const isKosher = mLib.site.isKosher();
        if (!((lettersListError || lettersForMemberList) && loggedCustomerInfo)) {
            return null;
        }

        return (
            <Fragment>
                <MainHeadline>
                    <MainHeadlineScrollable className={cx(style.headline)}>
                        <H1 tag="h1" hook="title" className={cx(style.headlineText)}>
                            {staticTxt.lettersForMemberTitle}
                        </H1>
                    </MainHeadlineScrollable>
                </MainHeadline>

                <MainBody
                    layout="spread"
                    className={cx(style.mainBody)}
                    classNameScroll={cx(isCurrentCustomerInfoExist && resultExist ? style.scroll : style.noPageScroll, style.cardBody)}>
                    <div className={cx(style.heightContainer)}>
                        {lettersForMemberList && (
                            <Fragment>
                                {!isKosher && isCurrentCustomerInfoExist && (
                                    <Button color="link" reverse size="sm" onClick={this.hrefHeandler} className={cx(style.termsOfUse)}>
                                        {staticTxt.termsOfUse}
                                    </Button>
                                )}
                            </Fragment>
                        )}
                        {isCurrentCustomerInfoExist && !lettersListError && (
                            <Fragment>
                                {/* Desktop */}
                                <div className={cx(style.filterLine, 'd-md-flex d-none')}>
                                    <Filter
                                        iconClassname={cx(style.iconClassname)}
                                        textToDisplay={activePeriod}
                                        toggleClassName={cx(style.dropDownToggle)}
                                        menulayout="fixed"
                                        classNameLabel={cx(style.classNameLabel, 'd-none d-sm-flex')}
                                        className={cx(style.dropdownMenu)}
                                        label={staticTxt.periodFilterByTxt}
                                        hookDesktop="period">
                                        {staticTxt.filterPeriod.map((item, index) => (
                                            <FilterItem
                                                hook={'period__' + index}
                                                tag="a"
                                                selected={index === activePeriodIndex}
                                                onClick={() => this.selectFilterValue(index)}
                                                key={item.month + index}
                                                data-hook={index}
                                                className={cx(index === activePeriodIndex ? style.active : style.dropdownItem)}>
                                                {item.txt}
                                            </FilterItem>
                                        ))}
                                    </Filter>

                                    <Filter
                                        iconClassname={cx(style.iconClassname)}
                                        textToDisplay={activeMessage}
                                        toggleClassName={cx(style.dropDownToggle)}
                                        menulayout="fixed"
                                        classNameLabel={cx(style.classNameLabel, 'd-none d-sm-flex')}
                                        className={cx(style.dropdownMenu)}
                                        menuclassname={cx(style.menuclassname)}
                                        label={staticTxt.messageFilterByTxt}
                                        hookDesktop="message">
                                        {staticTxt.messageFilter.map((item, index) => (
                                            <FilterItem
                                                hook={'message__' + index}
                                                tag="a"
                                                selected={index === activeMessageIndex}
                                                onClick={() => this.selectFilterMessageValue(index)}
                                                key={item.id + index}
                                                className={cx(index === activeMessageIndex ? style.active : style.dropdownItem)}>
                                                {item.txt}
                                            </FilterItem>
                                        ))}
                                    </Filter>

                                    <Button color="link" reverse size="md" onClick={this.clearFilter} className={cx(style.clearFilter)}>
                                        {staticTxt.clearFilter}
                                    </Button>
                                </div>

                                {/* Mobile */}
                                <Expandable className={cx(style.filterLine, 'd-md-none d-flex')}>
                                    <Clickable
                                        className={cx(style.Clickable)}
                                        classNameIconArrow={cx(style.classNameIconArrow)}
                                        isExpandReady={true}
                                        isOpen={this.state.toggleFilter}
                                        onExpand={() => this.toggleFilter()}
                                        onCollapse={() => this.toggleFilter()}>
                                        <sapn className={cx(style.ClickableText)}>סינון</sapn>
                                    </Clickable>
                                    <Collapsible className={cx(style.collapsible)} isOpen={this.state.toggleFilter}>
                                        <Filter
                                            iconClassname={cx(style.iconClassname)}
                                            textToDisplay={activePeriod}
                                            toggleClassName={cx(style.dropDownToggle)}
                                            menulayout="fixed"
                                            classNameLabel={cx(style.classNameLabel)}
                                            className={cx(style.dropdownMenu)}
                                            label={staticTxt.periodFilterByTxt}
                                            hookResponsive="period">
                                            {staticTxt.filterPeriod.map((item, index) => (
                                                <FilterItem
                                                hook={'period__' + index}
                                                    tag="a"
                                                    selected={index === activePeriodIndex}
                                                    onClick={() => this.selectFilterValue(index)}
                                                    key={item.month + index}
                                                    className={cx(index === activePeriodIndex ? style.active : style.dropdownItem)}>
                                                    {item.txt}
                                                </FilterItem>
                                            ))}
                                        </Filter>
                                        <Filter
                                            iconClassname={cx(style.iconClassname)}
                                            textToDisplay={activeMessage}
                                            toggleClassName={cx(style.dropDownToggle)}
                                            menulayout="fixed"
                                            classNameLabel={cx(style.classNameLabel)}
                                            className={cx(style.dropdownMenu)}
                                            label={staticTxt.messageFilterByTxt}
                                            hookResponsive="message">
                                            {staticTxt.messageFilter.map((item, index) => (
                                                <FilterItem
                                                    hook={'message__' + index}
                                                    tag="a"
                                                    selected={index === activeMessageIndex}
                                                    onClick={() => this.selectFilterMessageValue(index)}
                                                    key={item.id + index}
                                                    className={cx(index === activeMessageIndex ? style.active : style.dropdownItem)}>
                                                    {item.txt}
                                                </FilterItem>
                                            ))}
                                        </Filter>
                                        <Button color="link" reverse size="md" onClick={this.clearFilter} className={cx(style.clearFilter)}>
                                            {staticTxt.clearFilter}
                                        </Button>
                                    </Collapsible>
                                </Expandable>
                            </Fragment>
                        )}
                        {isCurrentCustomerInfoExist && (
                            <LettersForMemberResults
                                lettersForMemberList={filteredLetters}
                                openPdfHandler={this.openPdfHandler}
                                openPdfByLinkHandler={this.openPdfByLinkHandler}
                                openTutorialsHandler={this.openTutorialsHandler}
                                loggedCustomerInfo={loggedCustomerInfo}
                                currentCustomerInfo={currentCustomerInfo}
                                familyData={familyData}
                                staticTxt={staticTxt}
                            />
                        )}
                        {isShowLettersForMemberNoMsg && !isLoading && <LettersForMemberNoMsg staticTxt={staticTxt} />}
                        {!isCurrentCustomerInfoExist && !isLoading && <LettersForMemberMsgForParents staticTxt={staticTxt} />}
                        {lettersListError && <ErrorInModule className={cx('ml-lg-5 mt-4')} />}
                    </div>
                </MainBody>
            </Fragment>
        );
    }
}

export default LettersForMember;
