import {
    GET_LETTERS_FOR_MEMBER,
    GET_ALL_LETTERS_FOR_MEMBER,
    SET_LETTERS_FOR_MEMBER,
    ERROR_LETTERS_FOR_MEMBER,
    GET_GLOBAL_LOADING,
    SET_GLOBAL_LOADING,
    ACTIVE_INDEX,
    ACTIVE_PERIOD,
    ACTIVE_MESSAGE_INDEX,
    ACTIVE_MESSAGE
} from './constants';

export function getLettersForMember(data) {
    // step 3

    return {
        type: GET_LETTERS_FOR_MEMBER,
        data
    };
}

export function getAllLettersForMember(data) {
    // step 3

    return {
        type: GET_ALL_LETTERS_FOR_MEMBER,
        data
    };
}

export function setGlobalLoading(boolVal) {
    // step 3
    return {
        type: SET_GLOBAL_LOADING,
        boolVal
    };
}

export function getGlobalLoading(boolVal) {
    // step 3
    return {
        type: GET_GLOBAL_LOADING,
        boolVal
    };
}

export function setLettersForMember(lettersForMember) {
    // step 7
    return {
        type: SET_LETTERS_FOR_MEMBER,
        lettersForMember
    };
}

export function setLettersForMemberError(err) {
    // step 7
    return {
        type: ERROR_LETTERS_FOR_MEMBER,
        error: err
    };
}

export function activeIndex(periodIndex) {
    // step 3
    return {
        type: ACTIVE_INDEX,
        periodIndex
    };
}

export function activePeriod(activePeriod) {
    // step 3
    return {
        type: ACTIVE_PERIOD,
        activePeriod
    };
}

export function activeMessageIndex(messageIndex) {
    // step 3

    return {
        type: ACTIVE_MESSAGE_INDEX,
        messageIndex
    };
}

export function activeMessage(activeMessage) {
    // step 3
    return {
        type: ACTIVE_MESSAGE,
        activeMessage
    };
}
