export const GET_LETTERS_FOR_MEMBER = 'maccabi/directorship/letters/GET_LETTERS_FOR_MEMBER';
export const SET_LETTERS_FOR_MEMBER= 'maccabi/directorship/letters/LETTERS_FOR_MEMBER';
export const ERROR_LETTERS_FOR_MEMBER= 'maccabi/directorship/letters/ERROR_LETTERS_FOR_MEMBER';
export const GET_GLOBAL_LOADING= 'maccabi/directorship/GET_GLOBAL_LOADING';
export const SET_GLOBAL_LOADING= 'maccabi/directorship/SET_GLOBAL_LOADING';
export const ACTIVE_INDEX= 'maccabi/directorship/ACTIVE_INDEX';
export const ACTIVE_PERIOD= 'maccabi/directorship/ACTIVE_PERIOD';
export const ACTIVE_MESSAGE_INDEX= 'maccabi/directorship/ACTIVE_MESSAGE_INDEX';
export const ACTIVE_MESSAGE= 'maccabi/directorship/ACTIVE_MESSAGE';

export const GET_ALL_LETTERS_FOR_MEMBER = 'maccabi/directorship/letters/GET_ALL_LETTERS_FOR_MEMBER';



