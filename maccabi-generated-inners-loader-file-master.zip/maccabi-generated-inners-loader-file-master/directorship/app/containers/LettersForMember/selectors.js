import { createSelector } from 'reselect';
import { initialState } from './reducer';

const selectLettersForMember = state => {
    return state.get('lettersForMemberList', initialState);
};
export const makeSelectLettersForMember = createSelector(selectLettersForMember, lettersForMemberState =>
    lettersForMemberState.get('lettersForMemberList')
);

export const makeSelectLettersForMemberErr = createSelector(selectLettersForMember, err => err.get('lettersForMemberListError'));

export const makeSelectGlobalLader = createSelector(selectLettersForMember, loader => loader.get('globalLoader'));

export const makeSelectActiveIndex = createSelector(selectLettersForMember, index => index.get('activeIndex'));

export const makeSelectActivePeriod = createSelector(selectLettersForMember, period => period.get('activePeriod'));

export const makeSelectActiveMessageIndex = createSelector(selectLettersForMember, index => index.get('activeMessageIndex'));

export const makeSelectActiveMessage = createSelector(selectLettersForMember, period => period.get('activeMessage'));
