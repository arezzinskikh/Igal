import React from 'react';
import style from './LettersForMemberNoMsg.scss';
import { H4, Icon } from '@maccabi/m-ui';
import cx from 'classnames';

const LettersForMemberNoMsg = props => {
    return (
        <div className={cx(style.LettersForMemberNoMsg)}>
            <Icon name="envelope-big" className={cx(style.envelopeIcon)} />
            <H4 className="mt-3" tag="h2">
                {props.staticTxt.noMessages}
            </H4>
        </div>
    );
};

export default LettersForMemberNoMsg;
