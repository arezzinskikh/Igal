import { takeLatest, call, put } from 'redux-saga/effects';
import { GET_LETTERS_FOR_MEMBER, GET_ALL_LETTERS_FOR_MEMBER, ACTIVE_INDEX, ACTIVE_MESSAGE_INDEX } from './constants';
import { setLettersForMember, setLettersForMemberError, activePeriod, activeMessage } from './actions';
import { lettersForMember, allLettersForMember } from '../../services/LettersForMember/apiService';
import staticTxt from './staticText.json';
import mLib from '@maccabi/m-lib';

const { setGlobalLoading } = mLib.saveData.globalLoader;

function* handleGetLetters() {
    yield call(setGlobalLoading, true);
    yield put(setLettersForMember(null));

    const dateActive = mLib.date.setDateForService(60);

    let memberData = yield call(mLib.saveData.customerData.get);

    const params = {
        memberId: memberData.current_customer_info.member_id,
        memberIdCode: memberData.current_customer_info.member_id_code,
        from_date: dateActive,
        to_date: new Date().toISOString().slice(0, -14),
        requesting_user: ''
    };

    try {
        const result = yield call(lettersForMember, params);
        yield put(setLettersForMember(result));
    } catch (err) {
        yield put(setLettersForMemberError(err));
    } finally {
        yield call(setGlobalLoading, false);
    }
}

function* handleAllGetLetters() {
    yield call(setGlobalLoading, true);
    yield put(setLettersForMember(null));

    const dateActive = mLib.date.setDateForService(60);

    let memberData = yield call(mLib.saveData.customerData.get);

    let members = [];
    memberData.family_data.family_members.map(member => {
        return members.push({
            member_id_code: member.member_id_code,
            member_id: member.member_id
        });
    });

    const params = {
        memberId: memberData.current_customer_info.member_id,
        memberIdCode: memberData.current_customer_info.member_id_code,
        from_date: dateActive,
        to_date: new Date().toISOString().slice(0, -14),
        requesting_user: '',
        members: members
    };

    try {
        const result = yield call(allLettersForMember, params);

        yield put(setLettersForMember(result));
    } catch (err) {
        yield put(setLettersForMemberError(err));
    } finally {
        yield call(setGlobalLoading, false);
    }
}

function* handleSetActiveIndex(action) {
    const activeObject = staticTxt.filterPeriod[action.periodIndex];
    yield put(activePeriod(activeObject.txt));

    return action;
}

function* handleSetActiveMessageIndex(action) {
    const activeObject = staticTxt.messageFilter[action.messageIndex];
    yield put(activeMessage(activeObject.txt));

    return action;
}

export default function* rootSaga() {
    yield takeLatest(GET_LETTERS_FOR_MEMBER, handleGetLetters);
    yield takeLatest(ACTIVE_INDEX, handleSetActiveIndex);
    yield takeLatest(ACTIVE_MESSAGE_INDEX, handleSetActiveMessageIndex);
    yield takeLatest(GET_ALL_LETTERS_FOR_MEMBER, handleAllGetLetters);
}
