import NoCardVisit from 'containers/NoCardVisit';
import LettersForMember from 'containers/LettersForMember';
import OrderMagneticCard from 'containers/OrderMagneticCard';
import Biobank from 'containers/Biobank';
import EditInformation from 'containers/EditInformation';
import DirectDebit from 'containers/CreditsAndDebits/DirectDebit';
import JoinMyMaccabi from 'containers/JoinMyMaccabi';
import RequestSummary from './components/JoinMyMaccabi/StepTwo/RequestSummary';
import TravelAbroadInsurance from 'containers/TravelAbroadInsurance';
import BabyRegistration from './containers/BabyRegistration';
import BabyRegistrationSummaryAndConfirmation from './containers/BabyRegistration/BabyRegistrationSummaryAndConfirmation/BabyRegistrationSummaryAndConfirmation';
import ConfirmationDirectDebits from './containers/CreditsAndDebits/ConfirmationDirectDebits/ConfirmationDirectDebits';
import DirectDebitSuccess from './containers/CreditsAndDebits/DirectDebitSuccess/DirectDebitSuccess';
import BankAcountPermission from './containers/CreditsAndDebits/BankAcountPermission/BankAcountPermission';

const components = {
    containers: {
        NoCardVisit,
        LettersForMember,
        OrderMagneticCard,
        Biobank,
        EditInformation,
        TravelAbroadInsurance,
        RequestSummary,
        JoinMyMaccabi,
        DirectDebit,
        BabyRegistration,
        BabyRegistrationSummaryAndConfirmation,
        ConfirmationDirectDebits,
        DirectDebitSuccess,
        BankAcountPermission
    },
    components: {}
};

export default components;
