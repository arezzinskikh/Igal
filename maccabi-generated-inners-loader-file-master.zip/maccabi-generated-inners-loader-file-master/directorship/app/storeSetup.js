import Immutable from 'immutable';
import mLib from '@maccabi/m-lib';
import configureStore from './configureStore';


// Create redux store with history
const history = mLib.history;
const initialState = Immutable.Map();
const store = configureStore(initialState, history);

export {store,history}