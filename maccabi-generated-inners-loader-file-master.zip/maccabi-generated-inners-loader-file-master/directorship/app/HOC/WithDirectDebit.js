import React from 'react';
import {
    makeSelectPayerBillingSubjects,
    makeSelectPayerDebitAuthorization,
    makeSelectPayerTotalDebts,
    makeSelectIsLoading
} from '../containers/CreditsAndDebits/selectors';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import { getDirectDebitData } from '../containers/CreditsAndDebits/actions';

const mapStateToProps = createStructuredSelector({
    payerBillingSubjects: makeSelectPayerBillingSubjects,
    payerDebitAuthorization: makeSelectPayerDebitAuthorization,
    payerTotalDebts: makeSelectPayerTotalDebts,
    isLoading: makeSelectIsLoading
});

const mapDispatchToProps = {getDirectDebitData}

export const WithDirectDebitProps = (WrappedComponent) => {
    const WithDirectDebit = (props) =>{
        const { getDirectDebitData,...rest } = props;
        const directDebitProps = {
            onDirectDebitLoad: (isConfirmatioPageOfCC=false) => {getDirectDebitData(isConfirmatioPageOfCC)},
        };
        return (
            <WrappedComponent {...directDebitProps} {...rest}/>
        )
    }

    WithDirectDebit.displayName = `WithDirectDebit(${WrappedComponent.displayName || WrappedComponent.name || 'Component'})`;

    return connect(mapStateToProps,mapDispatchToProps)(WithDirectDebit);
}

