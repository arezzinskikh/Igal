import React, { Fragment, useState, useEffect } from 'react';
import mLib from '@maccabi/m-lib';
import style from '../containers/CreditsAndDebits/BankAcountPermission/BankAcountPermission.scss';
import { Img, InputAutoComplete, Button } from '@maccabi/m-ui';
import { FORM_BANK_LABEL } from '../containers/CreditsAndDebits/BankAcountPermission/constatns';
import { insertLog, FORM_FIELDS_TO_LOG } from '../containers/CreditsAndDebits/BankAcountPermission/logFile'

const MemoBankDropDown = ({ selectedBankCode, onBankSelect, banks, bankDetailsError }) => {
    const [isFoucus, setIsFocus] = useState(false);
    const [filterdList, setFilteredList] = useState([]);
    const [bankValue, setBankValue] = useState('');

    useEffect(() => {
        setFilteredList(banks);
    }, [banks]);

    useEffect(() => {
        if (selectedBankCode !== -1) {
            const { bank_code, bank_name } = banks.find(({ bank_code }) => bank_code === selectedBankCode);
            setBankValue(`${bank_code} - ${bank_name}`);
        }
    }, [selectedBankCode]);


    const getBankIconPath = bankCode => {
        const key = bankCode && bankCode.toString();
        let BankIconPath = mLib.resources.getImage('directorship/CreditsAndDebits/DirectDebit', key);
        if (BankIconPath === null) {
            BankIconPath = mLib.resources.getImage('directorship/CreditsAndDebits/DirectDebit', '-1');
        }
        return BankIconPath;
    };

    const handleBankSelect = (bankCode,bank_name) => {
        onBankSelect(bankCode,bank_name);
        setIsFocus(false);
    };

    const checkIfToClear =(value) => { 
        value === '' && onBankSelect(-1,'')
        setBankValue(value)
        serchBank(value)
    }

    const rowRenderer = ({ bank_code, bank_name }) => {
        return (
            <Button className={style.bankitem} key={bank_code} onClick={() => handleBankSelect(bank_code, bank_name)}>
                <div className={style.bankitemIcon}>
                    <Img extension="png" path={getBankIconPath(bank_code)} />
                </div>
                <div>{bank_code}</div>
                <span className="m-2">-</span>
                <div>{bank_name}</div>
            </Button>
        );
    };

    const serchBank = value => {
        onBankSelect(-1,'')
        setFilteredList(
            banks.filter(({ bank_code, bank_name }) => {
                const bankString = `${bank_code} - ${bank_name}`;
                return bankString.indexOf(value) > -1;
            })
        );
    };

    const setIsFocusBankName = () =>{
        setIsFocus(true);
        insertLog(FORM_FIELDS_TO_LOG.dropDownBankName);
    } 

    return (
        <Fragment>
            <InputAutoComplete
                disabled={false}
                errorMsg={bankDetailsError}
                filteredItems={filterdList}
                fullList={banks}
                rowRenderer={rowRenderer}
                onSerchFilter={serchBank}
                placeHolderText={FORM_BANK_LABEL}
                showFullListWhenNoInput={true}
                onFocus={setIsFocusBankName}
                onBlur={() =>
                    setTimeout(() => {
                        setIsFocus(false);
                    }, 100)
                }
                value={bankValue}
                isFocus={isFoucus}
                onValueChange={checkIfToClear}
                hook="bankAutoComplete"
                maxHeightClassName={style.maxHeightClassName}
            />
        </Fragment>
    );
};

export default React.memo(MemoBankDropDown);
