import mLib from '@maccabi/m-lib';
import format from 'string-format';
import axios from 'axios';

const { rest } = mLib;

export function getCustomerData(memberIdCode, memberId, checksum, full) {
    const options = {};
    const webapiName = 'MAIN';

    let webApiSuffix = format(process.env.WEB_API_URL_CURRENT_CUSTOMER_DATA, memberIdCode, memberId, checksum, 'info,remarks,insurance');
    if (full)
        webApiSuffix = format(process.env.WEB_API_URL_CURRENT_CUSTOMER_DATA, memberIdCode, memberId, checksum, 'info,contact,address,remarks,insurance,financial');

    return rest.get(webapiName, webApiSuffix, options);
}

export function getSeniority(memberIdCode, memberId) {
    const options = {};

    const webApiSuffix = format(process.env.WEB_API_URL_EDITINFORMATION_GET_SENIORITY, memberIdCode, memberId);

    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}

export function updateDetails(memberIdCode, memberId, params) {
    const options = {
        data: params
    };

    const webApiSuffix = format(process.env.WEB_API_URL_EDITDETAILS_UPDATE_INFO, memberIdCode, memberId);

    const webapiName = 'MAIN';
    return rest.patch(webapiName, webApiSuffix, options);
}

export function updateRemarks(memberIdCode, memberId, params) {
    const options = {
        data: params
    };

    const webApiSuffix = format(process.env.WEB_API_URL_EDITDETAILS_UPDATE_REMARKS, memberIdCode, memberId);

    const webapiName = 'DIRECTORSHIP';

    return rest.post(webapiName, webApiSuffix, options);
}

export function validateUpdatePassword(memberIdCode, memberId, oldPassword, newPassword) {
    const options = {
        data:{
            password: oldPassword,
            new_password: newPassword,
        }
    };

    const webApiSuffix = format(process.env.WEB_API_URL_EDITINFORMATION_VALIDATE_UPDATE_PASSWORD, memberIdCode, memberId);

    const webapiName = 'DIRECTORSHIP';

    return rest.patch(webapiName, webApiSuffix, options);
}

export function endSessionCustomer(){
    console.log('endSessionCustomer START');
    return new Promise((resolve, reject) => {
        
        const url =  'https://online.maccabi4u.co.il/Handlers/SiteGlobal/,DanaInfo=.aoonlrjFtilmlnvG9Pt6S26,dom=1,CT=sxml+EndSessionCustomer.ashx';
        const options = {
            method: 'POST', // By default it's POST in case you didnt specify anything
            timeout: 30000
        };
        
        // Fire the request for the prepared options.
        return axios(url, options)
            .then(response => {
                console.log('endSessionCustomer SUCCESS');
                resolve(response.data);
            })
            .catch(error => {
                //logs.writeLog(`callApi failed - url: ${url}`);
                console.log('endSessionCustomer FAILED');
                reject(error);
            });
    });

   
}
