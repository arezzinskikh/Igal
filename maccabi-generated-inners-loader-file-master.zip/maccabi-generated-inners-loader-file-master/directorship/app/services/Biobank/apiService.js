import mLib from '@maccabi/m-lib'
import format from 'string-format';

const {
    rest
} = mLib;


export function biobankStats() {
    const options = {};

    const webApiSuffix = process.env.WEB_API_URL_GET_BIOBANK_STATS
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}

export function biobankMember(params) {
    const options = {};

    const webApiSuffix = format(
        process.env.WEB_API_URL_GET_BIOBANK_MEMBER,
        params.member_id_code,
        params.member_id
    );
  const webapiName = 'DIRECTORSHIP';

  return rest.get(webapiName, webApiSuffix, options);
}