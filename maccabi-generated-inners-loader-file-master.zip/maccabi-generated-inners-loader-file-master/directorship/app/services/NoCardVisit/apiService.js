import mLib from '@maccabi/m-lib'
import format from 'string-format';

const {
    rest
} = mLib;

export function allowNoCardVisit(reasonCode, memberIdCode, memberId) {
    if (reasonCode === undefined || reasonCode === null || reasonCode === {}) {
        throw 'reasonCode is required';
    }

    const options = {};
    const webApiSuffix = format(
        process.env.WEB_API_URL_NOCARDVISIT_ALLOW,
        memberIdCode,
        memberId,
        reasonCode
    );
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}
