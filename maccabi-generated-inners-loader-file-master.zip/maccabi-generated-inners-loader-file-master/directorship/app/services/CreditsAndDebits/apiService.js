import mLib from '@maccabi/m-lib';
import format from 'string-format';
import fs from 'fs'

const { rest } = mLib;

export function getPayerTotalDebts(memberIdCode, memberId) {
    const options = {};

    const webApiSuffix = format(process.env.WEB_API_URL_GET_PAYER_TOTAL_DEBTS, memberIdCode, memberId);
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}

export function getPayerBillingSubjects(memberIdCode, memberId) {
    const options = {};

    const webApiSuffix = format(process.env.WEB_API_URL_GET_PAYER_BILLING_SUBJECTS, memberIdCode, memberId);
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}

export function getPayerDebitAuthorization(memberIdCode, memberId) {
    const options = {};

    const webApiSuffix = format(process.env.WEB_API_URL_GET_PAYER_DEBIT_AUTHORIZATION, memberIdCode, memberId);
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}

export function PrepeareTransaction(payerIdCode, PayerId){
    
    const isKosher = mLib.site.isKosher();
    const options = {
        data:{
            "success_url":format(process.env.CG_SUCCESS_URL),
            "error_url":format(process.env.CG_ERROR_URL),
            "cancel_url":format(process.env.CG_CANCEL_URL)
        }
    };
    const webApiSuffix = format(process.env.WEB_API_URL_PREPARE_TRANSACTION, payerIdCode, PayerId, isKosher);
    const webapiName = 'DIRECTORSHIP';

    return rest.post(webapiName, webApiSuffix, options);
}

export function postDebitAuthorizationCreditcard(memberIdCode, memberId , token, isCollectDebt,lastFourDigits,cardName){
    const options = {
        data:{
            "tranid_j102":token,
            "authorization_type":2,
            "is_collect_debt":isCollectDebt? "Y": "N",
            "request_form":"ה",
            "last_four_digits":lastFourDigits,
            "card_name":cardName
        }
    };
    const webApiSuffix = format(process.env.WEB_API_URL_POST_DEBIT_AUTHORIZATION_CREDITCARD, memberIdCode, memberId);
    const webapiName = 'DIRECTORSHIP';
    return rest.post(webapiName, webApiSuffix, options);
}

export function getDebtsDetailsForPayer(memberIdCode, memberId) {
    const options = {};

    const webApiSuffix = format(process.env.WEB_API_URL_GET_DEBTS_DETAILS_FOR_PAYER, memberIdCode, memberId);
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}

export function getBanks(memberIdCode,memberId){
    const webApiSuffix = format(process.env.WEB_API_URL_GET_BANKS, memberIdCode, memberId);
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, {});
}

export function getBanksBranches(memberIdCode,memberId,bankId){
    const webApiSuffix = format(process.env.WEB_API_URL_GET_BANKS_BRANCHES, memberIdCode, memberId,bankId);
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, {});
}

export function validateBankDetails(memberIdCode,memberId,bankCode,branchCode,accountNumber){
    const webApiSuffix = format(process.env.WEB_API_URL_VALIDATE_BANK_DETAILS, memberIdCode, memberId,bankCode,branchCode,accountNumber);
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, {});
}

export function createBankHokService(memberIdCode,memberId,hokData){
    const options = {
        data: hokData
    };
    const webApiSuffix = format(process.env.WEB_API_URL_CREATE_BANK_HOK, memberIdCode, memberId);
    const webapiName = 'DIRECTORSHIP';
    // return ({collect_debt_status: 4, user_pdf: "sdfsdfsdfsd"})
    return rest.post(webapiName, webApiSuffix, options);
}

export function getTransactionDetails(memberIdCode,memberId, cgData){
    const webApiSuffix = format(process.env.WEB_API_URL_GET_TRANSACTION_DETAILS, memberIdCode, memberId,cgData.token , cgData.terminal_number, cgData.mid, cgData.number_of_retries_esb, cgData.time_interval );
    const webapiName = 'DIRECTORSHIP';
    return rest.get(webapiName, webApiSuffix, {});
    
}