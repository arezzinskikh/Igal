import mLib from '@maccabi/m-lib'
import format from 'string-format';

const {
    rest
} = mLib;



export function getToken(params) {
    const options = {};

    const webApiSuffix = format(
        process.env.WEB_API_URL_GET_TOKEN,
        params.member_id_code,
        params.member_id
    );
  const webapiName = 'DIRECTORSHIP';

  return rest.get(webapiName, webApiSuffix, options);
}

export function getHashAndTimestamp(params) {
    const options = {};

    const webApiSuffix = format(
        process.env.WEB_API_GET_HASH_AND_TIMESTAMP,
        params.member_id_code,
        params.member_id
    );
  const webapiName = 'DIRECTORSHIP';

  return rest.get(webapiName, webApiSuffix, options);
}