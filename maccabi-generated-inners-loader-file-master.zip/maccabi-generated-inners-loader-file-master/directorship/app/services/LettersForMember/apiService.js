import mLib from '@maccabi/m-lib'
import format from 'string-format';

const {
    rest
} = mLib;

export function lettersForMember(params) {
      const options = {};
    const webApiSuffix = format(
        process.env.WEB_API_URL_LETTERS_FOR_MEMBER,
        params.memberIdCode,
        params.memberId,
        params.from_date,
        params.to_date,
      
    );
    const webapiName = 'DIRECTORSHIP';

    return rest.get(webapiName, webApiSuffix, options);
}


export function allLettersForMember(params) {
    const options = {
        data: {
            "from_date": params.from_date,
            "to_date": params.to_date,
            "members": params.members
        }
    };
  

    const webApiSuffix = format(
        process.env.WEB_API_URL_ALL_LETTERS_FOR_MEMBER,
        params.memberIdCode,
        params.memberId
    );
  const webapiName = 'DIRECTORSHIP';

  return rest.post(webapiName, webApiSuffix, options);
}
