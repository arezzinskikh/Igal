import mLib from '@maccabi/m-lib';
import format from 'string-format';

const { rest } = mLib;

export function getMembersAdditionalInsurances(request){
    const webApiSuffix = format(process.env.WEB_API_URL_GET_MEMBERS_INSURANCES, request.data.memberIdCode, request.data.memberId);
    const webapiName = 'DIRECTORSHIP';
    const options = {
        headers: request.headers
    };
    let serviceReqeust = rest.get(webapiName, webApiSuffix,options);
    return serviceReqeust;
}

export function postAdditionalMembersInsurances(request,memberIdCode,memberId){
    const webApiSuffix = format(process.env.WEB_API_URL_POST_MEMBERS_INSURANCES,memberId,memberIdCode);
    const webapiName = 'DIRECTORSHIP';
    const options = {
        data:request.data,
        headers: request.headers
    };
    let serviceReqeust = rest.post(webapiName, webApiSuffix,options);
    return serviceReqeust;
}