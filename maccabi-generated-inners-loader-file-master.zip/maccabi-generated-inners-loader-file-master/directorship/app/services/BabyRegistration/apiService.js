import mLib from '@maccabi/m-lib';
import format from 'string-format';
import {shabanInsuranceTypes,STATIC_TXT,SHABAN_NOT_CHOSEN_CODE_TO_API} from '../../containers/BabyRegistration/constants';
import moment from 'moment';

const {rest} = mLib;
const webApiName = 'DIRECTORSHIP';

export function getInfantEligibility(data) {
    const {babyId,member_id,member_id_code} = data;
    const webApiSuffix = format(process.env.WEB_API_GET_INFANT_ELIGIBILITY, member_id_code, member_id, 0, babyId);
    let serviceRequest = rest.get(webApiName, webApiSuffix,{});
    return serviceRequest;
}

export function infantRegistration(data) {
    const selectedShaban = data.insurance.value;
    const selectedBabyBirthDate = data.babyBirthDate.value.split("T")[0];
    const selectedStartDate = data.time.value;
    const getToday = moment().format('YYYY-MM-DD');

    let calculatedTime;
    let shabanTypeCode;
    if (selectedShaban < 0) {
        shabanTypeCode = SHABAN_NOT_CHOSEN_CODE_TO_API;
        //IF NO SHABAN -> SO WE REGISTERED BY DEFAULT TO MACCABI SIUDI AND THE DATE WILL ALWAYS BE FROM BIRTHDATE
        calculatedTime = selectedBabyBirthDate
    } else {
        shabanTypeCode = shabanInsuranceTypes.filter(shaban => shaban.index === selectedShaban)[0].shabanTypeToApi;
        // IF CHOSEN SHABAN BUT TIME COULD NOT HAVE CHOSEN (ShabanFromDOB=00 in Eligibility response) -> TODAY WILL BE THE DEFAULT DATE
        calculatedTime = selectedStartDate > -1 && selectedStartDate === STATIC_TXT.chooseTime.startingBirthDate.index ? selectedBabyBirthDate : getToday;
    }

    const options = {
        data:{
            infant_id_code: "0",
            infant_id: data.babyId.value,
            first_name: data.babyFirstName.value ? data.babyFirstName.value : data.babyFirstName.default,
            last_name: data.babySurname.value ? data.babySurname.value : data.babySurname.default,
            date_of_birth: selectedBabyBirthDate,
            gender: data.babyGender.value === "תינוק" ? "ז" : "נ",
            selected_shaban_id: shabanTypeCode,
            father_first_name: "",
            is_tc_selected: true, //disability insurance, always checked
            is_keren_selected: data.kerenMaccabi.value,
            shaban_start_date: calculatedTime,
        }
    };
    const webApiSuffix = format(process.env.WEB_API_URL_REGISTER_BABY,data.member_id_code,data.member_id);
    return rest.post(webApiName, webApiSuffix, options);
}
