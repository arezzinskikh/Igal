import mLib from '@maccabi/m-lib'
import format from 'string-format';

const {
    rest
} = mLib;

export function getCardCost(memberIdCode, memberId, memberIdCodeToOcrderCardFor, memberIdToOrderCardFor) {
    const options = {
        data: [{
            mem_code: memberIdCodeToOcrderCardFor,
            mem_id: memberIdToOrderCardFor
        }]
    };

    const webApiSuffix = format(
        process.env.WEB_API_URL_ORDERMAGNETICCARD_GETCARDCOST,
        memberIdCode,
        memberId
    );

    const webapiName = 'DIRECTORSHIP';

    return rest.post(webapiName, webApiSuffix, options);
}

export function finishOrder(memberIdCode, memberId, memberIdCodeToOrderCardFor, memberIdToOrderCardForm, issueReason) {
    const options = {
        data: [{
            mem_code: memberIdCodeToOrderCardFor,
            mem_id: memberIdToOrderCardForm,
            issue_reason: issueReason
        }]
    };

    const webApiSuffix = format(
        process.env.WEB_API_URL_ORDERMAGNETICCARD,
        memberIdCode,
        memberId
    );
    
    const webapiName = 'DIRECTORSHIP';

    return rest.post(webapiName, webApiSuffix, options);
}