/**
 * Combine all reducers in this file and export the combined reducers.
 */

import { combineReducers } from 'redux-immutable';
import { connectRouter } from 'connected-react-router/immutable';
import globalReducer from 'containers/AppInner/reducer';

/**
 * Merges the main reducer with the router state and dynamically injected reducers
 */
export default function createReducer(history, injectedReducers = {}) {
  return combineReducers({
    directorshipInnerGlobal: globalReducer,
    router: connectRouter(history),
    ...injectedReducers,
  });
}
