import React, { Component } from 'react';
import mLib from '@maccabi/m-lib';
import { fromJS } from 'immutable';
import { ConnectedRouter } from 'connected-react-router/immutable';
import { history } from '../storeSetup';
//TODO: import saga and reducers bace on inner

@mLib.appInfra.injectReducer({
    key: 'GlobalLoading',
    reducer: () => {
        return fromJS({ isGlobalLoading: false });
    }
})
class WithBaseSageAndReducers extends Component {
    render() {
        return this.props.children;
    }
}

export const withBaseSageAndReducers = InnerComponent => {
    return (
        <ConnectedRouter history={history}>
            <WithBaseSageAndReducers>{InnerComponent}</WithBaseSageAndReducers>
        </ConnectedRouter>
    );
};
