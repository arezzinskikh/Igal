const errorOrWarn = process.env.NODE_ENV === 'production' ? null : true;

module.exports = {
    extends: 'stylelint-config-recommended',
    ignoreFiles: ['.js'],
    rules: {
        'at-rule-no-unknown': null,
        'block-no-empty': errorOrWarn,
        'color-named': !errorOrWarn ? 'always-where-possible' : 'never',

        // "block-closing-brace-empty-line-before": null,
        // "block-closing-brace-newline-after": null,
        // "block-closing-brace-newline-before": null,
        // "block-closing-brace-space-before": null,
        // "block-opening-brace-newline-after": null,
        // "block-opening-brace-space-after": null,
        // "block-opening-brace-space-before": null,
        // "declaration-block-semicolon-newline-after": null,
        // "declaration-block-semicolon-space-after": null,
        // "declaration-block-semicolon-space-before": null,
        // "declaration-block-trailing-semicolon": null,

        'color-no-invalid-hex': null,
        'comment-no-empty': errorOrWarn,
        'declaration-block-no-duplicate-properties': [
            null, /////////////check
            {
                ignore: ['consecutive-duplicates-with-different-values']
            }
        ],
        //"no-tabs":  [errorOrWarn, { allowIndentationTabs: true }],
        'declaration-block-no-shorthand-property-overrides': errorOrWarn,
        'font-family-no-duplicate-names': errorOrWarn,
        'font-family-no-missing-generic-family-keyword': errorOrWarn,
        'function-calc-no-invalid': errorOrWarn,
        'function-calc-no-unspaced-operator': errorOrWarn,
        'function-linear-gradient-no-nonstandard-direction': errorOrWarn,
        'keyframe-declaration-no-important': errorOrWarn,
        'media-feature-name-no-unknown': null,
        'no-descending-specificity': null,
        'no-duplicate-at-import-rules': errorOrWarn,
        'no-duplicate-selectors': null,
        'no-empty-source': errorOrWarn,
        'no-extra-semicolons': errorOrWarn,
        'no-invalid-double-slash-comments': errorOrWarn,
        'property-no-unknown': errorOrWarn,
        'selector-pseudo-class-no-unknown': null,
        'selector-pseudo-element-no-unknown': null,
        'selector-type-no-unknown': null,
        'string-no-newline': errorOrWarn,
        'unit-no-unknown': errorOrWarn
    }
};
