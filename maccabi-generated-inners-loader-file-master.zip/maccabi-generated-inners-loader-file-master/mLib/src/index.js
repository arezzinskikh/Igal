// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';
// import App from './App';
// import * as serviceWorker from './serviceWorker';
//import 'babel-polyfill'; 
// import * as webpack from './utils/Webpack';

// ReactDOM.render(<App />, document.getElementById('root'));

// // If you want your app to work offline and load faster, you can change
// // unregister() to register() below. Note this comes with some pitfalls.
// // Learn more about service workers: https://bit.ly/CRA-PWA
// serviceWorker.unregister();

//ReactDOM.render(<App mDate={mDate}/>, document.getElementById('root'));

import customer from './utils/Customer';
import date from './utils/Date';
import getBase64 from './utils/GetBase64'
import juniper from './utils/Juniper';
import list from './utils/List';
import logs from './utils/Logs';
import rest from './utils/Rest';
import site from './utils/Site';
import url from './utils/Url';
import history from './utils/History';
import appInfra from './utils/AppInfra';
import cookie from './utils/Cookie';
import settings from './utils/Settings';
import saveData from './utils/SaveData';
import resources from './utils/Resources';
import openPdfNewTab from './utils/openPdfNewTab';
import routeLeavingGuard from './utils/RouteLeavingGuard';
import demographics from './utils/Demographics';
import * as featureToggles from './utils/FeatureToggles';

export default {
    customer,
    date,
    getBase64,
    juniper,
    list,
    logs,
    rest,
    site,
    url,
    history,
    appInfra,
    cookie,
    settings,
    saveData,
    resources,
    openPdfNewTab,
    routeLeavingGuard,
    demographics,
    featureToggles
};

