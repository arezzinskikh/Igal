import React from 'react';
import './App.css';

const App = props => {
    return (
        <div className="App">
            <div>
                <span>mDate.getDateFromUI </span>
                <span>{props.mDate.getDateFromUI(3)}</span>
            </div>
        </div>
    );
};

export default App;
