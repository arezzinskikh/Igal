import React from 'react';
import hoistNonReactStatics from 'hoist-non-react-statics';

const FeatureTogglesContext = React.createContext('featureTogglesContext');

export const withFeatureToggles = Component => {
    const WrappedComponent = props => (
        <FeatureTogglesContext.Consumer>
            {({ featureToggles }) => <Component {...props} featureToggles={featureToggles} />}
        </FeatureTogglesContext.Consumer>
    );
    WrappedComponent.getInitialProps = Component.getInitialProps;
    WrappedComponent.displayName = `withFeatureToggles(${Component.displayName || 'Component'})`;

    return hoistNonReactStatics(WrappedComponent, Component);
};

export const FeatureTogglesProvider = ({ featureToggles, children }) => (
    <FeatureTogglesContext.Provider value={{ featureToggles }}>{children}</FeatureTogglesContext.Provider>
);

FeatureTogglesProvider.propTypes = {
    featureToggles: PropTypes.object.isRequired,
    children: PropTypes.node.isRequired
};
