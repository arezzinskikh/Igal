// Warning: Please use `require("history").createBrowserHistory` instead of `require("history/createBrowserHistory")`.
// Support for the latter will be removed in the next major release.

import { createBrowserHistory } from 'history';
const history = createBrowserHistory();
export default history;
