import { post } from '../Rest/webApi'
import dateFormat from 'dateformat';
import format from 'string-format';
import { get as getCustomerData } from '../SaveData/customerData';
import juniper from '../Juniper/index'

const writeLog = (text, ip) => {
    if (process.env.IS_LOG === 'true') {
        const format = require('string-format');
        const date = dateFormat(new Date(), "dd/mm/yyyy HH:MM:ss");
        const log = format('{0} {1}. ip: {2}', date, text, ip);

        console.log(log);
    }
}

const insertCentralizedLog = (logElementId, logPage = null, logActionId = null, isUserAction = true, responseTime = 0, variables = null) => {
    const customerData = getCustomerData();

    if (logPage === null) {
        let path = window.location.pathname;

        logPage = juniper.cleanDanaInfo(path.replace(/^\/|\/$/g, ''));
    }

    if (customerData && customerData.current_customer_info) {
        const memberIdCode = customerData.current_customer_info.member_id_code;
        const memberId = customerData.current_customer_info.member_id;
        const data = {
            "log_element_id": logElementId,
            "log_action_id": logActionId,
            "log_page": logPage,
            "event_generator": isUserAction ? "ua" : "sr",
            "resolution": format("{0}X{1}", window.screen.width, window.screen.height),
            "variables": variables,
            "response_time": responseTime
        }

        let extendedOptions = {
            isErrorHandlingNeeded: false,
            data: data
        };
        const webApiSuffix = format(process.env.WEB_API_URL_INSERT_CENTRALIZED_LOG, memberIdCode, memberId);
        const webapiName = 'MAIN';

        return post(webapiName, webApiSuffix, extendedOptions);
    }
}

export default { writeLog, insertCentralizedLog };