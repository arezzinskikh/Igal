import * as route from '@maccabi/m-lib/src/utils/RouteLeavingGuard/routeLeavingGuard';

export default { route};