
let _setRouteLeavingGuard = () => {};

export function init (routeLeavingGuard){
    _setRouteLeavingGuard = routeLeavingGuard;
}

export function setRouteLeavingGuard (routeLeavingGuard){
   return _setRouteLeavingGuard(routeLeavingGuard);
}