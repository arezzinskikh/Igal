import customer from '../Customer';
import resources from '../Resources';
import saveData from '../SaveData';

const isKosher = () => {
    let kosher = false;

    if (isDevelopment() && process.env.IS_KOSHER === 'true') {
        kosher = true;
    } else {
        const settings = getSettings();

        kosher = settings && settings.is_kosher;
    }

    return kosher;
};

const isDevelopment = () => {
    const isDev = process.env.NODE_ENV === 'development';

    return isDev;
};

const isSupport = () => {
    let support = false;

    if (isDevelopment() && process.env.IS_SUPPORT === 'true') {
        support = true;
    } else {
        const settings = getSettings();

        support = settings && settings.is_support;
    }

    return support;
};

const getServerEnviromentAndName = () => {
    const settings = getSettings();
    const { enviroment, server_name } = settings;
    const serverEnviroment = enviroment !== 'Production' ? `${enviroment} - ${server_name}` : '';

    return serverEnviroment;
};

const getFullHebrewHeaderDate = () => {
    const settings = getSettings();
    const fullHebrewHeaderDate = settings ? settings.full_hebrew_header_date : '';

    return fullHebrewHeaderDate;
};

const getIdleTimeoutInSeconds = () => {
    const settings = getSettings();
    const idleTimeoutInSeconds = settings ? settings.idle_timeout_in_seconds : 360;

    return idleTimeoutInSeconds;
};

const getIdlePopupTimeoutInSeconds = () => {
    const settings = getSettings();
    const idlePopupTimeoutInSeconds = settings ? settings.idle_popup_timeout_in_seconds : 24;

    return idlePopupTimeoutInSeconds;
};

const getIdleKeepAliveTimeoutInSeconds = () => {
    const settings = getSettings();
    const idleKeepAliveTimeoutInSeconds = settings ? settings.idle_keep_alive_timeout_in_seconds : 6;

    return idleKeepAliveTimeoutInSeconds;
};

const getMenu = () => {
    let menu = {};
    const allSettings = getAllSetting();

    if (allSettings) {
        menu = allSettings.menu;
    }

    return menu;
};

const getFlattedMenuItems = () => {
    const flattedMenuItems = JSON.parse(sessionStorage.getItem('flattedMenuItems'));

    return flattedMenuItems;
};

const getSettings = () => {
    let settings = {};
    const allSettings = getAllSetting();

    if (allSettings) {
        settings = allSettings.settings;
    }

    return settings;
};

const getAllSetting = () => {
    const settings = JSON.parse(sessionStorage.getItem('settings'));

    return settings;
};

const getModuleTitle = (alias, key, defaultText) => {
    const customerData = saveData.customerData.get();
    const childTitle = customer.isParentAsChild() ? ` - עבור ${customerData.current_customer_info.f_name_hebrew}` : '';
    const moduletitle = `${resources.getResource(alias, key, defaultText)}${childTitle}`;

    return moduletitle;
};

export default {
    isKosher,
    isDevelopment,
    isSupport,
    getMenu,
    getFullHebrewHeaderDate,
    getModuleTitle,
    getFlattedMenuItems,
    getServerEnviromentAndName,
    getIdleTimeoutInSeconds,
    getIdlePopupTimeoutInSeconds,
    getIdleKeepAliveTimeoutInSeconds
};
