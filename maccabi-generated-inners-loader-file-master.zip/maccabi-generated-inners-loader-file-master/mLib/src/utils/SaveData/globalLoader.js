
let _setGlobalLoading = () => {};

export function init (setGlobalLoading){
    _setGlobalLoading = setGlobalLoading;

}

export function setGlobalLoading (isGlobalLoading){
   return _setGlobalLoading(isGlobalLoading);
    
}