export function setAll(customerData) {
    sessionStorage.setItem('customerData', JSON.stringify(customerData));
}

export function setCurrent(currentCustomerData) {
    let customerData = get();

    customerData.current_customer_info = currentCustomerData;
    sessionStorage.setItem('customerData', JSON.stringify(customerData));
}

export function get() {
    return JSON.parse(sessionStorage.getItem('customerData'));
}
