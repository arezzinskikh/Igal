
let _setGlobalErrorPopup = () => {};

export function init (setGlobalErrorPopup){
    _setGlobalErrorPopup = setGlobalErrorPopup;

}

export function setGlobalErrorPopup (isGlobalErrorPopup){
   return _setGlobalErrorPopup(isGlobalErrorPopup);
    
}