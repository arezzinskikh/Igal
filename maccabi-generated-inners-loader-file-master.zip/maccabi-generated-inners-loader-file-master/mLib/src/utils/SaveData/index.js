import * as globalLoader from './globalLoader';
import * as customerData from './customerData';
import * as globalErrorPopup from './globalErrorPopup';

export default { customerData, globalLoader, globalErrorPopup };