/**
 * COMMON WEBPACK CONFIGURATION
 */

const path = require('path');
const webpack = require('webpack');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

// Remove this line once the following warning goes away (it was meant for webpack loader authors not users):
// 'DeprecationWarning: loaderUtils.parseQuery() received a non-string value which can be problematic,
// see https://github.com/webpack/loader-utils/issues/56 parseQuery() will be replaced with getOptions()
// in the next major version of loader-utils.'
process.noDeprecation = true;

const defaultBabelQuery = {
    plugins: [
        ['@babel/plugin-proposal-decorators', { legacy: true }],
        '@babel/plugin-proposal-class-properties',
        'babel-plugin-transform-react-remove-prop-types',
        '@babel/transform-react-constant-elements',
        '@babel/proposal-optional-chaining'
    ],
    presets: [['@babel/preset-env', { modules: false, targets: 'defaults' }], '@babel/preset-react'],
    env: {
        production: {
            plugins: ['babel-plugin-transform-react-remove-prop-types', '@babel/transform-react-constant-elements']
        },
        test: {
            plugins: ['transform-es2015-modules-commonjs', 'dynamic-import-node']
        }
    }
};
const getCssLoaders = (options, isVendor) => [
    // Avoid FOUC on Prod by not loading CSS via JS. @see https://github.com/webpack-contrib/style-loader/issues/269#issuecomment-396725856
    options.mode === 'production' ? MiniCssExtractPlugin.loader : 'style-loader',
    {
        loader: 'css-loader',
        options: {
            modules: !isVendor,
            camelCase: true,
            sourceMap: false,
            localIdentName: options.mode === 'production' ? '[name]__[local]--[hash:base64:15]' : '[path][name]__[local]--[hash:base64:15]'
        }
    },
    {
        loader: 'postcss-loader'
    },
    {
        loader: 'sass-loader'
    }
];

const rules = options => [
    {
        test: /\.js$/, // Transform all .js files required somewhere with Babel
        exclude: function excludeBabelLoader(modulePath) {
            const isMui = modulePath.indexOf('m-ui') > -1;
            const isMlib = modulePath.indexOf('m-lib') > -1;
            const isMsc = modulePath.indexOf('m-sc') > -1;
            const isInsideSrc = modulePath.indexOf('src') > -1;
            const isInsideMain = modulePath.indexOf('app') > -1;
            const isTranspile = isInsideMain || ((isMui || isMlib || isMsc) && isInsideSrc);
            return !isTranspile;
        },
        include: [
            path.join(process.cwd(), 'app'),
            path.join(process.cwd(), 'node_modules', '@maccabi', 'm-ui'),
            path.join(process.cwd(), 'node_modules', '@maccabi', 'm-lib'),
            path.join(process.cwd(), 'node_modules', '@maccabi', 'm-sc', 'app'),
            path.join(process.cwd(), 'node_modules', '@maccabi', 'm-sc', 'node_modules', '@maccabi', 'm-ui'),
            path.join(process.cwd(), 'node_modules', '@maccabi', 'm-sc', 'node_modules', '@maccabi', 'm-lib')
        ],
        use: {
            loader: 'babel-loader',
            options: options.babelQuery || defaultBabelQuery
        }
    },
    {
        enforce: 'pre',
        test: /\.js$/,
        exclude: /node_modules/,
        loader: 'eslint-loader'
    },
    {
        // Preprocess All .scss files (app and dependencies)
        test: /\.(scss|css)$/,
        //  include: [path.join(process.cwd(), 'app'), path.join(process.cwd(), 'node_modules')],
        exclude: path.join(process.cwd(), 'app', 'styles'),
        use: getCssLoaders(options, false)
    },
    {
        // Preprocess our own SASS .scss files
        test: /\.(scss|css)$/,
        // include: path.join(process.cwd(), 'app', 'styles'),
        include: /app(\\|\/)styles/,
        use: getCssLoaders(options, true)
    },
    {
        test: /\.(eot|otf|ttf|woff|woff2)$/,
        use: 'file-loader'
    },
    {
        test: /\.(jpg|png|gif|svg)$/,
        use: [
            {
                loader: 'url-loader',
                options: {
                    // Inline files smaller than 10 kB
                    limit: 200 * 1024
                }
            }
        ]
    },
    {
        test: /\.html$/,
        use: 'html-loader',
        exclude: /index\.html$/
    },
    {
        test: /\.(mp4|webm)$/,
        use: {
            loader: 'url-loader',
            options: {
                limit: 10000
            }
        }
    }
];

const resolve = {
    modules: ['node_modules', 'app'],
    extensions: ['.js', '.jsx', '.react.js', '.scss', '.json'],
    mainFields: ['browser', 'jsnext:main', 'main']
};

const node = {
    fs: 'empty',
    module: 'empty',
    net: 'empty',
    child_process: 'empty'
};

module.exports = (options, buildId = 'defaultBuildId') => {
    const webpackBaseBabel = {
        mode: options.mode,
        entry: options.entry,
        output: Object.assign(
            {
                // Compile into js/build.js
                path: path.resolve(process.cwd(), 'build'),
                publicPath: '/'
            },
            options.output
        ), // Merge with env dependent settings
        optimization: options.optimization,
        module: options.module ? { rules: typeof options.rules === 'function' ? options.rules(rules) : rules(options) } : { rules: rules(options) },
        plugins: options.plugins.concat([
            new webpack.ProvidePlugin({
                fetch: 'exports-loader?self.fetch!whatwg-fetch',
                $: 'jquery',
                'window.$': 'jquery',
                jQuery: 'jquery',
                'window.jQuery': 'jquery',
                moment: ['moment', 'default'],
                'window.moment': ['moment', 'default']
            }),

            // Always expose NODE_ENV to webpack, in order to use `process.env.NODE_ENV`
            // inside your code for any environment checks; UglifyJS will automatically
            // drop any unreachable code.
            new webpack.DefinePlugin({
                'process.env': {
                    NODE_ENV: JSON.stringify(process.env.NODE_ENV),
                    APP_ENV: JSON.stringify(process.env.APP_ENV),
                    APP_BASE: JSON.stringify(process.env.APP_BASE),
                    API_BASE: JSON.stringify(process.env.API_BASE)
                }
            }),
            new MiniCssExtractPlugin({
                // Options similar to the same options in webpackOptions.output
                // both options are optional
                filename: `[name].${buildId}.css`,
                chunkFilename: `[id].${buildId}.css`
            }),
            new webpack.ContextReplacementPlugin(/moment[/\\]dist[/\\]locale$/, /he/)
        ]),
        resolve: typeof options.resolve === 'function' ? options.resolve(resolve) : resolve,
        devtool: options.devtool,
        target: options.target || 'web', // Make web variables accessible to webpack, e.g. window
        performance: options.performance || {},
        node: typeof options.node === 'function' ? options.node(node) : node,
        externals: {
            react: 'React',
            'react-dom': 'ReactDOM'
        }
    };

    return webpackBaseBabel;
};
