// Important modules this config uses
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { HashedModuleIdsPlugin } = require('webpack');

const buildId = uuidv4();

const plugins = (options = {}) => [
    // Minify and optimize the index.html
    new HtmlWebpackPlugin(Object.assign({
        template: 'app/index.html',
        minify: {
            removeComments: true,
            collapseWhitespace: true,
            removeRedundantAttributes: true,
            useShortDoctype: true,
            removeEmptyAttributes: true,
            removeStyleLinkTypeAttributes: true,
            keepClosingSlash: true,
            minifyJS: true,
            minifyCSS: true,
            minifyURLs: true
        },
        inject: true,
    }, options.HtmlWebpackPluginOptions)),
    new HashedModuleIdsPlugin({
        hashFunction: 'sha256',
        hashDigest: 'hex',
        hashDigestLength: 20
    })
];
const optimization = {
    minimize: true,
    nodeEnv: 'production',
    sideEffects: true,
    concatenateModules: true,
    splitChunks: { chunks: 'all' },
    runtimeChunk: 'single'
};
const output = {
    filename: `[name].${buildId}.js`,
    chunkFilename: `[name].${buildId}.js`,
    publicPath: '/' // cdn here
};
const performance = {
    assetFilter: assetFilename => !/(\.map$)|(^(main\.|favicon\.))/.test(assetFilename)
};
const entry = ['idempotent-babel-polyfill', path.join(process.cwd(), 'app/app.js')];

module.exports = options => {
    const webpackBaseProdBabel = require('./webpack.base.babel')(
        {
            mode: options.mode || 'production',
            // In production, we skip all hot-reloading stuff
            entry: typeof options.entry === 'function' ? options.entry(entry) : entry,
            // Utilize long-term caching by adding content hashes (not compilation hashes) to compiled assets
            output: typeof options.output === 'function' ? options.output(output) : output,
            optimization: typeof options.optimization === 'function' ? options.optimization(optimization) : optimization,
            plugins: typeof options.plugins !== 'undefined' ? plugins(options).concat(options.plugins) : plugins(options),
            performance: typeof options.performance === 'function' ? options.performance(performance) : performance,
            module: options.module,
            resolve: options.resolve,
            target: options.target,
            node: options.node
        },
        buildId
    );

    return webpackBaseProdBabel;
};
