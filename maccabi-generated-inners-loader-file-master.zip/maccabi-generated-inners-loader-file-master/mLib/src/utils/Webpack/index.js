const webpackBaseDev = require('./webpack.base.dev.babel');
const webpackBaseDll = require('./webpack.base.dll.babel');
const webpackBaseProd = require('./webpack.base.prod.babel');


module.exports = { webpackBaseDev, webpackBaseDll, webpackBaseProd };