/**
 * WEBPACK DLL GENERATOR
 *
 * This profile is used to cache webpack's module
 * contexts for external library and framework type
 * dependencies which will usually not change often enough
 * to warrant building them from scratch every time we use
 * the webpack process.
 */

const { join } = require('path');
const defaults = require('lodash/defaultsDeep');
const webpack = require('webpack');
const pkg = require(join(process.cwd(), 'package.json'));
const { dllPlugin } = require('./config');

if (!pkg.dllPlugin) {
    process.exit(0);
}

const dllConfig = defaults(pkg.dllPlugin, dllPlugin.defaults);
const outputPath = join(process.cwd(), dllConfig.path);
const plugins = () => [
    new webpack.DllPlugin({
        name: '[name]',
        path: join(outputPath, '[name].json')
    })
];
const optimization = {
    minimize: false
};
const output = {
    filename: '[name].dll.js',
    path: outputPath,
    library: '[name]'
};
const performance = {
    hints: false
};

const entry = () => {
    return dllConfig.dlls ? dllConfig.dlls : dllPlugin.entry(pkg);
};

module.exports = options => {
    const webpackBaseDllBabel = require('./webpack.base.babel')({
        mode: options.mode || 'development',
        context: process.cwd(),
        entry: typeof options.entry === 'function' ? options.entry(entry) : entry(options),
        optimization: typeof options.optimization === 'function' ? options.optimization(optimization) : optimization,
        devtool: options.devtool || 'eval',
        output: typeof options.output === 'function' ? options.output(output) : output,
        plugins: typeof options.plugins !== 'undefined' ? plugins(options).concat(options.plugins) : plugins(options),
        performance: typeof options.performance === 'function' ? options.performance(performance) : performance,
        module: options.module,
        resolve: options.resolve,
        target: options.target,
        node: options.node
    });

    return webpackBaseDllBabel;
};
