const APP_BASE = process.env.APP_BASE;
const nl = '\n';

Object.defineProperty(Array.prototype, 'flat', {
  value: function(depth = 1) {
    return this.reduce(function (flat, toFlatten) {
      return flat.concat((Array.isArray(toFlatten) && (depth>1)) ? toFlatten.flat(depth-1) : toFlatten);
    }, []);
  }
});

const write = (...code) => code.join(nl).split(nl).map(line => `document.write('${line}');`).join(nl);

const loadAsset = {
  js: path => `<script src="${path}" />`,
  css: path => `<link rel="stylesheet" href="${path}"/>`
};

const withoutLeadingSlash = (url = '') => url.replace(/^\/+/, '');

const toPath = (publicPath, asset) => [APP_BASE, publicPath, asset].map(withoutLeadingSlash).join('');

module.exports = ({ htmlWebpackPlugin }) => {
  const { publicPath, js, css } = htmlWebpackPlugin.files;
  const assetsCode =
    Object.entries({ js, css }).map(([type, assets]) =>
      assets.map(asset =>
          loadAsset[type](toPath(publicPath, asset))
      )
    )
    .flat()
    .join(nl);

  return write(assetsCode);
};
