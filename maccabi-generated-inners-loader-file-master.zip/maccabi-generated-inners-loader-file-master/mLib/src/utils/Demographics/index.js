import { get } from '../Rest/webApi';
import format from 'string-format';

const getCities = (filter = '', limit = 10, offset = 0) => {
    const webApiSuffix = format(process.env.WEB_API_URL_GET_CITIES, filter, limit, offset);
    const webapiName = 'MAIN';
    const extendedOptions = {
        isErrorHandlingNeeded: false,
    };

    return get(webapiName, webApiSuffix, extendedOptions);
};

const getCityStreets = (cityId, filter = '', limit = 10, offset = 0) => {
    const webApiSuffix = format(process.env.WEB_API_URL_GET_CITY_STREETS, cityId, filter, limit, offset);
    const webapiName = 'MAIN';
    const extendedOptions = {
        isErrorHandlingNeeded: false,
    };

    return get(webapiName, webApiSuffix, extendedOptions);
};

export default { getCities, getCityStreets };
