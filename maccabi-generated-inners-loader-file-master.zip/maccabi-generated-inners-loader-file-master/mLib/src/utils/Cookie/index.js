import Cookies from 'universal-cookie';

const set = (name, value, expiresInMinutes, options = {}) => {
    const now = new Date();
    const expires = new Date(now.setMinutes(now.getMinutes() + expiresInMinutes));
    const cookies = new Cookies();

    options = {expires: expires,...options};
    cookies.set(name, value, options);
};

const get = (name) => {
    const cookies = new Cookies();
    const cookieValue = cookies.get(name);

    return cookieValue;
};

const remove = (name) => {
    const cookies = new Cookies();

    cookies.remove(name);
};

export default { set, get, remove };