const removeMimeTile = (base64File) => {
    return base64File.replace(/^data:.*;base64,/, '');
}

const getBase64 = file => {
    return new Promise((resolve, reject) => {
        let reader = new FileReader();

        reader.onload = async function () {
            let b64 = removeMimeTile(reader.result);
            resolve({ fileData: file, base64: b64 });
        };

        reader.onerror = function (error) {
            reject(error);
        };
        reader.readAsDataURL(file);
    });
};

export default { getBase64 };
