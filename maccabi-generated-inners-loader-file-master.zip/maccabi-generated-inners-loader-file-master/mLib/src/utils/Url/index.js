import queryString from 'query-string';
import juniper from '../Juniper/index';
import saveData from '../SaveData';
import site from '../Site';
import cookie from '../Cookie';

const getQueryString = () => {
    let params = {};
    window.location.search.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(_, key, value) {
        params[key] = value;
    });

    return params;
};

const formatUrlWithCurrentDomain = (urlPattern, currentDomain, args = []) => {
    let formattedUrl = '';
    const format = require('string-format');

    args.splice(0, 0, currentDomain);
    formattedUrl = format(urlPattern, ...args);

    return formattedUrl;
};

const getCurrentUrl = () => {
    let currentUrl = '';
    if (typeof window === 'undefined') {
        currentUrl = global.currentUrl; // without domain
    } else {
        currentUrl = window.location.href;
    }

    return currentUrl;
};

const getUrl = (currentUrl, url) => {
    const currentUrlNoDanaInfo = juniper.cleanDanaInfo(url);

    if (!currentUrlNoDanaInfo) return '';

    //patch if code for dananinfo not correct
    let querystringParams = {};

    if (url.indexOf('?') > 0) {
        querystringParams = queryString.parse(currentUrlNoDanaInfo.split('?')[1]);
    }

    if (currentUrl === '') {
        if (typeof window === 'undefined') {
            currentUrl = global.currentUrl; // without domain
        } else {
            currentUrl = window.location.href;
        }
    }

    let currentPageQuerystringParams = {};

    if (global.currentQuery) {
        currentPageQuerystringParams = global.currentQuery;
    } else {
        if (window.location.href.indexOf('?') > 0) {
            currentPageQuerystringParams = queryString.parse(window.location.href.split('?')[1]);
        }
    }

    let newQuerystringParams = {};

    if (currentPageQuerystringParams.memCode) {
        newQuerystringParams.memCode = currentPageQuerystringParams.memCode;
    }
    if (currentPageQuerystringParams.memId) {
        newQuerystringParams.memId = currentPageQuerystringParams.memId;
    }

    let querystringParamsStr = queryString.stringify(querystringParams);
    let newQuerystringParamsStr = queryString.stringify(newQuerystringParams);

    if (querystringParamsStr !== '') {
        querystringParamsStr = '?' + querystringParamsStr;

        if (newQuerystringParamsStr !== '') {
            querystringParamsStr += '&' + newQuerystringParamsStr;
        }
    } else {
        if (newQuerystringParamsStr !== '') {
            querystringParamsStr = '?' + newQuerystringParamsStr;
        }
    }

    let newUrlNoParams = currentUrlNoDanaInfo.split('?')[0];
    const newUrl = newUrlNoParams + juniper.getDanaInfo(currentUrl) + querystringParamsStr;

    return newUrl;
};

const buildRelativeQueryString = () => {
    const format = require('string-format');
    const customerData = saveData.customerData.get();
    const cookieSessionIdKey = format(
        'cookie_sessionId_{0}_{1}',
        customerData.logged_customer_info.member_id_code,
        customerData.logged_customer_info.member_id
    );

    let relativeQueryString = '';
    if (customerData.current_customer_info.member_id === customerData.logged_customer_info.member_id) {
        relativeQueryString = format('?relative=-1&sr_id={0}', cookie.get(cookieSessionIdKey));
    } else {
        relativeQueryString = format('?relative={0}&sr_id={1}',
            customerData.current_customer_info.checksum_id, cookie.get(cookieSessionIdKey));
    }

    return relativeQueryString;
};

const getUrlByVersion = (version, link, hash, queryParam) => {
    if (version <= 1)
        //external links
        return link;

    const isKosher = site.isKosher();
    const isSupport = site.isSupport();
    const format = require('string-format');

    let domainUrlName = `SITE_DOMAIN_VERSION${version}`;
    if (isSupport) domainUrlName = `SITE_DOMAIN_VERSION${version}_SUPPORT`;

    if (isKosher) domainUrlName = `SITE_DOMAIN_VERSION${version}_KOSHER`;

    let domainUrl = process.env[domainUrlName];

    return format(domainUrl, link) + (hash ? hash : '') + buildRelativeQueryString() + (queryParam ? '&' + queryParam : '');
};

const objectToQueryString = (paramsObj) => Object.keys(paramsObj)
    .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(paramsObj[key])}`)
    .join('&');

export default {
    getQueryString,
    formatUrlWithCurrentDomain,
    getCurrentUrl,
    getUrl,
    getUrlByVersion,
    objectToQueryString
};
