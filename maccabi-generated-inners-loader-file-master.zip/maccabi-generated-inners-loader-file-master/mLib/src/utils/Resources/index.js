import { get } from '../Rest/webApi';
import queryStringHelper from '../Url';

const getImage = (alias, key) => {
    const resource = getResource(alias, key, null);
    const mediaDomain = process.env.MEDIA_DOMAIN || '';
    const imageResource = resource && mediaDomain + resource;

    return imageResource;
};

const getResource = (alias, key, defaultText) => {
    let resources = getResources();
    let resource = null;

    if (resources !== null) {
        //get by alias
        resource = getResourceByAlias(resources, alias, key);

        if (!resource)
            //get by global alias
            resource = getResourceByAlias(resources, 'Global', key);

        if (!resource) resource = defaultText;
        const quertString = queryStringHelper.getQueryString();
        
        if (quertString.showKeys) {
            resource = `${resource}|${key}`;
        }
    } else {
        resource = defaultText;
    }

    return resource;
};

const setResources = response => {
    //localStorage.setItem('resource', response);
    localStorage.setItem('resource', JSON.stringify(response)); //TODO
};

const getResources = () => {
    return JSON.parse(localStorage.getItem('resource'));
};

const getResourceByAlias = (resources, alias, key) => {
    let byAlias = resources.filter(res => res.alias.toLowerCase() == alias.toLowerCase());
    let resource = byAlias.length > 0 ? byAlias.filter(res => res.key === key) : null;
    if (resource && resource.length > 0) return resource[0].value;
};

const loadResources = () => {
    return new Promise((resolve, reject) => {
        let extendedOptions = {
            isErrorHandlingNeeded: true,
        };
        const webApiSuffix = process.env.WEB_API_URL_CONTENT_RESOURCES;
        const webapiName = 'MAIN';

        return get(webapiName, webApiSuffix, extendedOptions)
            .then(response => {
                setResources(response);
                resolve(response);
            })
            .catch(error => {
                console.log('getResources', error);

                reject(error);
            });
    });
};

export default { loadResources, getResource, getResources, getImage };