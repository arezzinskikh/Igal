const getDanaInfo = (url) => {
    let danaInfoString = '';
    
    if (url !== undefined && url.indexOf(',DanaInfo=') > 0) {
        let danaInfoStart = url.indexOf(',DanaInfo=');
        let danaInfoEnd = url.indexOf('?');
        
        if (danaInfoEnd < 0) {
            danaInfoEnd = url.length;
        }

        danaInfoString = url.substring(danaInfoStart, danaInfoEnd);
    }

    return danaInfoString;
};

const cleanDanaInfo = (url) => {
    const cleaned = url.replace(getDanaInfo(url) + '+', '').replace(getDanaInfo(url), '');

    return cleaned;
};

export default {getDanaInfo, cleanDanaInfo};