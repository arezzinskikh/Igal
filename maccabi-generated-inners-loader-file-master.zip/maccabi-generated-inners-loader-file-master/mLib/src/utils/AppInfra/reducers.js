import { combineReducers } from 'redux-immutable';
import { connectRouter } from 'connected-react-router/immutable';

/**
 * Merges the main reducer with the router state and dynamically injected reducers
 */
export default function createReducer(history, injectedReducers = {}) {
  return combineReducers({
    router: connectRouter(history),
     ...injectedReducers
   });
}
