import injectReducer from './injectReducer';
import injectSaga from './injectSaga';
import reducers from './reducers';

export default { injectReducer, injectSaga, reducers };