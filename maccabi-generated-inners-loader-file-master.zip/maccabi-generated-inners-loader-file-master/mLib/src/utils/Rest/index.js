import { get, post, patch, remove, put } from './webApi';

export default { get, post, patch, remove, put };