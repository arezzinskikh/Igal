import merge from 'lodash/merge';
import axios from 'axios';
import juniper from '../Juniper';
import logs from '../Logs';
import { API_NAMES } from './constants';

export const get = (webapiName, webApiSuffix, extendedOptions) => {
    return call(webapiName, webApiSuffix, 'GET', extendedOptions);
};

export const post = (webapiName, webApiSuffix, extendedOptions) => {
    return call(webapiName, webApiSuffix, 'POST', extendedOptions);
};

export const patch = (webapiName, webApiSuffix, extendedOptions) => {
    return call(webapiName, webApiSuffix, 'PATCH', extendedOptions);
};

export const put = (webapiName, webApiSuffix, extendedOptions) => {
    return call(webapiName, webApiSuffix, 'PUT', extendedOptions);
};

//Impossible to give name "delete" to function because delete is operator
export const remove = (webapiName, webApiSuffix, extendedOptions) => {
    return call(webapiName, webApiSuffix, 'DELETE', extendedOptions);
};

const call = (webapiName, webApiSuffix, method, extendedOptions) => {
    return new Promise((resolve, reject) => {
        const currentUrl = window.location.href;
        const danainfo = juniper.getDanaInfo(currentUrl);
        const url = getWebapiUrl(webapiName) + webApiSuffix + danainfo;
        const initalHttpData = {
            method: method, // By default it's POST in case you didnt specify anything
            timeout: 30000
        };
        let options = merge(initalHttpData, extendedOptions);

        // Fire the request for the prepared options.
        return axios(url, options)
            .then(response => {
                resolve(response.data);
            })
            .catch(error => {
                logs.writeLog(`callApi failed - url: ${url}`);

                if (extendedOptions && extendedOptions.isErrorHandlingNeeded) {
                    errorHandler(error);
                }

                reject(error);
            });
    });
};

const getWebapiUrl = name => {
    if (!API_NAMES.includes(name)) {
        throw `API name is unknown - ${name}`;
    }

    const webApiUrlName = `WEB_API_URL_${name}`;
    const webApiUrl = process.env[webApiUrlName];

    if (!webApiUrl) {
        throw `API url vairable is not defined - ${webApiUrlName}`;
    }

    return webApiUrl;
};

const errorHandler = error => {
    const errorCode = (error.response && error.response.status) || 500;
    const errorPath = '/error';

    if (!window.location.pathname.startsWith(errorPath)) {
        window.location.href = `${errorPath}/${errorCode}`;
    }

    //    return Promise.reject(error);
};

const doBeforeRequest = ref => {
    ref.headers.common['Authorization'] = `Bearer ${sessionStorage.getItem('token')}`;
    ref.headers.common['Content-Type'] = 'application/json';

    ref.withCredentials = true;
    //axios.defaults.headers.common['Authorization'] = 'Bearer ' + response.token.content;
    //axios.interceptors.response.use(undefined, errorHandler);
    //axios.interceptors.response.use(responseToCamelCase, undefined);
    //axios.defaults.params = axios.defaults.params || {};
    return ref;
};

axios.interceptors.request.use(doBeforeRequest, undefined);
