// //import camelCaseKeys from 'camelcase-keys';
// const camelCaseKeys = require('camelcase-keys');

// export const responseToCamelCase = res => {
//     res.data = camelCaseKeys(res.data, { deep: true });

//     return res;
// };