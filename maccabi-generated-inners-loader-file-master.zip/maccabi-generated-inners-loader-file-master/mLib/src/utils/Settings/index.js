import { get } from '../Rest/webApi';
import format from 'string-format';

const setSettings = (response) => {
    let flattedMenuItems = response && response.menu && response.menu.menu_items ?
        response.menu.menu_items
            .map(item => [item, ...(item.sub_menu_items || [])])
            .reduce((acc, val) => acc.concat(val), []) :
        [];

    flattedMenuItems = flattedMenuItems ?
        flattedMenuItems
            .map(item => [item, ...(item.sub_menu_items || [])])
            .reduce((acc, val) => acc.concat(val), []) :
        [];
    sessionStorage.setItem('flattedMenuItems', JSON.stringify(flattedMenuItems));
    sessionStorage.setItem('settings', JSON.stringify(response));
};

const accessSettings = () => ({
    flattedMenuItems: JSON.parse(sessionStorage.getItem('flattedMenuItems') || '{}'),
    settings: JSON.parse(sessionStorage.getItem('settings') || '{}')
});

const getSettings = () => {
    return new Promise((resolve, reject) => {
        let extendedOptions = {
            isErrorHandlingNeeded: true
        };
        const currentDate = new Date().toISOString();
        const webApiSuffix = format(process.env.WEB_API_URL_SITE_SETTINGS, currentDate);
        const webapiName = 'MAIN';

        return get(webapiName, webApiSuffix, extendedOptions)
            .then((response) => {
                setSettings(response);
                resolve(response);
            })
            .catch((error) => {
                console.log('getSettings', error);

                reject(error);
            });
    });
};

export default { getSettings, accessSettings };