import moment from 'moment';

const getDateFromUI = monthsToAdd => {
    const date = moment()
        .add(-1, 'day')
        .add(monthsToAdd, 'month')
        .format('DD/MM/YYYY');

    return date;
};

const getDateToUI = () => {
    const date = moment().format('DD/MM/YYYY');

    return date;
};

const getDateFromServer = monthsToAdd => {
    const date = moment()
        .add(-1, 'day')
        .add(monthsToAdd, 'month')
        .format('YYYY/MM/DD');

    return date;
};

const getDateToServer = () => {
    const date = moment().format('YYYY/MM/DD');

    return date;
};

const formatHour = date => {
    const momentDate = moment(date);
    const formatedHour = momentDate.format('HH:mm');

    return formatedHour;
};

const formatDate = date => {
    const momentDate = moment(date);
    const formatedDate = momentDate.format('DD/MM/YY');

    return formatedDate;
};

const setDateForService = month => {
    //yyyy-MM-dd
    const today = new Date();
    today.setMonth(today.getMonth() - month);
    return today.toISOString().slice(0, -14);
};

const isTimeBetween = (timeString, fromTimeString, toTimeString, format = 'HH:mm:ss') => {
    const time = moment(timeString, format);
    let fromTime = moment(fromTimeString, format);
    let toTime = moment(toTimeString, format);

    if (fromTime.isAfter(toTime)) {
        if (fromTime.isAfter(time)) {
            fromTime = fromTime.add(-1, 'day');
        } else if (toTime.isBefore(time)) {
            toTime = toTime.add(1, 'day');
        }
    }

    const isBetween = time.isBetween(fromTime, toTime);

    return isBetween;
};

const isDateBetween = (date, fromDatetring, toDateString, format = 'dd/mm/yy') => {
    let fromDate = moment(fromDatetring, format);
    let toDate = moment(toDateString, format);

    if (fromDate.isAfter(toDate)) {
        if (fromDate.isAfter(date)) {
            fromDate = fromDate.add(-1, 'day');
        } else if (toDate.isBefore(date)) {
            toDate = toDate.add(1, 'day');
        }
    }

    const isBetween = date.isBetween(fromDate, toDate);

    return isBetween;
};

const yearsFilter = (count, isAllYears = true) => {
    //const str = count + ' שנים אחרונות';
    const str = 'כל השנים';
    let years = [];
    isAllYears ? years.push(str) : null;
    for (let i = 0; i < count; i++) {
        years.push(
            moment()
                .subtract(i, 'years')
                .format('YYYY')
        );
    }
    return years;
};

export default {
    getDateFromUI,
    getDateToUI,
    setDateForService,
    getDateFromServer,
    getDateToServer,
    formatHour,
    formatDate,
    isTimeBetween,
    isDateBetween,
    yearsFilter
};
