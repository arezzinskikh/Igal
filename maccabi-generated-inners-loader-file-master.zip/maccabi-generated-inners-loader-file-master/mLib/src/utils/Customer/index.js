import format from 'string-format';
import { get } from '../Rest/webApi';
import site from '../Site';
import merge from 'lodash/merge';
import saveData from '../SaveData';

const isParentAsChild = () => {
    let parentAsChild = true;
    const customerData = saveData.customerData.get();

    if (
        customerData &&
        customerData.current_customer_info &&
        customerData.logged_customer_info &&
        customerData.current_customer_info.member_id === customerData.logged_customer_info.member_id &&
        customerData.current_customer_info.member_id_code === customerData.logged_customer_info.member_id_code
    ) {
        parentAsChild = false;
    }

    return parentAsChild;
};

const getCurrentInsurance = () => {
    let currentInsurance = '';
    const customerData = saveData.customerData.get();
    const relevantInsurances = ['02', '03', '07'];
    const insurances =
        customerData &&
        customerData.current_customer_info &&
        customerData.current_customer_info.insurances_groups &&
        customerData.current_customer_info.insurances_groups.filter(
            insurance => insurance.ins_status === 1 && relevantInsurances.includes(insurance.ins_type_code)
        );

    if (insurances) {
        if (insurances.find(insurance => insurance.ins_type_code === '07')) {
            currentInsurance = 'מכבי שלי';
        } else if (insurances.find(insurance => insurance.ins_type_code === '02')) {
            currentInsurance = 'מכבי זהב';
        } else if (insurances.find(insurance => insurance.ins_type_code === '03')) {
            currentInsurance = 'מכבי כסף';
        }
    }

    return currentInsurance;
};

const setToken = response => {
    sessionStorage.setItem('token', response && response.token && response.token.content);
};

const getCustomerData = (relative, session) => {
    return new Promise((resolve, reject) => {
        let extendedOptions = {
            isErrorHandlingNeeded: true
        };
        let initalHttpData = {};
        let options = {};
        const webApiSuffix = format(process.env.WEB_API_URL_CUSTOMER_DATA, relative, session);
        const webapiName = 'TOKEN_SERVER';

        if (site.isDevelopment()) {
            const memberId = process.env.DEV_MEMBER_ID;
            const memberIdCode = process.env.DEV_MEMBER_ID_CODE;
            const juniperUser = 'user-' + memberIdCode + '-' + memberId;

            initalHttpData = {
                headers: {
                    'Content-Type': 'application/json',
                    user: juniperUser
                }
            };
        } else {
            initalHttpData = {
                headers: { 'Content-Type': 'application/json' }
            };
        }

        options = merge(initalHttpData, extendedOptions);

        return get(webapiName, webApiSuffix, options)
            .then(response => {
                saveData.customerData.setAll(response);
                setToken(response);
                resolve(response);
            })
            .catch(error => {
                console.log('getCustomerAndFamily', error);
                const errorCode = (error.response && error.response.status) || 500;
                const errorPath = '/error';

                if (!window.location.pathname.startsWith(errorPath)) {
                    window.location.href = `${errorPath}/${errorCode}`;
                }
                reject(error);
            });
    });
};

const getCustomerColor = () => {
    const customerData = saveData.customerData.get();
    return customerData.family_data.family_members.findIndex(({ member_id }) =>
    member_id === customerData.current_customer_info.member_id) || 0 ;
}

export default { isParentAsChild, getCustomerData, getCurrentInsurance, getCustomerColor };
