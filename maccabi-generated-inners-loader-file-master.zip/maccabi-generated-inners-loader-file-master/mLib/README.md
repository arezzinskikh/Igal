# m-lib

mLib is a library for Maccabi Online applications by providing a common functions and logic.

## Quick Overview

```
npm install m-lib
```

These instructions will get you a copy of the project up and running on your local machine for development and production purposes.

## env. files settings

The following settings need to be declare in env. files in each app:
```
process.env.NODE_ENV
process.env.IS_LOG
process.env.OLD_SITE_KOSHER_DOMAIN
process.env.OLD_SITE_DOMAIN
process.env.PRIMARY_REACT_KOSHER_DOMAIN
process.env.PRIMARY_REACT_DOMAIN
```

e.g.
```
NODE_ENV=development
IS_LOG=false
```

The following settins need to be decalre in env. files with reference to the specific app:
process.env.WEB_API_URL_ + app name

```
WEB_API_URL_COMMUNICATION_WITH_DOCTOR=/CommunicationWithDoctor.Api/webapi/mac/v1/
WEB_API_URL_MAIN_APP=/MainApp.Api/webapi/mac/v1/
WEB_API_URL_DIRECTORSHIP_APP=/Directorship.Api/webapi/mac/v1/
WEB_API_URL_MEDICAL_FILE=/MedicalFile.Api/webapi/mac/v1/
WEB_API_URL_TOKEN=/TokenServerAPI/webapi/mac/v1/token
WEB_API_URL_REQUESTS_AND_APPROVALS=/RequestsAndApprovals.Api/webapi/mac/v1/
```

## Installing

### npm

```
npm install m-lib
```

End with an example of getting some data out of the system or using it for a little demo

## User Guide

### `npm start`

Runs the app in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br>
You will also see any lint errors in the console.

### Import & Using

```
import mLib from 'm-lib';

mLib.utilName.example1();
mLib.utilName.example2();

```

or


```
import mLib, { utilName } from 'm-lib';

mLib.UtilName.example1();
utilName.example1();
utilName.example2();

```


## What’s Included?

### AppInfra
1. injectReducer
2. injectSaga
3. reducers

### Customer
1. getParamsForCustomer

### Date
1. getDateFromUI
2. getDateToUI
3. getDateFromServer
4. getDateToServer

### History
1. createHistory

### Juniper
1. getDanaInfo
2. cleanDanaInfo

### List
1. sortBy
2. sortFunc

### Logs
1. writeLog

### Rest
1. webApi - get, post

### Site
1. isKosher - **TODO**
2. isDevelopment

### Token
1. getToken

### Url
1. formatOldSiteUrlWithCurrentDomain
2. formatPrimaryReactSiteUrlWithCurrentDomain
3. formatUrlWithCurrentDomain
4. getCurrentUrl
5. getImagesUrl
6. getUrl
7. buildRelativeQueryString

### Webpack